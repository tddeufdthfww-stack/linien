from pathlib import Path
import ast,hashlib,json,re,subprocess
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261110-r34-gpio-status-pipeline')
t=r/'gateware/build/trials/20261110_225335_r34_gpio_status_pipeline'
def oldfile(rel):return subprocess.check_output(['git','show','9c5c32a:'+rel],cwd=r).decode().replace('\r\n','\n')
unchanged=('gateware/logic/pid.py','gateware/logic/pid_pipeline.py','gateware/logic/pid_output_limit.py','gateware/logic/iir.py','gateware/logic/iir_registered_c48.py','gateware/logic/autolock_pipeline.py','gateware/logic/slow_pipeline.py','gateware/logic/feedback_pipeline.py','gateware/lowlevel/gpio.py')
for rel in unchanged:assert oldfile(rel)==(r/rel).read_text(encoding='utf-8'),rel
chains=(r/'gateware/logic/chains.py').read_text(encoding='utf-8');old=oldfile('gateware/logic/chains.py')
assert chains[:chains.index('def cross_connect(')]==old[:old.index('def cross_connect(')]
assert chains[chains.index('    # connect state ins'):]==old[old.index('    # connect state ins'):]
assert chains[chains.index('    state_names ='):chains.index('    # Only external')]==old[old.index('    state_names ='):old.index('    # connect gpio output')]
root=(r/'gateware/linien_module.py').read_text(encoding='utf-8')
assert root.replace('            gpio_status_pipeline=1,\n','')==oldfile('gateware/linien_module.py')
s=(t/'top.v').read_text();decl=re.findall(r"reg \[13:0\] (\w*gpio_status_(?:state|mask)_s1\w*) = 14'd0;",s)
assert len(decl)==9,decl
for name in decl:
    assert re.search(re.escape(name)+r' <= [^;]+;',s),name
assert 'gpio_status_pipeline=1' in root
base=Path('D:/RP_Dev/linien_trials/20261110-r28-pid-output-bitdecode/gateware/build/trials/20261110_193543_r28_pid_output_bitdecode')
assert (t/'top.xdc').read_bytes()==(base/'top.xdc').read_bytes()
ns={};bn={};exec((t/'csrmap.py').read_text(),ns);exec((base/'csrmap.py').read_text(),bn)
assert all(ns[n]==bn[n] for n in ('csr_constants','csr','states','signals'))
native=json.loads((t/'gpio_status_checks/results.json').read_text());assert native['passed'] and native['cycles']==63366
record={'passed':True,'top_sha256':hashlib.sha256((t/'top.v').read_bytes()).hexdigest(),'generated_snapshot_registers':decl,'snapshot_RTL_bits':126,'default_mode_exact_native':True,'ADC_PID_IIR_robust_FSM_and_control_sources_unchanged':True,'internal_state_signal_and_sticky_status_statements_same':True,'Root_only_change_enable_GPIO_option':True,'XDC_same_bytes_R28':True,'CSR_map_same_R28':True,'feedback_cycles_added':0,'derived_GPIO_LED_cycles_added':1,'full_root_SDF_board':'NOT_RUN','native':native}
(h/'r34_generated_structure.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print('R34_GPIO_SNAPSHOT_AND_UNCHANGED_INTERNAL_CONTROL_AUDIT_PASS')
