if {[llength $argv] != 2} {puts stderr "DCP and fresh output directory required"; exit 2}
set checkpoint [file normalize [lindex $argv 0]]
set out [file normalize [lindex $argv 1]]
if {[file exists $out]} {puts stderr "output must not exist"; exit 2}
file mkdir $out
proc props {c fileHandle} {
    set available [list_property $c]
    foreach p {NAME REF_NAME ORIG_REF_NAME ORIG_CELL_NAME LOC BEL INIT AREG BREG CREG DREG MREG PREG ADREG ACASCREG BCASCREG OPMODEREG ALUMODEREG USE_DPORT USE_MULT USE_SIMD DONT_TOUCH KEEP} {
        if {[lsearch -exact $available $p] >= 0} {puts $fileHandle "$p=[get_property $p $c]"}
    }
}
proc pin_info {cell fh} {
    props $cell $fh
    foreach p [get_pins -quiet -of_objects $cell] {
        set nets [get_nets -quiet -of_objects $p]
        set drivers [get_pins -quiet -of_objects $nets -filter {DIRECTION == OUT}]
        if {[get_property DIRECTION $p] eq "IN"} {
            puts $fh "PIN=$p NET=$nets DRIVER=$drivers"
        } else {puts $fh "PIN=$p NET=$nets LOAD_COUNT=[llength [get_pins -quiet -of_objects $nets -filter {DIRECTION == IN}]]"}
    }
}
if {[catch {
open_checkpoint $checkpoint
set f [open "$out/design.txt" w]
puts $f "CHECKPOINT=$checkpoint PART=[get_property PART [current_design]]"
puts $f "VIVADO=[version -short]"
close $f
report_timing -delay_type max -max_paths 20 -file "$out/worst20.rpt"
report_clock_interaction -file "$out/clock_interaction.rpt"
report_exceptions -summary -file "$out/exceptions.rpt"
report_cdc -details -file "$out/cdc.rpt"
report_utilization -hierarchical -file "$out/utilization_hier.rpt"
set iirCells [get_cells -hier -filter {NAME =~ *raw_acquisition_iir* || NAME =~ linienmodule_logic_iir_* || NAME =~ linienmodule_iir_*}]

proc mapped_dsp {kind} {
    set result {}
    foreach c [get_cells -hier -quiet -filter {REF_NAME == DSP48E1}] {
        set pp {}
        foreach p [get_pins -quiet -of_objects $c -filter {DIRECTION == OUT}] {
            if {[regexp {^(P|PCOUT)(\[[0-9]+\])?$} [get_property REF_PIN_NAME $p]]} {lappend pp $p}
        }
        set nets [get_nets -quiet -of_objects $pp]
        if {$kind eq "raw"} {
            set matches [filter $nets {NAME =~ linienmodule_iir_* || NAME =~ linienmodule_logic_iir_* || NAME =~ *raw_acquisition_iir*}]
        } elseif {$kind eq "fast_a"} {set matches [filter $nets {NAME =~ linienmodule_fast_a_iir*}]
        } elseif {$kind eq "fast_b"} {set matches [filter $nets {NAME =~ linienmodule_fast_b_iir*}]
        } else {set matches [filter $nets {NAME =~ *registerederrormixer* || NAME =~ *error_mixer*}]}
        if {[llength $matches]} {lappend result $c}
    }
    return $result
}
set rawMappedDSP [mapped_dsp raw]
set f [open "$out/raw_mapped_dsp.txt" w]
foreach c $rawMappedDSP {puts $f $c};close $f
foreach kind {fast_a fast_b} {
    set f [open "$out/${kind}_mapped_dsp.txt" w]
    foreach c [mapped_dsp $kind] {puts $f $c};close $f
}

set iirCells [lsort -unique [concat $iirCells $rawMappedDSP]]
set seq [filter $iirCells {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
if {![llength $seq]} {error "raw acquisition IIR sequential cells missing"}
report_timing -delay_type max -max_paths 30 -to $seq -file "$out/iir_to.rpt"
report_timing -delay_type max -max_paths 30 -from $seq -to $seq -file "$out/iir_internal.rpt"
report_timing -delay_type max -max_paths 20 -from $seq -file "$out/iir_from.rpt"
set f [open "$out/iir_cell_counts.txt" w]
set counts [dict create]
foreach c $iirCells {dict incr counts [get_property REF_NAME $c]}
dict for {key value} $counts {puts $f "$key $value"}
close $f
set f [open "$out/all_dsp.txt" w]
foreach c [get_cells -hier -filter {REF_NAME == DSP48E1}] {
    puts $f "CELL_BEGIN"
    props $c $f
    puts $f "CELL_END"
}
close $f
set f [open "$out/iir_dsp_ports.txt" w]
foreach c [filter $iirCells {REF_NAME == DSP48E1}] {pin_info $c $f}
close $f
set f [open "$out/iir_registers.txt" w]
foreach c [filter $iirCells {REF_NAME =~ FD*}] {puts $f "$c [get_property REF_NAME $c]"}
close $f
set f [open "$out/negative_paths.tsv" w]
puts $f "slack\tstart\tend"
set negative [get_timing_paths -delay_type max -max_paths 20000 -nworst 1 -slack_lesser_than 0.0]
foreach p $negative {puts $f "[get_property SLACK $p]\t[get_property STARTPOINT_PIN $p]\t[get_property ENDPOINT_PIN $p]"}
close $f
puts "NEGATIVE_PATH_COUNT [llength $negative]"
if {[llength $negative]} {
    set f [open "$out/timing_path_properties.txt" w]
    set p [lindex $negative 0]
    foreach key [list_property $p] {puts $f "$key=[get_property $key $p]"}
    close $f
}


set scale_cells [get_cells -hier -quiet -filter {NAME =~ *autolock*time_scale* && REF_NAME =~ FD*}]
set gpio_cells [get_cells -hier -quiet -filter {NAME =~ *gpio_n_o* && REF_NAME =~ FD*}]
if {[llength $scale_cells] && [llength $gpio_cells]} {
    report_timing -from $scale_cells -to $gpio_cells -max_paths 10 -file "$out/time_scale_to_gpio.rpt"
}
set sum_regs [get_cells -hier -quiet -filter {NAME =~ *autolock*sum_diff_s1* && REF_NAME =~ FD*}]
if {[llength $sum_regs]} {
    report_timing -to $sum_regs -max_paths 10 -file "$out/autolock_to_sum_stage.rpt"
    report_timing -from $sum_regs -max_paths 10 -file "$out/autolock_from_sum_stage.rpt"
}
set allDSP [get_cells -hier -filter {REF_NAME == DSP48E1}]
set fast [get_cells -hier -quiet -filter {NAME =~ *logic_pid* || NAME =~ *mixeralignedpid*}]
set fastDSP {}
foreach c $allDSP {
    set pp {}
    foreach p [get_pins -quiet -of_objects $c -filter {DIRECTION == OUT}] {
        if {[regexp {^P(\[[0-9]+\])?$} [get_property REF_PIN_NAME $p]]} {lappend pp $p}
    }
    set nets [get_nets -quiet -of_objects $pp]
    if {[llength [filter $nets {NAME =~ *logic_pid* || NAME =~ *mixeralignedpid*}]]} {lappend fastDSP $c; lappend fast $c}
}
set fast [lsort -unique $fast]
set f [open "$out/fast_mapped_cells.txt" w]
foreach c $fast {puts $f [get_property NAME $c]}; close $f
set f [open "$out/fast_mapped_dsp.txt" w]
foreach c $fastDSP {puts $f [get_property NAME $c]}; close $f
foreach pin {D R S CE} {
    set pins [get_pins -quiet -of_objects $fast -filter "REF_PIN_NAME == $pin"]
    if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/fast_${pin}.rpt"}
}
set seq [filter $fast {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
if {[llength $seq]} {report_timing -to $seq -max_paths 10 -file "$out/fast_all_sequential.rpt"}
if {[llength $seq]} {report_timing -from $seq -max_paths 20 -file "$out/fast_outgoing.rpt"}
set mixer [mapped_dsp mixer]
if {[llength $mixer]} {
    report_timing -from $mixer -max_paths 10 -file "$out/mixer_from_dsp.rpt"
    report_timing -to $mixer -max_paths 10 -file "$out/mixer_to_dsp.rpt"
}
set raw $iirCells
foreach chain {a b} {
    set src [get_cells -hier -quiet -filter "NAME =~ linienmodule_fast_${chain}_iir*_y* && REF_NAME =~ FD*"]
    if {[llength $src]} {report_timing -from $src -max_paths 10 -file "$out/frontend_${chain}_output.rpt"}
}
set avgctrl [get_cells -hier -quiet -filter {NAME =~ red_pitaya_scope/set_avg_en_reg* && REF_NAME =~ FD*}]
if {[llength $avgctrl]} {report_timing -from $avgctrl -max_paths 10 -file "$out/scope_average_control.rpt"}
set snap [get_cells -hier -quiet -filter {(NAME =~ *gpio_status_state_s1* || NAME =~ *gpio_status_mask_s1*) && REF_NAME =~ FD*}]
set f [open "$out/gpio_snapshot_registers.tsv" w]
puts $f "name\tref"
foreach c $snap {puts $f "[get_property NAME $c]\t[get_property REF_NAME $c]"};close $f
if {[llength $snap]} {
    report_timing -from $snap -max_paths 20 -file "$out/gpio_snapshot_from.rpt"
    report_timing -to $snap -max_paths 20 -file "$out/gpio_snapshot_to.rpt"
    foreach pin {D R S CE} {
        set pins [get_pins -quiet -of_objects $snap -filter "REF_PIN_NAME == $pin"]
        if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/gpio_snapshot_${pin}.rpt"}
    }
}
if {[llength $gpio_cells]} {report_timing -to $gpio_cells -max_paths 20 -file "$out/gpio_outputs_to.rpt"}
set ohcells [get_cells -hier -quiet -filter {NAME =~ *instruction_onehot*}]
set f [open "$out/onehot_mapped_cells.tsv" w]
puts $f "name\tref"
foreach c $ohcells {puts $f "[get_property NAME $c]\t[get_property REF_NAME $c]"};close $f
set ohseq [filter $ohcells {REF_NAME =~ FD* || REF_NAME =~ SRL*}]
if {[llength $ohseq]} {
    report_timing -from $ohseq -max_paths 20 -file "$out/onehot_from_registers.rpt"
    report_timing -to $ohseq -max_paths 20 -file "$out/onehot_to_registers.rpt"
    foreach pin {D R S CE} {
        set pins [get_pins -quiet -of_objects $ohseq -filter "REF_PIN_NAME == $pin"]
        if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/onehot_${pin}.rpt"}
    }
}
set rawseq [filter $raw {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
set outside [get_cells -hier -quiet -filter {(REF_NAME =~ FD* || REF_NAME == DSP48E1 || REF_NAME =~ RAMB*) && NAME !~ *raw_acquisition_iir* && NAME !~ linienmodule_logic_iir_* && NAME !~ linienmodule_iir_*}]
foreach c $rawMappedDSP {set index [lsearch -exact $outside $c];if {$index>=0} {set outside [lreplace $outside $index $index]}}
set dataPins {}
foreach p [get_pins -quiet -of_objects $rawseq -filter {DIRECTION == IN}] {
    if {[regexp {^(A|B|C|D)(\[[0-9]+\])?$} [get_property REF_PIN_NAME $p]]} {lappend dataPins $p}
}
if {[llength $outside] && [llength $dataPins]} {report_timing -from $outside -to $dataPins -max_paths 10 -file "$out/iir_external_data.rpt"}


foreach pair {{slow {*slow_chain_pid*}}} {
    lassign $pair label pattern
    set cells [get_cells -hier -quiet -filter "NAME =~ $pattern"]
    foreach pinName {D R S CE} {
        set pins [get_pins -quiet -of_objects $cells -filter "REF_PIN_NAME == $pinName"]
        if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/${label}_${pinName}.rpt"}
    }
    set seq [filter $cells {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
    if {[llength $seq]} {report_timing -to $seq -max_paths 10 -file "$out/${label}_all_sequential.rpt"}
}

write_verilog -force -mode funcsim "$out/routed_netlist.v"
help phys_opt_design
help place_design
help route_design
puts IIR_READONLY_AUDIT_COMPLETE
} msg opts]} {
    puts stderr "ERROR: $msg"
    puts stderr [dict get $opts -errorinfo]
    exit 3
}
exit 0
