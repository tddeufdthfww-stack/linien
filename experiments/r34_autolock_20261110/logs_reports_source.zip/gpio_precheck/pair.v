/* Machine-generated using Migen */
module gpio_pair(
	input sys_clk,
	input sys_rst,
	input [7:0] di,
	input [4:0] flags,
	input [24:0] trace_a,
	input [24:0] trace_b,
	input [13:0] csr_adr,
	input csr_we,
	input [7:0] csr_dat_w,
	output [7:0] old_gpio,
	output old_accept,
	output [24:0] old_take,
	output [7:0] old_read,
	output [7:0] plain_gpio,
	output plain_accept,
	output [24:0] plain_take,
	output [7:0] plain_read,
	output [7:0] new_gpio,
	output new_accept,
	output [24:0] new_take,
	output [7:0] new_read
);

wire [7:0] pair_bundle0_i;
reg [7:0] pair_bundle0_o = 8'd0;
wire pair_bundle0_flag0;
wire pair_bundle0_flag1;
wire pair_bundle0_flag2;
wire pair_bundle0_flag3;
wire pair_bundle0_flag4;
wire signed [24:0] pair_bundle0_trace0;
wire signed [24:0] pair_bundle0_trace1;
reg pair_bundle0_accept = 1'd0;
reg signed [24:0] pair_bundle0_take = 25'sd0;
wire [24:0] pair_bundle0_sig_status0;
wire pair_bundle0_trace0_clr_re;
wire pair_bundle0_trace0_clr_r;
reg pair_bundle0_trace0_clr_w = 1'd0;
reg [24:0] pair_bundle0_max_status0 = 25'd0;
reg [24:0] pair_bundle0_min_status0 = 25'd0;
wire [24:0] pair_bundle0_sig_status1;
wire pair_bundle0_trace1_clr_re;
wire pair_bundle0_trace1_clr_r;
reg pair_bundle0_trace1_clr_w = 1'd0;
reg [24:0] pair_bundle0_max_status1 = 25'd0;
reg [24:0] pair_bundle0_min_status1 = 25'd0;
wire [13:0] pair_bundle0_state;
reg [13:0] pair_bundle0_state_status = 14'd0;
wire pair_bundle0_state_clr_re;
wire pair_bundle0_state_clr_r;
reg pair_bundle0_state_clr_w = 1'd0;
reg [13:0] pair_bundle0_csrstorage0_storage_full = 14'd0;
wire [13:0] pair_bundle0_csrstorage0_storage;
reg pair_bundle0_csrstorage0_re = 1'd0;
reg [13:0] pair_bundle0_csrstorage1_storage_full = 14'd0;
wire [13:0] pair_bundle0_csrstorage1_storage;
reg pair_bundle0_csrstorage1_re = 1'd0;
reg [13:0] pair_bundle0_csrstorage2_storage_full = 14'd0;
wire [13:0] pair_bundle0_csrstorage2_storage;
reg pair_bundle0_csrstorage2_re = 1'd0;
reg [13:0] pair_bundle0_csrstorage3_storage_full = 14'd0;
wire [13:0] pair_bundle0_csrstorage3_storage;
reg pair_bundle0_csrstorage3_re = 1'd0;
reg [13:0] pair_bundle0_csrstorage4_storage_full = 14'd0;
wire [13:0] pair_bundle0_csrstorage4_storage;
reg pair_bundle0_csrstorage4_re = 1'd0;
reg [13:0] pair_bundle0_csrstorage5_storage_full = 14'd0;
wire [13:0] pair_bundle0_csrstorage5_storage;
reg pair_bundle0_csrstorage5_re = 1'd0;
reg [13:0] pair_bundle0_csrstorage6_storage_full = 14'd0;
wire [13:0] pair_bundle0_csrstorage6_storage;
reg pair_bundle0_csrstorage6_re = 1'd0;
reg [13:0] pair_bundle0_csrstorage7_storage_full = 14'd0;
wire [13:0] pair_bundle0_csrstorage7_storage;
reg pair_bundle0_csrstorage7_re = 1'd0;
reg [13:0] pair_bundle0_csrstorage8_storage_full = 14'd0;
wire [13:0] pair_bundle0_csrstorage8_storage;
reg pair_bundle0_csrstorage8_re = 1'd0;
reg [1:0] pair_bundle0_csrstorage9_storage_full = 2'd0;
wire [1:0] pair_bundle0_csrstorage9_storage;
reg pair_bundle0_csrstorage9_re = 1'd0;
wire [13:0] pair_bundle0_bus_adr;
wire pair_bundle0_bus_we;
wire [7:0] pair_bundle0_bus_dat_w;
reg [7:0] pair_bundle0_bus_dat_r = 8'd0;
wire pair_bundle0_source_trace0_max3_re;
wire pair_bundle0_source_trace0_max3_r;
wire pair_bundle0_source_trace0_max3_w;
wire pair_bundle0_source_trace0_max2_re;
wire [7:0] pair_bundle0_source_trace0_max2_r;
wire [7:0] pair_bundle0_source_trace0_max2_w;
wire pair_bundle0_source_trace0_max1_re;
wire [7:0] pair_bundle0_source_trace0_max1_r;
wire [7:0] pair_bundle0_source_trace0_max1_w;
wire pair_bundle0_source_trace0_max0_re;
wire [7:0] pair_bundle0_source_trace0_max0_r;
wire [7:0] pair_bundle0_source_trace0_max0_w;
wire pair_bundle0_source_trace0_min3_re;
wire pair_bundle0_source_trace0_min3_r;
wire pair_bundle0_source_trace0_min3_w;
wire pair_bundle0_source_trace0_min2_re;
wire [7:0] pair_bundle0_source_trace0_min2_r;
wire [7:0] pair_bundle0_source_trace0_min2_w;
wire pair_bundle0_source_trace0_min1_re;
wire [7:0] pair_bundle0_source_trace0_min1_r;
wire [7:0] pair_bundle0_source_trace0_min1_w;
wire pair_bundle0_source_trace0_min0_re;
wire [7:0] pair_bundle0_source_trace0_min0_r;
wire [7:0] pair_bundle0_source_trace0_min0_w;
wire pair_bundle0_source_trace1_max3_re;
wire pair_bundle0_source_trace1_max3_r;
wire pair_bundle0_source_trace1_max3_w;
wire pair_bundle0_source_trace1_max2_re;
wire [7:0] pair_bundle0_source_trace1_max2_r;
wire [7:0] pair_bundle0_source_trace1_max2_w;
wire pair_bundle0_source_trace1_max1_re;
wire [7:0] pair_bundle0_source_trace1_max1_r;
wire [7:0] pair_bundle0_source_trace1_max1_w;
wire pair_bundle0_source_trace1_max0_re;
wire [7:0] pair_bundle0_source_trace1_max0_r;
wire [7:0] pair_bundle0_source_trace1_max0_w;
wire pair_bundle0_source_trace1_min3_re;
wire pair_bundle0_source_trace1_min3_r;
wire pair_bundle0_source_trace1_min3_w;
wire pair_bundle0_source_trace1_min2_re;
wire [7:0] pair_bundle0_source_trace1_min2_r;
wire [7:0] pair_bundle0_source_trace1_min2_w;
wire pair_bundle0_source_trace1_min1_re;
wire [7:0] pair_bundle0_source_trace1_min1_r;
wire [7:0] pair_bundle0_source_trace1_min1_w;
wire pair_bundle0_source_trace1_min0_re;
wire [7:0] pair_bundle0_source_trace1_min0_r;
wire [7:0] pair_bundle0_source_trace1_min0_w;
wire pair_bundle0_gpio_state1_re;
wire [5:0] pair_bundle0_gpio_state1_r;
wire [5:0] pair_bundle0_gpio_state1_w;
wire pair_bundle0_gpio_state0_re;
wire [7:0] pair_bundle0_gpio_state0_r;
wire [7:0] pair_bundle0_gpio_state0_w;
wire pair_bundle0_gpio_do0_en1_re;
wire [5:0] pair_bundle0_gpio_do0_en1_r;
wire [5:0] pair_bundle0_gpio_do0_en1_w;
wire pair_bundle0_gpio_do0_en0_re;
wire [7:0] pair_bundle0_gpio_do0_en0_r;
wire [7:0] pair_bundle0_gpio_do0_en0_w;
wire pair_bundle0_gpio_do1_en1_re;
wire [5:0] pair_bundle0_gpio_do1_en1_r;
wire [5:0] pair_bundle0_gpio_do1_en1_w;
wire pair_bundle0_gpio_do1_en0_re;
wire [7:0] pair_bundle0_gpio_do1_en0_r;
wire [7:0] pair_bundle0_gpio_do1_en0_w;
wire pair_bundle0_gpio_do2_en1_re;
wire [5:0] pair_bundle0_gpio_do2_en1_r;
wire [5:0] pair_bundle0_gpio_do2_en1_w;
wire pair_bundle0_gpio_do2_en0_re;
wire [7:0] pair_bundle0_gpio_do2_en0_r;
wire [7:0] pair_bundle0_gpio_do2_en0_w;
wire pair_bundle0_gpio_do3_en1_re;
wire [5:0] pair_bundle0_gpio_do3_en1_r;
wire [5:0] pair_bundle0_gpio_do3_en1_w;
wire pair_bundle0_gpio_do3_en0_re;
wire [7:0] pair_bundle0_gpio_do3_en0_r;
wire [7:0] pair_bundle0_gpio_do3_en0_w;
wire pair_bundle0_gpio_do4_en1_re;
wire [5:0] pair_bundle0_gpio_do4_en1_r;
wire [5:0] pair_bundle0_gpio_do4_en1_w;
wire pair_bundle0_gpio_do4_en0_re;
wire [7:0] pair_bundle0_gpio_do4_en0_r;
wire [7:0] pair_bundle0_gpio_do4_en0_w;
wire pair_bundle0_gpio_do5_en1_re;
wire [5:0] pair_bundle0_gpio_do5_en1_r;
wire [5:0] pair_bundle0_gpio_do5_en1_w;
wire pair_bundle0_gpio_do5_en0_re;
wire [7:0] pair_bundle0_gpio_do5_en0_r;
wire [7:0] pair_bundle0_gpio_do5_en0_w;
wire pair_bundle0_gpio_do6_en1_re;
wire [5:0] pair_bundle0_gpio_do6_en1_r;
wire [5:0] pair_bundle0_gpio_do6_en1_w;
wire pair_bundle0_gpio_do6_en0_re;
wire [7:0] pair_bundle0_gpio_do6_en0_r;
wire [7:0] pair_bundle0_gpio_do6_en0_w;
wire pair_bundle0_gpio_do7_en1_re;
wire [5:0] pair_bundle0_gpio_do7_en1_r;
wire [5:0] pair_bundle0_gpio_do7_en1_w;
wire pair_bundle0_gpio_do7_en0_re;
wire [7:0] pair_bundle0_gpio_do7_en0_r;
wire [7:0] pair_bundle0_gpio_do7_en0_w;
wire pair_bundle0_sink_accept_en1_re;
wire [5:0] pair_bundle0_sink_accept_en1_r;
wire [5:0] pair_bundle0_sink_accept_en1_w;
wire pair_bundle0_sink_accept_en0_re;
wire [7:0] pair_bundle0_sink_accept_en0_r;
wire [7:0] pair_bundle0_sink_accept_en0_w;
wire pair_bundle0_sink_take_sel0_re;
wire [1:0] pair_bundle0_sink_take_sel0_r;
wire [1:0] pair_bundle0_sink_take_sel0_w;
wire pair_bundle0_sel;
wire [7:0] pair_bundle1_i;
reg [7:0] pair_bundle1_o = 8'd0;
wire pair_bundle1_flag0;
wire pair_bundle1_flag1;
wire pair_bundle1_flag2;
wire pair_bundle1_flag3;
wire pair_bundle1_flag4;
wire signed [24:0] pair_bundle1_trace0;
wire signed [24:0] pair_bundle1_trace1;
reg pair_bundle1_accept = 1'd0;
reg signed [24:0] pair_bundle1_take = 25'sd0;
wire [24:0] pair_bundle1_sig_status0;
wire pair_bundle1_trace0_clr_re;
wire pair_bundle1_trace0_clr_r;
reg pair_bundle1_trace0_clr_w = 1'd0;
reg [24:0] pair_bundle1_max_status0 = 25'd0;
reg [24:0] pair_bundle1_min_status0 = 25'd0;
wire [24:0] pair_bundle1_sig_status1;
wire pair_bundle1_trace1_clr_re;
wire pair_bundle1_trace1_clr_r;
reg pair_bundle1_trace1_clr_w = 1'd0;
reg [24:0] pair_bundle1_max_status1 = 25'd0;
reg [24:0] pair_bundle1_min_status1 = 25'd0;
wire [13:0] pair_bundle1_state;
reg [13:0] pair_bundle1_state_status = 14'd0;
wire pair_bundle1_state_clr_re;
wire pair_bundle1_state_clr_r;
reg pair_bundle1_state_clr_w = 1'd0;
reg [13:0] pair_bundle1_csrstorage0_storage_full = 14'd0;
wire [13:0] pair_bundle1_csrstorage0_storage;
reg pair_bundle1_csrstorage0_re = 1'd0;
reg [13:0] pair_bundle1_csrstorage1_storage_full = 14'd0;
wire [13:0] pair_bundle1_csrstorage1_storage;
reg pair_bundle1_csrstorage1_re = 1'd0;
reg [13:0] pair_bundle1_csrstorage2_storage_full = 14'd0;
wire [13:0] pair_bundle1_csrstorage2_storage;
reg pair_bundle1_csrstorage2_re = 1'd0;
reg [13:0] pair_bundle1_csrstorage3_storage_full = 14'd0;
wire [13:0] pair_bundle1_csrstorage3_storage;
reg pair_bundle1_csrstorage3_re = 1'd0;
reg [13:0] pair_bundle1_csrstorage4_storage_full = 14'd0;
wire [13:0] pair_bundle1_csrstorage4_storage;
reg pair_bundle1_csrstorage4_re = 1'd0;
reg [13:0] pair_bundle1_csrstorage5_storage_full = 14'd0;
wire [13:0] pair_bundle1_csrstorage5_storage;
reg pair_bundle1_csrstorage5_re = 1'd0;
reg [13:0] pair_bundle1_csrstorage6_storage_full = 14'd0;
wire [13:0] pair_bundle1_csrstorage6_storage;
reg pair_bundle1_csrstorage6_re = 1'd0;
reg [13:0] pair_bundle1_csrstorage7_storage_full = 14'd0;
wire [13:0] pair_bundle1_csrstorage7_storage;
reg pair_bundle1_csrstorage7_re = 1'd0;
reg [13:0] pair_bundle1_csrstorage8_storage_full = 14'd0;
wire [13:0] pair_bundle1_csrstorage8_storage;
reg pair_bundle1_csrstorage8_re = 1'd0;
reg [1:0] pair_bundle1_csrstorage9_storage_full = 2'd0;
wire [1:0] pair_bundle1_csrstorage9_storage;
reg pair_bundle1_csrstorage9_re = 1'd0;
wire [13:0] pair_bundle1_bus_adr;
wire pair_bundle1_bus_we;
wire [7:0] pair_bundle1_bus_dat_w;
reg [7:0] pair_bundle1_bus_dat_r = 8'd0;
wire pair_bundle1_source_trace0_max3_re;
wire pair_bundle1_source_trace0_max3_r;
wire pair_bundle1_source_trace0_max3_w;
wire pair_bundle1_source_trace0_max2_re;
wire [7:0] pair_bundle1_source_trace0_max2_r;
wire [7:0] pair_bundle1_source_trace0_max2_w;
wire pair_bundle1_source_trace0_max1_re;
wire [7:0] pair_bundle1_source_trace0_max1_r;
wire [7:0] pair_bundle1_source_trace0_max1_w;
wire pair_bundle1_source_trace0_max0_re;
wire [7:0] pair_bundle1_source_trace0_max0_r;
wire [7:0] pair_bundle1_source_trace0_max0_w;
wire pair_bundle1_source_trace0_min3_re;
wire pair_bundle1_source_trace0_min3_r;
wire pair_bundle1_source_trace0_min3_w;
wire pair_bundle1_source_trace0_min2_re;
wire [7:0] pair_bundle1_source_trace0_min2_r;
wire [7:0] pair_bundle1_source_trace0_min2_w;
wire pair_bundle1_source_trace0_min1_re;
wire [7:0] pair_bundle1_source_trace0_min1_r;
wire [7:0] pair_bundle1_source_trace0_min1_w;
wire pair_bundle1_source_trace0_min0_re;
wire [7:0] pair_bundle1_source_trace0_min0_r;
wire [7:0] pair_bundle1_source_trace0_min0_w;
wire pair_bundle1_source_trace1_max3_re;
wire pair_bundle1_source_trace1_max3_r;
wire pair_bundle1_source_trace1_max3_w;
wire pair_bundle1_source_trace1_max2_re;
wire [7:0] pair_bundle1_source_trace1_max2_r;
wire [7:0] pair_bundle1_source_trace1_max2_w;
wire pair_bundle1_source_trace1_max1_re;
wire [7:0] pair_bundle1_source_trace1_max1_r;
wire [7:0] pair_bundle1_source_trace1_max1_w;
wire pair_bundle1_source_trace1_max0_re;
wire [7:0] pair_bundle1_source_trace1_max0_r;
wire [7:0] pair_bundle1_source_trace1_max0_w;
wire pair_bundle1_source_trace1_min3_re;
wire pair_bundle1_source_trace1_min3_r;
wire pair_bundle1_source_trace1_min3_w;
wire pair_bundle1_source_trace1_min2_re;
wire [7:0] pair_bundle1_source_trace1_min2_r;
wire [7:0] pair_bundle1_source_trace1_min2_w;
wire pair_bundle1_source_trace1_min1_re;
wire [7:0] pair_bundle1_source_trace1_min1_r;
wire [7:0] pair_bundle1_source_trace1_min1_w;
wire pair_bundle1_source_trace1_min0_re;
wire [7:0] pair_bundle1_source_trace1_min0_r;
wire [7:0] pair_bundle1_source_trace1_min0_w;
wire pair_bundle1_gpio_state1_re;
wire [5:0] pair_bundle1_gpio_state1_r;
wire [5:0] pair_bundle1_gpio_state1_w;
wire pair_bundle1_gpio_state0_re;
wire [7:0] pair_bundle1_gpio_state0_r;
wire [7:0] pair_bundle1_gpio_state0_w;
wire pair_bundle1_gpio_do0_en1_re;
wire [5:0] pair_bundle1_gpio_do0_en1_r;
wire [5:0] pair_bundle1_gpio_do0_en1_w;
wire pair_bundle1_gpio_do0_en0_re;
wire [7:0] pair_bundle1_gpio_do0_en0_r;
wire [7:0] pair_bundle1_gpio_do0_en0_w;
wire pair_bundle1_gpio_do1_en1_re;
wire [5:0] pair_bundle1_gpio_do1_en1_r;
wire [5:0] pair_bundle1_gpio_do1_en1_w;
wire pair_bundle1_gpio_do1_en0_re;
wire [7:0] pair_bundle1_gpio_do1_en0_r;
wire [7:0] pair_bundle1_gpio_do1_en0_w;
wire pair_bundle1_gpio_do2_en1_re;
wire [5:0] pair_bundle1_gpio_do2_en1_r;
wire [5:0] pair_bundle1_gpio_do2_en1_w;
wire pair_bundle1_gpio_do2_en0_re;
wire [7:0] pair_bundle1_gpio_do2_en0_r;
wire [7:0] pair_bundle1_gpio_do2_en0_w;
wire pair_bundle1_gpio_do3_en1_re;
wire [5:0] pair_bundle1_gpio_do3_en1_r;
wire [5:0] pair_bundle1_gpio_do3_en1_w;
wire pair_bundle1_gpio_do3_en0_re;
wire [7:0] pair_bundle1_gpio_do3_en0_r;
wire [7:0] pair_bundle1_gpio_do3_en0_w;
wire pair_bundle1_gpio_do4_en1_re;
wire [5:0] pair_bundle1_gpio_do4_en1_r;
wire [5:0] pair_bundle1_gpio_do4_en1_w;
wire pair_bundle1_gpio_do4_en0_re;
wire [7:0] pair_bundle1_gpio_do4_en0_r;
wire [7:0] pair_bundle1_gpio_do4_en0_w;
wire pair_bundle1_gpio_do5_en1_re;
wire [5:0] pair_bundle1_gpio_do5_en1_r;
wire [5:0] pair_bundle1_gpio_do5_en1_w;
wire pair_bundle1_gpio_do5_en0_re;
wire [7:0] pair_bundle1_gpio_do5_en0_r;
wire [7:0] pair_bundle1_gpio_do5_en0_w;
wire pair_bundle1_gpio_do6_en1_re;
wire [5:0] pair_bundle1_gpio_do6_en1_r;
wire [5:0] pair_bundle1_gpio_do6_en1_w;
wire pair_bundle1_gpio_do6_en0_re;
wire [7:0] pair_bundle1_gpio_do6_en0_r;
wire [7:0] pair_bundle1_gpio_do6_en0_w;
wire pair_bundle1_gpio_do7_en1_re;
wire [5:0] pair_bundle1_gpio_do7_en1_r;
wire [5:0] pair_bundle1_gpio_do7_en1_w;
wire pair_bundle1_gpio_do7_en0_re;
wire [7:0] pair_bundle1_gpio_do7_en0_r;
wire [7:0] pair_bundle1_gpio_do7_en0_w;
wire pair_bundle1_sink_accept_en1_re;
wire [5:0] pair_bundle1_sink_accept_en1_r;
wire [5:0] pair_bundle1_sink_accept_en1_w;
wire pair_bundle1_sink_accept_en0_re;
wire [7:0] pair_bundle1_sink_accept_en0_r;
wire [7:0] pair_bundle1_sink_accept_en0_w;
wire pair_bundle1_sink_take_sel0_re;
wire [1:0] pair_bundle1_sink_take_sel0_r;
wire [1:0] pair_bundle1_sink_take_sel0_w;
wire pair_bundle1_sel;
wire [7:0] pair_bundle2_i;
reg [7:0] pair_bundle2_o = 8'd0;
wire pair_bundle2_flag0;
wire pair_bundle2_flag1;
wire pair_bundle2_flag2;
wire pair_bundle2_flag3;
wire pair_bundle2_flag4;
wire signed [24:0] pair_bundle2_trace0;
wire signed [24:0] pair_bundle2_trace1;
reg pair_bundle2_accept = 1'd0;
reg signed [24:0] pair_bundle2_take = 25'sd0;
wire [24:0] pair_bundle2_sig_status0;
wire pair_bundle2_trace0_clr_re;
wire pair_bundle2_trace0_clr_r;
reg pair_bundle2_trace0_clr_w = 1'd0;
reg [24:0] pair_bundle2_max_status0 = 25'd0;
reg [24:0] pair_bundle2_min_status0 = 25'd0;
wire [24:0] pair_bundle2_sig_status1;
wire pair_bundle2_trace1_clr_re;
wire pair_bundle2_trace1_clr_r;
reg pair_bundle2_trace1_clr_w = 1'd0;
reg [24:0] pair_bundle2_max_status1 = 25'd0;
reg [24:0] pair_bundle2_min_status1 = 25'd0;
wire [13:0] pair_bundle2_state;
reg [13:0] pair_bundle2_state_status = 14'd0;
wire pair_bundle2_state_clr_re;
wire pair_bundle2_state_clr_r;
reg pair_bundle2_state_clr_w = 1'd0;
reg [13:0] pair_bundle2_gpio_status_state_s1 = 14'd0;
reg [13:0] pair_bundle2_csrstorage10_storage_full = 14'd0;
wire [13:0] pair_bundle2_csrstorage10_storage;
reg pair_bundle2_csrstorage10_re = 1'd0;
reg [13:0] pair_bundle2_gpio_status_mask_s1_0 = 14'd0;
reg [13:0] pair_bundle2_csrstorage11_storage_full = 14'd0;
wire [13:0] pair_bundle2_csrstorage11_storage;
reg pair_bundle2_csrstorage11_re = 1'd0;
reg [13:0] pair_bundle2_gpio_status_mask_s1_1 = 14'd0;
reg [13:0] pair_bundle2_csrstorage12_storage_full = 14'd0;
wire [13:0] pair_bundle2_csrstorage12_storage;
reg pair_bundle2_csrstorage12_re = 1'd0;
reg [13:0] pair_bundle2_gpio_status_mask_s1_2 = 14'd0;
reg [13:0] pair_bundle2_csrstorage13_storage_full = 14'd0;
wire [13:0] pair_bundle2_csrstorage13_storage;
reg pair_bundle2_csrstorage13_re = 1'd0;
reg [13:0] pair_bundle2_gpio_status_mask_s1_3 = 14'd0;
reg [13:0] pair_bundle2_csrstorage14_storage_full = 14'd0;
wire [13:0] pair_bundle2_csrstorage14_storage;
reg pair_bundle2_csrstorage14_re = 1'd0;
reg [13:0] pair_bundle2_gpio_status_mask_s1_4 = 14'd0;
reg [13:0] pair_bundle2_csrstorage15_storage_full = 14'd0;
wire [13:0] pair_bundle2_csrstorage15_storage;
reg pair_bundle2_csrstorage15_re = 1'd0;
reg [13:0] pair_bundle2_gpio_status_mask_s1_5 = 14'd0;
reg [13:0] pair_bundle2_csrstorage16_storage_full = 14'd0;
wire [13:0] pair_bundle2_csrstorage16_storage;
reg pair_bundle2_csrstorage16_re = 1'd0;
reg [13:0] pair_bundle2_gpio_status_mask_s1_6 = 14'd0;
reg [13:0] pair_bundle2_csrstorage17_storage_full = 14'd0;
wire [13:0] pair_bundle2_csrstorage17_storage;
reg pair_bundle2_csrstorage17_re = 1'd0;
reg [13:0] pair_bundle2_gpio_status_mask_s1_7 = 14'd0;
reg [13:0] pair_bundle2_csrstorage18_storage_full = 14'd0;
wire [13:0] pair_bundle2_csrstorage18_storage;
reg pair_bundle2_csrstorage18_re = 1'd0;
reg [1:0] pair_bundle2_csrstorage19_storage_full = 2'd0;
wire [1:0] pair_bundle2_csrstorage19_storage;
reg pair_bundle2_csrstorage19_re = 1'd0;
wire [13:0] pair_bundle2_bus_adr;
wire pair_bundle2_bus_we;
wire [7:0] pair_bundle2_bus_dat_w;
reg [7:0] pair_bundle2_bus_dat_r = 8'd0;
wire pair_bundle2_source_trace0_max3_re;
wire pair_bundle2_source_trace0_max3_r;
wire pair_bundle2_source_trace0_max3_w;
wire pair_bundle2_source_trace0_max2_re;
wire [7:0] pair_bundle2_source_trace0_max2_r;
wire [7:0] pair_bundle2_source_trace0_max2_w;
wire pair_bundle2_source_trace0_max1_re;
wire [7:0] pair_bundle2_source_trace0_max1_r;
wire [7:0] pair_bundle2_source_trace0_max1_w;
wire pair_bundle2_source_trace0_max0_re;
wire [7:0] pair_bundle2_source_trace0_max0_r;
wire [7:0] pair_bundle2_source_trace0_max0_w;
wire pair_bundle2_source_trace0_min3_re;
wire pair_bundle2_source_trace0_min3_r;
wire pair_bundle2_source_trace0_min3_w;
wire pair_bundle2_source_trace0_min2_re;
wire [7:0] pair_bundle2_source_trace0_min2_r;
wire [7:0] pair_bundle2_source_trace0_min2_w;
wire pair_bundle2_source_trace0_min1_re;
wire [7:0] pair_bundle2_source_trace0_min1_r;
wire [7:0] pair_bundle2_source_trace0_min1_w;
wire pair_bundle2_source_trace0_min0_re;
wire [7:0] pair_bundle2_source_trace0_min0_r;
wire [7:0] pair_bundle2_source_trace0_min0_w;
wire pair_bundle2_source_trace1_max3_re;
wire pair_bundle2_source_trace1_max3_r;
wire pair_bundle2_source_trace1_max3_w;
wire pair_bundle2_source_trace1_max2_re;
wire [7:0] pair_bundle2_source_trace1_max2_r;
wire [7:0] pair_bundle2_source_trace1_max2_w;
wire pair_bundle2_source_trace1_max1_re;
wire [7:0] pair_bundle2_source_trace1_max1_r;
wire [7:0] pair_bundle2_source_trace1_max1_w;
wire pair_bundle2_source_trace1_max0_re;
wire [7:0] pair_bundle2_source_trace1_max0_r;
wire [7:0] pair_bundle2_source_trace1_max0_w;
wire pair_bundle2_source_trace1_min3_re;
wire pair_bundle2_source_trace1_min3_r;
wire pair_bundle2_source_trace1_min3_w;
wire pair_bundle2_source_trace1_min2_re;
wire [7:0] pair_bundle2_source_trace1_min2_r;
wire [7:0] pair_bundle2_source_trace1_min2_w;
wire pair_bundle2_source_trace1_min1_re;
wire [7:0] pair_bundle2_source_trace1_min1_r;
wire [7:0] pair_bundle2_source_trace1_min1_w;
wire pair_bundle2_source_trace1_min0_re;
wire [7:0] pair_bundle2_source_trace1_min0_r;
wire [7:0] pair_bundle2_source_trace1_min0_w;
wire pair_bundle2_gpio_state1_re;
wire [5:0] pair_bundle2_gpio_state1_r;
wire [5:0] pair_bundle2_gpio_state1_w;
wire pair_bundle2_gpio_state0_re;
wire [7:0] pair_bundle2_gpio_state0_r;
wire [7:0] pair_bundle2_gpio_state0_w;
wire pair_bundle2_gpio_do0_en1_re;
wire [5:0] pair_bundle2_gpio_do0_en1_r;
wire [5:0] pair_bundle2_gpio_do0_en1_w;
wire pair_bundle2_gpio_do0_en0_re;
wire [7:0] pair_bundle2_gpio_do0_en0_r;
wire [7:0] pair_bundle2_gpio_do0_en0_w;
wire pair_bundle2_gpio_do1_en1_re;
wire [5:0] pair_bundle2_gpio_do1_en1_r;
wire [5:0] pair_bundle2_gpio_do1_en1_w;
wire pair_bundle2_gpio_do1_en0_re;
wire [7:0] pair_bundle2_gpio_do1_en0_r;
wire [7:0] pair_bundle2_gpio_do1_en0_w;
wire pair_bundle2_gpio_do2_en1_re;
wire [5:0] pair_bundle2_gpio_do2_en1_r;
wire [5:0] pair_bundle2_gpio_do2_en1_w;
wire pair_bundle2_gpio_do2_en0_re;
wire [7:0] pair_bundle2_gpio_do2_en0_r;
wire [7:0] pair_bundle2_gpio_do2_en0_w;
wire pair_bundle2_gpio_do3_en1_re;
wire [5:0] pair_bundle2_gpio_do3_en1_r;
wire [5:0] pair_bundle2_gpio_do3_en1_w;
wire pair_bundle2_gpio_do3_en0_re;
wire [7:0] pair_bundle2_gpio_do3_en0_r;
wire [7:0] pair_bundle2_gpio_do3_en0_w;
wire pair_bundle2_gpio_do4_en1_re;
wire [5:0] pair_bundle2_gpio_do4_en1_r;
wire [5:0] pair_bundle2_gpio_do4_en1_w;
wire pair_bundle2_gpio_do4_en0_re;
wire [7:0] pair_bundle2_gpio_do4_en0_r;
wire [7:0] pair_bundle2_gpio_do4_en0_w;
wire pair_bundle2_gpio_do5_en1_re;
wire [5:0] pair_bundle2_gpio_do5_en1_r;
wire [5:0] pair_bundle2_gpio_do5_en1_w;
wire pair_bundle2_gpio_do5_en0_re;
wire [7:0] pair_bundle2_gpio_do5_en0_r;
wire [7:0] pair_bundle2_gpio_do5_en0_w;
wire pair_bundle2_gpio_do6_en1_re;
wire [5:0] pair_bundle2_gpio_do6_en1_r;
wire [5:0] pair_bundle2_gpio_do6_en1_w;
wire pair_bundle2_gpio_do6_en0_re;
wire [7:0] pair_bundle2_gpio_do6_en0_r;
wire [7:0] pair_bundle2_gpio_do6_en0_w;
wire pair_bundle2_gpio_do7_en1_re;
wire [5:0] pair_bundle2_gpio_do7_en1_r;
wire [5:0] pair_bundle2_gpio_do7_en1_w;
wire pair_bundle2_gpio_do7_en0_re;
wire [7:0] pair_bundle2_gpio_do7_en0_r;
wire [7:0] pair_bundle2_gpio_do7_en0_w;
wire pair_bundle2_sink_accept_en1_re;
wire [5:0] pair_bundle2_sink_accept_en1_r;
wire [5:0] pair_bundle2_sink_accept_en1_w;
wire pair_bundle2_sink_accept_en0_re;
wire [7:0] pair_bundle2_sink_accept_en0_r;
wire [7:0] pair_bundle2_sink_accept_en0_w;
wire pair_bundle2_sink_take_sel0_re;
wire [1:0] pair_bundle2_sink_take_sel0_r;
wire [1:0] pair_bundle2_sink_take_sel0_w;
wire pair_bundle2_sel;
reg signed [24:0] array_muxed0;
reg signed [24:0] array_muxed1;
reg signed [24:0] array_muxed2;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign pair_bundle0_i = di;
assign pair_bundle0_trace0 = trace_a;
assign pair_bundle0_trace1 = trace_b;
assign pair_bundle0_bus_adr = csr_adr;
assign pair_bundle0_bus_we = csr_we;
assign pair_bundle0_bus_dat_w = csr_dat_w;
assign pair_bundle0_flag0 = flags[0];
assign pair_bundle0_flag1 = flags[1];
assign pair_bundle0_flag2 = flags[2];
assign pair_bundle0_flag3 = flags[3];
assign pair_bundle0_flag4 = flags[4];
assign old_gpio = pair_bundle0_o;
assign old_accept = pair_bundle0_accept;
assign old_take = pair_bundle0_take;
assign old_read = pair_bundle0_bus_dat_r;
assign pair_bundle1_i = di;
assign pair_bundle1_trace0 = trace_a;
assign pair_bundle1_trace1 = trace_b;
assign pair_bundle1_bus_adr = csr_adr;
assign pair_bundle1_bus_we = csr_we;
assign pair_bundle1_bus_dat_w = csr_dat_w;
assign pair_bundle1_flag0 = flags[0];
assign pair_bundle1_flag1 = flags[1];
assign pair_bundle1_flag2 = flags[2];
assign pair_bundle1_flag3 = flags[3];
assign pair_bundle1_flag4 = flags[4];
assign plain_gpio = pair_bundle1_o;
assign plain_accept = pair_bundle1_accept;
assign plain_take = pair_bundle1_take;
assign plain_read = pair_bundle1_bus_dat_r;
assign pair_bundle2_i = di;
assign pair_bundle2_trace0 = trace_a;
assign pair_bundle2_trace1 = trace_b;
assign pair_bundle2_bus_adr = csr_adr;
assign pair_bundle2_bus_we = csr_we;
assign pair_bundle2_bus_dat_w = csr_dat_w;
assign pair_bundle2_flag0 = flags[0];
assign pair_bundle2_flag1 = flags[1];
assign pair_bundle2_flag2 = flags[2];
assign pair_bundle2_flag3 = flags[3];
assign pair_bundle2_flag4 = flags[4];
assign new_gpio = pair_bundle2_o;
assign new_accept = pair_bundle2_accept;
assign new_take = pair_bundle2_take;
assign new_read = pair_bundle2_bus_dat_r;
assign pair_bundle0_state = {pair_bundle0_flag4, pair_bundle0_flag3, pair_bundle0_flag2, pair_bundle0_flag1, pair_bundle0_flag0, pair_bundle0_i, 1'd1};
assign pair_bundle0_sig_status0 = pair_bundle0_trace0;
assign pair_bundle0_sig_status1 = pair_bundle0_trace1;
assign pair_bundle0_sel = (pair_bundle0_bus_adr[13:9] == 1'd0);
assign pair_bundle0_trace0_clr_r = pair_bundle0_bus_dat_w[0];
assign pair_bundle0_trace0_clr_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 1'd0));
assign pair_bundle0_source_trace0_max3_r = pair_bundle0_bus_dat_w[0];
assign pair_bundle0_source_trace0_max3_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 1'd1));
assign pair_bundle0_source_trace0_max2_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace0_max2_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 2'd2));
assign pair_bundle0_source_trace0_max1_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace0_max1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 2'd3));
assign pair_bundle0_source_trace0_max0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace0_max0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 3'd4));
assign pair_bundle0_source_trace0_min3_r = pair_bundle0_bus_dat_w[0];
assign pair_bundle0_source_trace0_min3_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 3'd5));
assign pair_bundle0_source_trace0_min2_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace0_min2_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 3'd6));
assign pair_bundle0_source_trace0_min1_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace0_min1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 3'd7));
assign pair_bundle0_source_trace0_min0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace0_min0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 4'd8));
assign pair_bundle0_trace1_clr_r = pair_bundle0_bus_dat_w[0];
assign pair_bundle0_trace1_clr_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 4'd9));
assign pair_bundle0_source_trace1_max3_r = pair_bundle0_bus_dat_w[0];
assign pair_bundle0_source_trace1_max3_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 4'd10));
assign pair_bundle0_source_trace1_max2_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace1_max2_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 4'd11));
assign pair_bundle0_source_trace1_max1_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace1_max1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 4'd12));
assign pair_bundle0_source_trace1_max0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace1_max0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 4'd13));
assign pair_bundle0_source_trace1_min3_r = pair_bundle0_bus_dat_w[0];
assign pair_bundle0_source_trace1_min3_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 4'd14));
assign pair_bundle0_source_trace1_min2_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace1_min2_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 4'd15));
assign pair_bundle0_source_trace1_min1_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace1_min1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd16));
assign pair_bundle0_source_trace1_min0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_source_trace1_min0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd17));
assign pair_bundle0_gpio_state1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_gpio_state1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd18));
assign pair_bundle0_gpio_state0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_gpio_state0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd19));
assign pair_bundle0_state_clr_r = pair_bundle0_bus_dat_w[0];
assign pair_bundle0_state_clr_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd20));
assign pair_bundle0_gpio_do0_en1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_gpio_do0_en1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd21));
assign pair_bundle0_gpio_do0_en0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_gpio_do0_en0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd22));
assign pair_bundle0_gpio_do1_en1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_gpio_do1_en1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd23));
assign pair_bundle0_gpio_do1_en0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_gpio_do1_en0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd24));
assign pair_bundle0_gpio_do2_en1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_gpio_do2_en1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd25));
assign pair_bundle0_gpio_do2_en0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_gpio_do2_en0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd26));
assign pair_bundle0_gpio_do3_en1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_gpio_do3_en1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd27));
assign pair_bundle0_gpio_do3_en0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_gpio_do3_en0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd28));
assign pair_bundle0_gpio_do4_en1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_gpio_do4_en1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd29));
assign pair_bundle0_gpio_do4_en0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_gpio_do4_en0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd30));
assign pair_bundle0_gpio_do5_en1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_gpio_do5_en1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 5'd31));
assign pair_bundle0_gpio_do5_en0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_gpio_do5_en0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 6'd32));
assign pair_bundle0_gpio_do6_en1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_gpio_do6_en1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 6'd33));
assign pair_bundle0_gpio_do6_en0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_gpio_do6_en0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 6'd34));
assign pair_bundle0_gpio_do7_en1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_gpio_do7_en1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 6'd35));
assign pair_bundle0_gpio_do7_en0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_gpio_do7_en0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 6'd36));
assign pair_bundle0_sink_accept_en1_r = pair_bundle0_bus_dat_w[5:0];
assign pair_bundle0_sink_accept_en1_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 6'd37));
assign pair_bundle0_sink_accept_en0_r = pair_bundle0_bus_dat_w[7:0];
assign pair_bundle0_sink_accept_en0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 6'd38));
assign pair_bundle0_sink_take_sel0_r = pair_bundle0_bus_dat_w[1:0];
assign pair_bundle0_sink_take_sel0_re = ((pair_bundle0_sel & pair_bundle0_bus_we) & (pair_bundle0_bus_adr[5:0] == 6'd39));
assign pair_bundle0_source_trace0_max3_w = pair_bundle0_max_status0[24];
assign pair_bundle0_source_trace0_max2_w = pair_bundle0_max_status0[23:16];
assign pair_bundle0_source_trace0_max1_w = pair_bundle0_max_status0[15:8];
assign pair_bundle0_source_trace0_max0_w = pair_bundle0_max_status0[7:0];
assign pair_bundle0_source_trace0_min3_w = pair_bundle0_min_status0[24];
assign pair_bundle0_source_trace0_min2_w = pair_bundle0_min_status0[23:16];
assign pair_bundle0_source_trace0_min1_w = pair_bundle0_min_status0[15:8];
assign pair_bundle0_source_trace0_min0_w = pair_bundle0_min_status0[7:0];
assign pair_bundle0_source_trace1_max3_w = pair_bundle0_max_status1[24];
assign pair_bundle0_source_trace1_max2_w = pair_bundle0_max_status1[23:16];
assign pair_bundle0_source_trace1_max1_w = pair_bundle0_max_status1[15:8];
assign pair_bundle0_source_trace1_max0_w = pair_bundle0_max_status1[7:0];
assign pair_bundle0_source_trace1_min3_w = pair_bundle0_min_status1[24];
assign pair_bundle0_source_trace1_min2_w = pair_bundle0_min_status1[23:16];
assign pair_bundle0_source_trace1_min1_w = pair_bundle0_min_status1[15:8];
assign pair_bundle0_source_trace1_min0_w = pair_bundle0_min_status1[7:0];
assign pair_bundle0_gpio_state1_w = pair_bundle0_state_status[13:8];
assign pair_bundle0_gpio_state0_w = pair_bundle0_state_status[7:0];
assign pair_bundle0_csrstorage0_storage = pair_bundle0_csrstorage0_storage_full[13:0];
assign pair_bundle0_gpio_do0_en1_w = pair_bundle0_csrstorage0_storage_full[13:8];
assign pair_bundle0_gpio_do0_en0_w = pair_bundle0_csrstorage0_storage_full[7:0];
assign pair_bundle0_csrstorage1_storage = pair_bundle0_csrstorage1_storage_full[13:0];
assign pair_bundle0_gpio_do1_en1_w = pair_bundle0_csrstorage1_storage_full[13:8];
assign pair_bundle0_gpio_do1_en0_w = pair_bundle0_csrstorage1_storage_full[7:0];
assign pair_bundle0_csrstorage2_storage = pair_bundle0_csrstorage2_storage_full[13:0];
assign pair_bundle0_gpio_do2_en1_w = pair_bundle0_csrstorage2_storage_full[13:8];
assign pair_bundle0_gpio_do2_en0_w = pair_bundle0_csrstorage2_storage_full[7:0];
assign pair_bundle0_csrstorage3_storage = pair_bundle0_csrstorage3_storage_full[13:0];
assign pair_bundle0_gpio_do3_en1_w = pair_bundle0_csrstorage3_storage_full[13:8];
assign pair_bundle0_gpio_do3_en0_w = pair_bundle0_csrstorage3_storage_full[7:0];
assign pair_bundle0_csrstorage4_storage = pair_bundle0_csrstorage4_storage_full[13:0];
assign pair_bundle0_gpio_do4_en1_w = pair_bundle0_csrstorage4_storage_full[13:8];
assign pair_bundle0_gpio_do4_en0_w = pair_bundle0_csrstorage4_storage_full[7:0];
assign pair_bundle0_csrstorage5_storage = pair_bundle0_csrstorage5_storage_full[13:0];
assign pair_bundle0_gpio_do5_en1_w = pair_bundle0_csrstorage5_storage_full[13:8];
assign pair_bundle0_gpio_do5_en0_w = pair_bundle0_csrstorage5_storage_full[7:0];
assign pair_bundle0_csrstorage6_storage = pair_bundle0_csrstorage6_storage_full[13:0];
assign pair_bundle0_gpio_do6_en1_w = pair_bundle0_csrstorage6_storage_full[13:8];
assign pair_bundle0_gpio_do6_en0_w = pair_bundle0_csrstorage6_storage_full[7:0];
assign pair_bundle0_csrstorage7_storage = pair_bundle0_csrstorage7_storage_full[13:0];
assign pair_bundle0_gpio_do7_en1_w = pair_bundle0_csrstorage7_storage_full[13:8];
assign pair_bundle0_gpio_do7_en0_w = pair_bundle0_csrstorage7_storage_full[7:0];
assign pair_bundle0_csrstorage8_storage = pair_bundle0_csrstorage8_storage_full[13:0];
assign pair_bundle0_sink_accept_en1_w = pair_bundle0_csrstorage8_storage_full[13:8];
assign pair_bundle0_sink_accept_en0_w = pair_bundle0_csrstorage8_storage_full[7:0];
assign pair_bundle0_csrstorage9_storage = pair_bundle0_csrstorage9_storage_full[1:0];
assign pair_bundle0_sink_take_sel0_w = pair_bundle0_csrstorage9_storage_full[1:0];
assign pair_bundle1_state = {pair_bundle1_flag4, pair_bundle1_flag3, pair_bundle1_flag2, pair_bundle1_flag1, pair_bundle1_flag0, pair_bundle1_i, 1'd1};
assign pair_bundle1_sig_status0 = pair_bundle1_trace0;
assign pair_bundle1_sig_status1 = pair_bundle1_trace1;
assign pair_bundle1_sel = (pair_bundle1_bus_adr[13:9] == 1'd0);
assign pair_bundle1_trace0_clr_r = pair_bundle1_bus_dat_w[0];
assign pair_bundle1_trace0_clr_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 1'd0));
assign pair_bundle1_source_trace0_max3_r = pair_bundle1_bus_dat_w[0];
assign pair_bundle1_source_trace0_max3_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 1'd1));
assign pair_bundle1_source_trace0_max2_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace0_max2_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 2'd2));
assign pair_bundle1_source_trace0_max1_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace0_max1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 2'd3));
assign pair_bundle1_source_trace0_max0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace0_max0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 3'd4));
assign pair_bundle1_source_trace0_min3_r = pair_bundle1_bus_dat_w[0];
assign pair_bundle1_source_trace0_min3_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 3'd5));
assign pair_bundle1_source_trace0_min2_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace0_min2_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 3'd6));
assign pair_bundle1_source_trace0_min1_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace0_min1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 3'd7));
assign pair_bundle1_source_trace0_min0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace0_min0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 4'd8));
assign pair_bundle1_trace1_clr_r = pair_bundle1_bus_dat_w[0];
assign pair_bundle1_trace1_clr_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 4'd9));
assign pair_bundle1_source_trace1_max3_r = pair_bundle1_bus_dat_w[0];
assign pair_bundle1_source_trace1_max3_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 4'd10));
assign pair_bundle1_source_trace1_max2_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace1_max2_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 4'd11));
assign pair_bundle1_source_trace1_max1_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace1_max1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 4'd12));
assign pair_bundle1_source_trace1_max0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace1_max0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 4'd13));
assign pair_bundle1_source_trace1_min3_r = pair_bundle1_bus_dat_w[0];
assign pair_bundle1_source_trace1_min3_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 4'd14));
assign pair_bundle1_source_trace1_min2_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace1_min2_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 4'd15));
assign pair_bundle1_source_trace1_min1_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace1_min1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd16));
assign pair_bundle1_source_trace1_min0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_source_trace1_min0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd17));
assign pair_bundle1_gpio_state1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_gpio_state1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd18));
assign pair_bundle1_gpio_state0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_gpio_state0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd19));
assign pair_bundle1_state_clr_r = pair_bundle1_bus_dat_w[0];
assign pair_bundle1_state_clr_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd20));
assign pair_bundle1_gpio_do0_en1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_gpio_do0_en1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd21));
assign pair_bundle1_gpio_do0_en0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_gpio_do0_en0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd22));
assign pair_bundle1_gpio_do1_en1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_gpio_do1_en1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd23));
assign pair_bundle1_gpio_do1_en0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_gpio_do1_en0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd24));
assign pair_bundle1_gpio_do2_en1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_gpio_do2_en1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd25));
assign pair_bundle1_gpio_do2_en0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_gpio_do2_en0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd26));
assign pair_bundle1_gpio_do3_en1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_gpio_do3_en1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd27));
assign pair_bundle1_gpio_do3_en0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_gpio_do3_en0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd28));
assign pair_bundle1_gpio_do4_en1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_gpio_do4_en1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd29));
assign pair_bundle1_gpio_do4_en0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_gpio_do4_en0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd30));
assign pair_bundle1_gpio_do5_en1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_gpio_do5_en1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 5'd31));
assign pair_bundle1_gpio_do5_en0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_gpio_do5_en0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 6'd32));
assign pair_bundle1_gpio_do6_en1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_gpio_do6_en1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 6'd33));
assign pair_bundle1_gpio_do6_en0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_gpio_do6_en0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 6'd34));
assign pair_bundle1_gpio_do7_en1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_gpio_do7_en1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 6'd35));
assign pair_bundle1_gpio_do7_en0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_gpio_do7_en0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 6'd36));
assign pair_bundle1_sink_accept_en1_r = pair_bundle1_bus_dat_w[5:0];
assign pair_bundle1_sink_accept_en1_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 6'd37));
assign pair_bundle1_sink_accept_en0_r = pair_bundle1_bus_dat_w[7:0];
assign pair_bundle1_sink_accept_en0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 6'd38));
assign pair_bundle1_sink_take_sel0_r = pair_bundle1_bus_dat_w[1:0];
assign pair_bundle1_sink_take_sel0_re = ((pair_bundle1_sel & pair_bundle1_bus_we) & (pair_bundle1_bus_adr[5:0] == 6'd39));
assign pair_bundle1_source_trace0_max3_w = pair_bundle1_max_status0[24];
assign pair_bundle1_source_trace0_max2_w = pair_bundle1_max_status0[23:16];
assign pair_bundle1_source_trace0_max1_w = pair_bundle1_max_status0[15:8];
assign pair_bundle1_source_trace0_max0_w = pair_bundle1_max_status0[7:0];
assign pair_bundle1_source_trace0_min3_w = pair_bundle1_min_status0[24];
assign pair_bundle1_source_trace0_min2_w = pair_bundle1_min_status0[23:16];
assign pair_bundle1_source_trace0_min1_w = pair_bundle1_min_status0[15:8];
assign pair_bundle1_source_trace0_min0_w = pair_bundle1_min_status0[7:0];
assign pair_bundle1_source_trace1_max3_w = pair_bundle1_max_status1[24];
assign pair_bundle1_source_trace1_max2_w = pair_bundle1_max_status1[23:16];
assign pair_bundle1_source_trace1_max1_w = pair_bundle1_max_status1[15:8];
assign pair_bundle1_source_trace1_max0_w = pair_bundle1_max_status1[7:0];
assign pair_bundle1_source_trace1_min3_w = pair_bundle1_min_status1[24];
assign pair_bundle1_source_trace1_min2_w = pair_bundle1_min_status1[23:16];
assign pair_bundle1_source_trace1_min1_w = pair_bundle1_min_status1[15:8];
assign pair_bundle1_source_trace1_min0_w = pair_bundle1_min_status1[7:0];
assign pair_bundle1_gpio_state1_w = pair_bundle1_state_status[13:8];
assign pair_bundle1_gpio_state0_w = pair_bundle1_state_status[7:0];
assign pair_bundle1_csrstorage0_storage = pair_bundle1_csrstorage0_storage_full[13:0];
assign pair_bundle1_gpio_do0_en1_w = pair_bundle1_csrstorage0_storage_full[13:8];
assign pair_bundle1_gpio_do0_en0_w = pair_bundle1_csrstorage0_storage_full[7:0];
assign pair_bundle1_csrstorage1_storage = pair_bundle1_csrstorage1_storage_full[13:0];
assign pair_bundle1_gpio_do1_en1_w = pair_bundle1_csrstorage1_storage_full[13:8];
assign pair_bundle1_gpio_do1_en0_w = pair_bundle1_csrstorage1_storage_full[7:0];
assign pair_bundle1_csrstorage2_storage = pair_bundle1_csrstorage2_storage_full[13:0];
assign pair_bundle1_gpio_do2_en1_w = pair_bundle1_csrstorage2_storage_full[13:8];
assign pair_bundle1_gpio_do2_en0_w = pair_bundle1_csrstorage2_storage_full[7:0];
assign pair_bundle1_csrstorage3_storage = pair_bundle1_csrstorage3_storage_full[13:0];
assign pair_bundle1_gpio_do3_en1_w = pair_bundle1_csrstorage3_storage_full[13:8];
assign pair_bundle1_gpio_do3_en0_w = pair_bundle1_csrstorage3_storage_full[7:0];
assign pair_bundle1_csrstorage4_storage = pair_bundle1_csrstorage4_storage_full[13:0];
assign pair_bundle1_gpio_do4_en1_w = pair_bundle1_csrstorage4_storage_full[13:8];
assign pair_bundle1_gpio_do4_en0_w = pair_bundle1_csrstorage4_storage_full[7:0];
assign pair_bundle1_csrstorage5_storage = pair_bundle1_csrstorage5_storage_full[13:0];
assign pair_bundle1_gpio_do5_en1_w = pair_bundle1_csrstorage5_storage_full[13:8];
assign pair_bundle1_gpio_do5_en0_w = pair_bundle1_csrstorage5_storage_full[7:0];
assign pair_bundle1_csrstorage6_storage = pair_bundle1_csrstorage6_storage_full[13:0];
assign pair_bundle1_gpio_do6_en1_w = pair_bundle1_csrstorage6_storage_full[13:8];
assign pair_bundle1_gpio_do6_en0_w = pair_bundle1_csrstorage6_storage_full[7:0];
assign pair_bundle1_csrstorage7_storage = pair_bundle1_csrstorage7_storage_full[13:0];
assign pair_bundle1_gpio_do7_en1_w = pair_bundle1_csrstorage7_storage_full[13:8];
assign pair_bundle1_gpio_do7_en0_w = pair_bundle1_csrstorage7_storage_full[7:0];
assign pair_bundle1_csrstorage8_storage = pair_bundle1_csrstorage8_storage_full[13:0];
assign pair_bundle1_sink_accept_en1_w = pair_bundle1_csrstorage8_storage_full[13:8];
assign pair_bundle1_sink_accept_en0_w = pair_bundle1_csrstorage8_storage_full[7:0];
assign pair_bundle1_csrstorage9_storage = pair_bundle1_csrstorage9_storage_full[1:0];
assign pair_bundle1_sink_take_sel0_w = pair_bundle1_csrstorage9_storage_full[1:0];
assign pair_bundle2_state = {pair_bundle2_flag4, pair_bundle2_flag3, pair_bundle2_flag2, pair_bundle2_flag1, pair_bundle2_flag0, pair_bundle2_i, 1'd1};
assign pair_bundle2_sig_status0 = pair_bundle2_trace0;
assign pair_bundle2_sig_status1 = pair_bundle2_trace1;
assign pair_bundle2_sel = (pair_bundle2_bus_adr[13:9] == 1'd0);
assign pair_bundle2_trace0_clr_r = pair_bundle2_bus_dat_w[0];
assign pair_bundle2_trace0_clr_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 1'd0));
assign pair_bundle2_source_trace0_max3_r = pair_bundle2_bus_dat_w[0];
assign pair_bundle2_source_trace0_max3_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 1'd1));
assign pair_bundle2_source_trace0_max2_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace0_max2_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 2'd2));
assign pair_bundle2_source_trace0_max1_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace0_max1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 2'd3));
assign pair_bundle2_source_trace0_max0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace0_max0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 3'd4));
assign pair_bundle2_source_trace0_min3_r = pair_bundle2_bus_dat_w[0];
assign pair_bundle2_source_trace0_min3_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 3'd5));
assign pair_bundle2_source_trace0_min2_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace0_min2_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 3'd6));
assign pair_bundle2_source_trace0_min1_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace0_min1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 3'd7));
assign pair_bundle2_source_trace0_min0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace0_min0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 4'd8));
assign pair_bundle2_trace1_clr_r = pair_bundle2_bus_dat_w[0];
assign pair_bundle2_trace1_clr_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 4'd9));
assign pair_bundle2_source_trace1_max3_r = pair_bundle2_bus_dat_w[0];
assign pair_bundle2_source_trace1_max3_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 4'd10));
assign pair_bundle2_source_trace1_max2_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace1_max2_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 4'd11));
assign pair_bundle2_source_trace1_max1_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace1_max1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 4'd12));
assign pair_bundle2_source_trace1_max0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace1_max0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 4'd13));
assign pair_bundle2_source_trace1_min3_r = pair_bundle2_bus_dat_w[0];
assign pair_bundle2_source_trace1_min3_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 4'd14));
assign pair_bundle2_source_trace1_min2_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace1_min2_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 4'd15));
assign pair_bundle2_source_trace1_min1_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace1_min1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd16));
assign pair_bundle2_source_trace1_min0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_source_trace1_min0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd17));
assign pair_bundle2_gpio_state1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_gpio_state1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd18));
assign pair_bundle2_gpio_state0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_gpio_state0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd19));
assign pair_bundle2_state_clr_r = pair_bundle2_bus_dat_w[0];
assign pair_bundle2_state_clr_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd20));
assign pair_bundle2_gpio_do0_en1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_gpio_do0_en1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd21));
assign pair_bundle2_gpio_do0_en0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_gpio_do0_en0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd22));
assign pair_bundle2_gpio_do1_en1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_gpio_do1_en1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd23));
assign pair_bundle2_gpio_do1_en0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_gpio_do1_en0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd24));
assign pair_bundle2_gpio_do2_en1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_gpio_do2_en1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd25));
assign pair_bundle2_gpio_do2_en0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_gpio_do2_en0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd26));
assign pair_bundle2_gpio_do3_en1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_gpio_do3_en1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd27));
assign pair_bundle2_gpio_do3_en0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_gpio_do3_en0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd28));
assign pair_bundle2_gpio_do4_en1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_gpio_do4_en1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd29));
assign pair_bundle2_gpio_do4_en0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_gpio_do4_en0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd30));
assign pair_bundle2_gpio_do5_en1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_gpio_do5_en1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 5'd31));
assign pair_bundle2_gpio_do5_en0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_gpio_do5_en0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 6'd32));
assign pair_bundle2_gpio_do6_en1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_gpio_do6_en1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 6'd33));
assign pair_bundle2_gpio_do6_en0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_gpio_do6_en0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 6'd34));
assign pair_bundle2_gpio_do7_en1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_gpio_do7_en1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 6'd35));
assign pair_bundle2_gpio_do7_en0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_gpio_do7_en0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 6'd36));
assign pair_bundle2_sink_accept_en1_r = pair_bundle2_bus_dat_w[5:0];
assign pair_bundle2_sink_accept_en1_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 6'd37));
assign pair_bundle2_sink_accept_en0_r = pair_bundle2_bus_dat_w[7:0];
assign pair_bundle2_sink_accept_en0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 6'd38));
assign pair_bundle2_sink_take_sel0_r = pair_bundle2_bus_dat_w[1:0];
assign pair_bundle2_sink_take_sel0_re = ((pair_bundle2_sel & pair_bundle2_bus_we) & (pair_bundle2_bus_adr[5:0] == 6'd39));
assign pair_bundle2_source_trace0_max3_w = pair_bundle2_max_status0[24];
assign pair_bundle2_source_trace0_max2_w = pair_bundle2_max_status0[23:16];
assign pair_bundle2_source_trace0_max1_w = pair_bundle2_max_status0[15:8];
assign pair_bundle2_source_trace0_max0_w = pair_bundle2_max_status0[7:0];
assign pair_bundle2_source_trace0_min3_w = pair_bundle2_min_status0[24];
assign pair_bundle2_source_trace0_min2_w = pair_bundle2_min_status0[23:16];
assign pair_bundle2_source_trace0_min1_w = pair_bundle2_min_status0[15:8];
assign pair_bundle2_source_trace0_min0_w = pair_bundle2_min_status0[7:0];
assign pair_bundle2_source_trace1_max3_w = pair_bundle2_max_status1[24];
assign pair_bundle2_source_trace1_max2_w = pair_bundle2_max_status1[23:16];
assign pair_bundle2_source_trace1_max1_w = pair_bundle2_max_status1[15:8];
assign pair_bundle2_source_trace1_max0_w = pair_bundle2_max_status1[7:0];
assign pair_bundle2_source_trace1_min3_w = pair_bundle2_min_status1[24];
assign pair_bundle2_source_trace1_min2_w = pair_bundle2_min_status1[23:16];
assign pair_bundle2_source_trace1_min1_w = pair_bundle2_min_status1[15:8];
assign pair_bundle2_source_trace1_min0_w = pair_bundle2_min_status1[7:0];
assign pair_bundle2_gpio_state1_w = pair_bundle2_state_status[13:8];
assign pair_bundle2_gpio_state0_w = pair_bundle2_state_status[7:0];
assign pair_bundle2_csrstorage10_storage = pair_bundle2_csrstorage10_storage_full[13:0];
assign pair_bundle2_gpio_do0_en1_w = pair_bundle2_csrstorage10_storage_full[13:8];
assign pair_bundle2_gpio_do0_en0_w = pair_bundle2_csrstorage10_storage_full[7:0];
assign pair_bundle2_csrstorage11_storage = pair_bundle2_csrstorage11_storage_full[13:0];
assign pair_bundle2_gpio_do1_en1_w = pair_bundle2_csrstorage11_storage_full[13:8];
assign pair_bundle2_gpio_do1_en0_w = pair_bundle2_csrstorage11_storage_full[7:0];
assign pair_bundle2_csrstorage12_storage = pair_bundle2_csrstorage12_storage_full[13:0];
assign pair_bundle2_gpio_do2_en1_w = pair_bundle2_csrstorage12_storage_full[13:8];
assign pair_bundle2_gpio_do2_en0_w = pair_bundle2_csrstorage12_storage_full[7:0];
assign pair_bundle2_csrstorage13_storage = pair_bundle2_csrstorage13_storage_full[13:0];
assign pair_bundle2_gpio_do3_en1_w = pair_bundle2_csrstorage13_storage_full[13:8];
assign pair_bundle2_gpio_do3_en0_w = pair_bundle2_csrstorage13_storage_full[7:0];
assign pair_bundle2_csrstorage14_storage = pair_bundle2_csrstorage14_storage_full[13:0];
assign pair_bundle2_gpio_do4_en1_w = pair_bundle2_csrstorage14_storage_full[13:8];
assign pair_bundle2_gpio_do4_en0_w = pair_bundle2_csrstorage14_storage_full[7:0];
assign pair_bundle2_csrstorage15_storage = pair_bundle2_csrstorage15_storage_full[13:0];
assign pair_bundle2_gpio_do5_en1_w = pair_bundle2_csrstorage15_storage_full[13:8];
assign pair_bundle2_gpio_do5_en0_w = pair_bundle2_csrstorage15_storage_full[7:0];
assign pair_bundle2_csrstorage16_storage = pair_bundle2_csrstorage16_storage_full[13:0];
assign pair_bundle2_gpio_do6_en1_w = pair_bundle2_csrstorage16_storage_full[13:8];
assign pair_bundle2_gpio_do6_en0_w = pair_bundle2_csrstorage16_storage_full[7:0];
assign pair_bundle2_csrstorage17_storage = pair_bundle2_csrstorage17_storage_full[13:0];
assign pair_bundle2_gpio_do7_en1_w = pair_bundle2_csrstorage17_storage_full[13:8];
assign pair_bundle2_gpio_do7_en0_w = pair_bundle2_csrstorage17_storage_full[7:0];
assign pair_bundle2_csrstorage18_storage = pair_bundle2_csrstorage18_storage_full[13:0];
assign pair_bundle2_sink_accept_en1_w = pair_bundle2_csrstorage18_storage_full[13:8];
assign pair_bundle2_sink_accept_en0_w = pair_bundle2_csrstorage18_storage_full[7:0];
assign pair_bundle2_csrstorage19_storage = pair_bundle2_csrstorage19_storage_full[1:0];
assign pair_bundle2_sink_take_sel0_w = pair_bundle2_csrstorage19_storage_full[1:0];

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	array_muxed0 <= 25'sd0;
	case (pair_bundle0_csrstorage9_storage)
		1'd0: begin
			array_muxed0 <= 1'd0;
		end
		1'd1: begin
			array_muxed0 <= pair_bundle0_trace0;
		end
		default: begin
			array_muxed0 <= pair_bundle0_trace1;
		end
	endcase
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_1;
// synthesis translate_on
always @(*) begin
	array_muxed1 <= 25'sd0;
	case (pair_bundle1_csrstorage9_storage)
		1'd0: begin
			array_muxed1 <= 1'd0;
		end
		1'd1: begin
			array_muxed1 <= pair_bundle1_trace0;
		end
		default: begin
			array_muxed1 <= pair_bundle1_trace1;
		end
	endcase
// synthesis translate_off
	dummy_d_1 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_2;
// synthesis translate_on
always @(*) begin
	array_muxed2 <= 25'sd0;
	case (pair_bundle2_csrstorage19_storage)
		1'd0: begin
			array_muxed2 <= 1'd0;
		end
		1'd1: begin
			array_muxed2 <= pair_bundle2_trace0;
		end
		default: begin
			array_muxed2 <= pair_bundle2_trace1;
		end
	endcase
// synthesis translate_off
	dummy_d_2 <= dummy_s;
// synthesis translate_on
end

always @(posedge sys_clk) begin
	if (pair_bundle0_state_clr_re) begin
		pair_bundle0_state_status <= 1'd0;
	end else begin
		pair_bundle0_state_status <= (pair_bundle0_state_status | pair_bundle0_state);
	end
	pair_bundle0_o[0] <= ((pair_bundle0_state & pair_bundle0_csrstorage0_storage) != 1'd0);
	pair_bundle0_o[1] <= ((pair_bundle0_state & pair_bundle0_csrstorage1_storage) != 1'd0);
	pair_bundle0_o[2] <= ((pair_bundle0_state & pair_bundle0_csrstorage2_storage) != 1'd0);
	pair_bundle0_o[3] <= ((pair_bundle0_state & pair_bundle0_csrstorage3_storage) != 1'd0);
	pair_bundle0_o[4] <= ((pair_bundle0_state & pair_bundle0_csrstorage4_storage) != 1'd0);
	pair_bundle0_o[5] <= ((pair_bundle0_state & pair_bundle0_csrstorage5_storage) != 1'd0);
	pair_bundle0_o[6] <= ((pair_bundle0_state & pair_bundle0_csrstorage6_storage) != 1'd0);
	pair_bundle0_o[7] <= ((pair_bundle0_state & pair_bundle0_csrstorage7_storage) != 1'd0);
	if (($signed({1'd0, pair_bundle0_trace0_clr_re}) | ($signed({1'd0, pair_bundle0_max_status0}) < pair_bundle0_trace0))) begin
		pair_bundle0_max_status0 <= pair_bundle0_trace0;
	end
	if (($signed({1'd0, pair_bundle0_trace0_clr_re}) | ($signed({1'd0, pair_bundle0_min_status0}) > pair_bundle0_trace0))) begin
		pair_bundle0_min_status0 <= pair_bundle0_trace0;
	end
	if (($signed({1'd0, pair_bundle0_trace1_clr_re}) | ($signed({1'd0, pair_bundle0_max_status1}) < pair_bundle0_trace1))) begin
		pair_bundle0_max_status1 <= pair_bundle0_trace1;
	end
	if (($signed({1'd0, pair_bundle0_trace1_clr_re}) | ($signed({1'd0, pair_bundle0_min_status1}) > pair_bundle0_trace1))) begin
		pair_bundle0_min_status1 <= pair_bundle0_trace1;
	end
	pair_bundle0_accept <= ((pair_bundle0_state & pair_bundle0_csrstorage8_storage) != 1'd0);
	pair_bundle0_take <= array_muxed0;
	pair_bundle0_bus_dat_r <= 1'd0;
	if (pair_bundle0_sel) begin
		case (pair_bundle0_bus_adr[5:0])
			1'd0: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_trace0_clr_w;
			end
			1'd1: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace0_max3_w;
			end
			2'd2: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace0_max2_w;
			end
			2'd3: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace0_max1_w;
			end
			3'd4: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace0_max0_w;
			end
			3'd5: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace0_min3_w;
			end
			3'd6: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace0_min2_w;
			end
			3'd7: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace0_min1_w;
			end
			4'd8: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace0_min0_w;
			end
			4'd9: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_trace1_clr_w;
			end
			4'd10: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace1_max3_w;
			end
			4'd11: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace1_max2_w;
			end
			4'd12: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace1_max1_w;
			end
			4'd13: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace1_max0_w;
			end
			4'd14: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace1_min3_w;
			end
			4'd15: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace1_min2_w;
			end
			5'd16: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace1_min1_w;
			end
			5'd17: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_source_trace1_min0_w;
			end
			5'd18: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_state1_w;
			end
			5'd19: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_state0_w;
			end
			5'd20: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_state_clr_w;
			end
			5'd21: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do0_en1_w;
			end
			5'd22: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do0_en0_w;
			end
			5'd23: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do1_en1_w;
			end
			5'd24: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do1_en0_w;
			end
			5'd25: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do2_en1_w;
			end
			5'd26: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do2_en0_w;
			end
			5'd27: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do3_en1_w;
			end
			5'd28: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do3_en0_w;
			end
			5'd29: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do4_en1_w;
			end
			5'd30: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do4_en0_w;
			end
			5'd31: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do5_en1_w;
			end
			6'd32: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do5_en0_w;
			end
			6'd33: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do6_en1_w;
			end
			6'd34: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do6_en0_w;
			end
			6'd35: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do7_en1_w;
			end
			6'd36: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_gpio_do7_en0_w;
			end
			6'd37: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_sink_accept_en1_w;
			end
			6'd38: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_sink_accept_en0_w;
			end
			6'd39: begin
				pair_bundle0_bus_dat_r <= pair_bundle0_sink_take_sel0_w;
			end
		endcase
	end
	if (pair_bundle0_gpio_do0_en1_re) begin
		pair_bundle0_csrstorage0_storage_full[13:8] <= pair_bundle0_gpio_do0_en1_r;
	end
	if (pair_bundle0_gpio_do0_en0_re) begin
		pair_bundle0_csrstorage0_storage_full[7:0] <= pair_bundle0_gpio_do0_en0_r;
	end
	pair_bundle0_csrstorage0_re <= pair_bundle0_gpio_do0_en0_re;
	if (pair_bundle0_gpio_do1_en1_re) begin
		pair_bundle0_csrstorage1_storage_full[13:8] <= pair_bundle0_gpio_do1_en1_r;
	end
	if (pair_bundle0_gpio_do1_en0_re) begin
		pair_bundle0_csrstorage1_storage_full[7:0] <= pair_bundle0_gpio_do1_en0_r;
	end
	pair_bundle0_csrstorage1_re <= pair_bundle0_gpio_do1_en0_re;
	if (pair_bundle0_gpio_do2_en1_re) begin
		pair_bundle0_csrstorage2_storage_full[13:8] <= pair_bundle0_gpio_do2_en1_r;
	end
	if (pair_bundle0_gpio_do2_en0_re) begin
		pair_bundle0_csrstorage2_storage_full[7:0] <= pair_bundle0_gpio_do2_en0_r;
	end
	pair_bundle0_csrstorage2_re <= pair_bundle0_gpio_do2_en0_re;
	if (pair_bundle0_gpio_do3_en1_re) begin
		pair_bundle0_csrstorage3_storage_full[13:8] <= pair_bundle0_gpio_do3_en1_r;
	end
	if (pair_bundle0_gpio_do3_en0_re) begin
		pair_bundle0_csrstorage3_storage_full[7:0] <= pair_bundle0_gpio_do3_en0_r;
	end
	pair_bundle0_csrstorage3_re <= pair_bundle0_gpio_do3_en0_re;
	if (pair_bundle0_gpio_do4_en1_re) begin
		pair_bundle0_csrstorage4_storage_full[13:8] <= pair_bundle0_gpio_do4_en1_r;
	end
	if (pair_bundle0_gpio_do4_en0_re) begin
		pair_bundle0_csrstorage4_storage_full[7:0] <= pair_bundle0_gpio_do4_en0_r;
	end
	pair_bundle0_csrstorage4_re <= pair_bundle0_gpio_do4_en0_re;
	if (pair_bundle0_gpio_do5_en1_re) begin
		pair_bundle0_csrstorage5_storage_full[13:8] <= pair_bundle0_gpio_do5_en1_r;
	end
	if (pair_bundle0_gpio_do5_en0_re) begin
		pair_bundle0_csrstorage5_storage_full[7:0] <= pair_bundle0_gpio_do5_en0_r;
	end
	pair_bundle0_csrstorage5_re <= pair_bundle0_gpio_do5_en0_re;
	if (pair_bundle0_gpio_do6_en1_re) begin
		pair_bundle0_csrstorage6_storage_full[13:8] <= pair_bundle0_gpio_do6_en1_r;
	end
	if (pair_bundle0_gpio_do6_en0_re) begin
		pair_bundle0_csrstorage6_storage_full[7:0] <= pair_bundle0_gpio_do6_en0_r;
	end
	pair_bundle0_csrstorage6_re <= pair_bundle0_gpio_do6_en0_re;
	if (pair_bundle0_gpio_do7_en1_re) begin
		pair_bundle0_csrstorage7_storage_full[13:8] <= pair_bundle0_gpio_do7_en1_r;
	end
	if (pair_bundle0_gpio_do7_en0_re) begin
		pair_bundle0_csrstorage7_storage_full[7:0] <= pair_bundle0_gpio_do7_en0_r;
	end
	pair_bundle0_csrstorage7_re <= pair_bundle0_gpio_do7_en0_re;
	if (pair_bundle0_sink_accept_en1_re) begin
		pair_bundle0_csrstorage8_storage_full[13:8] <= pair_bundle0_sink_accept_en1_r;
	end
	if (pair_bundle0_sink_accept_en0_re) begin
		pair_bundle0_csrstorage8_storage_full[7:0] <= pair_bundle0_sink_accept_en0_r;
	end
	pair_bundle0_csrstorage8_re <= pair_bundle0_sink_accept_en0_re;
	if (pair_bundle0_sink_take_sel0_re) begin
		pair_bundle0_csrstorage9_storage_full[1:0] <= pair_bundle0_sink_take_sel0_r;
	end
	pair_bundle0_csrstorage9_re <= pair_bundle0_sink_take_sel0_re;
	if (pair_bundle1_state_clr_re) begin
		pair_bundle1_state_status <= 1'd0;
	end else begin
		pair_bundle1_state_status <= (pair_bundle1_state_status | pair_bundle1_state);
	end
	pair_bundle1_o[0] <= ((pair_bundle1_state & pair_bundle1_csrstorage0_storage) != 1'd0);
	pair_bundle1_o[1] <= ((pair_bundle1_state & pair_bundle1_csrstorage1_storage) != 1'd0);
	pair_bundle1_o[2] <= ((pair_bundle1_state & pair_bundle1_csrstorage2_storage) != 1'd0);
	pair_bundle1_o[3] <= ((pair_bundle1_state & pair_bundle1_csrstorage3_storage) != 1'd0);
	pair_bundle1_o[4] <= ((pair_bundle1_state & pair_bundle1_csrstorage4_storage) != 1'd0);
	pair_bundle1_o[5] <= ((pair_bundle1_state & pair_bundle1_csrstorage5_storage) != 1'd0);
	pair_bundle1_o[6] <= ((pair_bundle1_state & pair_bundle1_csrstorage6_storage) != 1'd0);
	pair_bundle1_o[7] <= ((pair_bundle1_state & pair_bundle1_csrstorage7_storage) != 1'd0);
	if (($signed({1'd0, pair_bundle1_trace0_clr_re}) | ($signed({1'd0, pair_bundle1_max_status0}) < pair_bundle1_trace0))) begin
		pair_bundle1_max_status0 <= pair_bundle1_trace0;
	end
	if (($signed({1'd0, pair_bundle1_trace0_clr_re}) | ($signed({1'd0, pair_bundle1_min_status0}) > pair_bundle1_trace0))) begin
		pair_bundle1_min_status0 <= pair_bundle1_trace0;
	end
	if (($signed({1'd0, pair_bundle1_trace1_clr_re}) | ($signed({1'd0, pair_bundle1_max_status1}) < pair_bundle1_trace1))) begin
		pair_bundle1_max_status1 <= pair_bundle1_trace1;
	end
	if (($signed({1'd0, pair_bundle1_trace1_clr_re}) | ($signed({1'd0, pair_bundle1_min_status1}) > pair_bundle1_trace1))) begin
		pair_bundle1_min_status1 <= pair_bundle1_trace1;
	end
	pair_bundle1_accept <= ((pair_bundle1_state & pair_bundle1_csrstorage8_storage) != 1'd0);
	pair_bundle1_take <= array_muxed1;
	pair_bundle1_bus_dat_r <= 1'd0;
	if (pair_bundle1_sel) begin
		case (pair_bundle1_bus_adr[5:0])
			1'd0: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_trace0_clr_w;
			end
			1'd1: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace0_max3_w;
			end
			2'd2: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace0_max2_w;
			end
			2'd3: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace0_max1_w;
			end
			3'd4: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace0_max0_w;
			end
			3'd5: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace0_min3_w;
			end
			3'd6: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace0_min2_w;
			end
			3'd7: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace0_min1_w;
			end
			4'd8: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace0_min0_w;
			end
			4'd9: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_trace1_clr_w;
			end
			4'd10: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace1_max3_w;
			end
			4'd11: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace1_max2_w;
			end
			4'd12: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace1_max1_w;
			end
			4'd13: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace1_max0_w;
			end
			4'd14: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace1_min3_w;
			end
			4'd15: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace1_min2_w;
			end
			5'd16: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace1_min1_w;
			end
			5'd17: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_source_trace1_min0_w;
			end
			5'd18: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_state1_w;
			end
			5'd19: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_state0_w;
			end
			5'd20: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_state_clr_w;
			end
			5'd21: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do0_en1_w;
			end
			5'd22: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do0_en0_w;
			end
			5'd23: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do1_en1_w;
			end
			5'd24: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do1_en0_w;
			end
			5'd25: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do2_en1_w;
			end
			5'd26: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do2_en0_w;
			end
			5'd27: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do3_en1_w;
			end
			5'd28: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do3_en0_w;
			end
			5'd29: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do4_en1_w;
			end
			5'd30: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do4_en0_w;
			end
			5'd31: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do5_en1_w;
			end
			6'd32: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do5_en0_w;
			end
			6'd33: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do6_en1_w;
			end
			6'd34: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do6_en0_w;
			end
			6'd35: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do7_en1_w;
			end
			6'd36: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_gpio_do7_en0_w;
			end
			6'd37: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_sink_accept_en1_w;
			end
			6'd38: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_sink_accept_en0_w;
			end
			6'd39: begin
				pair_bundle1_bus_dat_r <= pair_bundle1_sink_take_sel0_w;
			end
		endcase
	end
	if (pair_bundle1_gpio_do0_en1_re) begin
		pair_bundle1_csrstorage0_storage_full[13:8] <= pair_bundle1_gpio_do0_en1_r;
	end
	if (pair_bundle1_gpio_do0_en0_re) begin
		pair_bundle1_csrstorage0_storage_full[7:0] <= pair_bundle1_gpio_do0_en0_r;
	end
	pair_bundle1_csrstorage0_re <= pair_bundle1_gpio_do0_en0_re;
	if (pair_bundle1_gpio_do1_en1_re) begin
		pair_bundle1_csrstorage1_storage_full[13:8] <= pair_bundle1_gpio_do1_en1_r;
	end
	if (pair_bundle1_gpio_do1_en0_re) begin
		pair_bundle1_csrstorage1_storage_full[7:0] <= pair_bundle1_gpio_do1_en0_r;
	end
	pair_bundle1_csrstorage1_re <= pair_bundle1_gpio_do1_en0_re;
	if (pair_bundle1_gpio_do2_en1_re) begin
		pair_bundle1_csrstorage2_storage_full[13:8] <= pair_bundle1_gpio_do2_en1_r;
	end
	if (pair_bundle1_gpio_do2_en0_re) begin
		pair_bundle1_csrstorage2_storage_full[7:0] <= pair_bundle1_gpio_do2_en0_r;
	end
	pair_bundle1_csrstorage2_re <= pair_bundle1_gpio_do2_en0_re;
	if (pair_bundle1_gpio_do3_en1_re) begin
		pair_bundle1_csrstorage3_storage_full[13:8] <= pair_bundle1_gpio_do3_en1_r;
	end
	if (pair_bundle1_gpio_do3_en0_re) begin
		pair_bundle1_csrstorage3_storage_full[7:0] <= pair_bundle1_gpio_do3_en0_r;
	end
	pair_bundle1_csrstorage3_re <= pair_bundle1_gpio_do3_en0_re;
	if (pair_bundle1_gpio_do4_en1_re) begin
		pair_bundle1_csrstorage4_storage_full[13:8] <= pair_bundle1_gpio_do4_en1_r;
	end
	if (pair_bundle1_gpio_do4_en0_re) begin
		pair_bundle1_csrstorage4_storage_full[7:0] <= pair_bundle1_gpio_do4_en0_r;
	end
	pair_bundle1_csrstorage4_re <= pair_bundle1_gpio_do4_en0_re;
	if (pair_bundle1_gpio_do5_en1_re) begin
		pair_bundle1_csrstorage5_storage_full[13:8] <= pair_bundle1_gpio_do5_en1_r;
	end
	if (pair_bundle1_gpio_do5_en0_re) begin
		pair_bundle1_csrstorage5_storage_full[7:0] <= pair_bundle1_gpio_do5_en0_r;
	end
	pair_bundle1_csrstorage5_re <= pair_bundle1_gpio_do5_en0_re;
	if (pair_bundle1_gpio_do6_en1_re) begin
		pair_bundle1_csrstorage6_storage_full[13:8] <= pair_bundle1_gpio_do6_en1_r;
	end
	if (pair_bundle1_gpio_do6_en0_re) begin
		pair_bundle1_csrstorage6_storage_full[7:0] <= pair_bundle1_gpio_do6_en0_r;
	end
	pair_bundle1_csrstorage6_re <= pair_bundle1_gpio_do6_en0_re;
	if (pair_bundle1_gpio_do7_en1_re) begin
		pair_bundle1_csrstorage7_storage_full[13:8] <= pair_bundle1_gpio_do7_en1_r;
	end
	if (pair_bundle1_gpio_do7_en0_re) begin
		pair_bundle1_csrstorage7_storage_full[7:0] <= pair_bundle1_gpio_do7_en0_r;
	end
	pair_bundle1_csrstorage7_re <= pair_bundle1_gpio_do7_en0_re;
	if (pair_bundle1_sink_accept_en1_re) begin
		pair_bundle1_csrstorage8_storage_full[13:8] <= pair_bundle1_sink_accept_en1_r;
	end
	if (pair_bundle1_sink_accept_en0_re) begin
		pair_bundle1_csrstorage8_storage_full[7:0] <= pair_bundle1_sink_accept_en0_r;
	end
	pair_bundle1_csrstorage8_re <= pair_bundle1_sink_accept_en0_re;
	if (pair_bundle1_sink_take_sel0_re) begin
		pair_bundle1_csrstorage9_storage_full[1:0] <= pair_bundle1_sink_take_sel0_r;
	end
	pair_bundle1_csrstorage9_re <= pair_bundle1_sink_take_sel0_re;
	if (pair_bundle2_state_clr_re) begin
		pair_bundle2_state_status <= 1'd0;
	end else begin
		pair_bundle2_state_status <= (pair_bundle2_state_status | pair_bundle2_state);
	end
	pair_bundle2_gpio_status_state_s1 <= pair_bundle2_state;
	pair_bundle2_gpio_status_mask_s1_0 <= pair_bundle2_csrstorage10_storage;
	pair_bundle2_o[0] <= ((pair_bundle2_gpio_status_state_s1 & pair_bundle2_gpio_status_mask_s1_0) != 1'd0);
	pair_bundle2_gpio_status_mask_s1_1 <= pair_bundle2_csrstorage11_storage;
	pair_bundle2_o[1] <= ((pair_bundle2_gpio_status_state_s1 & pair_bundle2_gpio_status_mask_s1_1) != 1'd0);
	pair_bundle2_gpio_status_mask_s1_2 <= pair_bundle2_csrstorage12_storage;
	pair_bundle2_o[2] <= ((pair_bundle2_gpio_status_state_s1 & pair_bundle2_gpio_status_mask_s1_2) != 1'd0);
	pair_bundle2_gpio_status_mask_s1_3 <= pair_bundle2_csrstorage13_storage;
	pair_bundle2_o[3] <= ((pair_bundle2_gpio_status_state_s1 & pair_bundle2_gpio_status_mask_s1_3) != 1'd0);
	pair_bundle2_gpio_status_mask_s1_4 <= pair_bundle2_csrstorage14_storage;
	pair_bundle2_o[4] <= ((pair_bundle2_gpio_status_state_s1 & pair_bundle2_gpio_status_mask_s1_4) != 1'd0);
	pair_bundle2_gpio_status_mask_s1_5 <= pair_bundle2_csrstorage15_storage;
	pair_bundle2_o[5] <= ((pair_bundle2_gpio_status_state_s1 & pair_bundle2_gpio_status_mask_s1_5) != 1'd0);
	pair_bundle2_gpio_status_mask_s1_6 <= pair_bundle2_csrstorage16_storage;
	pair_bundle2_o[6] <= ((pair_bundle2_gpio_status_state_s1 & pair_bundle2_gpio_status_mask_s1_6) != 1'd0);
	pair_bundle2_gpio_status_mask_s1_7 <= pair_bundle2_csrstorage17_storage;
	pair_bundle2_o[7] <= ((pair_bundle2_gpio_status_state_s1 & pair_bundle2_gpio_status_mask_s1_7) != 1'd0);
	if (($signed({1'd0, pair_bundle2_trace0_clr_re}) | ($signed({1'd0, pair_bundle2_max_status0}) < pair_bundle2_trace0))) begin
		pair_bundle2_max_status0 <= pair_bundle2_trace0;
	end
	if (($signed({1'd0, pair_bundle2_trace0_clr_re}) | ($signed({1'd0, pair_bundle2_min_status0}) > pair_bundle2_trace0))) begin
		pair_bundle2_min_status0 <= pair_bundle2_trace0;
	end
	if (($signed({1'd0, pair_bundle2_trace1_clr_re}) | ($signed({1'd0, pair_bundle2_max_status1}) < pair_bundle2_trace1))) begin
		pair_bundle2_max_status1 <= pair_bundle2_trace1;
	end
	if (($signed({1'd0, pair_bundle2_trace1_clr_re}) | ($signed({1'd0, pair_bundle2_min_status1}) > pair_bundle2_trace1))) begin
		pair_bundle2_min_status1 <= pair_bundle2_trace1;
	end
	pair_bundle2_accept <= ((pair_bundle2_state & pair_bundle2_csrstorage18_storage) != 1'd0);
	pair_bundle2_take <= array_muxed2;
	pair_bundle2_bus_dat_r <= 1'd0;
	if (pair_bundle2_sel) begin
		case (pair_bundle2_bus_adr[5:0])
			1'd0: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_trace0_clr_w;
			end
			1'd1: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace0_max3_w;
			end
			2'd2: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace0_max2_w;
			end
			2'd3: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace0_max1_w;
			end
			3'd4: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace0_max0_w;
			end
			3'd5: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace0_min3_w;
			end
			3'd6: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace0_min2_w;
			end
			3'd7: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace0_min1_w;
			end
			4'd8: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace0_min0_w;
			end
			4'd9: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_trace1_clr_w;
			end
			4'd10: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace1_max3_w;
			end
			4'd11: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace1_max2_w;
			end
			4'd12: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace1_max1_w;
			end
			4'd13: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace1_max0_w;
			end
			4'd14: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace1_min3_w;
			end
			4'd15: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace1_min2_w;
			end
			5'd16: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace1_min1_w;
			end
			5'd17: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_source_trace1_min0_w;
			end
			5'd18: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_state1_w;
			end
			5'd19: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_state0_w;
			end
			5'd20: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_state_clr_w;
			end
			5'd21: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do0_en1_w;
			end
			5'd22: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do0_en0_w;
			end
			5'd23: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do1_en1_w;
			end
			5'd24: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do1_en0_w;
			end
			5'd25: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do2_en1_w;
			end
			5'd26: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do2_en0_w;
			end
			5'd27: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do3_en1_w;
			end
			5'd28: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do3_en0_w;
			end
			5'd29: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do4_en1_w;
			end
			5'd30: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do4_en0_w;
			end
			5'd31: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do5_en1_w;
			end
			6'd32: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do5_en0_w;
			end
			6'd33: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do6_en1_w;
			end
			6'd34: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do6_en0_w;
			end
			6'd35: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do7_en1_w;
			end
			6'd36: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_gpio_do7_en0_w;
			end
			6'd37: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_sink_accept_en1_w;
			end
			6'd38: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_sink_accept_en0_w;
			end
			6'd39: begin
				pair_bundle2_bus_dat_r <= pair_bundle2_sink_take_sel0_w;
			end
		endcase
	end
	if (pair_bundle2_gpio_do0_en1_re) begin
		pair_bundle2_csrstorage10_storage_full[13:8] <= pair_bundle2_gpio_do0_en1_r;
	end
	if (pair_bundle2_gpio_do0_en0_re) begin
		pair_bundle2_csrstorage10_storage_full[7:0] <= pair_bundle2_gpio_do0_en0_r;
	end
	pair_bundle2_csrstorage10_re <= pair_bundle2_gpio_do0_en0_re;
	if (pair_bundle2_gpio_do1_en1_re) begin
		pair_bundle2_csrstorage11_storage_full[13:8] <= pair_bundle2_gpio_do1_en1_r;
	end
	if (pair_bundle2_gpio_do1_en0_re) begin
		pair_bundle2_csrstorage11_storage_full[7:0] <= pair_bundle2_gpio_do1_en0_r;
	end
	pair_bundle2_csrstorage11_re <= pair_bundle2_gpio_do1_en0_re;
	if (pair_bundle2_gpio_do2_en1_re) begin
		pair_bundle2_csrstorage12_storage_full[13:8] <= pair_bundle2_gpio_do2_en1_r;
	end
	if (pair_bundle2_gpio_do2_en0_re) begin
		pair_bundle2_csrstorage12_storage_full[7:0] <= pair_bundle2_gpio_do2_en0_r;
	end
	pair_bundle2_csrstorage12_re <= pair_bundle2_gpio_do2_en0_re;
	if (pair_bundle2_gpio_do3_en1_re) begin
		pair_bundle2_csrstorage13_storage_full[13:8] <= pair_bundle2_gpio_do3_en1_r;
	end
	if (pair_bundle2_gpio_do3_en0_re) begin
		pair_bundle2_csrstorage13_storage_full[7:0] <= pair_bundle2_gpio_do3_en0_r;
	end
	pair_bundle2_csrstorage13_re <= pair_bundle2_gpio_do3_en0_re;
	if (pair_bundle2_gpio_do4_en1_re) begin
		pair_bundle2_csrstorage14_storage_full[13:8] <= pair_bundle2_gpio_do4_en1_r;
	end
	if (pair_bundle2_gpio_do4_en0_re) begin
		pair_bundle2_csrstorage14_storage_full[7:0] <= pair_bundle2_gpio_do4_en0_r;
	end
	pair_bundle2_csrstorage14_re <= pair_bundle2_gpio_do4_en0_re;
	if (pair_bundle2_gpio_do5_en1_re) begin
		pair_bundle2_csrstorage15_storage_full[13:8] <= pair_bundle2_gpio_do5_en1_r;
	end
	if (pair_bundle2_gpio_do5_en0_re) begin
		pair_bundle2_csrstorage15_storage_full[7:0] <= pair_bundle2_gpio_do5_en0_r;
	end
	pair_bundle2_csrstorage15_re <= pair_bundle2_gpio_do5_en0_re;
	if (pair_bundle2_gpio_do6_en1_re) begin
		pair_bundle2_csrstorage16_storage_full[13:8] <= pair_bundle2_gpio_do6_en1_r;
	end
	if (pair_bundle2_gpio_do6_en0_re) begin
		pair_bundle2_csrstorage16_storage_full[7:0] <= pair_bundle2_gpio_do6_en0_r;
	end
	pair_bundle2_csrstorage16_re <= pair_bundle2_gpio_do6_en0_re;
	if (pair_bundle2_gpio_do7_en1_re) begin
		pair_bundle2_csrstorage17_storage_full[13:8] <= pair_bundle2_gpio_do7_en1_r;
	end
	if (pair_bundle2_gpio_do7_en0_re) begin
		pair_bundle2_csrstorage17_storage_full[7:0] <= pair_bundle2_gpio_do7_en0_r;
	end
	pair_bundle2_csrstorage17_re <= pair_bundle2_gpio_do7_en0_re;
	if (pair_bundle2_sink_accept_en1_re) begin
		pair_bundle2_csrstorage18_storage_full[13:8] <= pair_bundle2_sink_accept_en1_r;
	end
	if (pair_bundle2_sink_accept_en0_re) begin
		pair_bundle2_csrstorage18_storage_full[7:0] <= pair_bundle2_sink_accept_en0_r;
	end
	pair_bundle2_csrstorage18_re <= pair_bundle2_sink_accept_en0_re;
	if (pair_bundle2_sink_take_sel0_re) begin
		pair_bundle2_csrstorage19_storage_full[1:0] <= pair_bundle2_sink_take_sel0_r;
	end
	pair_bundle2_csrstorage19_re <= pair_bundle2_sink_take_sel0_re;
	if (sys_rst) begin
		pair_bundle0_o <= 8'd0;
		pair_bundle0_accept <= 1'd0;
		pair_bundle0_take <= 25'sd0;
		pair_bundle0_max_status0 <= 25'd0;
		pair_bundle0_min_status0 <= 25'd0;
		pair_bundle0_max_status1 <= 25'd0;
		pair_bundle0_min_status1 <= 25'd0;
		pair_bundle0_state_status <= 14'd0;
		pair_bundle0_csrstorage0_storage_full <= 14'd0;
		pair_bundle0_csrstorage0_re <= 1'd0;
		pair_bundle0_csrstorage1_storage_full <= 14'd0;
		pair_bundle0_csrstorage1_re <= 1'd0;
		pair_bundle0_csrstorage2_storage_full <= 14'd0;
		pair_bundle0_csrstorage2_re <= 1'd0;
		pair_bundle0_csrstorage3_storage_full <= 14'd0;
		pair_bundle0_csrstorage3_re <= 1'd0;
		pair_bundle0_csrstorage4_storage_full <= 14'd0;
		pair_bundle0_csrstorage4_re <= 1'd0;
		pair_bundle0_csrstorage5_storage_full <= 14'd0;
		pair_bundle0_csrstorage5_re <= 1'd0;
		pair_bundle0_csrstorage6_storage_full <= 14'd0;
		pair_bundle0_csrstorage6_re <= 1'd0;
		pair_bundle0_csrstorage7_storage_full <= 14'd0;
		pair_bundle0_csrstorage7_re <= 1'd0;
		pair_bundle0_csrstorage8_storage_full <= 14'd0;
		pair_bundle0_csrstorage8_re <= 1'd0;
		pair_bundle0_csrstorage9_storage_full <= 2'd0;
		pair_bundle0_csrstorage9_re <= 1'd0;
		pair_bundle0_bus_dat_r <= 8'd0;
		pair_bundle1_o <= 8'd0;
		pair_bundle1_accept <= 1'd0;
		pair_bundle1_take <= 25'sd0;
		pair_bundle1_max_status0 <= 25'd0;
		pair_bundle1_min_status0 <= 25'd0;
		pair_bundle1_max_status1 <= 25'd0;
		pair_bundle1_min_status1 <= 25'd0;
		pair_bundle1_state_status <= 14'd0;
		pair_bundle1_csrstorage0_storage_full <= 14'd0;
		pair_bundle1_csrstorage0_re <= 1'd0;
		pair_bundle1_csrstorage1_storage_full <= 14'd0;
		pair_bundle1_csrstorage1_re <= 1'd0;
		pair_bundle1_csrstorage2_storage_full <= 14'd0;
		pair_bundle1_csrstorage2_re <= 1'd0;
		pair_bundle1_csrstorage3_storage_full <= 14'd0;
		pair_bundle1_csrstorage3_re <= 1'd0;
		pair_bundle1_csrstorage4_storage_full <= 14'd0;
		pair_bundle1_csrstorage4_re <= 1'd0;
		pair_bundle1_csrstorage5_storage_full <= 14'd0;
		pair_bundle1_csrstorage5_re <= 1'd0;
		pair_bundle1_csrstorage6_storage_full <= 14'd0;
		pair_bundle1_csrstorage6_re <= 1'd0;
		pair_bundle1_csrstorage7_storage_full <= 14'd0;
		pair_bundle1_csrstorage7_re <= 1'd0;
		pair_bundle1_csrstorage8_storage_full <= 14'd0;
		pair_bundle1_csrstorage8_re <= 1'd0;
		pair_bundle1_csrstorage9_storage_full <= 2'd0;
		pair_bundle1_csrstorage9_re <= 1'd0;
		pair_bundle1_bus_dat_r <= 8'd0;
		pair_bundle2_o <= 8'd0;
		pair_bundle2_accept <= 1'd0;
		pair_bundle2_take <= 25'sd0;
		pair_bundle2_max_status0 <= 25'd0;
		pair_bundle2_min_status0 <= 25'd0;
		pair_bundle2_max_status1 <= 25'd0;
		pair_bundle2_min_status1 <= 25'd0;
		pair_bundle2_state_status <= 14'd0;
		pair_bundle2_gpio_status_state_s1 <= 14'd0;
		pair_bundle2_csrstorage10_storage_full <= 14'd0;
		pair_bundle2_csrstorage10_re <= 1'd0;
		pair_bundle2_gpio_status_mask_s1_0 <= 14'd0;
		pair_bundle2_csrstorage11_storage_full <= 14'd0;
		pair_bundle2_csrstorage11_re <= 1'd0;
		pair_bundle2_gpio_status_mask_s1_1 <= 14'd0;
		pair_bundle2_csrstorage12_storage_full <= 14'd0;
		pair_bundle2_csrstorage12_re <= 1'd0;
		pair_bundle2_gpio_status_mask_s1_2 <= 14'd0;
		pair_bundle2_csrstorage13_storage_full <= 14'd0;
		pair_bundle2_csrstorage13_re <= 1'd0;
		pair_bundle2_gpio_status_mask_s1_3 <= 14'd0;
		pair_bundle2_csrstorage14_storage_full <= 14'd0;
		pair_bundle2_csrstorage14_re <= 1'd0;
		pair_bundle2_gpio_status_mask_s1_4 <= 14'd0;
		pair_bundle2_csrstorage15_storage_full <= 14'd0;
		pair_bundle2_csrstorage15_re <= 1'd0;
		pair_bundle2_gpio_status_mask_s1_5 <= 14'd0;
		pair_bundle2_csrstorage16_storage_full <= 14'd0;
		pair_bundle2_csrstorage16_re <= 1'd0;
		pair_bundle2_gpio_status_mask_s1_6 <= 14'd0;
		pair_bundle2_csrstorage17_storage_full <= 14'd0;
		pair_bundle2_csrstorage17_re <= 1'd0;
		pair_bundle2_gpio_status_mask_s1_7 <= 14'd0;
		pair_bundle2_csrstorage18_storage_full <= 14'd0;
		pair_bundle2_csrstorage18_re <= 1'd0;
		pair_bundle2_csrstorage19_storage_full <= 2'd0;
		pair_bundle2_csrstorage19_re <= 1'd0;
		pair_bundle2_bus_dat_r <= 8'd0;
	end
end

endmodule
