`timescale 1ns/1ps
module tb_gpio;
reg sys_clk=0; always #4 sys_clk=~sys_clk; reg sys_rst=1;
reg [7:0] di=0;
reg [4:0] flags=0;
reg [24:0] trace_a=0;
reg [24:0] trace_b=0;
reg [13:0] csr_adr=0;
reg [0:0] csr_we=0;
reg [7:0] csr_dat_w=0;
wire [7:0] old_gpio;
wire [0:0] old_accept;
wire [24:0] old_take;
wire [7:0] old_read;
wire [7:0] plain_gpio;
wire [0:0] plain_accept;
wire [24:0] plain_take;
wire [7:0] plain_read;
wire [7:0] new_gpio;
wire [0:0] new_accept;
wire [24:0] new_take;
wire [7:0] new_read;
gpio_pair dut(.*);
reg [7:0] lag=0; always @(posedge sys_clk) if(sys_rst) lag<=0; else lag<=old_gpio;
reg known; reg [7:0] eg,ed; reg ea; reg [24:0] et;
integer fd,k,count=0;
initial begin
 fd=$fopen("vectors.txt","r"); if(!fd)$fatal(1,"vectors missing");
 while(!$feof(fd))begin
  @(negedge sys_clk); k=$fscanf(fd,"%h %h %h %h %h %h %h %h %h %h %h %h %h\n",sys_rst,di,flags,trace_a,trace_b,csr_adr,csr_we,csr_dat_w,known,eg,ed,ea,et);
  if(k!=13)$fatal(1,"vector malformed");
  @(posedge sys_clk); #1;
  if(plain_gpio!==old_gpio || new_gpio!==lag || plain_accept!==old_accept || new_accept!==old_accept || plain_take!==old_take || new_take!==old_take || plain_read!==old_read || new_read!==old_read)
   $fatal(1,"GPIO_DIFF cycle=%0d gpio=%h/%h/%h lag=%h accept=%h/%h take=%h/%h read=%h/%h",count,old_gpio,plain_gpio,new_gpio,lag,old_accept,new_accept,old_take,new_take,old_read,new_read);
  if(known && (old_gpio!==eg || new_gpio!==ed || old_accept!==ea || old_take!==et))
   $fatal(1,"GPIO_ORACLE cycle=%0d gpio=%h/%h new=%h/%h accept=%h/%h take=%h/%h",count,old_gpio,eg,new_gpio,ed,old_accept,ea,old_take,et);
  count=count+1;
 end
 $display("GPIO_STATUS_NATIVE_PASS cycles=%0d",count); $finish;
end
endmodule
