if {[catch {
set_param general.maxThreads 2
open_checkpoint {D:/RP_Dev/linien_trials/20261110-r28-pid-output-bitdecode/gateware/build/trials/20261110_193543_r28_pid_output_bitdecode/synth.dcp}
opt_design
place_design -directive Explore
write_checkpoint {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/placed_before_phys.dcp}
phys_opt_design -directive AggressiveFanoutOpt
write_checkpoint {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/placed_after_phys.dcp}
route_design -directive Explore -tns_cleanup
report_route_status -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_status.rpt}
report_timing_summary -max_paths 30 -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_timing.rpt}
report_timing -max_paths 100 -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_setup.rpt}
report_timing -delay_type min -max_paths 30 -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_hold.rpt}
report_utilization -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_utilization.rpt}
check_timing -verbose -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_checks.rpt}
report_cdc -details -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_cdc.rpt}
report_drc -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_drc.rpt}
report_clock_interaction -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_clocks.rpt}
report_exceptions -file {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed_exceptions.rpt}
write_checkpoint {D:/RP_Dev/linien_trials/20261110-r32-place-explore/gateware/build/trials/20261110_210929_r32_place_explore/routed.dcp}
puts FRESH_PLACE_TRIAL_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
