"""Read-only design exploration; does not edit any gateware."""
from pathlib import Path
import json,random
results=[]
for w,n in ((2,5),(3,6),(4,7),(14,51),(25,84)):
    u=(1<<(w-1))-1;l=-(1<<(w-1));mask=(1<<n)-1;hi_mask=(1<<(n-w+1))-1
    vals=list(range(-(1<<(n-1)),1<<(n-1))) if n<=7 else [l-2,l-1,l,l+1,-1,0,1,u-1,u,u+1,u+2,-(1<<(n-1)),(1<<(n-1))-1]
    if n>7:
        rng=random.Random(2026111028+w)
        for _ in range(60000):
            v=rng.getrandbits(n);vals.append(v-(1<<n) if v>>(n-1) else v)
    for s in vals:
        bits=s&mask;high=bits>>(w-1);neg=bool(bits>>(n-1))
        result=u if not neg and high!=0 else l if neg and high!=hi_mask else ((s+(1<<(w-1)))%(1<<w))-(1<<(w-1))
        assert result==min(u,max(l,s)),(w,n,s,result)
    results.append({'output_width':w,'sum_width':n,'cases':len(vals),'passed':True})
path=Path(__file__).with_name('r28_math_only.json');path.write_text(json.dumps({'scope':'Integer mathematical identity only; no RTL implementation or synthesis yet','results':results},indent=2),encoding='utf-8')
print('MATHEMATICAL_IDENTITY_PASS',results)
