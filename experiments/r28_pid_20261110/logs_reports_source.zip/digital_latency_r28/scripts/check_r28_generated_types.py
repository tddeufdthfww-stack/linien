from pathlib import Path
import ast,hashlib,json,re,subprocess
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261110-r28-pid-output-bitdecode');t=r/'gateware/build/trials/20261110_193543_r28_pid_output_bitdecode/top.v';s=t.read_text();rows={}
for c in ('a','b'):
    alias=f'linienmodule_fast_{c}_signed_offset';csr=f'linienmodule_chain_{c}_offset_storage';common=f'linienmodule_fast_{c}_common'
    assert re.search(r'wire signed \[13:0\] '+alias+r';',s)
    assert f'assign {alias} = {csr};' in s
    rhs=re.search(common+r' <= (.*);',s)[1];assert alias in rhs and csr not in rhs and "1'd0" not in rhs
    rows[c]={'signed_alias':alias,'registered_common_rhs':rhs,'passed':True}
def method(path,klass,name):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name==klass)
    return next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name==name)
original=method(r/'gateware/logic/pid.py','PID','calculate_sum');candidate=method(r/'gateware/logic/pid_pipeline.py','PipelinedPID','calculate_sum')
assert ast.dump(original.body[-1])==ast.dump(candidate.body[-1]),'Sum register/CE/expression changed'
for name in ('gateware/logic/pid.py','gateware/logic/slow_pipeline.py','gateware/logic/feedback_pipeline.py','gateware/linien_module.py'):
    old=subprocess.check_output(['git','show','c105b02:'+name],cwd=r).replace(b'\r\n',b'\n');now=(r/name).read_bytes().replace(b'\r\n',b'\n');assert old==now,name
assert 'linienmodule_mixeralignedpid_mixeralignedpid_pid_sum[83:24]' in s
assert 'linienmodule_slow_chain_pid_pipelinedpid_pid_sum[50:13]' in s
out={'passed':True,'top_sha256':hashlib.sha256(t.read_bytes()).hexdigest(),'preoffset_signedness':rows,'original_sum_sync_ast_identical':True,'unchanged_source':['pid.py','slow_pipeline.py','feedback_pipeline.py','linien_module.py'],'actual_scope':'SHARED_PipelinedPID_OUTPUT_CLAMP_FAST25_AND_SLOW14; not fast-only. Both retain original sum FF/CE/reset/expression, data stages and CSR. Full native slow regression 413022 cycles separately PASS.','generated_high_slices':{'fast':'83:24','slow':'50:13'}}
(h/'r28_generated_scope_and_types.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print('R28_ACTUAL_SHARED_PID_SCOPE_AND_TYPES_PASS')
