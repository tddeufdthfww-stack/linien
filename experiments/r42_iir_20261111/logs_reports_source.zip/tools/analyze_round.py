from pathlib import Path
import argparse,collections,csv,hashlib,json,re,subprocess
HERE=Path(__file__).parent
BASE=Path('D:/RP_Dev/linien_trials/20261109-r4-pid-pipeline/gateware/build/trials/20261109_111733_r4_fast_pipeline16')

def summary(path):
    txt=path.read_text(errors='replace')
    m=re.search(r'^\s*(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)',txt,re.M)
    assert m,path
    vals=m.groups();return dict(zip(['wns','tns','setup_failing','setup_total','whs','ths','hold_failing','hold_total','wpws','tpws','pulse_failing'],[int(v) if i in (2,3,6,7,10) else float(v) for i,v in enumerate(vals)]))
def worst(path):
    txt=path.read_text(errors='replace')
    return {'slack':float(re.search(r'Slack \([^)]*\)\s*:\s*(-?[\d.]+)ns',txt)[1]),
       'source':re.search(r'Source:\s*(\S+)',txt)[1],'destination':re.search(r'Destination:\s*(\S+)',txt)[1],
       'data_logic_route_ns':re.search(r'Data Path Delay:\s*([\d.]+)ns\s*\(logic ([\d.]+)ns.*?route ([\d.]+)ns',txt).groups(),
       'levels':re.search(r'Logic Levels:\s*(.*)',txt)[1].strip()}
def cdc(path):
    txt=path.read_text(errors='replace');rows=set()
    counts={m[1]:int(m[2]) for m in re.finditer(r'^(CDC-\d+)\s+(?:Critical|Warning|Info)\s+(\d+)\s+',txt,re.M)}
    for line in txt.splitlines():
        m=re.match(r'^\s*\d+\s+(CDC-\d+)\s+',line)
        if m:
            tokens=line.split();rows.add((m[1],tokens[-2],tokens[-1]))
    return counts,rows
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--trial',type=Path,required=True);parser.add_argument('--label',required=True)
    args=parser.parse_args();trial=args.trial.resolve();out=HERE/args.label;logs=HERE/(args.label+'_logs')
    logs.mkdir(exist_ok=False)
    script=(HERE.parent/'iir_readonly_audit/audit.tcl').read_text()
    begin=script.index('# Trace the legacy path');end=script.index('set f [open "$out/iir_registers.txt"',begin)
    script=script[:begin]+script[end:]
    # Free-function construction changes Migen's signal backtrace prefix. The
    # generated top.v still connects this IIR to the same filtered-error signal.
    script=script.replace('NAME =~ *raw_acquisition_iir*','NAME =~ *raw_acquisition_iir* || NAME =~ linienmodule_logic_iir_* || NAME =~ linienmodule_iir_*')
    mapped=r'''
proc mapped_dsp {kind} {
    set result {}
    foreach c [get_cells -hier -quiet -filter {REF_NAME == DSP48E1}] {
        set pp {}
        foreach p [get_pins -quiet -of_objects $c -filter {DIRECTION == OUT}] {
            if {[regexp {^(P|PCOUT)(\[[0-9]+\])?$} [get_property REF_PIN_NAME $p]]} {lappend pp $p}
        }
        set nets [get_nets -quiet -of_objects $pp]
        if {$kind eq "raw"} {
            set matches [filter $nets {NAME =~ linienmodule_iir_* || NAME =~ linienmodule_logic_iir_* || NAME =~ *raw_acquisition_iir*}]
        } elseif {$kind eq "fast_a"} {set matches [filter $nets {NAME =~ linienmodule_fast_a_iir*}]
        } elseif {$kind eq "fast_b"} {set matches [filter $nets {NAME =~ linienmodule_fast_b_iir*}]
        } else {set matches [filter $nets {NAME =~ *registerederrormixer* || NAME =~ *error_mixer*}]}
        if {[llength $matches]} {lappend result $c}
    }
    return $result
}
set rawMappedDSP [mapped_dsp raw]
set f [open "$out/raw_mapped_dsp.txt" w]
foreach c $rawMappedDSP {puts $f $c};close $f
foreach kind {fast_a fast_b} {
    set f [open "$out/${kind}_mapped_dsp.txt" w]
    foreach c [mapped_dsp $kind] {puts $f $c};close $f
}
'''
    needle='set seq [filter $iirCells'
    pos=script.index(needle)
    script=script[:pos]+mapped+'\nset iirCells [lsort -unique [concat $iirCells $rawMappedDSP]]\n'+script[pos:]
    insertion=r'''

set scale_cells [get_cells -hier -quiet -filter {NAME =~ *autolock*time_scale* && REF_NAME =~ FD*}]
set gpio_cells [get_cells -hier -quiet -filter {NAME =~ *gpio_n_o_reg* && REF_NAME =~ FD*}]
if {[llength $scale_cells] && [llength $gpio_cells]} {
    report_timing -from $scale_cells -to $gpio_cells -max_paths 10 -file "$out/time_scale_to_gpio.rpt"
}
set sum_regs [get_cells -hier -quiet -filter {NAME =~ *autolock*sum_diff_s1* && REF_NAME =~ FD*}]
if {[llength $sum_regs]} {
    report_timing -to $sum_regs -max_paths 10 -file "$out/autolock_to_sum_stage.rpt"
    report_timing -from $sum_regs -max_paths 10 -file "$out/autolock_from_sum_stage.rpt"
}
set allDSP [get_cells -hier -filter {REF_NAME == DSP48E1}]
set fast [get_cells -hier -quiet -filter {NAME =~ *logic_pid* || NAME =~ *mixeralignedpid*}]
set fastDSP {}
foreach c $allDSP {
    set pp {}
    foreach p [get_pins -quiet -of_objects $c -filter {DIRECTION == OUT}] {
        if {[regexp {^P(\[[0-9]+\])?$} [get_property REF_PIN_NAME $p]]} {lappend pp $p}
    }
    set nets [get_nets -quiet -of_objects $pp]
    if {[llength [filter $nets {NAME =~ *logic_pid* || NAME =~ *mixeralignedpid*}]]} {lappend fastDSP $c; lappend fast $c}
}
set fast [lsort -unique $fast]
set f [open "$out/fast_mapped_cells.txt" w]
foreach c $fast {puts $f [get_property NAME $c]}; close $f
set f [open "$out/fast_mapped_dsp.txt" w]
foreach c $fastDSP {puts $f [get_property NAME $c]}; close $f
foreach pin {D R S CE} {
    set pins [get_pins -quiet -of_objects $fast -filter "REF_PIN_NAME == $pin"]
    if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/fast_${pin}.rpt"}
}
set seq [filter $fast {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
if {[llength $seq]} {report_timing -to $seq -max_paths 10 -file "$out/fast_all_sequential.rpt"}
if {[llength $seq]} {report_timing -from $seq -max_paths 20 -file "$out/fast_outgoing.rpt"}
set mixer [mapped_dsp mixer]
if {[llength $mixer]} {
    report_timing -from $mixer -max_paths 10 -file "$out/mixer_from_dsp.rpt"
    report_timing -to $mixer -max_paths 10 -file "$out/mixer_to_dsp.rpt"
}
set raw $iirCells
foreach chain {a b} {
    set src [get_cells -hier -quiet -filter "NAME =~ linienmodule_fast_${chain}_iir*_y* && REF_NAME =~ FD*"]
    if {[llength $src]} {report_timing -from $src -max_paths 10 -file "$out/frontend_${chain}_output.rpt"}
}
set avgctrl [get_cells -hier -quiet -filter {NAME =~ red_pitaya_scope/set_avg_en_reg* && REF_NAME =~ FD*}]
if {[llength $avgctrl]} {report_timing -from $avgctrl -max_paths 10 -file "$out/scope_average_control.rpt"}
set scope_cfg [get_cells -hier -quiet -filter {NAME =~ red_pitaya_scope/set_* && REF_NAME =~ FD*}]
set csrdata [get_cells -hier -quiet -filter {NAME =~ linienmodule_csr_dat_w_reg* && REF_NAME =~ FD*}]
set f [open "$out/csr_data_registers.tsv" w]
puts $f "cell\tclock\tQ_net\tloads\tD_net\tD_startpoints\tCE_net\tASYNC_REG\tDONT_TOUCH\tINIT"
foreach c $csrdata {
 set cp [get_pins -of_objects $c -filter {REF_PIN_NAME == C}]
 set q [get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == Q}]]
 set d [get_pins -of_objects $c -filter {REF_PIN_NAME == D}]
 set ce [get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == CE}]]
 puts $f "$c\t[get_clocks -of_objects $cp]\t$q\t[llength [get_pins -quiet -of_objects $q -filter {DIRECTION == IN}]]\t[get_nets -of_objects $d]\t[all_fanin -flat -startpoints_only -to $d]\t$ce\t[get_property ASYNC_REG $c]\t[get_property DONT_TOUCH $c]\t[get_property INIT $c]"
}
close $f
if {[llength $csrdata]} {
 report_timing -from $csrdata -max_paths 20 -file "$out/csr_data_from.rpt"
 report_timing -to $csrdata -max_paths 20 -file "$out/csr_data_to.rpt"
}
set scope_pre [get_cells -hier -quiet -filter {NAME =~ red_pitaya_scope/scope_addr_match_reg* && REF_NAME =~ FD*}]
set iir_feedback [get_cells -hier -quiet -filter {(NAME =~ linienmodule_fast_*_iir*_y1_reg* || NAME =~ linienmodule_fast_*_iir*_y3_reg* || NAME =~ linienmodule_raw_acquisition_iir_y1_reg*) && REF_NAME =~ FD*}]
set f [open "$out/iir_feedback_fabric.tsv" w]
puts $f "cell\tref\tclock\tD\tCE\tR\tINIT\tDONT_TOUCH"
foreach c $iir_feedback {
 set cp [get_pins -of_objects $c -filter {REF_PIN_NAME == C}]
 puts $f "$c\t[get_property REF_NAME $c]\t[get_clocks -of_objects $cp]\t[get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == D}]]\t[get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == CE}]]\t[get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == R}]]\t[get_property INIT $c]\t[get_property DONT_TOUCH $c]"
};close $f
set f [open "$out/scope_predecode_registers.tsv" w]
puts $f "cell\tclock\tD\tCE\tQ\tloads\tINIT\tASYNC_REG"
foreach c $scope_pre {
 set cp [get_pins -of_objects $c -filter {REF_PIN_NAME == C}]
 set q [get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == Q}]]
 puts $f "$c\t[get_clocks -of_objects $cp]\t[get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == D}]]\t[get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == CE}]]\t$q\t[llength [get_pins -quiet -of_objects $q -filter {DIRECTION == IN}]]\t[get_property INIT $c]\t[get_property ASYNC_REG $c]"
};close $f
if {[llength $scope_pre]} {
 report_timing -from $scope_pre -max_paths 20 -file "$out/scope_predecode_from.rpt"
 report_timing -to $scope_pre -max_paths 20 -file "$out/scope_predecode_to.rpt"
 report_timing -from $scope_pre -to $scope_cfg -max_paths 20 -file "$out/scope_predecode_to_config.rpt"
}
set f [open "$out/common_alias_lut1.tsv" w]
puts $f "cell\tINIT\tinput_nets\toutput_nets\tDONT_TOUCH"
foreach c [get_cells -hier -quiet -filter {REF_NAME == LUT1}] {
    set in [get_nets -quiet -of_objects [get_pins -quiet -of_objects $c -filter {DIRECTION == IN}]]
    set ou [get_nets -quiet -of_objects [get_pins -quiet -of_objects $c -filter {DIRECTION == OUT}]]
    if {[string match *paralleltaplimitcsr*common_sum* $c] || [string match *common_sum* $in] || [string match *common_sum* $ou]} {
        puts $f "$c\t[get_property INIT $c]\t$in\t$ou\t[get_property DONT_TOUCH $c]"
    }
}
close $f
if {[llength $scope_cfg]} {
    report_timing -from [get_clocks clk_2] -to $scope_cfg -max_paths 20 -file "$out/scope_adc_control.rpt"
    report_timing -from [get_clocks clk_fpga_0] -to $scope_cfg -max_paths 20 -file "$out/scope_fclk_control.rpt"
}
report_timing -from [get_clocks clk_2] -to [get_clocks clk_2] -max_paths 20 -file "$out/same_adc_domain.rpt"
report_timing -from [get_clocks clk_fpga_0] -to [get_clocks clk_2] -max_paths 20 -file "$out/fclk_to_adc.rpt"
report_timing -from [get_clocks clk_2] -to [get_clocks clk_fpga_0] -max_paths 20 -file "$out/adc_to_fclk.rpt"
set snap [get_cells -hier -quiet -filter {(NAME =~ *gpio_status_state_s1* || NAME =~ *gpio_status_mask_s1*) && REF_NAME =~ FD*}]
set f [open "$out/gpio_snapshot_registers.tsv" w]
puts $f "name\tref"
foreach c $snap {puts $f "[get_property NAME $c]\t[get_property REF_NAME $c]"};close $f
if {[llength $snap]} {
    report_timing -from $snap -max_paths 20 -file "$out/gpio_snapshot_from.rpt"
    report_timing -to $snap -max_paths 20 -file "$out/gpio_snapshot_to.rpt"
    foreach pin {D R S CE} {
        set pins [get_pins -quiet -of_objects $snap -filter "REF_PIN_NAME == $pin"]
        if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/gpio_snapshot_${pin}.rpt"}
    }
}
if {[llength $gpio_cells]} {report_timing -to $gpio_cells -max_paths 20 -file "$out/gpio_outputs_to.rpt"}
set ohcells [get_cells -hier -quiet -filter {NAME =~ *instruction_onehot*}]
set prefetch [get_cells -hier -quiet -filter {NAME =~ *prefetch* && REF_NAME =~ FD*}]
set f [open "$out/prefetch_registers.tsv" w];puts $f "name\tref"
foreach c $prefetch {puts $f "$c\t[get_property REF_NAME $c]"};close $f
set prefchoice [get_cells -hier -quiet -filter {NAME =~ *prefetch_choice* && REF_NAME =~ FD*}]
foreach item [list [list prefetch $prefetch] [list prefetch_choice $prefchoice]] {
    lassign $item label seq
    if {[llength $seq]} {
        report_timing -to $seq -max_paths 20 -file "$out/${label}_to.rpt"
        report_timing -from $seq -max_paths 20 -file "$out/${label}_from.rpt"
        foreach pin {D R S CE} {
            set pins [get_pins -quiet -of_objects $seq -filter "REF_PIN_NAME == $pin"]
            if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/${label}_${pin}.rpt"}
        }
    }
}
set f [open "$out/onehot_mapped_cells.tsv" w]
puts $f "name\tref"
foreach c $ohcells {puts $f "[get_property NAME $c]\t[get_property REF_NAME $c]"};close $f
set ohseq [filter $ohcells {REF_NAME =~ FD* || REF_NAME =~ SRL*}]
if {[llength $ohseq]} {
    report_timing -from $ohseq -max_paths 20 -file "$out/onehot_from_registers.rpt"
    report_timing -to $ohseq -max_paths 20 -file "$out/onehot_to_registers.rpt"
    foreach pin {D R S CE} {
        set pins [get_pins -quiet -of_objects $ohseq -filter "REF_PIN_NAME == $pin"]
        if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/onehot_${pin}.rpt"}
    }
}
set rawseq [filter $raw {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
set outside [get_cells -hier -quiet -filter {(REF_NAME =~ FD* || REF_NAME == DSP48E1 || REF_NAME =~ RAMB*) && NAME !~ *raw_acquisition_iir* && NAME !~ linienmodule_logic_iir_* && NAME !~ linienmodule_iir_*}]
foreach c $rawMappedDSP {set index [lsearch -exact $outside $c];if {$index>=0} {set outside [lreplace $outside $index $index]}}
set dataPins {}
foreach p [get_pins -quiet -of_objects $rawseq -filter {DIRECTION == IN}] {
    if {[regexp {^(A|B|C|D)(\[[0-9]+\])?$} [get_property REF_PIN_NAME $p]]} {lappend dataPins $p}
}
if {[llength $outside] && [llength $dataPins]} {report_timing -from $outside -to $dataPins -max_paths 10 -file "$out/iir_external_data.rpt"}


foreach pair {{slow {*slow_chain_pid*}}} {
    lassign $pair label pattern
    set cells [get_cells -hier -quiet -filter "NAME =~ $pattern"]
    foreach pinName {D R S CE} {
        set pins [get_pins -quiet -of_objects $cells -filter "REF_PIN_NAME == $pinName"]
        if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/${label}_${pinName}.rpt"}
    }
    set seq [filter $cells {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
    if {[llength $seq]} {report_timing -to $seq -max_paths 10 -file "$out/${label}_all_sequential.rpt"}
}
'''
    script=script.replace('write_verilog -force -mode funcsim',insertion+'\nwrite_verilog -force -mode funcsim')
    script=script.replace('puts IIR_READONLY_AUDIT_COMPLETE', 'help phys_opt_design\nhelp place_design\nhelp route_design\nputs IIR_READONLY_AUDIT_COMPLETE')
    tcl=logs/'audit_round.tcl';tcl.write_bytes(script.encode())
    checkpoint=trial/'routed.dcp';before=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    cmd=['D:/Xilinx/Vivado/2020.1/bin/vivado.bat','-mode','batch','-source',str(tcl),'-log',str(logs/'vivado.log'),'-journal',str(logs/'vivado.jou'),'-tclargs',str(checkpoint),str(out)]
    r=subprocess.run(cmd,cwd=logs,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (logs/'stdout.log').write_bytes(r.stdout);(logs/'stderr.log').write_bytes(r.stderr)
    text=(r.stdout+b'\n'+r.stderr).decode(errors='replace')
    ok=r.returncode==0 and 'IIR_READONLY_AUDIT_COMPLETE' in text and not re.search(r'(?m)^ERROR:',text)
    status={'command':cmd,'exit_code':r.returncode,'passed':ok,'dcp_sha256':before,'dcp_unchanged':before==hashlib.sha256(checkpoint.read_bytes()).hexdigest()}
    (logs/'status.json').write_bytes(json.dumps(status,indent=2).encode());assert ok,text[-6000:]
    results={'trial':str(trial),'synth':summary(trial/'synth_timing.rpt'),'route':summary(trial/'routed_timing.rpt'),
      'global_worst':worst(out/'worst20.rpt'),'raw_internal':worst(out/'iir_internal.rpt'),'raw_entry':worst(out/'iir_to.rpt'),
      'xdc_matches_r4a':(trial/'top.xdc').read_bytes()==(BASE/'top.xdc').read_bytes()}
    for name in ('time_scale_to_gpio','mixer_from_dsp','mixer_to_dsp','autolock_to_sum_stage','autolock_from_sum_stage','iir_external_data','fast_all_sequential','fast_outgoing','fast_D','fast_R','fast_S','fast_CE','frontend_a_output','frontend_b_output','scope_average_control','onehot_from_registers','onehot_to_registers','onehot_D','onehot_R','onehot_S','onehot_CE','gpio_snapshot_from','gpio_snapshot_to','gpio_snapshot_D','gpio_snapshot_R','gpio_snapshot_S','gpio_snapshot_CE','gpio_outputs_to','scope_adc_control','scope_fclk_control','same_adc_domain','fclk_to_adc','adc_to_fclk'):
        p=out/(name+'.rpt')
        if p.exists():
            txt=p.read_text(errors='replace')
            if 'Data Path Delay:' in txt:results[name]=worst(p)
            elif 'No timing paths found' in txt:results[name]={'direct_combinational_path_exists':False}
        elif name in ('fast_D','fast_R','fast_S','fast_CE'):
            results[name]={'status':'NO_MAPPED_PIN','reason':'Successful audit only reports these pins when get_pins count is nonzero; absent pin is not a separate timing PASS.'}
    if 'iir_external_data' in results:
        results['raw_to_all_including_internal']=results['raw_entry'];results['raw_entry']=results['iir_external_data']
    results['fast_mapped_dsp_names']=(out/'fast_mapped_dsp.txt').read_text().splitlines()
    ohrows=list(csv.DictReader((out/'onehot_mapped_cells.tsv').open(),delimiter='\t'))
    results['onehot_mapped_refs']=dict(collections.Counter(row['ref'] for row in ohrows))
    snaprows=list(csv.DictReader((out/'gpio_snapshot_registers.tsv').open(),delimiter='\t'))
    results['gpio_snapshot_mapped_refs']=dict(collections.Counter(row['ref'] for row in snaprows))
    prefrows=list(csv.DictReader((out/'prefetch_registers.tsv').open(),delimiter='\t'))
    results['prefetch_mapped_refs']=dict(collections.Counter(row['ref'] for row in prefrows))
    results['common_alias_lut1_cells']=list(csv.DictReader((out/'common_alias_lut1.tsv').open(),delimiter='\t'))
    results['csr_data_registers']=list(csv.DictReader((out/'csr_data_registers.tsv').open(),delimiter='\t'))
    results['scope_predecode_registers']=list(csv.DictReader((out/'scope_predecode_registers.tsv').open(),delimiter='\t'))
    results['iir_feedback_fabric']=list(csv.DictReader((out/'iir_feedback_fabric.tsv').open(),delimiter='\t'))
    for name in ('scope_predecode_from','scope_predecode_to','scope_predecode_to_config'):
        if (out/(name+'.rpt')).exists() and 'Slack (' in (out/(name+'.rpt')).read_text():results[name]=worst(out/(name+'.rpt'))
    for name in ('csr_data_from','csr_data_to'):
        p=out/(name+'.rpt')
        if p.exists() and 'Data Path Delay:' in p.read_text(errors='replace'):results[name]=worst(p)
    for label in ('prefetch','prefetch_choice'):
        for suffix in ('from','to','D','R','S','CE'):
            p=out/(label+'_'+suffix+'.rpt')
            if p.exists() and 'Data Path Delay:' in p.read_text(errors='replace'):results[label+'_'+suffix]=worst(p)
    util=(trial/'routed_utilization.rpt').read_text(errors='replace')
    resources={}
    for key,pattern in [('lut',r'Slice LUTs\*?'),('ff','Slice Registers'),('dsp','DSPs'),('bram','Block RAM Tile'),('bufg','BUFGCTRL')]:
        mm=re.search(r'^\|\s*'+pattern+r'\s*\|\s*(\d+)',util,re.M)
        resources[key]=int(mm[1]) if mm else None
    results['resources']=resources
    checks=(trial/'routed_checks.rpt').read_text(errors='replace')
    results['coverage']={key:int(re.search(key+r'\s*\((\d+)\)',checks)[1]) for key in ['no_clock','unconstrained_internal_endpoints','no_input_delay','no_output_delay']}
    drc=(trial/'routed_drc.rpt').read_text(errors='replace')
    results['drc_total']=int(re.search(r'Violations found:\s*(\d+)',drc)[1])
    results['drc_rules']=[{'rule':q[1],'severity':q[2],'count':int(q[3])} for q in re.finditer(r'^\|\s*(\S+)\s*\|\s*(Warning|Advisory|Error|Critical Warning)\s*\|[^|]+\|\s*(\d+)\s*\|',drc,re.M)]
    dsps=[]
    rawmapped=set((out/'raw_mapped_dsp.txt').read_text().splitlines())
    for b in (out/'all_dsp.txt').read_text().split('CELL_BEGIN')[1:]:
        d=dict(s.split('=',1) for s in b.splitlines() if '=' in s)
        if d.get('NAME','') in rawmapped or 'raw_acquisition_iir' in d.get('NAME','') or d.get('NAME','').startswith(('linienmodule_logic_iir_','linienmodule_iir_')):dsps.append(d)
    results['raw_dsps']=dsps
    counts,rows=cdc(out/'cdc.rpt');oldcounts,oldrows=cdc(BASE/'routed_cdc.rpt')
    results['cdc']={'baseline_counts':oldcounts,'counts':counts,'added':len(rows-oldrows),'removed':len(oldrows-rows),'physical_safety':'NOT_PROVEN'}
    (out/'cdc_diff.json').write_bytes(json.dumps({'added':sorted(rows-oldrows),'removed':sorted(oldrows-rows)},indent=2).encode())
    paths=list(csv.DictReader((out/'negative_paths.tsv').open(),delimiter='\t'));groups=collections.defaultdict(list)
    fastcells=set((out/'fast_mapped_cells.txt').read_text().splitlines())
    fastamapped=set((out/'fast_a_mapped_dsp.txt').read_text().splitlines())
    fastbmapped=set((out/'fast_b_mapped_dsp.txt').read_text().splitlines())
    for row in paths:
        name=row['end'].replace('linienmodule_logic_iir_','linienmodule_logic_raw_acquisition_iir_').replace('linienmodule_iir_','linienmodule_raw_acquisition_iir_')
        cell=row['end'].rsplit('/',1)[0]
        group='pid' if cell in fastcells else 'raw_acquisition_iir' if cell in rawmapped else 'fast_a_iir' if cell in fastamapped else 'fast_b_iir' if cell in fastbmapped else next((s for s in ['raw_acquisition_iir','slow_chain','autolock','pid','gpio','fast_a_iir','fast_b_iir'] if s in name),'other')
        groups[group].append(float(row['slack']))
    slow=[q for q in paths if 'slow_chain_pid' in q['end']]
    results['slow_pid_negative_endpoints']={'csr':sum('storage' in q['end'] for q in slow),'non_csr':sum('storage' not in q['end'] for q in slow)}
    results['endpoint_groups']={k:{'count':len(v),'worst':min(v),'approx_tns':round(sum(v),3)} for k,v in groups.items()}
    (out/'metrics.json').write_bytes(json.dumps(results,indent=2).encode())
    print(json.dumps({k:v for k,v in results.items() if k not in ('raw_dsps',)},indent=2))
    print('RAW_DSP_COUNT',len(dsps));print('ROUND_ANALYSIS_COMPLETE',args.label)
if __name__=='__main__':main()
