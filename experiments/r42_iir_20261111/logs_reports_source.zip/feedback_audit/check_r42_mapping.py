from pathlib import Path
import collections,csv,json,re
h=Path(__file__).parent
m=json.loads((h/'r42_mapped/metrics.json').read_text());rows=m['iir_feedback_fabric']
names=json.loads((h/'r42_generated_structure.json').read_text())['feedback_y_attribute_names']
groups=collections.defaultdict(list)
for row in rows:
 key=re.sub(r'_reg\[\d+\].*','',row['cell']);groups[key].append(row)
assert set(groups)==set(names),(set(groups),set(names))
assert all(len(v)==25 for v in groups.values()) and len(rows)==225
assert all(v['clock']=='clk_2' and v['ref']=='FDRE' and v['INIT']=="1'b0" and v['DONT_TOUCH']=='1' for v in rows)
def parse(p):
 d={}
 for b in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in b.splitlines() if '=' in s);d[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return d
a=parse(h/'r40_mapped/all_dsp.txt');b=parse(h/'r42_mapped/all_dsp.txt')
selected=lambda v:{k:x for k,x in v.items() if re.match(r'linienmodule_(?:fast_[ab]_iir[01]|raw_acquisition_iir)_z_(?:low|high)',k)}
sa,sb=selected(a),selected(b)
diff={k:{'before':sa.get(k),'after':sb.get(k)} for k in sa.keys()|sb.keys() if sa.get(k)!=sb.get(k)}
rec={'passed':True,'nine_feedback_banks':{k:len(v) for k,v in groups.items()},'existing_feedback_state_FDRE_count':225,'all_ADC_clock_INIT0_boundary_DONT_TOUCH':True,'DSP_count_before':len(a),'DSP_count_after':len(b),'named_final_MAC_DSP_changes':diff,'new_feedback_serial_cycles':0,'scope':'Attributes retain actual named feedback fabric FF banks. DSP input register configuration may change intentionally; full RTL/native is separate, not full Root/SDF physical equivalence or CDC/IO signoff.'}
(h/'r42_feedback_mapping_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R42_FEEDBACK_FABRIC_MAPPING_AUDIT_PASS',len(rows),'named DSP differences',len(diff))
