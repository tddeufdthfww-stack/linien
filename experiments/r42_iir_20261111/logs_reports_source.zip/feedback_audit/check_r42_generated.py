from pathlib import Path
import hashlib,json,re
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r42-iir-feedback-fabric');t=r/'gateware/build/trials/20261111_110104_r42_iir_feedback_fabric'
old=Path('D:/RP_Dev/linien_trials/20261111-r38-common-alias-buffer/gateware/build/trials/20261111_092433_r38_common_alias_buffer')
a=(old/'top.v').read_text();b=(t/'top.v').read_text()
pattern=r'^\(\* dont_touch = "true" \*\) (?=reg signed \[24:0\] (linienmodule_(?:fast_[ab]_iir[01]_y[13]|raw_acquisition_iir_y1)) = 25\x27sd0;$)'
names=re.findall(pattern,b,re.M);normalized,count=re.subn(pattern,'',b,flags=re.M)
assert count==9 and len(set(names))==9 and normalized==a,(count,names,'HDL must differ only by nine feedback attributes')
for n in ('top.xdc','csrmap.py'):assert (old/n).read_bytes()==(t/n).read_bytes(),n
rec={'passed':True,'feedback_y_attribute_names':names,'generated_top_only_nine_DONT_TOUCH_additions':True,'CSR_XDC_bytes_identical_R38':True,'new_sync_statements':0,'new_serial_ADC_IIR_CSR_cycles':0,'candidate_top_sha256':hashlib.sha256((t/'top.v').read_bytes()).hexdigest(),'reference_top_sha256':hashlib.sha256((old/'top.v').read_bytes()).hexdigest(),'source_math':json.loads((h/'r42_attribute_only_math.json').read_text())}
(h/'r42_generated_structure.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R42_ONLY_NINE_FEEDBACK_ATTRIBUTES_GENERATED_PASS')
