from pathlib import Path
import json
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r48-routed-pin-refine');t=r/'gateware/build/trials/20261111_130524_r48_compatible_postroute_v3'
m=json.loads((t/'manifest.json').read_text());assert m['route']=='COMPLETE' and m['postopt']=='COMPLETE' and m['input_r47_dcp_unchanged'] and not m['source_changes_during_run'] and all(m['r47_code_and_test_hash_matches'].values())
def parse(p):
 d={}
 for b in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in b.splitlines() if '=' in s);d[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return d
a=parse(h/'r47_mapped/all_dsp.txt');b=parse(h/'r48_mapped/all_dsp.txt');assert len(a)==len(b)==94 and a==b
old=Path(m['input_r47_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(old/n).read_bytes(),n
rec={'passed':True,'all_94_DSP_register_and_operating_properties_same_input_R47_ignoring_LOC_BEL':True,'raw_hardware_test_inputs_same_R47':True,'generated_top_CSR_XDC_bytes_same_R47':True,'new_serial_data_feedback_CSR_cycles':0,'input_DCP_SHA_unchanged':True,'postopt_marker':'EXACT_EXECUTED_STANDALONE_LINE','phys_options':['placement_opt','routing_opt','rewire','critical_cell_opt'],'critical_pin_opt_executed':False,'phys_tns_cleanup_executed':False,'route_tns_cleanup_executed':True,'scope':'Standard compatible post-route flow. Functional/synth inherited R46 via R47; not postroute fullRoot SDF/formal/physical CDC proof.'}
(h/'r48_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R48_ALL94_DSP_AND_FROZEN_INPUTS_AUDIT_PASS')
