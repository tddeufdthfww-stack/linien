if {[catch {
set out {D:/RP_Dev/linien_trials/20261111-r48-routed-pin-refine/gateware/build/trials/20261111_130524_r48_compatible_postroute_v3}
set input_dcp {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed.dcp}

set_param general.maxThreads 2
open_checkpoint $input_dcp
report_timing_summary -file "$out/input_routed_timing.rpt"
phys_opt_design -placement_opt -routing_opt -rewire -critical_cell_opt
report_timing_summary -file "$out/postopt_timing.rpt"
report_utilization -file "$out/postopt_utilization.rpt"
write_checkpoint "$out/postopt.dcp"
puts ROUTED_PIN_PHYSOPT_COMPLETE
route_design -directive Explore -tns_cleanup
report_route_status -file "$out/routed_status.rpt"
report_timing_summary -max_paths 30 -file "$out/routed_timing.rpt"
report_timing -max_paths 100 -file "$out/routed_setup.rpt"
report_timing -delay_type min -max_paths 30 -file "$out/routed_hold.rpt"
report_utilization -file "$out/routed_utilization.rpt"
check_timing -verbose -file "$out/routed_checks.rpt"
report_cdc -details -file "$out/routed_cdc.rpt"
report_drc -file "$out/routed_drc.rpt"
report_clock_interaction -file "$out/routed_clocks.rpt"
report_exceptions -file "$out/routed_exceptions.rpt"
write_checkpoint "$out/routed.dcp"
puts ROUTED_PIN_TRIAL_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
