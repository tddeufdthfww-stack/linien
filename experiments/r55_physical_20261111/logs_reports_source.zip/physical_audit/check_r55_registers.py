from pathlib import Path
import csv,json
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r55-cordic-local-route');t=r/'gateware/build/trials/20261111_170556_r55_cordic_local_route'
m=json.loads((t/'manifest.json').read_text());assert m['route']=='COMPLETE' and m['target_routing']=='COMPLETE' and m['input_r53_dcp_unchanged'] and not m['source_changes_during_run'] and all(m['r53_code_and_test_hash_matches'].values())
def parse(p):
 d={}
 for b in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in b.splitlines() if '=' in s);d[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return d
a=parse(h/'r53_mapped/all_dsp.txt');b=parse(h/'r55_mapped/all_dsp.txt');assert len(a)==len(b)==94 and a==b
old=Path(m['input_r53_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(old/n).read_bytes(),n
before=(t/'target_nets_before.tsv').read_bytes();assert before==(t/'target_nets_after.tsv').read_bytes()==(t/'target_nets_routed.tsv').read_bytes()
rows=list(csv.DictReader((t/'target_nets_before.tsv').open(),delimiter='\t'));assert len(rows)==2 and sorted(int(v['loads']) for v in rows)==[28,43]
rec={'passed':True,'all94_DSP_properties_identical_R53_ignoring_LOC_BEL':True,'two_target_driver_and_all_load_pin_sets_identical_before_after_final':True,'actual_targets':rows,'raw90_hardware_test_inputs_same_R53':True,'top_CSR_XDC_bytes_same_R53':True,'input_DCP_SHA_unchanged':True,'new_serial_cycles_this_routing_round':0,'scope':'Only two data nets unroute/auto_delay followed by TNS cleanup; no physical synthesis/FF copy/logic change. Source native/synth reused R52 via R53, NOT RERUN. Timing result separate, not a fullRoot/SDF/formal/physical CDC proof.'}
(h/'r55_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R55_ALL94_DSP_AND_EXACT_TWO_TARGET_CONNECTIONS_PASS')
