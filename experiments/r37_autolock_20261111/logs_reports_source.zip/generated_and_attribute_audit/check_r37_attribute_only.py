from pathlib import Path
import ast,hashlib,json,subprocess
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r37-tap-value-optimization');rel='gateware/logic/parallel_tap_limit.py'
old=subprocess.check_output(['git','show','52fba6b:'+rel],cwd=r).decode();new=(r/rel).read_text(encoding='utf-8')
removed=[]
class StripValueKeep(ast.NodeTransformer):
    def visit_Expr(self,node):
        c=node.value
        if isinstance(c,ast.Call) and isinstance(c.func,ast.Attribute) and c.func.attr=='add' and len(c.args)==1 and isinstance(c.args[0],ast.Constant) and c.args[0].value=='keep':
            obj=c.func.value
            if isinstance(obj,ast.Attribute) and obj.attr=='attr':
                target=ast.unparse(obj.value)
                if target in ('limiter.y','neg_value'):
                    removed.append(target);return None
        return self.generic_visit(node)
a=ast.dump(StripValueKeep().visit(ast.parse(old)));b=ast.dump(ast.parse(new))
assert a==b and sorted(removed)==['limiter.y','neg_value']
unchanged=[]
for p in ('gateware/logic/autolock_pipeline.py','gateware/logic/instruction_prefetch.py','gateware/logic/same_edge_common.py','gateware/logic/pid.py','gateware/logic/pid_pipeline.py','gateware/logic/iir.py','gateware/logic/chains.py','gateware/linien_module.py','gateware/verilog/axi_slave.v','gateware/verilog/bus_clk_bridge.v','gateware/verilog/red_pitaya_scope.v','tools/check_parallel_tap.py'):
    assert subprocess.check_output(['git','show','52fba6b:'+p],cwd=r).replace(b'\r\n',b'\n')==(r/p).read_bytes().replace(b'\r\n',b'\n'),p
    unchanged.append(p)
record={'passed':True,'removed_only_synthesis_attributes':removed,'entire_behavior_AST_identical_after_removing_exact_two_metadata_calls':True,'behavior_AST_SHA256':hashlib.sha256(a.encode()).hexdigest(),'unrelated_files_same_R36':unchanged,'added_cycles':0,'numeric_proof':'All arithmetic, comparisons, priority, signals, CSR/reset/CE and sync statements are literally same AST. Only two synthesis KEEP constraints removed. Canonical AST comparison does not drop other KEEP attrs.'}
(h/'r37_attribute_only_preanalysis.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print('R37_EXACT_TWO_ATTRIBUTE_REMOVALS_AND_FULL_BEHAVIOR_AST_PASS')
