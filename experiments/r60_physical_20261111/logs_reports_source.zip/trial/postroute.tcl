if {[catch {
set out {D:/RP_Dev/linien_trials/20261111-r60-phase-output-postroute/gateware/build/trials/20261111_192731_r60_phase_output_postroute}
set input_dcp {D:/RP_Dev/linien_trials/20261111-r59-phase-output-distribution/gateware/build/trials/20261111_191728_r59_phase_output_distribution/routed.dcp}

set_param general.maxThreads 2
open_checkpoint $input_dcp
proc ff_sig {c} {
    set sig [list [get_property REF_NAME $c]]
    foreach pin {D C CE R} {lappend sig [get_nets -quiet -of_objects [get_pins -quiet -of_objects $c -filter "REF_PIN_NAME == $pin"]]}
    foreach prop {INIT ASYNC_REG DONT_TOUCH} {lappend sig [get_property $prop $c]}
    return $sig
}
proc family_table {file signatures} {
    set f [open $file w];puts $f "source\tcell\tref\tD\tC\tCE\tR\tINIT\tASYNC_REG\tDONT_TOUCH\tQ_net\tloads\tload_pins"
    set count 0
    dict for {source sig} $signatures {
        set dn [lindex $sig 1]
        set candidates [get_cells -quiet -of_objects [get_pins -quiet -leaf -of_objects [get_nets $dn] -filter {DIRECTION == IN && REF_PIN_NAME == D}]]
        foreach c [lsort -unique $candidates] {
            if {[get_property REF_NAME $c] ne "FDRE" || [ff_sig $c] ne $sig} {continue}
            set q [get_nets -quiet -of_objects [get_pins -quiet -of_objects $c -filter {REF_PIN_NAME == Q}]]
            set lp [lsort [get_pins -quiet -leaf -of_objects $q -filter {DIRECTION == IN}]]
            puts $f [join [concat [list $source $c] $sig [list $q [llength $lp] [join $lp |]]] "\t"]
            incr count
        }
    };close $f
    return $count
}

source "$out/signatures.tcl"
family_table "$out/ff_before_phys.tsv" $signatures
report_timing_summary -file "$out/input_routed_timing.rpt"
phys_opt_design -placement_opt -routing_opt -rewire -critical_cell_opt
report_timing_summary -file "$out/postopt_timing.rpt"
report_utilization -file "$out/postopt_utilization.rpt"
write_checkpoint "$out/postopt.dcp"
family_table "$out/ff_after_phys.tsv" $signatures
puts PHASE_OUTPUT_PHYS_PHYSOPT_COMPLETE
route_design -directive Explore -tns_cleanup
family_table "$out/ff_routed.tsv" $signatures
report_route_status -file "$out/routed_status.rpt"
report_timing_summary -max_paths 30 -file "$out/routed_timing.rpt"
report_timing -max_paths 100 -file "$out/routed_setup.rpt"
report_timing -delay_type min -max_paths 30 -file "$out/routed_hold.rpt"
report_utilization -file "$out/routed_utilization.rpt"
check_timing -verbose -file "$out/routed_checks.rpt"
report_cdc -details -file "$out/routed_cdc.rpt"
report_drc -file "$out/routed_drc.rpt"
report_clock_interaction -file "$out/routed_clocks.rpt"
report_exceptions -file "$out/routed_exceptions.rpt"
write_checkpoint "$out/routed.dcp"
puts PHASE_OUTPUT_PHYS_TRIAL_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
