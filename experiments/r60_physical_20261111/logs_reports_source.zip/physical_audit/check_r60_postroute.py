from pathlib import Path
import re,json,csv,itertools
h=Path(__file__).parent
m=json.loads((h/'r60_mapped/metrics.json').read_text());t=Path(m['trial']);ma=json.loads((t/'manifest.json').read_text())
assert ma['route']=='COMPLETE' and ma['postopt']=='COMPLETE' and ma['input_r59_dcp_unchanged'] and ma['input_FF_table_unchanged'] and not ma['source_changes_during_run'] and all(ma['r59_code_and_test_hash_matches'].values())
def norm(s):return re.sub(r'\s+','',s.replace('\\',''))
busdims={}
def parse(label):
 s=(h/(label+'_mapped/routed_netlist.v')).read_text();out={}
 for mod in re.finditer(r'^module (\S+).*?^endmodule',s,re.M|re.S):
  for v in re.finditer(r'^\s*(?:wire|input|output|inout)\s+\[(\d+):(\d+)\]\s*(\S+)\s*;',mod[0],re.M):
   key=(mod[1],norm(v[3]));dims=(int(v[1]),int(v[2]));assert key not in busdims or busdims[key]==dims,(key,dims,busdims.get(key));busdims[key]=dims
  for v in re.finditer(r'^  (\w+)(?: #\(\s*(.*?)\))?\s+([^\s]+)\s+\((.*?)\);',mod[0],re.M|re.S):
   pars=dict((k,norm(x)) for k,x in re.findall(r'\.(\w+)\((.*?)\)',v[2] or '',re.S));ports=dict((k,norm(x)) for k,x in re.findall(r'\.(\w+)\((.*?)\)',v[4],re.S))
   assert ports;key=mod[1]+'/'+norm(v[3]);assert key not in out;out[key]={'ref':v[1],'params':pars,'ports':ports}
 return out
a,b=parse('r59'),parse('r60');new=set(b)-set(a);removed=set(a)-set(b)
is_lut=lambda c:bool(re.fullmatch('LUT[1-6]',c['ref']))
assert all(is_lut(a[k]) for k in removed),removed
assert all(b[k]['ref'] in ('FDRE','FDSE') or is_lut(b[k]) for k in new),new
def sig(c):return (c['ref'],tuple(sorted(c['params'].items())),tuple(sorted((k,v) for k,v in c['ports'].items() if k!='Q')))
aliases={};copies=[]
for k in sorted(new):
 if b[k]['ref'] not in ('FDRE','FDSE'):continue
 assert k.startswith('top/'),k
 matches=[n for n,c in a.items() if n.startswith('top/') and sig(c)==sig(b[k])];assert matches,(k,b[k])
 qs={a[n]['ports']['Q'] for n in matches};representative=min(qs)
 for q in qs:aliases[q]=representative
 aliases[b[k]['ports']['Q']]=representative;copies.append({'copy':k,'source_matches':matches,'all_matched_state_equal_Q_nets':sorted(qs),'canonical_Q':representative,'signature':b[k]})
def aliased(s):
 for k,v in sorted(aliases.items(),key=lambda kv:-len(kv[0])):s=re.sub(r'(?<![\w$])'+re.escape(k)+r'(?![\w$])',lambda _:v,s)
 return s
def port_bits(s,module):
 s=aliased(s)
 if re.search(r'\d+\{',s):return s
 def whole(v):
  name=v[0];dims=busdims.get((module,name))
  if dims is None:return name
  x,y=dims;return ','.join(name+'['+str(i)+']' for i in range(x,y+(-1 if x>y else 1),-1 if x>y else 1))
 s=re.sub(r'(?<![\w$\]])[A-Za-z_][\w$]*(?![\w$]|\[)',whole,s)
 def expand(v):
  x,y=int(v[2]),int(v[3]);return ','.join(v[1]+'['+str(i)+']' for i in range(x,y+(-1 if x>y else 1),-1 if x>y else 1))
 return re.sub(r'([\w$]+)\[(\d+):(\d+)\]',expand,s).replace('{','').replace('}','')
def canon(c,module):return {**c,'ports':{k:port_bits(v,module) for k,v in c['ports'].items()}}
ac={k:canon(c,k.split('/',1)[0]) for k,c in a.items()};bc={k:canon(c,k.split('/',1)[0]) for k,c in b.items()}
def lutmap(nodes):
 out={}
 for k,c in nodes.items():
  if not is_lut(c):continue
  key=(k.split('/',1)[0],c['ports']['O']);assert key not in out;out[key]=c
 return out
la,lb=lutmap(ac),lutmap(bc);stable={k for k in la.keys()&lb.keys() if la[k]==lb[k]};proofs=[]
def const(s):
 return {'1\'b0':0,'1\'h0':0,'1\'b1':1,'1\'h1':1}.get(s)
def ports(c):return [c['ports']['I'+str(i)] for i in range(int(c['ref'][3:]))]
def cut(nodes,k,seen):
 if const(k[1]) is not None:return set()
 if k in stable or k not in nodes:return {k}
 assert k not in seen,'Combinational cycle'
 return set().union(*(cut(nodes,(k[0],n),seen|{k}) for n in ports(nodes[k])))
def ev(nodes,k,values):
 if const(k[1]) is not None:return const(k[1])
 if k in values:return values[k]
 c=nodes[k];mm=re.fullmatch(r"(\d+)'h([0-9a-fA-F]+)",c['params']['INIT']);assert mm,c
 idx=sum(ev(nodes,(k[0],n),values)<<i for i,n in enumerate(ports(c)))
 return (int(mm[2],16)>>idx)&1
def prove(ka,kb):
 if ka==kb and (ka in stable or ka not in la and kb not in lb):return
 variables=sorted(cut(la,ka,set())|cut(lb,kb,set()));assert len(variables)<=14,(ka,kb,len(variables))
 for bits in itertools.product((0,1),repeat=len(variables)):
  values=dict(zip(variables,bits));assert ev(la,ka,values)==ev(lb,kb,values),(ka,kb,values)
 proofs.append({'old_output':ka,'new_output':kb,'independent_cut_inputs':variables,'exhaustive_boolean_vectors':2**len(variables),'passed':True})
for k in sorted(la.keys()&lb.keys()-stable):prove(k,k)
nonlut_diffs=[]
for k in a.keys()&b.keys():
 if is_lut(a[k]) or is_lut(b[k]):assert is_lut(a[k]) and is_lut(b[k]);continue
 x,y=ac[k],bc[k];assert x['ref']==y['ref'] and x['params']==y['params'] and x['ports'].keys()==y['ports'].keys(),k
 for pn,pv in x['ports'].items():
  nv=y['ports'][pn]
  if pv==nv:continue
  assert ',' not in pv and ',' not in nv,(k,pn,pv,nv)
  prove((k.split('/',1)[0],pv),(k.split('/',1)[0],nv));nonlut_diffs.append((k,pn,pv,nv))
tables={n:list(csv.DictReader((t/n).open(),delimiter='\t')) for n in ('input_ff_routed.tsv','ff_before_phys.tsv','ff_after_phys.tsv','ff_routed.tsv')}
keys=('ref','D','C','CE','R','INIT','ASYNC_REG','DONT_TOUCH')
def states(rows):return {(v['source'],*(v[k] for k in keys)) for v in rows}
assert all(states(v)==states(tables['input_ff_routed.tsv']) for v in tables.values())
def loads(rows):
 out={}
 for v in rows:
  pins=v['load_pins'].split('|') if v['load_pins'] else [];assert len(pins)==int(v['loads']) and not out.get(v['source'],set()).intersection(pins)
  out.setdefault(v['source'],set()).update(pins)
 return out
xl,yl=loads(tables['input_ff_routed.tsv']),loads(tables['ff_routed.tsv']);delta={k:{'added':sorted(yl[k]-xl[k]),'removed':sorted(xl[k]-yl[k])} for k in xl if xl[k]!=yl[k]}
def dsps(lab):
 out={}
 for block in (h/(lab+'_mapped/all_dsp.txt')).read_text().split('CELL_BEGIN')[1:]:
  q=dict(s.split('=',1) for s in block.splitlines() if '=' in s);out[q['NAME']]={k:x for k,x in q.items() if k not in ('LOC','BEL')}
 return out
assert len(dsps('r59'))==94 and dsps('r59')==dsps('r60')
old=json.loads((h/'r59_mapped/metrics.json').read_text())['resources'];cur=m['resources'];assert cur['ff']-old['ff']==len(copies)
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(Path(ma['input_r59_trial'])/n).read_bytes()
rec={'passed':True,'parsed_instance_count_before':len(a),'parsed_instance_count_after':len(b),'new_parallel_FF':copies,'new_parallel_FF_count':len(copies),'new_parallel_FDRE_count':sum(c['signature']['ref']=='FDRE' for c in copies),'new_parallel_FDSE_count':sum(c['signature']['ref']=='FDSE' for c in copies),'state_copy_math':'FDRE q_next=R?0:(CE?D:q); FDSE q_next=S?1:(CE?D:q). Same primitive, INIT, clock, set/reset, CE and D imply equal copies by induction for known digital controls. New multiplier bit0 is FDSE/INIT1 because original CSR resets to1; its S input is preserved, not treated as FDRE/reset0. Multiple matching existing copies are canonicalized only after identical raw state signatures are verified.','initial_audit_stop':'Initial FDRE-only allowed-list stopped on actual FDSE multiplier bit0 replica before PASS. Inspected original and new ref/INIT/S/D/CE/C, added explicit FDSE state-copy proof; no production/netlist edits or skipped port comparisons.','new_LUT_cells':[k for k in sorted(new) if is_lut(b[k])],'removed_LUT_cells':sorted(removed),'changed_shared_LUT_outputs_exhaustively_proven':proofs,'non_LUT_changed_ports_equivalently_proven':nonlut_diffs,'existing_non_LUT_parameters_ports_preserved_or_explicitly_proven':True,'all_original_state_family_signatures_same':True,'raw_family_load_sets_identical':not bool(delta),'raw_family_load_differences':delta,'all94_DSP_properties_same_R59_ignoring_LOC_BEL':True,'resources_before':old,'resources_after':cur,'source_inputs_same_R59':len(ma['r59_code_and_test_hash_matches']),'input_DCP_and_FF_CSV_SHA_unchanged':True,'functional_and_synthesis':'REUSED_R52_VIA_R59_NOT_RERUN','new_serial_ADC_feedback_CSR_cycles':0,'scope':'Parsed mapped instance graph plus exact FDRE/FDSE state-copy induction and exhaustive known-binary changed LUT cuts. Rewire raw load differences if any are recorded, never claimed invariant. Not arbitrary X/Z equivalence, independent fullRoot formal/postmap/SDF simulation, physical CDC/metastability or board/plant proof. RTL native tests and synthesis inherited R52, not rerun.'}
rec['vector_normalization_audit']={'declared_bus_ranges_checked':len(busdims),'method':'Use actual per-module wire/input/output/inout declarations, assert shared ranges identical before/after, expand whole buses and part-selects in exact Verilog MSB-to-LSB concatenation order, then apply verified state aliases. Repetitions kept intact. No port excluded.','initial_stops':'First vector comparison stopped at DSP48E1_48/B: {1b0,xlo0[16:0]} represented by a whole17-bit wire versus17 explicit bits because bit2 was replicated. Added declaration-aware expansion. First declaration regex expected a space after ], but Vivado writes wire [16:0]name; regex corrected to optional whitespace. Assertions still compare every bit and every parsed instance; original netlists/source unchanged.'}
(h/'r60_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R60_PARSED_STATE_GRAPH_LUT_CUT_AND94DSP_AUDIT_PASS',len(copies),len(proofs),len(a),len(b))
