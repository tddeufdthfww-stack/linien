set signatures [dict create]
dict set signatures {linienmodule_fast_b_zi0__9} [list {FDRE} {linienmodule_fast_b_zi0__7_i_1_n_6} {sys_clk} {<const1>} {linienmodule_fast_b_zi0_i_1_n_0} {1'b0} {} {}]
dict set signatures {linienmodule_fast_b_iir0_y2_reg[15]} [list {FDRE} {linienmodule_fast_b_iir0_z_high1_n_84} {sys_clk} {linienmodule_fast_b_iir0_z_low1_i_1_n_0} {dac_rst_OBUF_repN_45} {1'b0} {} {}]
