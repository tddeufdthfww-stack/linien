module ce_leaf(input clk,input rst14,ce14,input [13:0] din14,input rst25,ce25,input [24:0] din25,
output reg [13:0] qr14=14'd0,qs14=14'h3fff,output reg [24:0] qr25=25'd0,qs25=25'h1ffffff);
always @(posedge clk) begin
 if(rst14) begin qr14<=0;qs14<=14'h3fff;end else if(ce14)begin qr14<=din14;qs14<=din14;end
 if(rst25) begin qr25<=0;qs25<=25'h1ffffff;end else if(ce25)begin qr25<=din25;qs25<=din25;end
end
endmodule
