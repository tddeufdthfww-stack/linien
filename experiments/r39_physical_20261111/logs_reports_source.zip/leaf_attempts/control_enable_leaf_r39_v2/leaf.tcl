proc ff_table {file} {
 set f [open $file w];puts $f "cell\tref\tCE_net\tCE_driver_ref\tINIT"
 foreach c [get_cells -hier -filter {REF_NAME == FDRE || REF_NAME == FDSE}] {
  set p [get_pins -of_objects $c -filter {REF_PIN_NAME == CE}]
  set n [get_nets -of_objects $p]
  set d [get_cells -quiet -of_objects [get_pins -quiet -of_objects $n -filter {DIRECTION == OUT}]]
  set dtype INPUT_PORT
  if {[llength $d]} {set dtype [get_property REF_NAME $d]}
  puts $f "$c\t[get_property REF_NAME $c]\t$n\t$dtype\t[get_property INIT $c]"
 };close $f
}
read_verilog leaf.v
synth_design -top ce_leaf -part xc7z020clg400-1 -mode out_of_context
create_clock -period 8 [get_ports clk]
ff_table before.tsv
set ffs [get_cells -hier -filter {REF_NAME == FDRE || REF_NAME == FDSE}]
if {[llength $ffs]!=78} {error "unexpected leaf FF count"}
set_property CONTROL_SET_REMAP ENABLE $ffs
opt_design
ff_table after.tsv
if {[llength [get_cells -hier -filter {REF_NAME == FDRE || REF_NAME == FDSE}]]!=78} {error "leaf register count changed"}
write_verilog -force -mode funcsim -rename_top ce_leaf_mapped mapped.v
write_checkpoint leaf_opt.dcp
puts CONTROL_ENABLE_LEAF_OPT_COMPLETE
exit 0
