`timescale 1ns/1ps
module tb_ce_remap;
reg clk=0;always #4 clk=~clk;
reg rst14=1,ce14=0,rst25=1,ce25=0;reg [13:0] din14=0;reg [24:0] din25=0;
wire [13:0] qr14,qs14,ref_r14,ref_s14;wire [24:0] qr25,qs25,ref_r25,ref_s25;
ce_leaf_mapped dut(.*);
genvar g;
generate for(g=0;g<14;g=g+1)begin:ref14
 FDRE #(.INIT(1'b0)) r(.C(clk),.R(rst14),.CE(ce14),.D(din14[g]),.Q(ref_r14[g]));
 FDSE #(.INIT(1'b1)) s(.C(clk),.S(rst14),.CE(ce14),.D(din14[g]),.Q(ref_s14[g]));
end
for(g=0;g<25;g=g+1)begin:ref25
 FDRE #(.INIT(1'b0)) r(.C(clk),.R(rst25),.CE(ce25),.D(din25[g]),.Q(ref_r25[g]));
 FDSE #(.INIT(1'b1)) s(.C(clk),.S(rst25),.CE(ce25),.D(din25[g]),.Q(ref_s25[g]));
end endgenerate
integer i,cycles=0;integer seed=2026111139;
always @(posedge clk)begin
 #1;if({qr14,qs14,qr25,qs25}!=={ref_r14,ref_s14,ref_r25,ref_s25})
 $fatal(1,"CE_REMAP_DIFF cycle=%0d ctl=%b%b%b%b d14=%h actual=%h/%h ref=%h/%h d25=%h actual=%h/%h ref=%h/%h",cycles,rst14,ce14,rst25,ce25,din14,qr14,qs14,ref_r14,ref_s14,din25,qr25,qs25,ref_r25,ref_s25);
 cycles=cycles+1;
end
initial begin
 repeat(25)@(negedge clk);
 for(i=0;i<40000;i=i+1)begin
  @(negedge clk);ce14=i[0];ce25=i[1];rst14=(i%97==0);rst25=(i%89==0);
  if(i<32)begin rst14=i[0];ce14=i[1];rst25=i[2];ce25=i[3];end
  din14=$random(seed);din25=$random(seed);
  if(i%11==0)begin din14=14'h2000;din25=25'h1000000;end
  if(i%13==0)begin din14=14'h3fff;din25=25'h1ffffff;end
 end
 for(i=0;i<3000;i=i+1)begin
  @(negedge clk);rst14=(i%101==0);rst25=(i%113==0);ce14=i[0];ce25=i[1];din14=$random(seed);din25=$random(seed);
  case(i%4)
   0:begin din14[i%14]=1'bx;din25[i%25]=1'bx;end
   1:begin din14[i%14]=1'bz;din25[i%25]=1'bz;end
   2:begin din14='hx;din25='hx;end
   3:begin din14='hz;din25='hz;end
  endcase
 end
 @(negedge clk);rst14=1;rst25=1;repeat(5)@(negedge clk);
 $display("CONTROL_ENABLE_POSTOPT_NATIVE_PASS cycles=%0d widths=14,25 reset_zero_and_one=1 known_controls=1 XZ_data=3000",cycles);$finish;
end
endmodule
