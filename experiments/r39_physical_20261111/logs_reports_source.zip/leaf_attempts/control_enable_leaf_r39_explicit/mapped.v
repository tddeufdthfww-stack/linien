// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.1 (win64) Build 2902540 Wed May 27 19:54:49 MDT 2020
// Date        : Wed Nov 11 10:08:48 2026
// Host        : DESKTOP-UPVE1P4 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top ce_leaf_mapped mapped.v
// Design      : ce_leaf
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* NETLIST_CHECKSUM = "8a2504e1" *) 
(* NotValidForBitStream *)
module ce_leaf_mapped
   (clk,
    rst14,
    ce14,
    din14,
    rst25,
    ce25,
    din25,
    qr14,
    qs14,
    qr25,
    qs25);
  input clk;
  input rst14;
  input ce14;
  input [13:0]din14;
  input rst25;
  input ce25;
  input [24:0]din25;
  output [13:0]qr14;
  output [13:0]qs14;
  output [24:0]qr25;
  output [24:0]qs25;

  wire ce14;
  wire ce25;
  wire clk;
  wire [13:0]din14;
  wire [24:0]din25;
  wire [13:0]qr14;
  wire \qr14_reg[0]__enable_to_d_data ;
  wire \qr14_reg[10]__enable_to_d_data ;
  wire \qr14_reg[11]__enable_to_d_data ;
  wire \qr14_reg[12]__enable_to_d_data ;
  wire \qr14_reg[13]__enable_to_d_data ;
  wire \qr14_reg[1]__enable_to_d_data ;
  wire \qr14_reg[2]__enable_to_d_data ;
  wire \qr14_reg[3]__enable_to_d_data ;
  wire \qr14_reg[4]__enable_to_d_data ;
  wire \qr14_reg[5]__enable_to_d_data ;
  wire \qr14_reg[6]__enable_to_d_data ;
  wire \qr14_reg[7]__enable_to_d_data ;
  wire \qr14_reg[8]__enable_to_d_data ;
  wire \qr14_reg[9]__enable_to_d_data ;
  wire [24:0]qr25;
  wire \qr25_reg[0]__enable_to_d_data ;
  wire \qr25_reg[10]__enable_to_d_data ;
  wire \qr25_reg[11]__enable_to_d_data ;
  wire \qr25_reg[12]__enable_to_d_data ;
  wire \qr25_reg[13]__enable_to_d_data ;
  wire \qr25_reg[14]__enable_to_d_data ;
  wire \qr25_reg[15]__enable_to_d_data ;
  wire \qr25_reg[16]__enable_to_d_data ;
  wire \qr25_reg[17]__enable_to_d_data ;
  wire \qr25_reg[18]__enable_to_d_data ;
  wire \qr25_reg[19]__enable_to_d_data ;
  wire \qr25_reg[1]__enable_to_d_data ;
  wire \qr25_reg[20]__enable_to_d_data ;
  wire \qr25_reg[21]__enable_to_d_data ;
  wire \qr25_reg[22]__enable_to_d_data ;
  wire \qr25_reg[23]__enable_to_d_data ;
  wire \qr25_reg[24]__enable_to_d_data ;
  wire \qr25_reg[2]__enable_to_d_data ;
  wire \qr25_reg[3]__enable_to_d_data ;
  wire \qr25_reg[4]__enable_to_d_data ;
  wire \qr25_reg[5]__enable_to_d_data ;
  wire \qr25_reg[6]__enable_to_d_data ;
  wire \qr25_reg[7]__enable_to_d_data ;
  wire \qr25_reg[8]__enable_to_d_data ;
  wire \qr25_reg[9]__enable_to_d_data ;
  wire [13:0]qs14;
  wire \qs14_reg[0]__enable_to_d_data ;
  wire \qs14_reg[10]__enable_to_d_data ;
  wire \qs14_reg[11]__enable_to_d_data ;
  wire \qs14_reg[12]__enable_to_d_data ;
  wire \qs14_reg[13]__enable_to_d_data ;
  wire \qs14_reg[1]__enable_to_d_data ;
  wire \qs14_reg[2]__enable_to_d_data ;
  wire \qs14_reg[3]__enable_to_d_data ;
  wire \qs14_reg[4]__enable_to_d_data ;
  wire \qs14_reg[5]__enable_to_d_data ;
  wire \qs14_reg[6]__enable_to_d_data ;
  wire \qs14_reg[7]__enable_to_d_data ;
  wire \qs14_reg[8]__enable_to_d_data ;
  wire \qs14_reg[9]__enable_to_d_data ;
  wire [24:0]qs25;
  wire \qs25_reg[0]__enable_to_d_data ;
  wire \qs25_reg[10]__enable_to_d_data ;
  wire \qs25_reg[11]__enable_to_d_data ;
  wire \qs25_reg[12]__enable_to_d_data ;
  wire \qs25_reg[13]__enable_to_d_data ;
  wire \qs25_reg[14]__enable_to_d_data ;
  wire \qs25_reg[15]__enable_to_d_data ;
  wire \qs25_reg[16]__enable_to_d_data ;
  wire \qs25_reg[17]__enable_to_d_data ;
  wire \qs25_reg[18]__enable_to_d_data ;
  wire \qs25_reg[19]__enable_to_d_data ;
  wire \qs25_reg[1]__enable_to_d_data ;
  wire \qs25_reg[20]__enable_to_d_data ;
  wire \qs25_reg[21]__enable_to_d_data ;
  wire \qs25_reg[22]__enable_to_d_data ;
  wire \qs25_reg[23]__enable_to_d_data ;
  wire \qs25_reg[24]__enable_to_d_data ;
  wire \qs25_reg[2]__enable_to_d_data ;
  wire \qs25_reg[3]__enable_to_d_data ;
  wire \qs25_reg[4]__enable_to_d_data ;
  wire \qs25_reg[5]__enable_to_d_data ;
  wire \qs25_reg[6]__enable_to_d_data ;
  wire \qs25_reg[7]__enable_to_d_data ;
  wire \qs25_reg[8]__enable_to_d_data ;
  wire \qs25_reg[9]__enable_to_d_data ;
  wire rst14;
  wire rst25;

  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[0]__enable_to_d_data ),
        .Q(qr14[0]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[0]__enable_to_d_mux 
       (.I0(din14[0]),
        .I1(qr14[0]),
        .I2(ce14),
        .O(\qr14_reg[0]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[10]__enable_to_d_data ),
        .Q(qr14[10]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[10]__enable_to_d_mux 
       (.I0(din14[10]),
        .I1(qr14[10]),
        .I2(ce14),
        .O(\qr14_reg[10]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[11]__enable_to_d_data ),
        .Q(qr14[11]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[11]__enable_to_d_mux 
       (.I0(din14[11]),
        .I1(qr14[11]),
        .I2(ce14),
        .O(\qr14_reg[11]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[12] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[12]__enable_to_d_data ),
        .Q(qr14[12]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[12]__enable_to_d_mux 
       (.I0(din14[12]),
        .I1(qr14[12]),
        .I2(ce14),
        .O(\qr14_reg[12]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[13]__enable_to_d_data ),
        .Q(qr14[13]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[13]__enable_to_d_mux 
       (.I0(din14[13]),
        .I1(qr14[13]),
        .I2(ce14),
        .O(\qr14_reg[13]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[1]__enable_to_d_data ),
        .Q(qr14[1]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[1]__enable_to_d_mux 
       (.I0(din14[1]),
        .I1(qr14[1]),
        .I2(ce14),
        .O(\qr14_reg[1]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[2]__enable_to_d_data ),
        .Q(qr14[2]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[2]__enable_to_d_mux 
       (.I0(din14[2]),
        .I1(qr14[2]),
        .I2(ce14),
        .O(\qr14_reg[2]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[3]__enable_to_d_data ),
        .Q(qr14[3]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[3]__enable_to_d_mux 
       (.I0(din14[3]),
        .I1(qr14[3]),
        .I2(ce14),
        .O(\qr14_reg[3]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[4]__enable_to_d_data ),
        .Q(qr14[4]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[4]__enable_to_d_mux 
       (.I0(din14[4]),
        .I1(qr14[4]),
        .I2(ce14),
        .O(\qr14_reg[4]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[5]__enable_to_d_data ),
        .Q(qr14[5]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[5]__enable_to_d_mux 
       (.I0(din14[5]),
        .I1(qr14[5]),
        .I2(ce14),
        .O(\qr14_reg[5]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[6]__enable_to_d_data ),
        .Q(qr14[6]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[6]__enable_to_d_mux 
       (.I0(din14[6]),
        .I1(qr14[6]),
        .I2(ce14),
        .O(\qr14_reg[6]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[7]__enable_to_d_data ),
        .Q(qr14[7]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[7]__enable_to_d_mux 
       (.I0(din14[7]),
        .I1(qr14[7]),
        .I2(ce14),
        .O(\qr14_reg[7]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[8]__enable_to_d_data ),
        .Q(qr14[8]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[8]__enable_to_d_mux 
       (.I0(din14[8]),
        .I1(qr14[8]),
        .I2(ce14),
        .O(\qr14_reg[8]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr14_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr14_reg[9]__enable_to_d_data ),
        .Q(qr14[9]),
        .R(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr14_reg[9]__enable_to_d_mux 
       (.I0(din14[9]),
        .I1(qr14[9]),
        .I2(ce14),
        .O(\qr14_reg[9]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[0]__enable_to_d_data ),
        .Q(qr25[0]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[0]__enable_to_d_mux 
       (.I0(din25[0]),
        .I1(qr25[0]),
        .I2(ce25),
        .O(\qr25_reg[0]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[10]__enable_to_d_data ),
        .Q(qr25[10]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[10]__enable_to_d_mux 
       (.I0(din25[10]),
        .I1(qr25[10]),
        .I2(ce25),
        .O(\qr25_reg[10]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[11]__enable_to_d_data ),
        .Q(qr25[11]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[11]__enable_to_d_mux 
       (.I0(din25[11]),
        .I1(qr25[11]),
        .I2(ce25),
        .O(\qr25_reg[11]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[12] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[12]__enable_to_d_data ),
        .Q(qr25[12]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[12]__enable_to_d_mux 
       (.I0(din25[12]),
        .I1(qr25[12]),
        .I2(ce25),
        .O(\qr25_reg[12]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[13]__enable_to_d_data ),
        .Q(qr25[13]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[13]__enable_to_d_mux 
       (.I0(din25[13]),
        .I1(qr25[13]),
        .I2(ce25),
        .O(\qr25_reg[13]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[14] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[14]__enable_to_d_data ),
        .Q(qr25[14]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[14]__enable_to_d_mux 
       (.I0(din25[14]),
        .I1(qr25[14]),
        .I2(ce25),
        .O(\qr25_reg[14]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[15] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[15]__enable_to_d_data ),
        .Q(qr25[15]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[15]__enable_to_d_mux 
       (.I0(din25[15]),
        .I1(qr25[15]),
        .I2(ce25),
        .O(\qr25_reg[15]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[16] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[16]__enable_to_d_data ),
        .Q(qr25[16]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[16]__enable_to_d_mux 
       (.I0(din25[16]),
        .I1(qr25[16]),
        .I2(ce25),
        .O(\qr25_reg[16]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[17] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[17]__enable_to_d_data ),
        .Q(qr25[17]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[17]__enable_to_d_mux 
       (.I0(din25[17]),
        .I1(qr25[17]),
        .I2(ce25),
        .O(\qr25_reg[17]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[18] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[18]__enable_to_d_data ),
        .Q(qr25[18]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[18]__enable_to_d_mux 
       (.I0(din25[18]),
        .I1(qr25[18]),
        .I2(ce25),
        .O(\qr25_reg[18]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[19] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[19]__enable_to_d_data ),
        .Q(qr25[19]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[19]__enable_to_d_mux 
       (.I0(din25[19]),
        .I1(qr25[19]),
        .I2(ce25),
        .O(\qr25_reg[19]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[1]__enable_to_d_data ),
        .Q(qr25[1]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[1]__enable_to_d_mux 
       (.I0(din25[1]),
        .I1(qr25[1]),
        .I2(ce25),
        .O(\qr25_reg[1]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[20] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[20]__enable_to_d_data ),
        .Q(qr25[20]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[20]__enable_to_d_mux 
       (.I0(din25[20]),
        .I1(qr25[20]),
        .I2(ce25),
        .O(\qr25_reg[20]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[21] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[21]__enable_to_d_data ),
        .Q(qr25[21]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[21]__enable_to_d_mux 
       (.I0(din25[21]),
        .I1(qr25[21]),
        .I2(ce25),
        .O(\qr25_reg[21]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[22] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[22]__enable_to_d_data ),
        .Q(qr25[22]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[22]__enable_to_d_mux 
       (.I0(din25[22]),
        .I1(qr25[22]),
        .I2(ce25),
        .O(\qr25_reg[22]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[23] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[23]__enable_to_d_data ),
        .Q(qr25[23]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[23]__enable_to_d_mux 
       (.I0(din25[23]),
        .I1(qr25[23]),
        .I2(ce25),
        .O(\qr25_reg[23]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[24] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[24]__enable_to_d_data ),
        .Q(qr25[24]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[24]__enable_to_d_mux 
       (.I0(din25[24]),
        .I1(qr25[24]),
        .I2(ce25),
        .O(\qr25_reg[24]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[2]__enable_to_d_data ),
        .Q(qr25[2]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[2]__enable_to_d_mux 
       (.I0(din25[2]),
        .I1(qr25[2]),
        .I2(ce25),
        .O(\qr25_reg[2]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[3]__enable_to_d_data ),
        .Q(qr25[3]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[3]__enable_to_d_mux 
       (.I0(din25[3]),
        .I1(qr25[3]),
        .I2(ce25),
        .O(\qr25_reg[3]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[4]__enable_to_d_data ),
        .Q(qr25[4]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[4]__enable_to_d_mux 
       (.I0(din25[4]),
        .I1(qr25[4]),
        .I2(ce25),
        .O(\qr25_reg[4]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[5]__enable_to_d_data ),
        .Q(qr25[5]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[5]__enable_to_d_mux 
       (.I0(din25[5]),
        .I1(qr25[5]),
        .I2(ce25),
        .O(\qr25_reg[5]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[6]__enable_to_d_data ),
        .Q(qr25[6]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[6]__enable_to_d_mux 
       (.I0(din25[6]),
        .I1(qr25[6]),
        .I2(ce25),
        .O(\qr25_reg[6]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[7]__enable_to_d_data ),
        .Q(qr25[7]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[7]__enable_to_d_mux 
       (.I0(din25[7]),
        .I1(qr25[7]),
        .I2(ce25),
        .O(\qr25_reg[7]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[8]__enable_to_d_data ),
        .Q(qr25[8]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[8]__enable_to_d_mux 
       (.I0(din25[8]),
        .I1(qr25[8]),
        .I2(ce25),
        .O(\qr25_reg[8]__enable_to_d_data ));
  FDRE #(
    .INIT(1'b0)) 
    \qr25_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(\qr25_reg[9]__enable_to_d_data ),
        .Q(qr25[9]),
        .R(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qr25_reg[9]__enable_to_d_mux 
       (.I0(din25[9]),
        .I1(qr25[9]),
        .I2(ce25),
        .O(\qr25_reg[9]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[0]__enable_to_d_data ),
        .Q(qs14[0]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[0]__enable_to_d_mux 
       (.I0(din14[0]),
        .I1(qs14[0]),
        .I2(ce14),
        .O(\qs14_reg[0]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[10]__enable_to_d_data ),
        .Q(qs14[10]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[10]__enable_to_d_mux 
       (.I0(din14[10]),
        .I1(qs14[10]),
        .I2(ce14),
        .O(\qs14_reg[10]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[11]__enable_to_d_data ),
        .Q(qs14[11]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[11]__enable_to_d_mux 
       (.I0(din14[11]),
        .I1(qs14[11]),
        .I2(ce14),
        .O(\qs14_reg[11]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[12] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[12]__enable_to_d_data ),
        .Q(qs14[12]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[12]__enable_to_d_mux 
       (.I0(din14[12]),
        .I1(qs14[12]),
        .I2(ce14),
        .O(\qs14_reg[12]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[13]__enable_to_d_data ),
        .Q(qs14[13]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[13]__enable_to_d_mux 
       (.I0(din14[13]),
        .I1(qs14[13]),
        .I2(ce14),
        .O(\qs14_reg[13]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[1]__enable_to_d_data ),
        .Q(qs14[1]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[1]__enable_to_d_mux 
       (.I0(din14[1]),
        .I1(qs14[1]),
        .I2(ce14),
        .O(\qs14_reg[1]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[2]__enable_to_d_data ),
        .Q(qs14[2]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[2]__enable_to_d_mux 
       (.I0(din14[2]),
        .I1(qs14[2]),
        .I2(ce14),
        .O(\qs14_reg[2]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[3]__enable_to_d_data ),
        .Q(qs14[3]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[3]__enable_to_d_mux 
       (.I0(din14[3]),
        .I1(qs14[3]),
        .I2(ce14),
        .O(\qs14_reg[3]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[4]__enable_to_d_data ),
        .Q(qs14[4]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[4]__enable_to_d_mux 
       (.I0(din14[4]),
        .I1(qs14[4]),
        .I2(ce14),
        .O(\qs14_reg[4]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[5]__enable_to_d_data ),
        .Q(qs14[5]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[5]__enable_to_d_mux 
       (.I0(din14[5]),
        .I1(qs14[5]),
        .I2(ce14),
        .O(\qs14_reg[5]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[6]__enable_to_d_data ),
        .Q(qs14[6]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[6]__enable_to_d_mux 
       (.I0(din14[6]),
        .I1(qs14[6]),
        .I2(ce14),
        .O(\qs14_reg[6]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[7]__enable_to_d_data ),
        .Q(qs14[7]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[7]__enable_to_d_mux 
       (.I0(din14[7]),
        .I1(qs14[7]),
        .I2(ce14),
        .O(\qs14_reg[7]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[8]__enable_to_d_data ),
        .Q(qs14[8]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[8]__enable_to_d_mux 
       (.I0(din14[8]),
        .I1(qs14[8]),
        .I2(ce14),
        .O(\qs14_reg[8]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs14_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs14_reg[9]__enable_to_d_data ),
        .Q(qs14[9]),
        .S(rst14));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs14_reg[9]__enable_to_d_mux 
       (.I0(din14[9]),
        .I1(qs14[9]),
        .I2(ce14),
        .O(\qs14_reg[9]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[0]__enable_to_d_data ),
        .Q(qs25[0]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[0]__enable_to_d_mux 
       (.I0(din25[0]),
        .I1(qs25[0]),
        .I2(ce25),
        .O(\qs25_reg[0]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[10]__enable_to_d_data ),
        .Q(qs25[10]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[10]__enable_to_d_mux 
       (.I0(din25[10]),
        .I1(qs25[10]),
        .I2(ce25),
        .O(\qs25_reg[10]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[11]__enable_to_d_data ),
        .Q(qs25[11]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[11]__enable_to_d_mux 
       (.I0(din25[11]),
        .I1(qs25[11]),
        .I2(ce25),
        .O(\qs25_reg[11]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[12] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[12]__enable_to_d_data ),
        .Q(qs25[12]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[12]__enable_to_d_mux 
       (.I0(din25[12]),
        .I1(qs25[12]),
        .I2(ce25),
        .O(\qs25_reg[12]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[13]__enable_to_d_data ),
        .Q(qs25[13]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[13]__enable_to_d_mux 
       (.I0(din25[13]),
        .I1(qs25[13]),
        .I2(ce25),
        .O(\qs25_reg[13]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[14] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[14]__enable_to_d_data ),
        .Q(qs25[14]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[14]__enable_to_d_mux 
       (.I0(din25[14]),
        .I1(qs25[14]),
        .I2(ce25),
        .O(\qs25_reg[14]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[15] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[15]__enable_to_d_data ),
        .Q(qs25[15]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[15]__enable_to_d_mux 
       (.I0(din25[15]),
        .I1(qs25[15]),
        .I2(ce25),
        .O(\qs25_reg[15]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[16] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[16]__enable_to_d_data ),
        .Q(qs25[16]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[16]__enable_to_d_mux 
       (.I0(din25[16]),
        .I1(qs25[16]),
        .I2(ce25),
        .O(\qs25_reg[16]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[17] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[17]__enable_to_d_data ),
        .Q(qs25[17]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[17]__enable_to_d_mux 
       (.I0(din25[17]),
        .I1(qs25[17]),
        .I2(ce25),
        .O(\qs25_reg[17]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[18] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[18]__enable_to_d_data ),
        .Q(qs25[18]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[18]__enable_to_d_mux 
       (.I0(din25[18]),
        .I1(qs25[18]),
        .I2(ce25),
        .O(\qs25_reg[18]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[19] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[19]__enable_to_d_data ),
        .Q(qs25[19]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[19]__enable_to_d_mux 
       (.I0(din25[19]),
        .I1(qs25[19]),
        .I2(ce25),
        .O(\qs25_reg[19]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[1]__enable_to_d_data ),
        .Q(qs25[1]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[1]__enable_to_d_mux 
       (.I0(din25[1]),
        .I1(qs25[1]),
        .I2(ce25),
        .O(\qs25_reg[1]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[20] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[20]__enable_to_d_data ),
        .Q(qs25[20]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[20]__enable_to_d_mux 
       (.I0(din25[20]),
        .I1(qs25[20]),
        .I2(ce25),
        .O(\qs25_reg[20]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[21] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[21]__enable_to_d_data ),
        .Q(qs25[21]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[21]__enable_to_d_mux 
       (.I0(din25[21]),
        .I1(qs25[21]),
        .I2(ce25),
        .O(\qs25_reg[21]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[22] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[22]__enable_to_d_data ),
        .Q(qs25[22]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[22]__enable_to_d_mux 
       (.I0(din25[22]),
        .I1(qs25[22]),
        .I2(ce25),
        .O(\qs25_reg[22]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[23] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[23]__enable_to_d_data ),
        .Q(qs25[23]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[23]__enable_to_d_mux 
       (.I0(din25[23]),
        .I1(qs25[23]),
        .I2(ce25),
        .O(\qs25_reg[23]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[24] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[24]__enable_to_d_data ),
        .Q(qs25[24]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[24]__enable_to_d_mux 
       (.I0(din25[24]),
        .I1(qs25[24]),
        .I2(ce25),
        .O(\qs25_reg[24]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[2]__enable_to_d_data ),
        .Q(qs25[2]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[2]__enable_to_d_mux 
       (.I0(din25[2]),
        .I1(qs25[2]),
        .I2(ce25),
        .O(\qs25_reg[2]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[3]__enable_to_d_data ),
        .Q(qs25[3]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[3]__enable_to_d_mux 
       (.I0(din25[3]),
        .I1(qs25[3]),
        .I2(ce25),
        .O(\qs25_reg[3]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[4]__enable_to_d_data ),
        .Q(qs25[4]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[4]__enable_to_d_mux 
       (.I0(din25[4]),
        .I1(qs25[4]),
        .I2(ce25),
        .O(\qs25_reg[4]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[5]__enable_to_d_data ),
        .Q(qs25[5]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[5]__enable_to_d_mux 
       (.I0(din25[5]),
        .I1(qs25[5]),
        .I2(ce25),
        .O(\qs25_reg[5]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[6]__enable_to_d_data ),
        .Q(qs25[6]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[6]__enable_to_d_mux 
       (.I0(din25[6]),
        .I1(qs25[6]),
        .I2(ce25),
        .O(\qs25_reg[6]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[7]__enable_to_d_data ),
        .Q(qs25[7]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[7]__enable_to_d_mux 
       (.I0(din25[7]),
        .I1(qs25[7]),
        .I2(ce25),
        .O(\qs25_reg[7]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[8]__enable_to_d_data ),
        .Q(qs25[8]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[8]__enable_to_d_mux 
       (.I0(din25[8]),
        .I1(qs25[8]),
        .I2(ce25),
        .O(\qs25_reg[8]__enable_to_d_data ));
  FDSE #(
    .INIT(1'b1)) 
    \qs25_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(\qs25_reg[9]__enable_to_d_data ),
        .Q(qs25[9]),
        .S(rst25));
  LUT3 #(
    .INIT(8'hAC)) 
    \qs25_reg[9]__enable_to_d_mux 
       (.I0(din25[9]),
        .I1(qs25[9]),
        .I2(ce25),
        .O(\qs25_reg[9]__enable_to_d_data ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
