from pathlib import Path
import csv,hashlib,json
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r39-scope-enable-remap');t=r/'gateware/build/trials/20261111_101917_r39_scope_enable_remap'
m=json.loads((t/'manifest.json').read_text());old=Path(m['input_r38_trial'])
assert m['functional']=='REUSED_R38_EXACT_INPUTS_NOT_RERUN' and m['logical_opt']=='COMPLETE' and m['route']=='COMPLETE' and m['input_r38_dcp_unchanged'] and not m['source_changes_during_run'] and all(m['r38_code_and_test_hash_matches'].values())
def rows(n):return list(csv.DictReader((t/n).open(),delimiter='\t'))
before=rows('scope_targets_before.tsv');after=rows('scope_targets_after_route.tsv');assert len(before)==len(after)==366
assert [(v['cell'],v['ref'],v['INIT']) for v in before]==[(v['cell'],v['ref'],v['INIT']) for v in after]
assert all(v['CE_driver_ref']=='VCC' and v['DONT_TOUCH']=='1' for v in after)
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(old/n).read_bytes(),n
leaf=json.loads((r/'gateware/build/control_enable_leaf_r39_explicit/results.json').read_text());assert leaf['passed'] and leaf['FF_before']==leaf['FF_after']==78
property_rows=list(csv.DictReader((r/'gateware/build/control_enable_leaf_r39_v2/after.tsv').open(),delimiter='\t'))
attempts={'initial_logging_prototype':{'status':'HARNESS_ERROR_BEFORE_REMAP','error':'get_property on empty driver collection for top-level CE input port; logged Vivado17-55','native':'NOT_RUN'},'property_only_prototype':{'status':'STRUCTURAL_EFFECT_FAIL','opt_design':'COMPLETE','CE_pins_still_on_original_input':len([v for v in property_rows if v['CE_driver_ref']=='INPUT_PORT']),'native':'NOT_RUN'},'explicit_mux_prototype':{'status':'PASS','native':leaf}}
record={'passed':True,'Scope_target_count':366,'target_names_types_INIT_identical':True,'all_target_CE_after_VCC':True,'FF_state_boundaries_protected':True,'RTL_generated_top_CSR_XDC_same_bytes_R38':True,'raw_hardware_test_input_count':len(m['r38_code_and_test_hash_matches']),'new_synthesis':'NOT_RUN_REUSED_R38','new_full_RTL_regression':'NOT_RUN_REUSED_R38','new_postopt_leaf':leaf,'precheck_attempts':attempts,'added_feedback_or_CSR_cycles':0,'root_postroute_SDF_or_formal':'NOT_RUN','physical_CDC_safety':'NOT_PROVEN'}
(h/'r39_mapping_audit.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print('R39_366_SCOPE_FF_CE_CONST_INIT_AND_SOURCE_PROVENANCE_AUDIT_PASS')
