if {[catch {
set out {D:/RP_Dev/linien_trials/20261111-r39-scope-enable-remap/gateware/build/trials/20261111_101917_r39_scope_enable_remap}
set input_dcp {D:/RP_Dev/linien_trials/20261111-r38-common-alias-buffer/gateware/build/trials/20261111_092433_r38_common_alias_buffer/synth.dcp}
set helper {D:/RP_Dev/linien_trials/20261111-r39-scope-enable-remap/tools/control_enable_remap.tcl}

set_param general.maxThreads 2
open_checkpoint $input_dcp
source $helper
set candidates [get_cells -hier -quiet -filter {NAME =~ red_pitaya_scope/set_* && (REF_NAME == FDRE || REF_NAME == FDSE)}]
set targets {}
foreach c $candidates {
 set cp [get_pins -of_objects $c -filter {REF_PIN_NAME == C}]
 if {[get_clocks -of_objects $cp] ne "clk_2"} {error "Unexpected Scope configuration clock: $c"}
 set net [get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == CE}]]
 set drv [get_cells -quiet -of_objects [get_pins -quiet -of_objects $net -filter {DIRECTION == OUT}]]
 set ref ""
 if {[llength $drv]} {set ref [get_property REF_NAME $drv]}
 if {$ref ni {VCC GND}} {lappend targets $c}
}
if {![llength $targets]} {error "No live Scope configuration enables"}
proc target_table {file cells} {
 set f [open $file w];puts $f "cell\tref\tCE_net\tCE_driver_ref\tINIT\tDONT_TOUCH"
 foreach c $cells {
  set n [get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == CE}]]
  set drv [get_cells -quiet -of_objects [get_pins -quiet -of_objects $n -filter {DIRECTION == OUT}]]
  set ref "INPUT_PORT"
  if {[llength $drv]} {set ref [get_property REF_NAME $drv]}
  puts $f "$c\t[get_property REF_NAME $c]\t$n\t$ref\t[get_property INIT $c]\t[get_property DONT_TOUCH $c]"
 };close $f
}
target_table "$out/scope_targets_before.tsv" $targets
set count [explicit_enable_to_d $targets]
puts "SCOPE_ENABLE_REMAP_COUNT $count"
target_table "$out/scope_targets_after_rewire.tsv" $targets
opt_design
target_table "$out/scope_targets_after_opt.tsv" $targets
report_utilization -file "$out/opt_utilization.rpt"
report_timing_summary -file "$out/opt_timing.rpt"
write_checkpoint "$out/opt.dcp"
puts SCOPE_LOGICAL_OPT_COMPLETE
place_design
phys_opt_design
route_design
target_table "$out/scope_targets_after_route.tsv" $targets
report_route_status -file "$out/routed_status.rpt"
report_timing_summary -max_paths 30 -file "$out/routed_timing.rpt"
report_timing -max_paths 100 -file "$out/routed_setup.rpt"
report_timing -delay_type min -max_paths 30 -file "$out/routed_hold.rpt"
report_utilization -file "$out/routed_utilization.rpt"
check_timing -verbose -file "$out/routed_checks.rpt"
report_cdc -details -file "$out/routed_cdc.rpt"
report_drc -file "$out/routed_drc.rpt"
report_clock_interaction -file "$out/routed_clocks.rpt"
report_exceptions -file "$out/routed_exceptions.rpt"
write_checkpoint "$out/routed.dcp"
puts SCOPE_ENABLE_IMPLEMENTATION_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
