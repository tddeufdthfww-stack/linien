from pathlib import Path
import json,re
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r49-critical-pin');t=r/'gateware/build/trials/20261111_132029_r49_critical_pin'
m=json.loads((t/'manifest.json').read_text());assert m['route']=='COMPLETE' and m['postopt']=='COMPLETE' and m['input_r48_dcp_unchanged'] and not m['source_changes_during_run'] and all(m['r48_code_and_test_hash_matches'].values())
def parse(p):
 d={}
 for b in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in b.splitlines() if '=' in s);d[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return d
a=parse(h/'r48_mapped/all_dsp.txt');b=parse(h/'r49_mapped/all_dsp.txt');assert len(a)==len(b)==94 and a==b
old=Path(m['input_r48_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(old/n).read_bytes(),n
text=(t/'implementation.stdout.log').read_text(errors='replace')
assert re.search(r'(?m)^phys_opt_design completed successfully',text)
row=re.search(r'^\|\s*Critical Path\s*\|\s*0\.000\s*\|\s*0\.000\s*\|\s*0\s*\|\s*0\s*\|\s*0\s*\|',text,re.M);assert row
rec={'passed':True,'all_94_DSP_register_and_operating_properties_same_input_R48_ignoring_LOC_BEL':True,'raw_hardware_test_inputs_same_R48':True,'generated_top_CSR_XDC_bytes_same_R48':True,'new_serial_data_feedback_CSR_cycles':0,'input_DCP_SHA_unchanged':True,'phys_options':['critical_pin_opt'],'critical_pin_optimized_cells_or_nets':0,'postopt_WNS_gain_ns':0,'postopt_TNS_gain_ns':0,'actual_route_TNS_cleanup_executed':True,'scope':'Critical pin option executed, zero optimized cells/nets. Any final route improvement comes from actual routing cleanup, not pin swapping. Functional/synth inherited R46 via R47/R48, NOT RERUN; not fullRoot SDF/formal/physical CDC proof.'}
(h/'r49_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R49_ALL94_DSP_AND_FROZEN_INPUTS_AUDIT_PASS')
