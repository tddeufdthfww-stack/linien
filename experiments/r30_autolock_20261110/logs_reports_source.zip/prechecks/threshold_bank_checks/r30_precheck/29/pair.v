/* Machine-generated using Migen */
module threshold_bank_pair(
	input sys_clk,
	input sys_rst,
	input signed [28:0] value,
	input [4:0] index,
	input [13:0] csr_adr,
	input csr_we,
	input [7:0] csr_dat_w,
	output old_y,
	output new_y,
	output [27:0] selected_t,
	output [28:0] selected_neg,
	output [27:0] cfg,
	output [7:0] csr_read
);

reg [27:0] pair_csrstorage0_storage_full = 28'd0;
wire [27:0] pair_csrstorage0_storage;
reg pair_csrstorage0_re = 1'd0;
reg [27:0] pair_csrstorage1_storage_full = 28'd0;
wire [27:0] pair_csrstorage1_storage;
reg pair_csrstorage1_re = 1'd0;
reg [27:0] pair_csrstorage2_storage_full = 28'd0;
wire [27:0] pair_csrstorage2_storage;
reg pair_csrstorage2_re = 1'd0;
reg [27:0] pair_csrstorage3_storage_full = 28'd0;
wire [27:0] pair_csrstorage3_storage;
reg pair_csrstorage3_re = 1'd0;
reg [27:0] pair_csrstorage4_storage_full = 28'd0;
wire [27:0] pair_csrstorage4_storage;
reg pair_csrstorage4_re = 1'd0;
reg [27:0] pair_csrstorage5_storage_full = 28'd0;
wire [27:0] pair_csrstorage5_storage;
reg pair_csrstorage5_re = 1'd0;
reg [27:0] pair_csrstorage6_storage_full = 28'd0;
wire [27:0] pair_csrstorage6_storage;
reg pair_csrstorage6_re = 1'd0;
reg [27:0] pair_csrstorage7_storage_full = 28'd0;
wire [27:0] pair_csrstorage7_storage;
reg pair_csrstorage7_re = 1'd0;
reg [27:0] pair_csrstorage8_storage_full = 28'd0;
wire [27:0] pair_csrstorage8_storage;
reg pair_csrstorage8_re = 1'd0;
reg [27:0] pair_csrstorage9_storage_full = 28'd0;
wire [27:0] pair_csrstorage9_storage;
reg pair_csrstorage9_re = 1'd0;
reg [27:0] pair_csrstorage10_storage_full = 28'd0;
wire [27:0] pair_csrstorage10_storage;
reg pair_csrstorage10_re = 1'd0;
reg [27:0] pair_csrstorage11_storage_full = 28'd0;
wire [27:0] pair_csrstorage11_storage;
reg pair_csrstorage11_re = 1'd0;
reg [27:0] pair_csrstorage12_storage_full = 28'd0;
wire [27:0] pair_csrstorage12_storage;
reg pair_csrstorage12_re = 1'd0;
reg [27:0] pair_csrstorage13_storage_full = 28'd0;
wire [27:0] pair_csrstorage13_storage;
reg pair_csrstorage13_re = 1'd0;
reg [27:0] pair_csrstorage14_storage_full = 28'd0;
wire [27:0] pair_csrstorage14_storage;
reg pair_csrstorage14_re = 1'd0;
reg [27:0] pair_csrstorage15_storage_full = 28'd0;
wire [27:0] pair_csrstorage15_storage;
reg pair_csrstorage15_re = 1'd0;
reg [27:0] pair_csrstorage16_storage_full = 28'd0;
wire [27:0] pair_csrstorage16_storage;
reg pair_csrstorage16_re = 1'd0;
reg [27:0] pair_csrstorage17_storage_full = 28'd0;
wire [27:0] pair_csrstorage17_storage;
reg pair_csrstorage17_re = 1'd0;
reg [27:0] pair_csrstorage18_storage_full = 28'd0;
wire [27:0] pair_csrstorage18_storage;
reg pair_csrstorage18_re = 1'd0;
reg [27:0] pair_csrstorage19_storage_full = 28'd0;
wire [27:0] pair_csrstorage19_storage;
reg pair_csrstorage19_re = 1'd0;
reg [27:0] pair_csrstorage20_storage_full = 28'd0;
wire [27:0] pair_csrstorage20_storage;
reg pair_csrstorage20_re = 1'd0;
reg [27:0] pair_csrstorage21_storage_full = 28'd0;
wire [27:0] pair_csrstorage21_storage;
reg pair_csrstorage21_re = 1'd0;
reg [27:0] pair_csrstorage22_storage_full = 28'd0;
wire [27:0] pair_csrstorage22_storage;
reg pair_csrstorage22_re = 1'd0;
reg [27:0] pair_csrstorage23_storage_full = 28'd0;
wire [27:0] pair_csrstorage23_storage;
reg pair_csrstorage23_re = 1'd0;
reg [27:0] pair_csrstorage24_storage_full = 28'd0;
wire [27:0] pair_csrstorage24_storage;
reg pair_csrstorage24_re = 1'd0;
reg [27:0] pair_csrstorage25_storage_full = 28'd0;
wire [27:0] pair_csrstorage25_storage;
reg pair_csrstorage25_re = 1'd0;
reg [27:0] pair_csrstorage26_storage_full = 28'd0;
wire [27:0] pair_csrstorage26_storage;
reg pair_csrstorage26_re = 1'd0;
reg [27:0] pair_csrstorage27_storage_full = 28'd0;
wire [27:0] pair_csrstorage27_storage;
reg pair_csrstorage27_re = 1'd0;
reg [27:0] pair_csrstorage28_storage_full = 28'd0;
wire [27:0] pair_csrstorage28_storage;
reg pair_csrstorage28_re = 1'd0;
reg [27:0] pair_csrstorage29_storage_full = 28'd0;
wire [27:0] pair_csrstorage29_storage;
reg pair_csrstorage29_re = 1'd0;
reg [27:0] pair_csrstorage30_storage_full = 28'd0;
wire [27:0] pair_csrstorage30_storage;
reg pair_csrstorage30_re = 1'd0;
reg [27:0] pair_csrstorage31_storage_full = 28'd0;
wire [27:0] pair_csrstorage31_storage;
reg pair_csrstorage31_re = 1'd0;
wire [13:0] pair_bus_adr;
wire pair_bus_we;
wire [7:0] pair_bus_dat_w;
reg [7:0] pair_bus_dat_r = 8'd0;
wire pair_peak003_re;
wire [3:0] pair_peak003_r;
wire [3:0] pair_peak003_w;
wire pair_peak002_re;
wire [7:0] pair_peak002_r;
wire [7:0] pair_peak002_w;
wire pair_peak001_re;
wire [7:0] pair_peak001_r;
wire [7:0] pair_peak001_w;
wire pair_peak000_re;
wire [7:0] pair_peak000_r;
wire [7:0] pair_peak000_w;
wire pair_peak013_re;
wire [3:0] pair_peak013_r;
wire [3:0] pair_peak013_w;
wire pair_peak012_re;
wire [7:0] pair_peak012_r;
wire [7:0] pair_peak012_w;
wire pair_peak011_re;
wire [7:0] pair_peak011_r;
wire [7:0] pair_peak011_w;
wire pair_peak010_re;
wire [7:0] pair_peak010_r;
wire [7:0] pair_peak010_w;
wire pair_peak023_re;
wire [3:0] pair_peak023_r;
wire [3:0] pair_peak023_w;
wire pair_peak022_re;
wire [7:0] pair_peak022_r;
wire [7:0] pair_peak022_w;
wire pair_peak021_re;
wire [7:0] pair_peak021_r;
wire [7:0] pair_peak021_w;
wire pair_peak020_re;
wire [7:0] pair_peak020_r;
wire [7:0] pair_peak020_w;
wire pair_peak033_re;
wire [3:0] pair_peak033_r;
wire [3:0] pair_peak033_w;
wire pair_peak032_re;
wire [7:0] pair_peak032_r;
wire [7:0] pair_peak032_w;
wire pair_peak031_re;
wire [7:0] pair_peak031_r;
wire [7:0] pair_peak031_w;
wire pair_peak030_re;
wire [7:0] pair_peak030_r;
wire [7:0] pair_peak030_w;
wire pair_peak043_re;
wire [3:0] pair_peak043_r;
wire [3:0] pair_peak043_w;
wire pair_peak042_re;
wire [7:0] pair_peak042_r;
wire [7:0] pair_peak042_w;
wire pair_peak041_re;
wire [7:0] pair_peak041_r;
wire [7:0] pair_peak041_w;
wire pair_peak040_re;
wire [7:0] pair_peak040_r;
wire [7:0] pair_peak040_w;
wire pair_peak053_re;
wire [3:0] pair_peak053_r;
wire [3:0] pair_peak053_w;
wire pair_peak052_re;
wire [7:0] pair_peak052_r;
wire [7:0] pair_peak052_w;
wire pair_peak051_re;
wire [7:0] pair_peak051_r;
wire [7:0] pair_peak051_w;
wire pair_peak050_re;
wire [7:0] pair_peak050_r;
wire [7:0] pair_peak050_w;
wire pair_peak063_re;
wire [3:0] pair_peak063_r;
wire [3:0] pair_peak063_w;
wire pair_peak062_re;
wire [7:0] pair_peak062_r;
wire [7:0] pair_peak062_w;
wire pair_peak061_re;
wire [7:0] pair_peak061_r;
wire [7:0] pair_peak061_w;
wire pair_peak060_re;
wire [7:0] pair_peak060_r;
wire [7:0] pair_peak060_w;
wire pair_peak073_re;
wire [3:0] pair_peak073_r;
wire [3:0] pair_peak073_w;
wire pair_peak072_re;
wire [7:0] pair_peak072_r;
wire [7:0] pair_peak072_w;
wire pair_peak071_re;
wire [7:0] pair_peak071_r;
wire [7:0] pair_peak071_w;
wire pair_peak070_re;
wire [7:0] pair_peak070_r;
wire [7:0] pair_peak070_w;
wire pair_peak083_re;
wire [3:0] pair_peak083_r;
wire [3:0] pair_peak083_w;
wire pair_peak082_re;
wire [7:0] pair_peak082_r;
wire [7:0] pair_peak082_w;
wire pair_peak081_re;
wire [7:0] pair_peak081_r;
wire [7:0] pair_peak081_w;
wire pair_peak080_re;
wire [7:0] pair_peak080_r;
wire [7:0] pair_peak080_w;
wire pair_peak093_re;
wire [3:0] pair_peak093_r;
wire [3:0] pair_peak093_w;
wire pair_peak092_re;
wire [7:0] pair_peak092_r;
wire [7:0] pair_peak092_w;
wire pair_peak091_re;
wire [7:0] pair_peak091_r;
wire [7:0] pair_peak091_w;
wire pair_peak090_re;
wire [7:0] pair_peak090_r;
wire [7:0] pair_peak090_w;
wire pair_peak103_re;
wire [3:0] pair_peak103_r;
wire [3:0] pair_peak103_w;
wire pair_peak102_re;
wire [7:0] pair_peak102_r;
wire [7:0] pair_peak102_w;
wire pair_peak101_re;
wire [7:0] pair_peak101_r;
wire [7:0] pair_peak101_w;
wire pair_peak100_re;
wire [7:0] pair_peak100_r;
wire [7:0] pair_peak100_w;
wire pair_peak113_re;
wire [3:0] pair_peak113_r;
wire [3:0] pair_peak113_w;
wire pair_peak112_re;
wire [7:0] pair_peak112_r;
wire [7:0] pair_peak112_w;
wire pair_peak111_re;
wire [7:0] pair_peak111_r;
wire [7:0] pair_peak111_w;
wire pair_peak110_re;
wire [7:0] pair_peak110_r;
wire [7:0] pair_peak110_w;
wire pair_peak123_re;
wire [3:0] pair_peak123_r;
wire [3:0] pair_peak123_w;
wire pair_peak122_re;
wire [7:0] pair_peak122_r;
wire [7:0] pair_peak122_w;
wire pair_peak121_re;
wire [7:0] pair_peak121_r;
wire [7:0] pair_peak121_w;
wire pair_peak120_re;
wire [7:0] pair_peak120_r;
wire [7:0] pair_peak120_w;
wire pair_peak133_re;
wire [3:0] pair_peak133_r;
wire [3:0] pair_peak133_w;
wire pair_peak132_re;
wire [7:0] pair_peak132_r;
wire [7:0] pair_peak132_w;
wire pair_peak131_re;
wire [7:0] pair_peak131_r;
wire [7:0] pair_peak131_w;
wire pair_peak130_re;
wire [7:0] pair_peak130_r;
wire [7:0] pair_peak130_w;
wire pair_peak143_re;
wire [3:0] pair_peak143_r;
wire [3:0] pair_peak143_w;
wire pair_peak142_re;
wire [7:0] pair_peak142_r;
wire [7:0] pair_peak142_w;
wire pair_peak141_re;
wire [7:0] pair_peak141_r;
wire [7:0] pair_peak141_w;
wire pair_peak140_re;
wire [7:0] pair_peak140_r;
wire [7:0] pair_peak140_w;
wire pair_peak153_re;
wire [3:0] pair_peak153_r;
wire [3:0] pair_peak153_w;
wire pair_peak152_re;
wire [7:0] pair_peak152_r;
wire [7:0] pair_peak152_w;
wire pair_peak151_re;
wire [7:0] pair_peak151_r;
wire [7:0] pair_peak151_w;
wire pair_peak150_re;
wire [7:0] pair_peak150_r;
wire [7:0] pair_peak150_w;
wire pair_peak163_re;
wire [3:0] pair_peak163_r;
wire [3:0] pair_peak163_w;
wire pair_peak162_re;
wire [7:0] pair_peak162_r;
wire [7:0] pair_peak162_w;
wire pair_peak161_re;
wire [7:0] pair_peak161_r;
wire [7:0] pair_peak161_w;
wire pair_peak160_re;
wire [7:0] pair_peak160_r;
wire [7:0] pair_peak160_w;
wire pair_peak173_re;
wire [3:0] pair_peak173_r;
wire [3:0] pair_peak173_w;
wire pair_peak172_re;
wire [7:0] pair_peak172_r;
wire [7:0] pair_peak172_w;
wire pair_peak171_re;
wire [7:0] pair_peak171_r;
wire [7:0] pair_peak171_w;
wire pair_peak170_re;
wire [7:0] pair_peak170_r;
wire [7:0] pair_peak170_w;
wire pair_peak183_re;
wire [3:0] pair_peak183_r;
wire [3:0] pair_peak183_w;
wire pair_peak182_re;
wire [7:0] pair_peak182_r;
wire [7:0] pair_peak182_w;
wire pair_peak181_re;
wire [7:0] pair_peak181_r;
wire [7:0] pair_peak181_w;
wire pair_peak180_re;
wire [7:0] pair_peak180_r;
wire [7:0] pair_peak180_w;
wire pair_peak193_re;
wire [3:0] pair_peak193_r;
wire [3:0] pair_peak193_w;
wire pair_peak192_re;
wire [7:0] pair_peak192_r;
wire [7:0] pair_peak192_w;
wire pair_peak191_re;
wire [7:0] pair_peak191_r;
wire [7:0] pair_peak191_w;
wire pair_peak190_re;
wire [7:0] pair_peak190_r;
wire [7:0] pair_peak190_w;
wire pair_peak203_re;
wire [3:0] pair_peak203_r;
wire [3:0] pair_peak203_w;
wire pair_peak202_re;
wire [7:0] pair_peak202_r;
wire [7:0] pair_peak202_w;
wire pair_peak201_re;
wire [7:0] pair_peak201_r;
wire [7:0] pair_peak201_w;
wire pair_peak200_re;
wire [7:0] pair_peak200_r;
wire [7:0] pair_peak200_w;
wire pair_peak213_re;
wire [3:0] pair_peak213_r;
wire [3:0] pair_peak213_w;
wire pair_peak212_re;
wire [7:0] pair_peak212_r;
wire [7:0] pair_peak212_w;
wire pair_peak211_re;
wire [7:0] pair_peak211_r;
wire [7:0] pair_peak211_w;
wire pair_peak210_re;
wire [7:0] pair_peak210_r;
wire [7:0] pair_peak210_w;
wire pair_peak223_re;
wire [3:0] pair_peak223_r;
wire [3:0] pair_peak223_w;
wire pair_peak222_re;
wire [7:0] pair_peak222_r;
wire [7:0] pair_peak222_w;
wire pair_peak221_re;
wire [7:0] pair_peak221_r;
wire [7:0] pair_peak221_w;
wire pair_peak220_re;
wire [7:0] pair_peak220_r;
wire [7:0] pair_peak220_w;
wire pair_peak233_re;
wire [3:0] pair_peak233_r;
wire [3:0] pair_peak233_w;
wire pair_peak232_re;
wire [7:0] pair_peak232_r;
wire [7:0] pair_peak232_w;
wire pair_peak231_re;
wire [7:0] pair_peak231_r;
wire [7:0] pair_peak231_w;
wire pair_peak230_re;
wire [7:0] pair_peak230_r;
wire [7:0] pair_peak230_w;
wire pair_peak243_re;
wire [3:0] pair_peak243_r;
wire [3:0] pair_peak243_w;
wire pair_peak242_re;
wire [7:0] pair_peak242_r;
wire [7:0] pair_peak242_w;
wire pair_peak241_re;
wire [7:0] pair_peak241_r;
wire [7:0] pair_peak241_w;
wire pair_peak240_re;
wire [7:0] pair_peak240_r;
wire [7:0] pair_peak240_w;
wire pair_peak253_re;
wire [3:0] pair_peak253_r;
wire [3:0] pair_peak253_w;
wire pair_peak252_re;
wire [7:0] pair_peak252_r;
wire [7:0] pair_peak252_w;
wire pair_peak251_re;
wire [7:0] pair_peak251_r;
wire [7:0] pair_peak251_w;
wire pair_peak250_re;
wire [7:0] pair_peak250_r;
wire [7:0] pair_peak250_w;
wire pair_peak263_re;
wire [3:0] pair_peak263_r;
wire [3:0] pair_peak263_w;
wire pair_peak262_re;
wire [7:0] pair_peak262_r;
wire [7:0] pair_peak262_w;
wire pair_peak261_re;
wire [7:0] pair_peak261_r;
wire [7:0] pair_peak261_w;
wire pair_peak260_re;
wire [7:0] pair_peak260_r;
wire [7:0] pair_peak260_w;
wire pair_peak273_re;
wire [3:0] pair_peak273_r;
wire [3:0] pair_peak273_w;
wire pair_peak272_re;
wire [7:0] pair_peak272_r;
wire [7:0] pair_peak272_w;
wire pair_peak271_re;
wire [7:0] pair_peak271_r;
wire [7:0] pair_peak271_w;
wire pair_peak270_re;
wire [7:0] pair_peak270_r;
wire [7:0] pair_peak270_w;
wire pair_peak283_re;
wire [3:0] pair_peak283_r;
wire [3:0] pair_peak283_w;
wire pair_peak282_re;
wire [7:0] pair_peak282_r;
wire [7:0] pair_peak282_w;
wire pair_peak281_re;
wire [7:0] pair_peak281_r;
wire [7:0] pair_peak281_w;
wire pair_peak280_re;
wire [7:0] pair_peak280_r;
wire [7:0] pair_peak280_w;
wire pair_peak293_re;
wire [3:0] pair_peak293_r;
wire [3:0] pair_peak293_w;
wire pair_peak292_re;
wire [7:0] pair_peak292_r;
wire [7:0] pair_peak292_w;
wire pair_peak291_re;
wire [7:0] pair_peak291_r;
wire [7:0] pair_peak291_w;
wire pair_peak290_re;
wire [7:0] pair_peak290_r;
wire [7:0] pair_peak290_w;
wire pair_peak303_re;
wire [3:0] pair_peak303_r;
wire [3:0] pair_peak303_w;
wire pair_peak302_re;
wire [7:0] pair_peak302_r;
wire [7:0] pair_peak302_w;
wire pair_peak301_re;
wire [7:0] pair_peak301_r;
wire [7:0] pair_peak301_w;
wire pair_peak300_re;
wire [7:0] pair_peak300_r;
wire [7:0] pair_peak300_w;
wire pair_peak313_re;
wire [3:0] pair_peak313_r;
wire [3:0] pair_peak313_w;
wire pair_peak312_re;
wire [7:0] pair_peak312_r;
wire [7:0] pair_peak312_w;
wire pair_peak311_re;
wire [7:0] pair_peak311_r;
wire [7:0] pair_peak311_w;
wire pair_peak310_re;
wire [7:0] pair_peak310_r;
wire [7:0] pair_peak310_w;
wire pair_sel;
wire signed [27:0] pair_height0;
reg signed [27:0] pair_absolute0;
wire signed [28:0] pair_wide0;
reg signed [27:0] pair_q0 = 28'sd0;
reg signed [28:0] pair_neg0 = 29'sd0;
wire signed [27:0] pair_height1;
reg signed [27:0] pair_absolute1;
wire signed [28:0] pair_wide1;
reg signed [27:0] pair_q1 = 28'sd0;
reg signed [28:0] pair_neg1 = 29'sd0;
wire signed [27:0] pair_height2;
reg signed [27:0] pair_absolute2;
wire signed [28:0] pair_wide2;
reg signed [27:0] pair_q2 = 28'sd0;
reg signed [28:0] pair_neg2 = 29'sd0;
wire signed [27:0] pair_height3;
reg signed [27:0] pair_absolute3;
wire signed [28:0] pair_wide3;
reg signed [27:0] pair_q3 = 28'sd0;
reg signed [28:0] pair_neg3 = 29'sd0;
wire signed [27:0] pair_height4;
reg signed [27:0] pair_absolute4;
wire signed [28:0] pair_wide4;
reg signed [27:0] pair_q4 = 28'sd0;
reg signed [28:0] pair_neg4 = 29'sd0;
wire signed [27:0] pair_height5;
reg signed [27:0] pair_absolute5;
wire signed [28:0] pair_wide5;
reg signed [27:0] pair_q5 = 28'sd0;
reg signed [28:0] pair_neg5 = 29'sd0;
wire signed [27:0] pair_height6;
reg signed [27:0] pair_absolute6;
wire signed [28:0] pair_wide6;
reg signed [27:0] pair_q6 = 28'sd0;
reg signed [28:0] pair_neg6 = 29'sd0;
wire signed [27:0] pair_height7;
reg signed [27:0] pair_absolute7;
wire signed [28:0] pair_wide7;
reg signed [27:0] pair_q7 = 28'sd0;
reg signed [28:0] pair_neg7 = 29'sd0;
wire signed [27:0] pair_height8;
reg signed [27:0] pair_absolute8;
wire signed [28:0] pair_wide8;
reg signed [27:0] pair_q8 = 28'sd0;
reg signed [28:0] pair_neg8 = 29'sd0;
wire signed [27:0] pair_height9;
reg signed [27:0] pair_absolute9;
wire signed [28:0] pair_wide9;
reg signed [27:0] pair_q9 = 28'sd0;
reg signed [28:0] pair_neg9 = 29'sd0;
wire signed [27:0] pair_height10;
reg signed [27:0] pair_absolute10;
wire signed [28:0] pair_wide10;
reg signed [27:0] pair_q10 = 28'sd0;
reg signed [28:0] pair_neg10 = 29'sd0;
wire signed [27:0] pair_height11;
reg signed [27:0] pair_absolute11;
wire signed [28:0] pair_wide11;
reg signed [27:0] pair_q11 = 28'sd0;
reg signed [28:0] pair_neg11 = 29'sd0;
wire signed [27:0] pair_height12;
reg signed [27:0] pair_absolute12;
wire signed [28:0] pair_wide12;
reg signed [27:0] pair_q12 = 28'sd0;
reg signed [28:0] pair_neg12 = 29'sd0;
wire signed [27:0] pair_height13;
reg signed [27:0] pair_absolute13;
wire signed [28:0] pair_wide13;
reg signed [27:0] pair_q13 = 28'sd0;
reg signed [28:0] pair_neg13 = 29'sd0;
wire signed [27:0] pair_height14;
reg signed [27:0] pair_absolute14;
wire signed [28:0] pair_wide14;
reg signed [27:0] pair_q14 = 28'sd0;
reg signed [28:0] pair_neg14 = 29'sd0;
wire signed [27:0] pair_height15;
reg signed [27:0] pair_absolute15;
wire signed [28:0] pair_wide15;
reg signed [27:0] pair_q15 = 28'sd0;
reg signed [28:0] pair_neg15 = 29'sd0;
wire signed [27:0] pair_height16;
reg signed [27:0] pair_absolute16;
wire signed [28:0] pair_wide16;
reg signed [27:0] pair_q16 = 28'sd0;
reg signed [28:0] pair_neg16 = 29'sd0;
wire signed [27:0] pair_height17;
reg signed [27:0] pair_absolute17;
wire signed [28:0] pair_wide17;
reg signed [27:0] pair_q17 = 28'sd0;
reg signed [28:0] pair_neg17 = 29'sd0;
wire signed [27:0] pair_height18;
reg signed [27:0] pair_absolute18;
wire signed [28:0] pair_wide18;
reg signed [27:0] pair_q18 = 28'sd0;
reg signed [28:0] pair_neg18 = 29'sd0;
wire signed [27:0] pair_height19;
reg signed [27:0] pair_absolute19;
wire signed [28:0] pair_wide19;
reg signed [27:0] pair_q19 = 28'sd0;
reg signed [28:0] pair_neg19 = 29'sd0;
wire signed [27:0] pair_height20;
reg signed [27:0] pair_absolute20;
wire signed [28:0] pair_wide20;
reg signed [27:0] pair_q20 = 28'sd0;
reg signed [28:0] pair_neg20 = 29'sd0;
wire signed [27:0] pair_height21;
reg signed [27:0] pair_absolute21;
wire signed [28:0] pair_wide21;
reg signed [27:0] pair_q21 = 28'sd0;
reg signed [28:0] pair_neg21 = 29'sd0;
wire signed [27:0] pair_height22;
reg signed [27:0] pair_absolute22;
wire signed [28:0] pair_wide22;
reg signed [27:0] pair_q22 = 28'sd0;
reg signed [28:0] pair_neg22 = 29'sd0;
wire signed [27:0] pair_height23;
reg signed [27:0] pair_absolute23;
wire signed [28:0] pair_wide23;
reg signed [27:0] pair_q23 = 28'sd0;
reg signed [28:0] pair_neg23 = 29'sd0;
wire signed [27:0] pair_height24;
reg signed [27:0] pair_absolute24;
wire signed [28:0] pair_wide24;
reg signed [27:0] pair_q24 = 28'sd0;
reg signed [28:0] pair_neg24 = 29'sd0;
wire signed [27:0] pair_height25;
reg signed [27:0] pair_absolute25;
wire signed [28:0] pair_wide25;
reg signed [27:0] pair_q25 = 28'sd0;
reg signed [28:0] pair_neg25 = 29'sd0;
wire signed [27:0] pair_height26;
reg signed [27:0] pair_absolute26;
wire signed [28:0] pair_wide26;
reg signed [27:0] pair_q26 = 28'sd0;
reg signed [28:0] pair_neg26 = 29'sd0;
wire signed [27:0] pair_height27;
reg signed [27:0] pair_absolute27;
wire signed [28:0] pair_wide27;
reg signed [27:0] pair_q27 = 28'sd0;
reg signed [28:0] pair_neg27 = 29'sd0;
wire signed [27:0] pair_height28;
reg signed [27:0] pair_absolute28;
wire signed [28:0] pair_wide28;
reg signed [27:0] pair_q28 = 28'sd0;
reg signed [28:0] pair_neg28 = 29'sd0;
wire signed [27:0] pair_height29;
reg signed [27:0] pair_absolute29;
wire signed [28:0] pair_wide29;
reg signed [27:0] pair_q29 = 28'sd0;
reg signed [28:0] pair_neg29 = 29'sd0;
wire signed [27:0] pair_height30;
reg signed [27:0] pair_absolute30;
wire signed [28:0] pair_wide30;
reg signed [27:0] pair_q30 = 28'sd0;
reg signed [28:0] pair_neg30 = 29'sd0;
wire signed [27:0] pair_height31;
reg signed [27:0] pair_absolute31;
wire signed [28:0] pair_wide31;
reg signed [27:0] pair_q31 = 28'sd0;
reg signed [28:0] pair_neg31 = 29'sd0;
wire signed [27:0] pair_selected;
wire signed [28:0] pair_selected_neg;
wire pair_old;
wire pair_new;
(* keep = "true" *) wire pair_result0;
(* keep = "true" *) wire pair_result1;
(* keep = "true" *) wire pair_result2;
(* keep = "true" *) wire pair_result3;
(* keep = "true" *) wire pair_result4;
(* keep = "true" *) wire pair_result5;
(* keep = "true" *) wire pair_result6;
(* keep = "true" *) wire pair_result7;
(* keep = "true" *) wire pair_result8;
(* keep = "true" *) wire pair_result9;
(* keep = "true" *) wire pair_result10;
(* keep = "true" *) wire pair_result11;
(* keep = "true" *) wire pair_result12;
(* keep = "true" *) wire pair_result13;
(* keep = "true" *) wire pair_result14;
(* keep = "true" *) wire pair_result15;
(* keep = "true" *) wire pair_result16;
(* keep = "true" *) wire pair_result17;
(* keep = "true" *) wire pair_result18;
(* keep = "true" *) wire pair_result19;
(* keep = "true" *) wire pair_result20;
(* keep = "true" *) wire pair_result21;
(* keep = "true" *) wire pair_result22;
(* keep = "true" *) wire pair_result23;
(* keep = "true" *) wire pair_result24;
(* keep = "true" *) wire pair_result25;
(* keep = "true" *) wire pair_result26;
(* keep = "true" *) wire pair_result27;
(* keep = "true" *) wire pair_result28;
(* keep = "true" *) wire pair_result29;
(* keep = "true" *) wire pair_result30;
(* keep = "true" *) wire pair_result31;
reg signed [27:0] array_muxed0;
reg signed [28:0] array_muxed1;
reg array_muxed2;
reg [27:0] array_muxed3;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign pair_bus_adr = csr_adr;
assign pair_bus_we = csr_we;
assign pair_bus_dat_w = csr_dat_w;
assign pair_height0 = pair_csrstorage0_storage;

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	pair_absolute0 <= 28'sd0;
	if ((pair_height0 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute0 <= pair_height0;
	end else begin
		pair_absolute0 <= (-pair_height0);
	end
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end
assign pair_wide0 = pair_absolute0;
assign pair_height1 = pair_csrstorage1_storage;

// synthesis translate_off
reg dummy_d_1;
// synthesis translate_on
always @(*) begin
	pair_absolute1 <= 28'sd0;
	if ((pair_height1 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute1 <= pair_height1;
	end else begin
		pair_absolute1 <= (-pair_height1);
	end
// synthesis translate_off
	dummy_d_1 <= dummy_s;
// synthesis translate_on
end
assign pair_wide1 = pair_absolute1;
assign pair_height2 = pair_csrstorage2_storage;

// synthesis translate_off
reg dummy_d_2;
// synthesis translate_on
always @(*) begin
	pair_absolute2 <= 28'sd0;
	if ((pair_height2 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute2 <= pair_height2;
	end else begin
		pair_absolute2 <= (-pair_height2);
	end
// synthesis translate_off
	dummy_d_2 <= dummy_s;
// synthesis translate_on
end
assign pair_wide2 = pair_absolute2;
assign pair_height3 = pair_csrstorage3_storage;

// synthesis translate_off
reg dummy_d_3;
// synthesis translate_on
always @(*) begin
	pair_absolute3 <= 28'sd0;
	if ((pair_height3 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute3 <= pair_height3;
	end else begin
		pair_absolute3 <= (-pair_height3);
	end
// synthesis translate_off
	dummy_d_3 <= dummy_s;
// synthesis translate_on
end
assign pair_wide3 = pair_absolute3;
assign pair_height4 = pair_csrstorage4_storage;

// synthesis translate_off
reg dummy_d_4;
// synthesis translate_on
always @(*) begin
	pair_absolute4 <= 28'sd0;
	if ((pair_height4 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute4 <= pair_height4;
	end else begin
		pair_absolute4 <= (-pair_height4);
	end
// synthesis translate_off
	dummy_d_4 <= dummy_s;
// synthesis translate_on
end
assign pair_wide4 = pair_absolute4;
assign pair_height5 = pair_csrstorage5_storage;

// synthesis translate_off
reg dummy_d_5;
// synthesis translate_on
always @(*) begin
	pair_absolute5 <= 28'sd0;
	if ((pair_height5 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute5 <= pair_height5;
	end else begin
		pair_absolute5 <= (-pair_height5);
	end
// synthesis translate_off
	dummy_d_5 <= dummy_s;
// synthesis translate_on
end
assign pair_wide5 = pair_absolute5;
assign pair_height6 = pair_csrstorage6_storage;

// synthesis translate_off
reg dummy_d_6;
// synthesis translate_on
always @(*) begin
	pair_absolute6 <= 28'sd0;
	if ((pair_height6 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute6 <= pair_height6;
	end else begin
		pair_absolute6 <= (-pair_height6);
	end
// synthesis translate_off
	dummy_d_6 <= dummy_s;
// synthesis translate_on
end
assign pair_wide6 = pair_absolute6;
assign pair_height7 = pair_csrstorage7_storage;

// synthesis translate_off
reg dummy_d_7;
// synthesis translate_on
always @(*) begin
	pair_absolute7 <= 28'sd0;
	if ((pair_height7 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute7 <= pair_height7;
	end else begin
		pair_absolute7 <= (-pair_height7);
	end
// synthesis translate_off
	dummy_d_7 <= dummy_s;
// synthesis translate_on
end
assign pair_wide7 = pair_absolute7;
assign pair_height8 = pair_csrstorage8_storage;

// synthesis translate_off
reg dummy_d_8;
// synthesis translate_on
always @(*) begin
	pair_absolute8 <= 28'sd0;
	if ((pair_height8 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute8 <= pair_height8;
	end else begin
		pair_absolute8 <= (-pair_height8);
	end
// synthesis translate_off
	dummy_d_8 <= dummy_s;
// synthesis translate_on
end
assign pair_wide8 = pair_absolute8;
assign pair_height9 = pair_csrstorage9_storage;

// synthesis translate_off
reg dummy_d_9;
// synthesis translate_on
always @(*) begin
	pair_absolute9 <= 28'sd0;
	if ((pair_height9 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute9 <= pair_height9;
	end else begin
		pair_absolute9 <= (-pair_height9);
	end
// synthesis translate_off
	dummy_d_9 <= dummy_s;
// synthesis translate_on
end
assign pair_wide9 = pair_absolute9;
assign pair_height10 = pair_csrstorage10_storage;

// synthesis translate_off
reg dummy_d_10;
// synthesis translate_on
always @(*) begin
	pair_absolute10 <= 28'sd0;
	if ((pair_height10 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute10 <= pair_height10;
	end else begin
		pair_absolute10 <= (-pair_height10);
	end
// synthesis translate_off
	dummy_d_10 <= dummy_s;
// synthesis translate_on
end
assign pair_wide10 = pair_absolute10;
assign pair_height11 = pair_csrstorage11_storage;

// synthesis translate_off
reg dummy_d_11;
// synthesis translate_on
always @(*) begin
	pair_absolute11 <= 28'sd0;
	if ((pair_height11 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute11 <= pair_height11;
	end else begin
		pair_absolute11 <= (-pair_height11);
	end
// synthesis translate_off
	dummy_d_11 <= dummy_s;
// synthesis translate_on
end
assign pair_wide11 = pair_absolute11;
assign pair_height12 = pair_csrstorage12_storage;

// synthesis translate_off
reg dummy_d_12;
// synthesis translate_on
always @(*) begin
	pair_absolute12 <= 28'sd0;
	if ((pair_height12 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute12 <= pair_height12;
	end else begin
		pair_absolute12 <= (-pair_height12);
	end
// synthesis translate_off
	dummy_d_12 <= dummy_s;
// synthesis translate_on
end
assign pair_wide12 = pair_absolute12;
assign pair_height13 = pair_csrstorage13_storage;

// synthesis translate_off
reg dummy_d_13;
// synthesis translate_on
always @(*) begin
	pair_absolute13 <= 28'sd0;
	if ((pair_height13 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute13 <= pair_height13;
	end else begin
		pair_absolute13 <= (-pair_height13);
	end
// synthesis translate_off
	dummy_d_13 <= dummy_s;
// synthesis translate_on
end
assign pair_wide13 = pair_absolute13;
assign pair_height14 = pair_csrstorage14_storage;

// synthesis translate_off
reg dummy_d_14;
// synthesis translate_on
always @(*) begin
	pair_absolute14 <= 28'sd0;
	if ((pair_height14 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute14 <= pair_height14;
	end else begin
		pair_absolute14 <= (-pair_height14);
	end
// synthesis translate_off
	dummy_d_14 <= dummy_s;
// synthesis translate_on
end
assign pair_wide14 = pair_absolute14;
assign pair_height15 = pair_csrstorage15_storage;

// synthesis translate_off
reg dummy_d_15;
// synthesis translate_on
always @(*) begin
	pair_absolute15 <= 28'sd0;
	if ((pair_height15 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute15 <= pair_height15;
	end else begin
		pair_absolute15 <= (-pair_height15);
	end
// synthesis translate_off
	dummy_d_15 <= dummy_s;
// synthesis translate_on
end
assign pair_wide15 = pair_absolute15;
assign pair_height16 = pair_csrstorage16_storage;

// synthesis translate_off
reg dummy_d_16;
// synthesis translate_on
always @(*) begin
	pair_absolute16 <= 28'sd0;
	if ((pair_height16 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute16 <= pair_height16;
	end else begin
		pair_absolute16 <= (-pair_height16);
	end
// synthesis translate_off
	dummy_d_16 <= dummy_s;
// synthesis translate_on
end
assign pair_wide16 = pair_absolute16;
assign pair_height17 = pair_csrstorage17_storage;

// synthesis translate_off
reg dummy_d_17;
// synthesis translate_on
always @(*) begin
	pair_absolute17 <= 28'sd0;
	if ((pair_height17 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute17 <= pair_height17;
	end else begin
		pair_absolute17 <= (-pair_height17);
	end
// synthesis translate_off
	dummy_d_17 <= dummy_s;
// synthesis translate_on
end
assign pair_wide17 = pair_absolute17;
assign pair_height18 = pair_csrstorage18_storage;

// synthesis translate_off
reg dummy_d_18;
// synthesis translate_on
always @(*) begin
	pair_absolute18 <= 28'sd0;
	if ((pair_height18 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute18 <= pair_height18;
	end else begin
		pair_absolute18 <= (-pair_height18);
	end
// synthesis translate_off
	dummy_d_18 <= dummy_s;
// synthesis translate_on
end
assign pair_wide18 = pair_absolute18;
assign pair_height19 = pair_csrstorage19_storage;

// synthesis translate_off
reg dummy_d_19;
// synthesis translate_on
always @(*) begin
	pair_absolute19 <= 28'sd0;
	if ((pair_height19 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute19 <= pair_height19;
	end else begin
		pair_absolute19 <= (-pair_height19);
	end
// synthesis translate_off
	dummy_d_19 <= dummy_s;
// synthesis translate_on
end
assign pair_wide19 = pair_absolute19;
assign pair_height20 = pair_csrstorage20_storage;

// synthesis translate_off
reg dummy_d_20;
// synthesis translate_on
always @(*) begin
	pair_absolute20 <= 28'sd0;
	if ((pair_height20 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute20 <= pair_height20;
	end else begin
		pair_absolute20 <= (-pair_height20);
	end
// synthesis translate_off
	dummy_d_20 <= dummy_s;
// synthesis translate_on
end
assign pair_wide20 = pair_absolute20;
assign pair_height21 = pair_csrstorage21_storage;

// synthesis translate_off
reg dummy_d_21;
// synthesis translate_on
always @(*) begin
	pair_absolute21 <= 28'sd0;
	if ((pair_height21 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute21 <= pair_height21;
	end else begin
		pair_absolute21 <= (-pair_height21);
	end
// synthesis translate_off
	dummy_d_21 <= dummy_s;
// synthesis translate_on
end
assign pair_wide21 = pair_absolute21;
assign pair_height22 = pair_csrstorage22_storage;

// synthesis translate_off
reg dummy_d_22;
// synthesis translate_on
always @(*) begin
	pair_absolute22 <= 28'sd0;
	if ((pair_height22 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute22 <= pair_height22;
	end else begin
		pair_absolute22 <= (-pair_height22);
	end
// synthesis translate_off
	dummy_d_22 <= dummy_s;
// synthesis translate_on
end
assign pair_wide22 = pair_absolute22;
assign pair_height23 = pair_csrstorage23_storage;

// synthesis translate_off
reg dummy_d_23;
// synthesis translate_on
always @(*) begin
	pair_absolute23 <= 28'sd0;
	if ((pair_height23 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute23 <= pair_height23;
	end else begin
		pair_absolute23 <= (-pair_height23);
	end
// synthesis translate_off
	dummy_d_23 <= dummy_s;
// synthesis translate_on
end
assign pair_wide23 = pair_absolute23;
assign pair_height24 = pair_csrstorage24_storage;

// synthesis translate_off
reg dummy_d_24;
// synthesis translate_on
always @(*) begin
	pair_absolute24 <= 28'sd0;
	if ((pair_height24 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute24 <= pair_height24;
	end else begin
		pair_absolute24 <= (-pair_height24);
	end
// synthesis translate_off
	dummy_d_24 <= dummy_s;
// synthesis translate_on
end
assign pair_wide24 = pair_absolute24;
assign pair_height25 = pair_csrstorage25_storage;

// synthesis translate_off
reg dummy_d_25;
// synthesis translate_on
always @(*) begin
	pair_absolute25 <= 28'sd0;
	if ((pair_height25 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute25 <= pair_height25;
	end else begin
		pair_absolute25 <= (-pair_height25);
	end
// synthesis translate_off
	dummy_d_25 <= dummy_s;
// synthesis translate_on
end
assign pair_wide25 = pair_absolute25;
assign pair_height26 = pair_csrstorage26_storage;

// synthesis translate_off
reg dummy_d_26;
// synthesis translate_on
always @(*) begin
	pair_absolute26 <= 28'sd0;
	if ((pair_height26 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute26 <= pair_height26;
	end else begin
		pair_absolute26 <= (-pair_height26);
	end
// synthesis translate_off
	dummy_d_26 <= dummy_s;
// synthesis translate_on
end
assign pair_wide26 = pair_absolute26;
assign pair_height27 = pair_csrstorage27_storage;

// synthesis translate_off
reg dummy_d_27;
// synthesis translate_on
always @(*) begin
	pair_absolute27 <= 28'sd0;
	if ((pair_height27 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute27 <= pair_height27;
	end else begin
		pair_absolute27 <= (-pair_height27);
	end
// synthesis translate_off
	dummy_d_27 <= dummy_s;
// synthesis translate_on
end
assign pair_wide27 = pair_absolute27;
assign pair_height28 = pair_csrstorage28_storage;

// synthesis translate_off
reg dummy_d_28;
// synthesis translate_on
always @(*) begin
	pair_absolute28 <= 28'sd0;
	if ((pair_height28 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute28 <= pair_height28;
	end else begin
		pair_absolute28 <= (-pair_height28);
	end
// synthesis translate_off
	dummy_d_28 <= dummy_s;
// synthesis translate_on
end
assign pair_wide28 = pair_absolute28;
assign pair_height29 = pair_csrstorage29_storage;

// synthesis translate_off
reg dummy_d_29;
// synthesis translate_on
always @(*) begin
	pair_absolute29 <= 28'sd0;
	if ((pair_height29 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute29 <= pair_height29;
	end else begin
		pair_absolute29 <= (-pair_height29);
	end
// synthesis translate_off
	dummy_d_29 <= dummy_s;
// synthesis translate_on
end
assign pair_wide29 = pair_absolute29;
assign pair_height30 = pair_csrstorage30_storage;

// synthesis translate_off
reg dummy_d_30;
// synthesis translate_on
always @(*) begin
	pair_absolute30 <= 28'sd0;
	if ((pair_height30 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute30 <= pair_height30;
	end else begin
		pair_absolute30 <= (-pair_height30);
	end
// synthesis translate_off
	dummy_d_30 <= dummy_s;
// synthesis translate_on
end
assign pair_wide30 = pair_absolute30;
assign pair_height31 = pair_csrstorage31_storage;

// synthesis translate_off
reg dummy_d_31;
// synthesis translate_on
always @(*) begin
	pair_absolute31 <= 28'sd0;
	if ((pair_height31 >= $signed({1'd0, 1'd0}))) begin
		pair_absolute31 <= pair_height31;
	end else begin
		pair_absolute31 <= (-pair_height31);
	end
// synthesis translate_off
	dummy_d_31 <= dummy_s;
// synthesis translate_on
end
assign pair_wide31 = pair_absolute31;
assign pair_selected = array_muxed0;
assign pair_selected_neg = array_muxed1;
assign pair_old = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_selected_neg) : (value >= pair_selected));
assign pair_result0 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg0) : (value >= pair_q0));
assign pair_result1 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg1) : (value >= pair_q1));
assign pair_result2 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg2) : (value >= pair_q2));
assign pair_result3 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg3) : (value >= pair_q3));
assign pair_result4 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg4) : (value >= pair_q4));
assign pair_result5 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg5) : (value >= pair_q5));
assign pair_result6 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg6) : (value >= pair_q6));
assign pair_result7 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg7) : (value >= pair_q7));
assign pair_result8 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg8) : (value >= pair_q8));
assign pair_result9 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg9) : (value >= pair_q9));
assign pair_result10 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg10) : (value >= pair_q10));
assign pair_result11 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg11) : (value >= pair_q11));
assign pair_result12 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg12) : (value >= pair_q12));
assign pair_result13 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg13) : (value >= pair_q13));
assign pair_result14 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg14) : (value >= pair_q14));
assign pair_result15 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg15) : (value >= pair_q15));
assign pair_result16 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg16) : (value >= pair_q16));
assign pair_result17 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg17) : (value >= pair_q17));
assign pair_result18 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg18) : (value >= pair_q18));
assign pair_result19 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg19) : (value >= pair_q19));
assign pair_result20 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg20) : (value >= pair_q20));
assign pair_result21 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg21) : (value >= pair_q21));
assign pair_result22 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg22) : (value >= pair_q22));
assign pair_result23 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg23) : (value >= pair_q23));
assign pair_result24 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg24) : (value >= pair_q24));
assign pair_result25 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg25) : (value >= pair_q25));
assign pair_result26 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg26) : (value >= pair_q26));
assign pair_result27 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg27) : (value >= pair_q27));
assign pair_result28 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg28) : (value >= pair_q28));
assign pair_result29 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg29) : (value >= pair_q29));
assign pair_result30 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg30) : (value >= pair_q30));
assign pair_result31 = ((value[28] & (value != 29'sd268435456)) ? (value <= pair_neg31) : (value >= pair_q31));
assign pair_new = array_muxed2;
assign old_y = pair_old;
assign new_y = pair_new;
assign selected_t = pair_selected;
assign selected_neg = pair_selected_neg;
assign cfg = array_muxed3;
assign csr_read = pair_bus_dat_r;
assign pair_sel = (pair_bus_adr[13:9] == 1'd0);
assign pair_peak003_r = pair_bus_dat_w[3:0];
assign pair_peak003_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 1'd0));
assign pair_peak002_r = pair_bus_dat_w[7:0];
assign pair_peak002_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 1'd1));
assign pair_peak001_r = pair_bus_dat_w[7:0];
assign pair_peak001_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 2'd2));
assign pair_peak000_r = pair_bus_dat_w[7:0];
assign pair_peak000_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 2'd3));
assign pair_peak013_r = pair_bus_dat_w[3:0];
assign pair_peak013_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 3'd4));
assign pair_peak012_r = pair_bus_dat_w[7:0];
assign pair_peak012_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 3'd5));
assign pair_peak011_r = pair_bus_dat_w[7:0];
assign pair_peak011_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 3'd6));
assign pair_peak010_r = pair_bus_dat_w[7:0];
assign pair_peak010_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 3'd7));
assign pair_peak023_r = pair_bus_dat_w[3:0];
assign pair_peak023_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 4'd8));
assign pair_peak022_r = pair_bus_dat_w[7:0];
assign pair_peak022_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 4'd9));
assign pair_peak021_r = pair_bus_dat_w[7:0];
assign pair_peak021_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 4'd10));
assign pair_peak020_r = pair_bus_dat_w[7:0];
assign pair_peak020_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 4'd11));
assign pair_peak033_r = pair_bus_dat_w[3:0];
assign pair_peak033_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 4'd12));
assign pair_peak032_r = pair_bus_dat_w[7:0];
assign pair_peak032_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 4'd13));
assign pair_peak031_r = pair_bus_dat_w[7:0];
assign pair_peak031_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 4'd14));
assign pair_peak030_r = pair_bus_dat_w[7:0];
assign pair_peak030_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 4'd15));
assign pair_peak043_r = pair_bus_dat_w[3:0];
assign pair_peak043_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd16));
assign pair_peak042_r = pair_bus_dat_w[7:0];
assign pair_peak042_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd17));
assign pair_peak041_r = pair_bus_dat_w[7:0];
assign pair_peak041_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd18));
assign pair_peak040_r = pair_bus_dat_w[7:0];
assign pair_peak040_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd19));
assign pair_peak053_r = pair_bus_dat_w[3:0];
assign pair_peak053_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd20));
assign pair_peak052_r = pair_bus_dat_w[7:0];
assign pair_peak052_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd21));
assign pair_peak051_r = pair_bus_dat_w[7:0];
assign pair_peak051_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd22));
assign pair_peak050_r = pair_bus_dat_w[7:0];
assign pair_peak050_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd23));
assign pair_peak063_r = pair_bus_dat_w[3:0];
assign pair_peak063_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd24));
assign pair_peak062_r = pair_bus_dat_w[7:0];
assign pair_peak062_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd25));
assign pair_peak061_r = pair_bus_dat_w[7:0];
assign pair_peak061_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd26));
assign pair_peak060_r = pair_bus_dat_w[7:0];
assign pair_peak060_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd27));
assign pair_peak073_r = pair_bus_dat_w[3:0];
assign pair_peak073_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd28));
assign pair_peak072_r = pair_bus_dat_w[7:0];
assign pair_peak072_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd29));
assign pair_peak071_r = pair_bus_dat_w[7:0];
assign pair_peak071_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd30));
assign pair_peak070_r = pair_bus_dat_w[7:0];
assign pair_peak070_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 5'd31));
assign pair_peak083_r = pair_bus_dat_w[3:0];
assign pair_peak083_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd32));
assign pair_peak082_r = pair_bus_dat_w[7:0];
assign pair_peak082_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd33));
assign pair_peak081_r = pair_bus_dat_w[7:0];
assign pair_peak081_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd34));
assign pair_peak080_r = pair_bus_dat_w[7:0];
assign pair_peak080_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd35));
assign pair_peak093_r = pair_bus_dat_w[3:0];
assign pair_peak093_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd36));
assign pair_peak092_r = pair_bus_dat_w[7:0];
assign pair_peak092_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd37));
assign pair_peak091_r = pair_bus_dat_w[7:0];
assign pair_peak091_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd38));
assign pair_peak090_r = pair_bus_dat_w[7:0];
assign pair_peak090_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd39));
assign pair_peak103_r = pair_bus_dat_w[3:0];
assign pair_peak103_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd40));
assign pair_peak102_r = pair_bus_dat_w[7:0];
assign pair_peak102_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd41));
assign pair_peak101_r = pair_bus_dat_w[7:0];
assign pair_peak101_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd42));
assign pair_peak100_r = pair_bus_dat_w[7:0];
assign pair_peak100_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd43));
assign pair_peak113_r = pair_bus_dat_w[3:0];
assign pair_peak113_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd44));
assign pair_peak112_r = pair_bus_dat_w[7:0];
assign pair_peak112_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd45));
assign pair_peak111_r = pair_bus_dat_w[7:0];
assign pair_peak111_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd46));
assign pair_peak110_r = pair_bus_dat_w[7:0];
assign pair_peak110_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd47));
assign pair_peak123_r = pair_bus_dat_w[3:0];
assign pair_peak123_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd48));
assign pair_peak122_r = pair_bus_dat_w[7:0];
assign pair_peak122_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd49));
assign pair_peak121_r = pair_bus_dat_w[7:0];
assign pair_peak121_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd50));
assign pair_peak120_r = pair_bus_dat_w[7:0];
assign pair_peak120_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd51));
assign pair_peak133_r = pair_bus_dat_w[3:0];
assign pair_peak133_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd52));
assign pair_peak132_r = pair_bus_dat_w[7:0];
assign pair_peak132_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd53));
assign pair_peak131_r = pair_bus_dat_w[7:0];
assign pair_peak131_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd54));
assign pair_peak130_r = pair_bus_dat_w[7:0];
assign pair_peak130_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd55));
assign pair_peak143_r = pair_bus_dat_w[3:0];
assign pair_peak143_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd56));
assign pair_peak142_r = pair_bus_dat_w[7:0];
assign pair_peak142_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd57));
assign pair_peak141_r = pair_bus_dat_w[7:0];
assign pair_peak141_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd58));
assign pair_peak140_r = pair_bus_dat_w[7:0];
assign pair_peak140_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd59));
assign pair_peak153_r = pair_bus_dat_w[3:0];
assign pair_peak153_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd60));
assign pair_peak152_r = pair_bus_dat_w[7:0];
assign pair_peak152_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd61));
assign pair_peak151_r = pair_bus_dat_w[7:0];
assign pair_peak151_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd62));
assign pair_peak150_r = pair_bus_dat_w[7:0];
assign pair_peak150_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 6'd63));
assign pair_peak163_r = pair_bus_dat_w[3:0];
assign pair_peak163_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd64));
assign pair_peak162_r = pair_bus_dat_w[7:0];
assign pair_peak162_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd65));
assign pair_peak161_r = pair_bus_dat_w[7:0];
assign pair_peak161_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd66));
assign pair_peak160_r = pair_bus_dat_w[7:0];
assign pair_peak160_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd67));
assign pair_peak173_r = pair_bus_dat_w[3:0];
assign pair_peak173_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd68));
assign pair_peak172_r = pair_bus_dat_w[7:0];
assign pair_peak172_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd69));
assign pair_peak171_r = pair_bus_dat_w[7:0];
assign pair_peak171_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd70));
assign pair_peak170_r = pair_bus_dat_w[7:0];
assign pair_peak170_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd71));
assign pair_peak183_r = pair_bus_dat_w[3:0];
assign pair_peak183_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd72));
assign pair_peak182_r = pair_bus_dat_w[7:0];
assign pair_peak182_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd73));
assign pair_peak181_r = pair_bus_dat_w[7:0];
assign pair_peak181_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd74));
assign pair_peak180_r = pair_bus_dat_w[7:0];
assign pair_peak180_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd75));
assign pair_peak193_r = pair_bus_dat_w[3:0];
assign pair_peak193_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd76));
assign pair_peak192_r = pair_bus_dat_w[7:0];
assign pair_peak192_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd77));
assign pair_peak191_r = pair_bus_dat_w[7:0];
assign pair_peak191_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd78));
assign pair_peak190_r = pair_bus_dat_w[7:0];
assign pair_peak190_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd79));
assign pair_peak203_r = pair_bus_dat_w[3:0];
assign pair_peak203_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd80));
assign pair_peak202_r = pair_bus_dat_w[7:0];
assign pair_peak202_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd81));
assign pair_peak201_r = pair_bus_dat_w[7:0];
assign pair_peak201_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd82));
assign pair_peak200_r = pair_bus_dat_w[7:0];
assign pair_peak200_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd83));
assign pair_peak213_r = pair_bus_dat_w[3:0];
assign pair_peak213_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd84));
assign pair_peak212_r = pair_bus_dat_w[7:0];
assign pair_peak212_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd85));
assign pair_peak211_r = pair_bus_dat_w[7:0];
assign pair_peak211_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd86));
assign pair_peak210_r = pair_bus_dat_w[7:0];
assign pair_peak210_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd87));
assign pair_peak223_r = pair_bus_dat_w[3:0];
assign pair_peak223_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd88));
assign pair_peak222_r = pair_bus_dat_w[7:0];
assign pair_peak222_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd89));
assign pair_peak221_r = pair_bus_dat_w[7:0];
assign pair_peak221_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd90));
assign pair_peak220_r = pair_bus_dat_w[7:0];
assign pair_peak220_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd91));
assign pair_peak233_r = pair_bus_dat_w[3:0];
assign pair_peak233_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd92));
assign pair_peak232_r = pair_bus_dat_w[7:0];
assign pair_peak232_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd93));
assign pair_peak231_r = pair_bus_dat_w[7:0];
assign pair_peak231_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd94));
assign pair_peak230_r = pair_bus_dat_w[7:0];
assign pair_peak230_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd95));
assign pair_peak243_r = pair_bus_dat_w[3:0];
assign pair_peak243_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd96));
assign pair_peak242_r = pair_bus_dat_w[7:0];
assign pair_peak242_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd97));
assign pair_peak241_r = pair_bus_dat_w[7:0];
assign pair_peak241_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd98));
assign pair_peak240_r = pair_bus_dat_w[7:0];
assign pair_peak240_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd99));
assign pair_peak253_r = pair_bus_dat_w[3:0];
assign pair_peak253_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd100));
assign pair_peak252_r = pair_bus_dat_w[7:0];
assign pair_peak252_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd101));
assign pair_peak251_r = pair_bus_dat_w[7:0];
assign pair_peak251_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd102));
assign pair_peak250_r = pair_bus_dat_w[7:0];
assign pair_peak250_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd103));
assign pair_peak263_r = pair_bus_dat_w[3:0];
assign pair_peak263_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd104));
assign pair_peak262_r = pair_bus_dat_w[7:0];
assign pair_peak262_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd105));
assign pair_peak261_r = pair_bus_dat_w[7:0];
assign pair_peak261_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd106));
assign pair_peak260_r = pair_bus_dat_w[7:0];
assign pair_peak260_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd107));
assign pair_peak273_r = pair_bus_dat_w[3:0];
assign pair_peak273_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd108));
assign pair_peak272_r = pair_bus_dat_w[7:0];
assign pair_peak272_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd109));
assign pair_peak271_r = pair_bus_dat_w[7:0];
assign pair_peak271_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd110));
assign pair_peak270_r = pair_bus_dat_w[7:0];
assign pair_peak270_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd111));
assign pair_peak283_r = pair_bus_dat_w[3:0];
assign pair_peak283_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd112));
assign pair_peak282_r = pair_bus_dat_w[7:0];
assign pair_peak282_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd113));
assign pair_peak281_r = pair_bus_dat_w[7:0];
assign pair_peak281_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd114));
assign pair_peak280_r = pair_bus_dat_w[7:0];
assign pair_peak280_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd115));
assign pair_peak293_r = pair_bus_dat_w[3:0];
assign pair_peak293_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd116));
assign pair_peak292_r = pair_bus_dat_w[7:0];
assign pair_peak292_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd117));
assign pair_peak291_r = pair_bus_dat_w[7:0];
assign pair_peak291_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd118));
assign pair_peak290_r = pair_bus_dat_w[7:0];
assign pair_peak290_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd119));
assign pair_peak303_r = pair_bus_dat_w[3:0];
assign pair_peak303_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd120));
assign pair_peak302_r = pair_bus_dat_w[7:0];
assign pair_peak302_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd121));
assign pair_peak301_r = pair_bus_dat_w[7:0];
assign pair_peak301_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd122));
assign pair_peak300_r = pair_bus_dat_w[7:0];
assign pair_peak300_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd123));
assign pair_peak313_r = pair_bus_dat_w[3:0];
assign pair_peak313_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd124));
assign pair_peak312_r = pair_bus_dat_w[7:0];
assign pair_peak312_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd125));
assign pair_peak311_r = pair_bus_dat_w[7:0];
assign pair_peak311_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd126));
assign pair_peak310_r = pair_bus_dat_w[7:0];
assign pair_peak310_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[6:0] == 7'd127));
assign pair_csrstorage0_storage = pair_csrstorage0_storage_full[27:0];
assign pair_peak003_w = pair_csrstorage0_storage_full[27:24];
assign pair_peak002_w = pair_csrstorage0_storage_full[23:16];
assign pair_peak001_w = pair_csrstorage0_storage_full[15:8];
assign pair_peak000_w = pair_csrstorage0_storage_full[7:0];
assign pair_csrstorage1_storage = pair_csrstorage1_storage_full[27:0];
assign pair_peak013_w = pair_csrstorage1_storage_full[27:24];
assign pair_peak012_w = pair_csrstorage1_storage_full[23:16];
assign pair_peak011_w = pair_csrstorage1_storage_full[15:8];
assign pair_peak010_w = pair_csrstorage1_storage_full[7:0];
assign pair_csrstorage2_storage = pair_csrstorage2_storage_full[27:0];
assign pair_peak023_w = pair_csrstorage2_storage_full[27:24];
assign pair_peak022_w = pair_csrstorage2_storage_full[23:16];
assign pair_peak021_w = pair_csrstorage2_storage_full[15:8];
assign pair_peak020_w = pair_csrstorage2_storage_full[7:0];
assign pair_csrstorage3_storage = pair_csrstorage3_storage_full[27:0];
assign pair_peak033_w = pair_csrstorage3_storage_full[27:24];
assign pair_peak032_w = pair_csrstorage3_storage_full[23:16];
assign pair_peak031_w = pair_csrstorage3_storage_full[15:8];
assign pair_peak030_w = pair_csrstorage3_storage_full[7:0];
assign pair_csrstorage4_storage = pair_csrstorage4_storage_full[27:0];
assign pair_peak043_w = pair_csrstorage4_storage_full[27:24];
assign pair_peak042_w = pair_csrstorage4_storage_full[23:16];
assign pair_peak041_w = pair_csrstorage4_storage_full[15:8];
assign pair_peak040_w = pair_csrstorage4_storage_full[7:0];
assign pair_csrstorage5_storage = pair_csrstorage5_storage_full[27:0];
assign pair_peak053_w = pair_csrstorage5_storage_full[27:24];
assign pair_peak052_w = pair_csrstorage5_storage_full[23:16];
assign pair_peak051_w = pair_csrstorage5_storage_full[15:8];
assign pair_peak050_w = pair_csrstorage5_storage_full[7:0];
assign pair_csrstorage6_storage = pair_csrstorage6_storage_full[27:0];
assign pair_peak063_w = pair_csrstorage6_storage_full[27:24];
assign pair_peak062_w = pair_csrstorage6_storage_full[23:16];
assign pair_peak061_w = pair_csrstorage6_storage_full[15:8];
assign pair_peak060_w = pair_csrstorage6_storage_full[7:0];
assign pair_csrstorage7_storage = pair_csrstorage7_storage_full[27:0];
assign pair_peak073_w = pair_csrstorage7_storage_full[27:24];
assign pair_peak072_w = pair_csrstorage7_storage_full[23:16];
assign pair_peak071_w = pair_csrstorage7_storage_full[15:8];
assign pair_peak070_w = pair_csrstorage7_storage_full[7:0];
assign pair_csrstorage8_storage = pair_csrstorage8_storage_full[27:0];
assign pair_peak083_w = pair_csrstorage8_storage_full[27:24];
assign pair_peak082_w = pair_csrstorage8_storage_full[23:16];
assign pair_peak081_w = pair_csrstorage8_storage_full[15:8];
assign pair_peak080_w = pair_csrstorage8_storage_full[7:0];
assign pair_csrstorage9_storage = pair_csrstorage9_storage_full[27:0];
assign pair_peak093_w = pair_csrstorage9_storage_full[27:24];
assign pair_peak092_w = pair_csrstorage9_storage_full[23:16];
assign pair_peak091_w = pair_csrstorage9_storage_full[15:8];
assign pair_peak090_w = pair_csrstorage9_storage_full[7:0];
assign pair_csrstorage10_storage = pair_csrstorage10_storage_full[27:0];
assign pair_peak103_w = pair_csrstorage10_storage_full[27:24];
assign pair_peak102_w = pair_csrstorage10_storage_full[23:16];
assign pair_peak101_w = pair_csrstorage10_storage_full[15:8];
assign pair_peak100_w = pair_csrstorage10_storage_full[7:0];
assign pair_csrstorage11_storage = pair_csrstorage11_storage_full[27:0];
assign pair_peak113_w = pair_csrstorage11_storage_full[27:24];
assign pair_peak112_w = pair_csrstorage11_storage_full[23:16];
assign pair_peak111_w = pair_csrstorage11_storage_full[15:8];
assign pair_peak110_w = pair_csrstorage11_storage_full[7:0];
assign pair_csrstorage12_storage = pair_csrstorage12_storage_full[27:0];
assign pair_peak123_w = pair_csrstorage12_storage_full[27:24];
assign pair_peak122_w = pair_csrstorage12_storage_full[23:16];
assign pair_peak121_w = pair_csrstorage12_storage_full[15:8];
assign pair_peak120_w = pair_csrstorage12_storage_full[7:0];
assign pair_csrstorage13_storage = pair_csrstorage13_storage_full[27:0];
assign pair_peak133_w = pair_csrstorage13_storage_full[27:24];
assign pair_peak132_w = pair_csrstorage13_storage_full[23:16];
assign pair_peak131_w = pair_csrstorage13_storage_full[15:8];
assign pair_peak130_w = pair_csrstorage13_storage_full[7:0];
assign pair_csrstorage14_storage = pair_csrstorage14_storage_full[27:0];
assign pair_peak143_w = pair_csrstorage14_storage_full[27:24];
assign pair_peak142_w = pair_csrstorage14_storage_full[23:16];
assign pair_peak141_w = pair_csrstorage14_storage_full[15:8];
assign pair_peak140_w = pair_csrstorage14_storage_full[7:0];
assign pair_csrstorage15_storage = pair_csrstorage15_storage_full[27:0];
assign pair_peak153_w = pair_csrstorage15_storage_full[27:24];
assign pair_peak152_w = pair_csrstorage15_storage_full[23:16];
assign pair_peak151_w = pair_csrstorage15_storage_full[15:8];
assign pair_peak150_w = pair_csrstorage15_storage_full[7:0];
assign pair_csrstorage16_storage = pair_csrstorage16_storage_full[27:0];
assign pair_peak163_w = pair_csrstorage16_storage_full[27:24];
assign pair_peak162_w = pair_csrstorage16_storage_full[23:16];
assign pair_peak161_w = pair_csrstorage16_storage_full[15:8];
assign pair_peak160_w = pair_csrstorage16_storage_full[7:0];
assign pair_csrstorage17_storage = pair_csrstorage17_storage_full[27:0];
assign pair_peak173_w = pair_csrstorage17_storage_full[27:24];
assign pair_peak172_w = pair_csrstorage17_storage_full[23:16];
assign pair_peak171_w = pair_csrstorage17_storage_full[15:8];
assign pair_peak170_w = pair_csrstorage17_storage_full[7:0];
assign pair_csrstorage18_storage = pair_csrstorage18_storage_full[27:0];
assign pair_peak183_w = pair_csrstorage18_storage_full[27:24];
assign pair_peak182_w = pair_csrstorage18_storage_full[23:16];
assign pair_peak181_w = pair_csrstorage18_storage_full[15:8];
assign pair_peak180_w = pair_csrstorage18_storage_full[7:0];
assign pair_csrstorage19_storage = pair_csrstorage19_storage_full[27:0];
assign pair_peak193_w = pair_csrstorage19_storage_full[27:24];
assign pair_peak192_w = pair_csrstorage19_storage_full[23:16];
assign pair_peak191_w = pair_csrstorage19_storage_full[15:8];
assign pair_peak190_w = pair_csrstorage19_storage_full[7:0];
assign pair_csrstorage20_storage = pair_csrstorage20_storage_full[27:0];
assign pair_peak203_w = pair_csrstorage20_storage_full[27:24];
assign pair_peak202_w = pair_csrstorage20_storage_full[23:16];
assign pair_peak201_w = pair_csrstorage20_storage_full[15:8];
assign pair_peak200_w = pair_csrstorage20_storage_full[7:0];
assign pair_csrstorage21_storage = pair_csrstorage21_storage_full[27:0];
assign pair_peak213_w = pair_csrstorage21_storage_full[27:24];
assign pair_peak212_w = pair_csrstorage21_storage_full[23:16];
assign pair_peak211_w = pair_csrstorage21_storage_full[15:8];
assign pair_peak210_w = pair_csrstorage21_storage_full[7:0];
assign pair_csrstorage22_storage = pair_csrstorage22_storage_full[27:0];
assign pair_peak223_w = pair_csrstorage22_storage_full[27:24];
assign pair_peak222_w = pair_csrstorage22_storage_full[23:16];
assign pair_peak221_w = pair_csrstorage22_storage_full[15:8];
assign pair_peak220_w = pair_csrstorage22_storage_full[7:0];
assign pair_csrstorage23_storage = pair_csrstorage23_storage_full[27:0];
assign pair_peak233_w = pair_csrstorage23_storage_full[27:24];
assign pair_peak232_w = pair_csrstorage23_storage_full[23:16];
assign pair_peak231_w = pair_csrstorage23_storage_full[15:8];
assign pair_peak230_w = pair_csrstorage23_storage_full[7:0];
assign pair_csrstorage24_storage = pair_csrstorage24_storage_full[27:0];
assign pair_peak243_w = pair_csrstorage24_storage_full[27:24];
assign pair_peak242_w = pair_csrstorage24_storage_full[23:16];
assign pair_peak241_w = pair_csrstorage24_storage_full[15:8];
assign pair_peak240_w = pair_csrstorage24_storage_full[7:0];
assign pair_csrstorage25_storage = pair_csrstorage25_storage_full[27:0];
assign pair_peak253_w = pair_csrstorage25_storage_full[27:24];
assign pair_peak252_w = pair_csrstorage25_storage_full[23:16];
assign pair_peak251_w = pair_csrstorage25_storage_full[15:8];
assign pair_peak250_w = pair_csrstorage25_storage_full[7:0];
assign pair_csrstorage26_storage = pair_csrstorage26_storage_full[27:0];
assign pair_peak263_w = pair_csrstorage26_storage_full[27:24];
assign pair_peak262_w = pair_csrstorage26_storage_full[23:16];
assign pair_peak261_w = pair_csrstorage26_storage_full[15:8];
assign pair_peak260_w = pair_csrstorage26_storage_full[7:0];
assign pair_csrstorage27_storage = pair_csrstorage27_storage_full[27:0];
assign pair_peak273_w = pair_csrstorage27_storage_full[27:24];
assign pair_peak272_w = pair_csrstorage27_storage_full[23:16];
assign pair_peak271_w = pair_csrstorage27_storage_full[15:8];
assign pair_peak270_w = pair_csrstorage27_storage_full[7:0];
assign pair_csrstorage28_storage = pair_csrstorage28_storage_full[27:0];
assign pair_peak283_w = pair_csrstorage28_storage_full[27:24];
assign pair_peak282_w = pair_csrstorage28_storage_full[23:16];
assign pair_peak281_w = pair_csrstorage28_storage_full[15:8];
assign pair_peak280_w = pair_csrstorage28_storage_full[7:0];
assign pair_csrstorage29_storage = pair_csrstorage29_storage_full[27:0];
assign pair_peak293_w = pair_csrstorage29_storage_full[27:24];
assign pair_peak292_w = pair_csrstorage29_storage_full[23:16];
assign pair_peak291_w = pair_csrstorage29_storage_full[15:8];
assign pair_peak290_w = pair_csrstorage29_storage_full[7:0];
assign pair_csrstorage30_storage = pair_csrstorage30_storage_full[27:0];
assign pair_peak303_w = pair_csrstorage30_storage_full[27:24];
assign pair_peak302_w = pair_csrstorage30_storage_full[23:16];
assign pair_peak301_w = pair_csrstorage30_storage_full[15:8];
assign pair_peak300_w = pair_csrstorage30_storage_full[7:0];
assign pair_csrstorage31_storage = pair_csrstorage31_storage_full[27:0];
assign pair_peak313_w = pair_csrstorage31_storage_full[27:24];
assign pair_peak312_w = pair_csrstorage31_storage_full[23:16];
assign pair_peak311_w = pair_csrstorage31_storage_full[15:8];
assign pair_peak310_w = pair_csrstorage31_storage_full[7:0];

// synthesis translate_off
reg dummy_d_32;
// synthesis translate_on
always @(*) begin
	array_muxed0 <= 28'sd0;
	case (index)
		1'd0: begin
			array_muxed0 <= pair_q0;
		end
		1'd1: begin
			array_muxed0 <= pair_q1;
		end
		2'd2: begin
			array_muxed0 <= pair_q2;
		end
		2'd3: begin
			array_muxed0 <= pair_q3;
		end
		3'd4: begin
			array_muxed0 <= pair_q4;
		end
		3'd5: begin
			array_muxed0 <= pair_q5;
		end
		3'd6: begin
			array_muxed0 <= pair_q6;
		end
		3'd7: begin
			array_muxed0 <= pair_q7;
		end
		4'd8: begin
			array_muxed0 <= pair_q8;
		end
		4'd9: begin
			array_muxed0 <= pair_q9;
		end
		4'd10: begin
			array_muxed0 <= pair_q10;
		end
		4'd11: begin
			array_muxed0 <= pair_q11;
		end
		4'd12: begin
			array_muxed0 <= pair_q12;
		end
		4'd13: begin
			array_muxed0 <= pair_q13;
		end
		4'd14: begin
			array_muxed0 <= pair_q14;
		end
		4'd15: begin
			array_muxed0 <= pair_q15;
		end
		5'd16: begin
			array_muxed0 <= pair_q16;
		end
		5'd17: begin
			array_muxed0 <= pair_q17;
		end
		5'd18: begin
			array_muxed0 <= pair_q18;
		end
		5'd19: begin
			array_muxed0 <= pair_q19;
		end
		5'd20: begin
			array_muxed0 <= pair_q20;
		end
		5'd21: begin
			array_muxed0 <= pair_q21;
		end
		5'd22: begin
			array_muxed0 <= pair_q22;
		end
		5'd23: begin
			array_muxed0 <= pair_q23;
		end
		5'd24: begin
			array_muxed0 <= pair_q24;
		end
		5'd25: begin
			array_muxed0 <= pair_q25;
		end
		5'd26: begin
			array_muxed0 <= pair_q26;
		end
		5'd27: begin
			array_muxed0 <= pair_q27;
		end
		5'd28: begin
			array_muxed0 <= pair_q28;
		end
		5'd29: begin
			array_muxed0 <= pair_q29;
		end
		5'd30: begin
			array_muxed0 <= pair_q30;
		end
		default: begin
			array_muxed0 <= pair_q31;
		end
	endcase
// synthesis translate_off
	dummy_d_32 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_33;
// synthesis translate_on
always @(*) begin
	array_muxed1 <= 29'sd0;
	case (index)
		1'd0: begin
			array_muxed1 <= pair_neg0;
		end
		1'd1: begin
			array_muxed1 <= pair_neg1;
		end
		2'd2: begin
			array_muxed1 <= pair_neg2;
		end
		2'd3: begin
			array_muxed1 <= pair_neg3;
		end
		3'd4: begin
			array_muxed1 <= pair_neg4;
		end
		3'd5: begin
			array_muxed1 <= pair_neg5;
		end
		3'd6: begin
			array_muxed1 <= pair_neg6;
		end
		3'd7: begin
			array_muxed1 <= pair_neg7;
		end
		4'd8: begin
			array_muxed1 <= pair_neg8;
		end
		4'd9: begin
			array_muxed1 <= pair_neg9;
		end
		4'd10: begin
			array_muxed1 <= pair_neg10;
		end
		4'd11: begin
			array_muxed1 <= pair_neg11;
		end
		4'd12: begin
			array_muxed1 <= pair_neg12;
		end
		4'd13: begin
			array_muxed1 <= pair_neg13;
		end
		4'd14: begin
			array_muxed1 <= pair_neg14;
		end
		4'd15: begin
			array_muxed1 <= pair_neg15;
		end
		5'd16: begin
			array_muxed1 <= pair_neg16;
		end
		5'd17: begin
			array_muxed1 <= pair_neg17;
		end
		5'd18: begin
			array_muxed1 <= pair_neg18;
		end
		5'd19: begin
			array_muxed1 <= pair_neg19;
		end
		5'd20: begin
			array_muxed1 <= pair_neg20;
		end
		5'd21: begin
			array_muxed1 <= pair_neg21;
		end
		5'd22: begin
			array_muxed1 <= pair_neg22;
		end
		5'd23: begin
			array_muxed1 <= pair_neg23;
		end
		5'd24: begin
			array_muxed1 <= pair_neg24;
		end
		5'd25: begin
			array_muxed1 <= pair_neg25;
		end
		5'd26: begin
			array_muxed1 <= pair_neg26;
		end
		5'd27: begin
			array_muxed1 <= pair_neg27;
		end
		5'd28: begin
			array_muxed1 <= pair_neg28;
		end
		5'd29: begin
			array_muxed1 <= pair_neg29;
		end
		5'd30: begin
			array_muxed1 <= pair_neg30;
		end
		default: begin
			array_muxed1 <= pair_neg31;
		end
	endcase
// synthesis translate_off
	dummy_d_33 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_34;
// synthesis translate_on
always @(*) begin
	array_muxed2 <= 1'd0;
	case (index)
		1'd0: begin
			array_muxed2 <= pair_result0;
		end
		1'd1: begin
			array_muxed2 <= pair_result1;
		end
		2'd2: begin
			array_muxed2 <= pair_result2;
		end
		2'd3: begin
			array_muxed2 <= pair_result3;
		end
		3'd4: begin
			array_muxed2 <= pair_result4;
		end
		3'd5: begin
			array_muxed2 <= pair_result5;
		end
		3'd6: begin
			array_muxed2 <= pair_result6;
		end
		3'd7: begin
			array_muxed2 <= pair_result7;
		end
		4'd8: begin
			array_muxed2 <= pair_result8;
		end
		4'd9: begin
			array_muxed2 <= pair_result9;
		end
		4'd10: begin
			array_muxed2 <= pair_result10;
		end
		4'd11: begin
			array_muxed2 <= pair_result11;
		end
		4'd12: begin
			array_muxed2 <= pair_result12;
		end
		4'd13: begin
			array_muxed2 <= pair_result13;
		end
		4'd14: begin
			array_muxed2 <= pair_result14;
		end
		4'd15: begin
			array_muxed2 <= pair_result15;
		end
		5'd16: begin
			array_muxed2 <= pair_result16;
		end
		5'd17: begin
			array_muxed2 <= pair_result17;
		end
		5'd18: begin
			array_muxed2 <= pair_result18;
		end
		5'd19: begin
			array_muxed2 <= pair_result19;
		end
		5'd20: begin
			array_muxed2 <= pair_result20;
		end
		5'd21: begin
			array_muxed2 <= pair_result21;
		end
		5'd22: begin
			array_muxed2 <= pair_result22;
		end
		5'd23: begin
			array_muxed2 <= pair_result23;
		end
		5'd24: begin
			array_muxed2 <= pair_result24;
		end
		5'd25: begin
			array_muxed2 <= pair_result25;
		end
		5'd26: begin
			array_muxed2 <= pair_result26;
		end
		5'd27: begin
			array_muxed2 <= pair_result27;
		end
		5'd28: begin
			array_muxed2 <= pair_result28;
		end
		5'd29: begin
			array_muxed2 <= pair_result29;
		end
		5'd30: begin
			array_muxed2 <= pair_result30;
		end
		default: begin
			array_muxed2 <= pair_result31;
		end
	endcase
// synthesis translate_off
	dummy_d_34 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_35;
// synthesis translate_on
always @(*) begin
	array_muxed3 <= 28'd0;
	case (index)
		1'd0: begin
			array_muxed3 <= pair_csrstorage0_storage;
		end
		1'd1: begin
			array_muxed3 <= pair_csrstorage1_storage;
		end
		2'd2: begin
			array_muxed3 <= pair_csrstorage2_storage;
		end
		2'd3: begin
			array_muxed3 <= pair_csrstorage3_storage;
		end
		3'd4: begin
			array_muxed3 <= pair_csrstorage4_storage;
		end
		3'd5: begin
			array_muxed3 <= pair_csrstorage5_storage;
		end
		3'd6: begin
			array_muxed3 <= pair_csrstorage6_storage;
		end
		3'd7: begin
			array_muxed3 <= pair_csrstorage7_storage;
		end
		4'd8: begin
			array_muxed3 <= pair_csrstorage8_storage;
		end
		4'd9: begin
			array_muxed3 <= pair_csrstorage9_storage;
		end
		4'd10: begin
			array_muxed3 <= pair_csrstorage10_storage;
		end
		4'd11: begin
			array_muxed3 <= pair_csrstorage11_storage;
		end
		4'd12: begin
			array_muxed3 <= pair_csrstorage12_storage;
		end
		4'd13: begin
			array_muxed3 <= pair_csrstorage13_storage;
		end
		4'd14: begin
			array_muxed3 <= pair_csrstorage14_storage;
		end
		4'd15: begin
			array_muxed3 <= pair_csrstorage15_storage;
		end
		5'd16: begin
			array_muxed3 <= pair_csrstorage16_storage;
		end
		5'd17: begin
			array_muxed3 <= pair_csrstorage17_storage;
		end
		5'd18: begin
			array_muxed3 <= pair_csrstorage18_storage;
		end
		5'd19: begin
			array_muxed3 <= pair_csrstorage19_storage;
		end
		5'd20: begin
			array_muxed3 <= pair_csrstorage20_storage;
		end
		5'd21: begin
			array_muxed3 <= pair_csrstorage21_storage;
		end
		5'd22: begin
			array_muxed3 <= pair_csrstorage22_storage;
		end
		5'd23: begin
			array_muxed3 <= pair_csrstorage23_storage;
		end
		5'd24: begin
			array_muxed3 <= pair_csrstorage24_storage;
		end
		5'd25: begin
			array_muxed3 <= pair_csrstorage25_storage;
		end
		5'd26: begin
			array_muxed3 <= pair_csrstorage26_storage;
		end
		5'd27: begin
			array_muxed3 <= pair_csrstorage27_storage;
		end
		5'd28: begin
			array_muxed3 <= pair_csrstorage28_storage;
		end
		5'd29: begin
			array_muxed3 <= pair_csrstorage29_storage;
		end
		5'd30: begin
			array_muxed3 <= pair_csrstorage30_storage;
		end
		default: begin
			array_muxed3 <= pair_csrstorage31_storage;
		end
	endcase
// synthesis translate_off
	dummy_d_35 <= dummy_s;
// synthesis translate_on
end

always @(posedge sys_clk) begin
	pair_q0 <= pair_absolute0;
	pair_neg0 <= (-pair_wide0);
	pair_q1 <= pair_absolute1;
	pair_neg1 <= (-pair_wide1);
	pair_q2 <= pair_absolute2;
	pair_neg2 <= (-pair_wide2);
	pair_q3 <= pair_absolute3;
	pair_neg3 <= (-pair_wide3);
	pair_q4 <= pair_absolute4;
	pair_neg4 <= (-pair_wide4);
	pair_q5 <= pair_absolute5;
	pair_neg5 <= (-pair_wide5);
	pair_q6 <= pair_absolute6;
	pair_neg6 <= (-pair_wide6);
	pair_q7 <= pair_absolute7;
	pair_neg7 <= (-pair_wide7);
	pair_q8 <= pair_absolute8;
	pair_neg8 <= (-pair_wide8);
	pair_q9 <= pair_absolute9;
	pair_neg9 <= (-pair_wide9);
	pair_q10 <= pair_absolute10;
	pair_neg10 <= (-pair_wide10);
	pair_q11 <= pair_absolute11;
	pair_neg11 <= (-pair_wide11);
	pair_q12 <= pair_absolute12;
	pair_neg12 <= (-pair_wide12);
	pair_q13 <= pair_absolute13;
	pair_neg13 <= (-pair_wide13);
	pair_q14 <= pair_absolute14;
	pair_neg14 <= (-pair_wide14);
	pair_q15 <= pair_absolute15;
	pair_neg15 <= (-pair_wide15);
	pair_q16 <= pair_absolute16;
	pair_neg16 <= (-pair_wide16);
	pair_q17 <= pair_absolute17;
	pair_neg17 <= (-pair_wide17);
	pair_q18 <= pair_absolute18;
	pair_neg18 <= (-pair_wide18);
	pair_q19 <= pair_absolute19;
	pair_neg19 <= (-pair_wide19);
	pair_q20 <= pair_absolute20;
	pair_neg20 <= (-pair_wide20);
	pair_q21 <= pair_absolute21;
	pair_neg21 <= (-pair_wide21);
	pair_q22 <= pair_absolute22;
	pair_neg22 <= (-pair_wide22);
	pair_q23 <= pair_absolute23;
	pair_neg23 <= (-pair_wide23);
	pair_q24 <= pair_absolute24;
	pair_neg24 <= (-pair_wide24);
	pair_q25 <= pair_absolute25;
	pair_neg25 <= (-pair_wide25);
	pair_q26 <= pair_absolute26;
	pair_neg26 <= (-pair_wide26);
	pair_q27 <= pair_absolute27;
	pair_neg27 <= (-pair_wide27);
	pair_q28 <= pair_absolute28;
	pair_neg28 <= (-pair_wide28);
	pair_q29 <= pair_absolute29;
	pair_neg29 <= (-pair_wide29);
	pair_q30 <= pair_absolute30;
	pair_neg30 <= (-pair_wide30);
	pair_q31 <= pair_absolute31;
	pair_neg31 <= (-pair_wide31);
	pair_bus_dat_r <= 1'd0;
	if (pair_sel) begin
		case (pair_bus_adr[6:0])
			1'd0: begin
				pair_bus_dat_r <= pair_peak003_w;
			end
			1'd1: begin
				pair_bus_dat_r <= pair_peak002_w;
			end
			2'd2: begin
				pair_bus_dat_r <= pair_peak001_w;
			end
			2'd3: begin
				pair_bus_dat_r <= pair_peak000_w;
			end
			3'd4: begin
				pair_bus_dat_r <= pair_peak013_w;
			end
			3'd5: begin
				pair_bus_dat_r <= pair_peak012_w;
			end
			3'd6: begin
				pair_bus_dat_r <= pair_peak011_w;
			end
			3'd7: begin
				pair_bus_dat_r <= pair_peak010_w;
			end
			4'd8: begin
				pair_bus_dat_r <= pair_peak023_w;
			end
			4'd9: begin
				pair_bus_dat_r <= pair_peak022_w;
			end
			4'd10: begin
				pair_bus_dat_r <= pair_peak021_w;
			end
			4'd11: begin
				pair_bus_dat_r <= pair_peak020_w;
			end
			4'd12: begin
				pair_bus_dat_r <= pair_peak033_w;
			end
			4'd13: begin
				pair_bus_dat_r <= pair_peak032_w;
			end
			4'd14: begin
				pair_bus_dat_r <= pair_peak031_w;
			end
			4'd15: begin
				pair_bus_dat_r <= pair_peak030_w;
			end
			5'd16: begin
				pair_bus_dat_r <= pair_peak043_w;
			end
			5'd17: begin
				pair_bus_dat_r <= pair_peak042_w;
			end
			5'd18: begin
				pair_bus_dat_r <= pair_peak041_w;
			end
			5'd19: begin
				pair_bus_dat_r <= pair_peak040_w;
			end
			5'd20: begin
				pair_bus_dat_r <= pair_peak053_w;
			end
			5'd21: begin
				pair_bus_dat_r <= pair_peak052_w;
			end
			5'd22: begin
				pair_bus_dat_r <= pair_peak051_w;
			end
			5'd23: begin
				pair_bus_dat_r <= pair_peak050_w;
			end
			5'd24: begin
				pair_bus_dat_r <= pair_peak063_w;
			end
			5'd25: begin
				pair_bus_dat_r <= pair_peak062_w;
			end
			5'd26: begin
				pair_bus_dat_r <= pair_peak061_w;
			end
			5'd27: begin
				pair_bus_dat_r <= pair_peak060_w;
			end
			5'd28: begin
				pair_bus_dat_r <= pair_peak073_w;
			end
			5'd29: begin
				pair_bus_dat_r <= pair_peak072_w;
			end
			5'd30: begin
				pair_bus_dat_r <= pair_peak071_w;
			end
			5'd31: begin
				pair_bus_dat_r <= pair_peak070_w;
			end
			6'd32: begin
				pair_bus_dat_r <= pair_peak083_w;
			end
			6'd33: begin
				pair_bus_dat_r <= pair_peak082_w;
			end
			6'd34: begin
				pair_bus_dat_r <= pair_peak081_w;
			end
			6'd35: begin
				pair_bus_dat_r <= pair_peak080_w;
			end
			6'd36: begin
				pair_bus_dat_r <= pair_peak093_w;
			end
			6'd37: begin
				pair_bus_dat_r <= pair_peak092_w;
			end
			6'd38: begin
				pair_bus_dat_r <= pair_peak091_w;
			end
			6'd39: begin
				pair_bus_dat_r <= pair_peak090_w;
			end
			6'd40: begin
				pair_bus_dat_r <= pair_peak103_w;
			end
			6'd41: begin
				pair_bus_dat_r <= pair_peak102_w;
			end
			6'd42: begin
				pair_bus_dat_r <= pair_peak101_w;
			end
			6'd43: begin
				pair_bus_dat_r <= pair_peak100_w;
			end
			6'd44: begin
				pair_bus_dat_r <= pair_peak113_w;
			end
			6'd45: begin
				pair_bus_dat_r <= pair_peak112_w;
			end
			6'd46: begin
				pair_bus_dat_r <= pair_peak111_w;
			end
			6'd47: begin
				pair_bus_dat_r <= pair_peak110_w;
			end
			6'd48: begin
				pair_bus_dat_r <= pair_peak123_w;
			end
			6'd49: begin
				pair_bus_dat_r <= pair_peak122_w;
			end
			6'd50: begin
				pair_bus_dat_r <= pair_peak121_w;
			end
			6'd51: begin
				pair_bus_dat_r <= pair_peak120_w;
			end
			6'd52: begin
				pair_bus_dat_r <= pair_peak133_w;
			end
			6'd53: begin
				pair_bus_dat_r <= pair_peak132_w;
			end
			6'd54: begin
				pair_bus_dat_r <= pair_peak131_w;
			end
			6'd55: begin
				pair_bus_dat_r <= pair_peak130_w;
			end
			6'd56: begin
				pair_bus_dat_r <= pair_peak143_w;
			end
			6'd57: begin
				pair_bus_dat_r <= pair_peak142_w;
			end
			6'd58: begin
				pair_bus_dat_r <= pair_peak141_w;
			end
			6'd59: begin
				pair_bus_dat_r <= pair_peak140_w;
			end
			6'd60: begin
				pair_bus_dat_r <= pair_peak153_w;
			end
			6'd61: begin
				pair_bus_dat_r <= pair_peak152_w;
			end
			6'd62: begin
				pair_bus_dat_r <= pair_peak151_w;
			end
			6'd63: begin
				pair_bus_dat_r <= pair_peak150_w;
			end
			7'd64: begin
				pair_bus_dat_r <= pair_peak163_w;
			end
			7'd65: begin
				pair_bus_dat_r <= pair_peak162_w;
			end
			7'd66: begin
				pair_bus_dat_r <= pair_peak161_w;
			end
			7'd67: begin
				pair_bus_dat_r <= pair_peak160_w;
			end
			7'd68: begin
				pair_bus_dat_r <= pair_peak173_w;
			end
			7'd69: begin
				pair_bus_dat_r <= pair_peak172_w;
			end
			7'd70: begin
				pair_bus_dat_r <= pair_peak171_w;
			end
			7'd71: begin
				pair_bus_dat_r <= pair_peak170_w;
			end
			7'd72: begin
				pair_bus_dat_r <= pair_peak183_w;
			end
			7'd73: begin
				pair_bus_dat_r <= pair_peak182_w;
			end
			7'd74: begin
				pair_bus_dat_r <= pair_peak181_w;
			end
			7'd75: begin
				pair_bus_dat_r <= pair_peak180_w;
			end
			7'd76: begin
				pair_bus_dat_r <= pair_peak193_w;
			end
			7'd77: begin
				pair_bus_dat_r <= pair_peak192_w;
			end
			7'd78: begin
				pair_bus_dat_r <= pair_peak191_w;
			end
			7'd79: begin
				pair_bus_dat_r <= pair_peak190_w;
			end
			7'd80: begin
				pair_bus_dat_r <= pair_peak203_w;
			end
			7'd81: begin
				pair_bus_dat_r <= pair_peak202_w;
			end
			7'd82: begin
				pair_bus_dat_r <= pair_peak201_w;
			end
			7'd83: begin
				pair_bus_dat_r <= pair_peak200_w;
			end
			7'd84: begin
				pair_bus_dat_r <= pair_peak213_w;
			end
			7'd85: begin
				pair_bus_dat_r <= pair_peak212_w;
			end
			7'd86: begin
				pair_bus_dat_r <= pair_peak211_w;
			end
			7'd87: begin
				pair_bus_dat_r <= pair_peak210_w;
			end
			7'd88: begin
				pair_bus_dat_r <= pair_peak223_w;
			end
			7'd89: begin
				pair_bus_dat_r <= pair_peak222_w;
			end
			7'd90: begin
				pair_bus_dat_r <= pair_peak221_w;
			end
			7'd91: begin
				pair_bus_dat_r <= pair_peak220_w;
			end
			7'd92: begin
				pair_bus_dat_r <= pair_peak233_w;
			end
			7'd93: begin
				pair_bus_dat_r <= pair_peak232_w;
			end
			7'd94: begin
				pair_bus_dat_r <= pair_peak231_w;
			end
			7'd95: begin
				pair_bus_dat_r <= pair_peak230_w;
			end
			7'd96: begin
				pair_bus_dat_r <= pair_peak243_w;
			end
			7'd97: begin
				pair_bus_dat_r <= pair_peak242_w;
			end
			7'd98: begin
				pair_bus_dat_r <= pair_peak241_w;
			end
			7'd99: begin
				pair_bus_dat_r <= pair_peak240_w;
			end
			7'd100: begin
				pair_bus_dat_r <= pair_peak253_w;
			end
			7'd101: begin
				pair_bus_dat_r <= pair_peak252_w;
			end
			7'd102: begin
				pair_bus_dat_r <= pair_peak251_w;
			end
			7'd103: begin
				pair_bus_dat_r <= pair_peak250_w;
			end
			7'd104: begin
				pair_bus_dat_r <= pair_peak263_w;
			end
			7'd105: begin
				pair_bus_dat_r <= pair_peak262_w;
			end
			7'd106: begin
				pair_bus_dat_r <= pair_peak261_w;
			end
			7'd107: begin
				pair_bus_dat_r <= pair_peak260_w;
			end
			7'd108: begin
				pair_bus_dat_r <= pair_peak273_w;
			end
			7'd109: begin
				pair_bus_dat_r <= pair_peak272_w;
			end
			7'd110: begin
				pair_bus_dat_r <= pair_peak271_w;
			end
			7'd111: begin
				pair_bus_dat_r <= pair_peak270_w;
			end
			7'd112: begin
				pair_bus_dat_r <= pair_peak283_w;
			end
			7'd113: begin
				pair_bus_dat_r <= pair_peak282_w;
			end
			7'd114: begin
				pair_bus_dat_r <= pair_peak281_w;
			end
			7'd115: begin
				pair_bus_dat_r <= pair_peak280_w;
			end
			7'd116: begin
				pair_bus_dat_r <= pair_peak293_w;
			end
			7'd117: begin
				pair_bus_dat_r <= pair_peak292_w;
			end
			7'd118: begin
				pair_bus_dat_r <= pair_peak291_w;
			end
			7'd119: begin
				pair_bus_dat_r <= pair_peak290_w;
			end
			7'd120: begin
				pair_bus_dat_r <= pair_peak303_w;
			end
			7'd121: begin
				pair_bus_dat_r <= pair_peak302_w;
			end
			7'd122: begin
				pair_bus_dat_r <= pair_peak301_w;
			end
			7'd123: begin
				pair_bus_dat_r <= pair_peak300_w;
			end
			7'd124: begin
				pair_bus_dat_r <= pair_peak313_w;
			end
			7'd125: begin
				pair_bus_dat_r <= pair_peak312_w;
			end
			7'd126: begin
				pair_bus_dat_r <= pair_peak311_w;
			end
			7'd127: begin
				pair_bus_dat_r <= pair_peak310_w;
			end
		endcase
	end
	if (pair_peak003_re) begin
		pair_csrstorage0_storage_full[27:24] <= pair_peak003_r;
	end
	if (pair_peak002_re) begin
		pair_csrstorage0_storage_full[23:16] <= pair_peak002_r;
	end
	if (pair_peak001_re) begin
		pair_csrstorage0_storage_full[15:8] <= pair_peak001_r;
	end
	if (pair_peak000_re) begin
		pair_csrstorage0_storage_full[7:0] <= pair_peak000_r;
	end
	pair_csrstorage0_re <= pair_peak000_re;
	if (pair_peak013_re) begin
		pair_csrstorage1_storage_full[27:24] <= pair_peak013_r;
	end
	if (pair_peak012_re) begin
		pair_csrstorage1_storage_full[23:16] <= pair_peak012_r;
	end
	if (pair_peak011_re) begin
		pair_csrstorage1_storage_full[15:8] <= pair_peak011_r;
	end
	if (pair_peak010_re) begin
		pair_csrstorage1_storage_full[7:0] <= pair_peak010_r;
	end
	pair_csrstorage1_re <= pair_peak010_re;
	if (pair_peak023_re) begin
		pair_csrstorage2_storage_full[27:24] <= pair_peak023_r;
	end
	if (pair_peak022_re) begin
		pair_csrstorage2_storage_full[23:16] <= pair_peak022_r;
	end
	if (pair_peak021_re) begin
		pair_csrstorage2_storage_full[15:8] <= pair_peak021_r;
	end
	if (pair_peak020_re) begin
		pair_csrstorage2_storage_full[7:0] <= pair_peak020_r;
	end
	pair_csrstorage2_re <= pair_peak020_re;
	if (pair_peak033_re) begin
		pair_csrstorage3_storage_full[27:24] <= pair_peak033_r;
	end
	if (pair_peak032_re) begin
		pair_csrstorage3_storage_full[23:16] <= pair_peak032_r;
	end
	if (pair_peak031_re) begin
		pair_csrstorage3_storage_full[15:8] <= pair_peak031_r;
	end
	if (pair_peak030_re) begin
		pair_csrstorage3_storage_full[7:0] <= pair_peak030_r;
	end
	pair_csrstorage3_re <= pair_peak030_re;
	if (pair_peak043_re) begin
		pair_csrstorage4_storage_full[27:24] <= pair_peak043_r;
	end
	if (pair_peak042_re) begin
		pair_csrstorage4_storage_full[23:16] <= pair_peak042_r;
	end
	if (pair_peak041_re) begin
		pair_csrstorage4_storage_full[15:8] <= pair_peak041_r;
	end
	if (pair_peak040_re) begin
		pair_csrstorage4_storage_full[7:0] <= pair_peak040_r;
	end
	pair_csrstorage4_re <= pair_peak040_re;
	if (pair_peak053_re) begin
		pair_csrstorage5_storage_full[27:24] <= pair_peak053_r;
	end
	if (pair_peak052_re) begin
		pair_csrstorage5_storage_full[23:16] <= pair_peak052_r;
	end
	if (pair_peak051_re) begin
		pair_csrstorage5_storage_full[15:8] <= pair_peak051_r;
	end
	if (pair_peak050_re) begin
		pair_csrstorage5_storage_full[7:0] <= pair_peak050_r;
	end
	pair_csrstorage5_re <= pair_peak050_re;
	if (pair_peak063_re) begin
		pair_csrstorage6_storage_full[27:24] <= pair_peak063_r;
	end
	if (pair_peak062_re) begin
		pair_csrstorage6_storage_full[23:16] <= pair_peak062_r;
	end
	if (pair_peak061_re) begin
		pair_csrstorage6_storage_full[15:8] <= pair_peak061_r;
	end
	if (pair_peak060_re) begin
		pair_csrstorage6_storage_full[7:0] <= pair_peak060_r;
	end
	pair_csrstorage6_re <= pair_peak060_re;
	if (pair_peak073_re) begin
		pair_csrstorage7_storage_full[27:24] <= pair_peak073_r;
	end
	if (pair_peak072_re) begin
		pair_csrstorage7_storage_full[23:16] <= pair_peak072_r;
	end
	if (pair_peak071_re) begin
		pair_csrstorage7_storage_full[15:8] <= pair_peak071_r;
	end
	if (pair_peak070_re) begin
		pair_csrstorage7_storage_full[7:0] <= pair_peak070_r;
	end
	pair_csrstorage7_re <= pair_peak070_re;
	if (pair_peak083_re) begin
		pair_csrstorage8_storage_full[27:24] <= pair_peak083_r;
	end
	if (pair_peak082_re) begin
		pair_csrstorage8_storage_full[23:16] <= pair_peak082_r;
	end
	if (pair_peak081_re) begin
		pair_csrstorage8_storage_full[15:8] <= pair_peak081_r;
	end
	if (pair_peak080_re) begin
		pair_csrstorage8_storage_full[7:0] <= pair_peak080_r;
	end
	pair_csrstorage8_re <= pair_peak080_re;
	if (pair_peak093_re) begin
		pair_csrstorage9_storage_full[27:24] <= pair_peak093_r;
	end
	if (pair_peak092_re) begin
		pair_csrstorage9_storage_full[23:16] <= pair_peak092_r;
	end
	if (pair_peak091_re) begin
		pair_csrstorage9_storage_full[15:8] <= pair_peak091_r;
	end
	if (pair_peak090_re) begin
		pair_csrstorage9_storage_full[7:0] <= pair_peak090_r;
	end
	pair_csrstorage9_re <= pair_peak090_re;
	if (pair_peak103_re) begin
		pair_csrstorage10_storage_full[27:24] <= pair_peak103_r;
	end
	if (pair_peak102_re) begin
		pair_csrstorage10_storage_full[23:16] <= pair_peak102_r;
	end
	if (pair_peak101_re) begin
		pair_csrstorage10_storage_full[15:8] <= pair_peak101_r;
	end
	if (pair_peak100_re) begin
		pair_csrstorage10_storage_full[7:0] <= pair_peak100_r;
	end
	pair_csrstorage10_re <= pair_peak100_re;
	if (pair_peak113_re) begin
		pair_csrstorage11_storage_full[27:24] <= pair_peak113_r;
	end
	if (pair_peak112_re) begin
		pair_csrstorage11_storage_full[23:16] <= pair_peak112_r;
	end
	if (pair_peak111_re) begin
		pair_csrstorage11_storage_full[15:8] <= pair_peak111_r;
	end
	if (pair_peak110_re) begin
		pair_csrstorage11_storage_full[7:0] <= pair_peak110_r;
	end
	pair_csrstorage11_re <= pair_peak110_re;
	if (pair_peak123_re) begin
		pair_csrstorage12_storage_full[27:24] <= pair_peak123_r;
	end
	if (pair_peak122_re) begin
		pair_csrstorage12_storage_full[23:16] <= pair_peak122_r;
	end
	if (pair_peak121_re) begin
		pair_csrstorage12_storage_full[15:8] <= pair_peak121_r;
	end
	if (pair_peak120_re) begin
		pair_csrstorage12_storage_full[7:0] <= pair_peak120_r;
	end
	pair_csrstorage12_re <= pair_peak120_re;
	if (pair_peak133_re) begin
		pair_csrstorage13_storage_full[27:24] <= pair_peak133_r;
	end
	if (pair_peak132_re) begin
		pair_csrstorage13_storage_full[23:16] <= pair_peak132_r;
	end
	if (pair_peak131_re) begin
		pair_csrstorage13_storage_full[15:8] <= pair_peak131_r;
	end
	if (pair_peak130_re) begin
		pair_csrstorage13_storage_full[7:0] <= pair_peak130_r;
	end
	pair_csrstorage13_re <= pair_peak130_re;
	if (pair_peak143_re) begin
		pair_csrstorage14_storage_full[27:24] <= pair_peak143_r;
	end
	if (pair_peak142_re) begin
		pair_csrstorage14_storage_full[23:16] <= pair_peak142_r;
	end
	if (pair_peak141_re) begin
		pair_csrstorage14_storage_full[15:8] <= pair_peak141_r;
	end
	if (pair_peak140_re) begin
		pair_csrstorage14_storage_full[7:0] <= pair_peak140_r;
	end
	pair_csrstorage14_re <= pair_peak140_re;
	if (pair_peak153_re) begin
		pair_csrstorage15_storage_full[27:24] <= pair_peak153_r;
	end
	if (pair_peak152_re) begin
		pair_csrstorage15_storage_full[23:16] <= pair_peak152_r;
	end
	if (pair_peak151_re) begin
		pair_csrstorage15_storage_full[15:8] <= pair_peak151_r;
	end
	if (pair_peak150_re) begin
		pair_csrstorage15_storage_full[7:0] <= pair_peak150_r;
	end
	pair_csrstorage15_re <= pair_peak150_re;
	if (pair_peak163_re) begin
		pair_csrstorage16_storage_full[27:24] <= pair_peak163_r;
	end
	if (pair_peak162_re) begin
		pair_csrstorage16_storage_full[23:16] <= pair_peak162_r;
	end
	if (pair_peak161_re) begin
		pair_csrstorage16_storage_full[15:8] <= pair_peak161_r;
	end
	if (pair_peak160_re) begin
		pair_csrstorage16_storage_full[7:0] <= pair_peak160_r;
	end
	pair_csrstorage16_re <= pair_peak160_re;
	if (pair_peak173_re) begin
		pair_csrstorage17_storage_full[27:24] <= pair_peak173_r;
	end
	if (pair_peak172_re) begin
		pair_csrstorage17_storage_full[23:16] <= pair_peak172_r;
	end
	if (pair_peak171_re) begin
		pair_csrstorage17_storage_full[15:8] <= pair_peak171_r;
	end
	if (pair_peak170_re) begin
		pair_csrstorage17_storage_full[7:0] <= pair_peak170_r;
	end
	pair_csrstorage17_re <= pair_peak170_re;
	if (pair_peak183_re) begin
		pair_csrstorage18_storage_full[27:24] <= pair_peak183_r;
	end
	if (pair_peak182_re) begin
		pair_csrstorage18_storage_full[23:16] <= pair_peak182_r;
	end
	if (pair_peak181_re) begin
		pair_csrstorage18_storage_full[15:8] <= pair_peak181_r;
	end
	if (pair_peak180_re) begin
		pair_csrstorage18_storage_full[7:0] <= pair_peak180_r;
	end
	pair_csrstorage18_re <= pair_peak180_re;
	if (pair_peak193_re) begin
		pair_csrstorage19_storage_full[27:24] <= pair_peak193_r;
	end
	if (pair_peak192_re) begin
		pair_csrstorage19_storage_full[23:16] <= pair_peak192_r;
	end
	if (pair_peak191_re) begin
		pair_csrstorage19_storage_full[15:8] <= pair_peak191_r;
	end
	if (pair_peak190_re) begin
		pair_csrstorage19_storage_full[7:0] <= pair_peak190_r;
	end
	pair_csrstorage19_re <= pair_peak190_re;
	if (pair_peak203_re) begin
		pair_csrstorage20_storage_full[27:24] <= pair_peak203_r;
	end
	if (pair_peak202_re) begin
		pair_csrstorage20_storage_full[23:16] <= pair_peak202_r;
	end
	if (pair_peak201_re) begin
		pair_csrstorage20_storage_full[15:8] <= pair_peak201_r;
	end
	if (pair_peak200_re) begin
		pair_csrstorage20_storage_full[7:0] <= pair_peak200_r;
	end
	pair_csrstorage20_re <= pair_peak200_re;
	if (pair_peak213_re) begin
		pair_csrstorage21_storage_full[27:24] <= pair_peak213_r;
	end
	if (pair_peak212_re) begin
		pair_csrstorage21_storage_full[23:16] <= pair_peak212_r;
	end
	if (pair_peak211_re) begin
		pair_csrstorage21_storage_full[15:8] <= pair_peak211_r;
	end
	if (pair_peak210_re) begin
		pair_csrstorage21_storage_full[7:0] <= pair_peak210_r;
	end
	pair_csrstorage21_re <= pair_peak210_re;
	if (pair_peak223_re) begin
		pair_csrstorage22_storage_full[27:24] <= pair_peak223_r;
	end
	if (pair_peak222_re) begin
		pair_csrstorage22_storage_full[23:16] <= pair_peak222_r;
	end
	if (pair_peak221_re) begin
		pair_csrstorage22_storage_full[15:8] <= pair_peak221_r;
	end
	if (pair_peak220_re) begin
		pair_csrstorage22_storage_full[7:0] <= pair_peak220_r;
	end
	pair_csrstorage22_re <= pair_peak220_re;
	if (pair_peak233_re) begin
		pair_csrstorage23_storage_full[27:24] <= pair_peak233_r;
	end
	if (pair_peak232_re) begin
		pair_csrstorage23_storage_full[23:16] <= pair_peak232_r;
	end
	if (pair_peak231_re) begin
		pair_csrstorage23_storage_full[15:8] <= pair_peak231_r;
	end
	if (pair_peak230_re) begin
		pair_csrstorage23_storage_full[7:0] <= pair_peak230_r;
	end
	pair_csrstorage23_re <= pair_peak230_re;
	if (pair_peak243_re) begin
		pair_csrstorage24_storage_full[27:24] <= pair_peak243_r;
	end
	if (pair_peak242_re) begin
		pair_csrstorage24_storage_full[23:16] <= pair_peak242_r;
	end
	if (pair_peak241_re) begin
		pair_csrstorage24_storage_full[15:8] <= pair_peak241_r;
	end
	if (pair_peak240_re) begin
		pair_csrstorage24_storage_full[7:0] <= pair_peak240_r;
	end
	pair_csrstorage24_re <= pair_peak240_re;
	if (pair_peak253_re) begin
		pair_csrstorage25_storage_full[27:24] <= pair_peak253_r;
	end
	if (pair_peak252_re) begin
		pair_csrstorage25_storage_full[23:16] <= pair_peak252_r;
	end
	if (pair_peak251_re) begin
		pair_csrstorage25_storage_full[15:8] <= pair_peak251_r;
	end
	if (pair_peak250_re) begin
		pair_csrstorage25_storage_full[7:0] <= pair_peak250_r;
	end
	pair_csrstorage25_re <= pair_peak250_re;
	if (pair_peak263_re) begin
		pair_csrstorage26_storage_full[27:24] <= pair_peak263_r;
	end
	if (pair_peak262_re) begin
		pair_csrstorage26_storage_full[23:16] <= pair_peak262_r;
	end
	if (pair_peak261_re) begin
		pair_csrstorage26_storage_full[15:8] <= pair_peak261_r;
	end
	if (pair_peak260_re) begin
		pair_csrstorage26_storage_full[7:0] <= pair_peak260_r;
	end
	pair_csrstorage26_re <= pair_peak260_re;
	if (pair_peak273_re) begin
		pair_csrstorage27_storage_full[27:24] <= pair_peak273_r;
	end
	if (pair_peak272_re) begin
		pair_csrstorage27_storage_full[23:16] <= pair_peak272_r;
	end
	if (pair_peak271_re) begin
		pair_csrstorage27_storage_full[15:8] <= pair_peak271_r;
	end
	if (pair_peak270_re) begin
		pair_csrstorage27_storage_full[7:0] <= pair_peak270_r;
	end
	pair_csrstorage27_re <= pair_peak270_re;
	if (pair_peak283_re) begin
		pair_csrstorage28_storage_full[27:24] <= pair_peak283_r;
	end
	if (pair_peak282_re) begin
		pair_csrstorage28_storage_full[23:16] <= pair_peak282_r;
	end
	if (pair_peak281_re) begin
		pair_csrstorage28_storage_full[15:8] <= pair_peak281_r;
	end
	if (pair_peak280_re) begin
		pair_csrstorage28_storage_full[7:0] <= pair_peak280_r;
	end
	pair_csrstorage28_re <= pair_peak280_re;
	if (pair_peak293_re) begin
		pair_csrstorage29_storage_full[27:24] <= pair_peak293_r;
	end
	if (pair_peak292_re) begin
		pair_csrstorage29_storage_full[23:16] <= pair_peak292_r;
	end
	if (pair_peak291_re) begin
		pair_csrstorage29_storage_full[15:8] <= pair_peak291_r;
	end
	if (pair_peak290_re) begin
		pair_csrstorage29_storage_full[7:0] <= pair_peak290_r;
	end
	pair_csrstorage29_re <= pair_peak290_re;
	if (pair_peak303_re) begin
		pair_csrstorage30_storage_full[27:24] <= pair_peak303_r;
	end
	if (pair_peak302_re) begin
		pair_csrstorage30_storage_full[23:16] <= pair_peak302_r;
	end
	if (pair_peak301_re) begin
		pair_csrstorage30_storage_full[15:8] <= pair_peak301_r;
	end
	if (pair_peak300_re) begin
		pair_csrstorage30_storage_full[7:0] <= pair_peak300_r;
	end
	pair_csrstorage30_re <= pair_peak300_re;
	if (pair_peak313_re) begin
		pair_csrstorage31_storage_full[27:24] <= pair_peak313_r;
	end
	if (pair_peak312_re) begin
		pair_csrstorage31_storage_full[23:16] <= pair_peak312_r;
	end
	if (pair_peak311_re) begin
		pair_csrstorage31_storage_full[15:8] <= pair_peak311_r;
	end
	if (pair_peak310_re) begin
		pair_csrstorage31_storage_full[7:0] <= pair_peak310_r;
	end
	pair_csrstorage31_re <= pair_peak310_re;
	if (sys_rst) begin
		pair_csrstorage0_storage_full <= 28'd0;
		pair_csrstorage0_re <= 1'd0;
		pair_csrstorage1_storage_full <= 28'd0;
		pair_csrstorage1_re <= 1'd0;
		pair_csrstorage2_storage_full <= 28'd0;
		pair_csrstorage2_re <= 1'd0;
		pair_csrstorage3_storage_full <= 28'd0;
		pair_csrstorage3_re <= 1'd0;
		pair_csrstorage4_storage_full <= 28'd0;
		pair_csrstorage4_re <= 1'd0;
		pair_csrstorage5_storage_full <= 28'd0;
		pair_csrstorage5_re <= 1'd0;
		pair_csrstorage6_storage_full <= 28'd0;
		pair_csrstorage6_re <= 1'd0;
		pair_csrstorage7_storage_full <= 28'd0;
		pair_csrstorage7_re <= 1'd0;
		pair_csrstorage8_storage_full <= 28'd0;
		pair_csrstorage8_re <= 1'd0;
		pair_csrstorage9_storage_full <= 28'd0;
		pair_csrstorage9_re <= 1'd0;
		pair_csrstorage10_storage_full <= 28'd0;
		pair_csrstorage10_re <= 1'd0;
		pair_csrstorage11_storage_full <= 28'd0;
		pair_csrstorage11_re <= 1'd0;
		pair_csrstorage12_storage_full <= 28'd0;
		pair_csrstorage12_re <= 1'd0;
		pair_csrstorage13_storage_full <= 28'd0;
		pair_csrstorage13_re <= 1'd0;
		pair_csrstorage14_storage_full <= 28'd0;
		pair_csrstorage14_re <= 1'd0;
		pair_csrstorage15_storage_full <= 28'd0;
		pair_csrstorage15_re <= 1'd0;
		pair_csrstorage16_storage_full <= 28'd0;
		pair_csrstorage16_re <= 1'd0;
		pair_csrstorage17_storage_full <= 28'd0;
		pair_csrstorage17_re <= 1'd0;
		pair_csrstorage18_storage_full <= 28'd0;
		pair_csrstorage18_re <= 1'd0;
		pair_csrstorage19_storage_full <= 28'd0;
		pair_csrstorage19_re <= 1'd0;
		pair_csrstorage20_storage_full <= 28'd0;
		pair_csrstorage20_re <= 1'd0;
		pair_csrstorage21_storage_full <= 28'd0;
		pair_csrstorage21_re <= 1'd0;
		pair_csrstorage22_storage_full <= 28'd0;
		pair_csrstorage22_re <= 1'd0;
		pair_csrstorage23_storage_full <= 28'd0;
		pair_csrstorage23_re <= 1'd0;
		pair_csrstorage24_storage_full <= 28'd0;
		pair_csrstorage24_re <= 1'd0;
		pair_csrstorage25_storage_full <= 28'd0;
		pair_csrstorage25_re <= 1'd0;
		pair_csrstorage26_storage_full <= 28'd0;
		pair_csrstorage26_re <= 1'd0;
		pair_csrstorage27_storage_full <= 28'd0;
		pair_csrstorage27_re <= 1'd0;
		pair_csrstorage28_storage_full <= 28'd0;
		pair_csrstorage28_re <= 1'd0;
		pair_csrstorage29_storage_full <= 28'd0;
		pair_csrstorage29_re <= 1'd0;
		pair_csrstorage30_storage_full <= 28'd0;
		pair_csrstorage30_re <= 1'd0;
		pair_csrstorage31_storage_full <= 28'd0;
		pair_csrstorage31_re <= 1'd0;
		pair_bus_dat_r <= 8'd0;
		pair_q0 <= 28'sd0;
		pair_neg0 <= 29'sd0;
		pair_q1 <= 28'sd0;
		pair_neg1 <= 29'sd0;
		pair_q2 <= 28'sd0;
		pair_neg2 <= 29'sd0;
		pair_q3 <= 28'sd0;
		pair_neg3 <= 29'sd0;
		pair_q4 <= 28'sd0;
		pair_neg4 <= 29'sd0;
		pair_q5 <= 28'sd0;
		pair_neg5 <= 29'sd0;
		pair_q6 <= 28'sd0;
		pair_neg6 <= 29'sd0;
		pair_q7 <= 28'sd0;
		pair_neg7 <= 29'sd0;
		pair_q8 <= 28'sd0;
		pair_neg8 <= 29'sd0;
		pair_q9 <= 28'sd0;
		pair_neg9 <= 29'sd0;
		pair_q10 <= 28'sd0;
		pair_neg10 <= 29'sd0;
		pair_q11 <= 28'sd0;
		pair_neg11 <= 29'sd0;
		pair_q12 <= 28'sd0;
		pair_neg12 <= 29'sd0;
		pair_q13 <= 28'sd0;
		pair_neg13 <= 29'sd0;
		pair_q14 <= 28'sd0;
		pair_neg14 <= 29'sd0;
		pair_q15 <= 28'sd0;
		pair_neg15 <= 29'sd0;
		pair_q16 <= 28'sd0;
		pair_neg16 <= 29'sd0;
		pair_q17 <= 28'sd0;
		pair_neg17 <= 29'sd0;
		pair_q18 <= 28'sd0;
		pair_neg18 <= 29'sd0;
		pair_q19 <= 28'sd0;
		pair_neg19 <= 29'sd0;
		pair_q20 <= 28'sd0;
		pair_neg20 <= 29'sd0;
		pair_q21 <= 28'sd0;
		pair_neg21 <= 29'sd0;
		pair_q22 <= 28'sd0;
		pair_neg22 <= 29'sd0;
		pair_q23 <= 28'sd0;
		pair_neg23 <= 29'sd0;
		pair_q24 <= 28'sd0;
		pair_neg24 <= 29'sd0;
		pair_q25 <= 28'sd0;
		pair_neg25 <= 29'sd0;
		pair_q26 <= 28'sd0;
		pair_neg26 <= 29'sd0;
		pair_q27 <= 28'sd0;
		pair_neg27 <= 29'sd0;
		pair_q28 <= 28'sd0;
		pair_neg28 <= 29'sd0;
		pair_q29 <= 28'sd0;
		pair_neg29 <= 29'sd0;
		pair_q30 <= 28'sd0;
		pair_neg30 <= 29'sd0;
		pair_q31 <= 28'sd0;
		pair_neg31 <= 29'sd0;
	end
end

endmodule
