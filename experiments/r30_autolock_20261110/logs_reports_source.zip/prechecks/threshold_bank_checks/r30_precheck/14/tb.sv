`timescale 1ns/1ps
module tb_threshold_bank;
reg sys_clk=0;always #4 sys_clk=~sys_clk;reg sys_rst=1;
reg signed [13:0] value=0;reg [4:0] index=0;reg [13:0] csr_adr=0;reg csr_we=0;reg [7:0] csr_dat_w=0;
wire old_y,new_y;wire [12:0] selected_t,cfg;wire [13:0] selected_neg;wire [7:0] csr_read;
reg expected;reg [12:0] expected_t,expected_cfg;reg [13:0] expected_neg;reg [7:0] expected_read;
integer fd,k,count=0,unknown_count=0;threshold_bank_pair dut(.*);
initial begin
fd=$fopen("vectors.txt","r");if(!fd)$fatal(1,"missing vectors");
while(!$feof(fd))begin
@(negedge sys_clk);k=$fscanf(fd,"%h %h %h %h %h %h %h %h %h %h %h\n",sys_rst,value,index,csr_adr,csr_we,csr_dat_w,expected,expected_t,expected_neg,expected_cfg,expected_read);if(k!=11)$fatal(1,"bad vector");
@(posedge sys_clk);#1;
if(old_y!==expected || new_y!==expected || selected_t!==expected_t || selected_neg!==expected_neg || cfg!==expected_cfg || csr_read!==expected_read)$fatal(1,"THRESHOLD_BANK_FAIL N=14 cycle=%0d idx=%0d old=%b new=%b expected=%b threshold=%h/%h cfg=%h/%h read=%h/%h",count,index,old_y,new_y,expected,selected_t,expected_t,cfg,expected_cfg,csr_read,expected_read);
count=count+1;
end
$fclose(fd);fd=$fopen("unknown.txt","r");sys_rst=0;csr_we=0;
while(!$feof(fd))begin
@(negedge sys_clk);k=$fscanf(fd,"%b %b\n",value,index);if(k!=2)$fatal(1,"bad unknown vector");
@(posedge sys_clk);#1;if(old_y!==new_y)$fatal(1,"THRESHOLD_BANK_XZ_FAIL N=14 case=%0d idx=%b value=%b old=%b new=%b",unknown_count,index,value,old_y,new_y);
unknown_count=unknown_count+1;
end
$display("THRESHOLD_BANK_FULL_PASS N=14 M=13 cycles=%0d unknown=%0d indices=32",count,unknown_count);$finish;
end
endmodule
