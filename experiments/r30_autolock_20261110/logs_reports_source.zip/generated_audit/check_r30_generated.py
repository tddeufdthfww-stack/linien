from pathlib import Path
import ast,hashlib,json,re,subprocess
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261110-r30-autolock-late-threshold');trial=r/'gateware/build/trials/20261110_201606_r30_autolock_late_threshold';s=(trial/'top.v').read_text();prefix='linienmodule_autolock_pipelinedrobustautolock_'
decls=re.findall(r'\(\* dont_touch = "true" \*\) wire '+prefix+r'result(\d+);',s);assert sorted(map(int,decls))==list(range(32))
for i in range(32):
    rhs=re.search(r'^assign '+prefix+f'result{i} = (.*);',s,re.M)[1]
    assert prefix+f'magnitude{i}' in rhs and prefix+f'negative{i}' in rhs and prefix+'sum_diff' in rhs
selected=re.search(r'^assign '+prefix+r'over_threshold = (\w+);',s,re.M)[1]
assert re.search(r'\breg '+selected+r';',s),selected
def sync_statements(text):
    tree=ast.parse(text);return [ast.dump(n) for n in ast.walk(tree) if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Attribute) and n.target.attr=='sync']
old=subprocess.check_output(['git','show','9c5c32a:gateware/logic/autolock_pipeline.py'],cwd=r).decode();new=(r/'gateware/logic/autolock_pipeline.py').read_text(encoding='utf-8')
assert sync_statements(old)==sync_statements(new)
for rel in ('gateware/logic/pid.py','gateware/logic/pid_pipeline.py','gateware/logic/pid_output_limit.py','gateware/logic/iir.py','gateware/linien_module.py','gateware/logic/slow_pipeline.py','gateware/logic/abs_threshold.py'):
    previous=subprocess.check_output(['git','show','9c5c32a:'+rel],cwd=r).replace(b'\r\n',b'\n');current=(r/rel).read_bytes().replace(b'\r\n',b'\n');assert previous==current,rel
baseline=Path('D:/RP_Dev/linien_trials/20261110-r28-pid-output-bitdecode/gateware/build/trials/20261110_193543_r28_pid_output_bitdecode');assert (trial/'top.xdc').read_bytes()==(baseline/'top.xdc').read_bytes()
namespace={};exec((trial/'csrmap.py').read_text(),namespace);assert namespace['states'][12]=='robustover_threshold'
record={'passed':True,'top_sha256':hashlib.sha256((trial/'top.v').read_bytes()).hexdigest(),'parallel_predicates':32,'selected_mux_width':1,'actual_attribute':'Migen keep translated by Xilinx backend to dont_touch=true on32 result wires; no module-wide DONT_TOUCH','original_sync_AST_unchanged':True,'new_serial_cycles':0,'original_scalar_helper_unchanged':True,'PID_IIR_Root_sources_same_as_R28':True,'XDC_same_bytes_R28':True,'public_state12':'robustover_threshold','scope':'Static generated production structure/AST/input checks; separate native functional/route/CDC evidence still required.'}
(h/'r30_generated_structure.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print('R30_GENERATED_ONE_BIT_LATE_SELECT_AND_SYNC_AST_PASS')
