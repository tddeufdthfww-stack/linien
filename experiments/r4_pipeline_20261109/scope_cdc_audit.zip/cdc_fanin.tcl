if {[catch {
set f [open {D:/RP_Dev/linien_trials/20261109-r4-pid-pipeline/gateware/build/r4_scope_cdc_audit/fanin.txt} w]
foreach dcp {{D:/RP_Dev/linien_trials/20261106-ce-saturation/gateware/build/trials/20261109_100550_ce_sat_bits/routed.dcp} {D:/RP_Dev/linien_trials/20261109-r4-pid-pipeline/gateware/build/trials/20261109_111733_r4_fast_pipeline16/routed.dcp}} {
 open_checkpoint $dcp
 puts $f "CHECKPOINT $dcp"
 foreach endpoint {{red_pitaya_scope/set_a_filt_kk_reg[0]/CE} {red_pitaya_scope/set_a_hyst_reg[0]/CE} {red_pitaya_scope/set_b_filt_kk_reg[0]/CE}} {
  set pin [get_pins -quiet $endpoint]
  puts $f "ENDPOINT $endpoint"
  puts $f [lsort [all_fanin -flat -startpoints_only -to $pin]]
 }
 close_design
}
close $f
puts R4_SCOPE_CDC_FANIN_COMPLETE

} msg opts]} {
puts stderr "ERROR: $msg"
puts stderr [dict get $opts -errorinfo]
exit 3
}
exit 0
