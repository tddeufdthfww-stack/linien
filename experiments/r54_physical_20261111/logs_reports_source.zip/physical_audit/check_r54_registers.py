from pathlib import Path
import json,re
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r54-carry-fold-pin-refine');t=r/'gateware/build/trials/20261111_165319_r54_carry_fold_pin_refine'
m=json.loads((t/'manifest.json').read_text());assert m['route']=='COMPLETE' and m['pinopt']=='COMPLETE' and m['postopt']=='COMPLETE' and m['input_r53_dcp_unchanged'] and not m['source_changes_during_run'] and all(m['r53_code_and_test_hash_matches'].values())
def parse(p):
 d={}
 for b in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in b.splitlines() if '=' in s);d[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return d
a=parse(h/'r53_mapped/all_dsp.txt');b=parse(h/'r54_mapped/all_dsp.txt');assert len(a)==len(b)==94 and a==b
old=Path(m['input_r53_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(old/n).read_bytes(),n
text=(t/'implementation.stdout.log').read_text(errors='replace');mark=re.search(r'(?m)^CARRY_FOLD_PIN_SWAP_COMPLETE\s*$',text);assert mark
pintext=text[:mark.start()];summaries=[]
for line in pintext.splitlines():
 if re.match(r'^\|\s*Critical Path\s*\|',line):
  fields=[v.strip() for v in line.strip().strip('|').split('|')]
  summaries.append({'WNS_gain_ns':float(fields[1]),'TNS_gain_ns':float(fields[2]),'added_cells':int(fields[3]),'removed_cells':int(fields[4]),'optimized_cells_nets':int(fields[5])})
rec={'passed':True,'all_94_DSP_register_and_operating_properties_same_input_R53_ignoring_LOC_BEL':True,'raw_hardware_test_count':len(m['r53_code_and_test_hash_matches']),'raw_inputs_same_R53':True,'top_CSR_XDC_bytes_same_R53':True,'input_DCP_SHA_unchanged':True,'new_serial_cycles_this_physical_round':0,'pin_stage_optimization_summaries':summaries,'pin_stage_complete':True,'postroute_options':['placement_opt','routing_opt','rewire','critical_cell_opt'],'scope':'Native/synthesis inherited R52 via R53, NOT RERUN. Actual pin-only/postopt/final route reports kept separately. 94DSP invariance is relative to input R53; does not erase older R52-vs-R48 mapping differences. Not postroute fullRoot SDF/formal/physical CDC proof.'}
(h/'r54_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R54_ALL94_DSP_AND_FROZEN_INPUTS_AUDIT_PASS','pin summaries',summaries)
