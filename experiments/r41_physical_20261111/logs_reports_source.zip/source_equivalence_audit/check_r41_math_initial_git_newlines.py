from pathlib import Path
import hashlib,json,re,subprocess
h=Path(__file__).parent;root=Path('D:/RP_Dev/linien_trials/20261111-r41-scope-source-predecode')
ref=root/'gateware/tests/timing/reference'
old=(ref/'r38_bus_clk_bridge.v').read_text(encoding='utf-8');new=(root/'gateware/verilog/bus_clk_bridge.v').read_text(encoding='utf-8')
new=new.replace('   input                 ack_i         ,  //!< acknowledge signal\n   output                src_capture_o    //!< original source request capture condition','   input                 ack_i            //!< acknowledge signal')
new=new.replace('// No state or CDC stage added; caller mirrors the existing source reset guard.\nassign src_capture_o = (sys_do == sys_done) && (sys_wen_i || sys_ren_i);\n\n','')
assert new==old,'Original bridge state/reset/CDC/return logic changed'
old=(ref/'r38_red_pitaya_scope.v').read_text(encoding='utf-8');new=(root/'gateware/verilog/red_pitaya_scope.v').read_text(encoding='utf-8')
start=new.index('// Source-domain predecode');end=new.index('wire [ 14-1: 0] adc_a_filt_in',start)
block=new[start:end];assert len(re.findall(r'scope_addr_match\[\d+\] <=',block))==17
new=new[:start]+new[end:]
values=[0,4,8,12,16,20,32,36,40,48,52,56,60,64,68,72,76]
for i,v in enumerate(values):new=new.replace(f'scope_addr_match[{i}]',f"addr[19:0]==20'h{v:X}")
new=new.replace('   .ack_i         (  ack            ),\n   .src_capture_o (  scope_src_capture )','   .ack_i         (  ack            )')
# Only whitespace padding of rewritten if statements is irrelevant.
normalize=lambda v:re.sub(r'\s+','',v)
assert normalize(new)==normalize(old),'Non-address behavior in Scope changed'
# Exhaustive all 20-bit legal addresses, including exactly the 17 selected hits.
hits={a:0 for a in values}
for addr in range(1<<20):
 mask=sum((int(addr==v)<<i) for i,v in enumerate(values))
 assert mask.bit_count()<=1
 for v in (addr,) if addr in hits else ():hits[v]+=1
assert all(n==1 for n in hits.values())
parent=subprocess.check_output(['git','show','3fef5e4:tools/check_scope_average.py'],cwd=root)
assert (root/'tools/check_scope_average.py').read_bytes()==parent,'Original Scope regression changed'
unchanged=['gateware/logic/pid.py','gateware/logic/iir.py','gateware/logic/chains.py','gateware/linien_module.py','gateware/lowlevel/crg.py','gateware/lowlevel/pitaya_ps.py','gateware/hw_platform.py','gateware/verilog/axi_slave.v']
for n in unchanged:
 prior=subprocess.check_output(['git','show','3fef5e4:'+n],cwd=root)
 assert (root/n).read_bytes()==prior,n
rec={'passed':True,'original_bridge_all_state_and_control_statements_identical':True,'source_predecode_count':17,'write_comparisons_replaced':19,'scope_all_other_behavior_lexically_identical_ignoring_whitespace':True,'exhaustive_legal_20bit_addresses':1<<20,'original_scope_regression_fixture_unchanged':True,'unrelated_PID_IIR_Root_PS_CRg_platform_AXI_source_bytes_unchanged':unchanged,'new_ADC_CSR_trigger_cycles':0,'proof':'addr and match capture same source accept edge under identical reset/hold guard; match_j == (held_addr[19:0]==j), so same destination wen and original write semantics. Four-state/cohort tests separate; physical CDC not proven.'}
(h/'r41_mathematical_scope_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print(json.dumps(rec,indent=2))
