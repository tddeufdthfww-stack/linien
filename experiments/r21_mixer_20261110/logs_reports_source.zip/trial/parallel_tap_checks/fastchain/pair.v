/* Machine-generated using Migen */
module fastchain_parallel_pair(
	input sys_clk,
	input sys_rst,
	input signed [13:0] adc,
	input signed [13:0] offset,
	input signed [24:0] dx,
	input signed [24:0] dy,
	input [31:0] phase,
	input cei,
	input ceq,
	input [13:0] csr_adr,
	input csr_we,
	input [7:0] csr_dat_w,
	output [24:0] ref_i,
	output [24:0] ref_q,
	output [24:0] ref_pre,
	output ref_ei,
	output ref_eq,
	output [7:0] ref_read,
	output [24:0] cand_i,
	output [24:0] cand_q,
	output [24:0] cand_pre,
	output cand_ei,
	output cand_eq,
	output [7:0] cand_read
);

wire signed [13:0] pair_fastchain0_adc;
wire signed [24:0] pair_fastchain0_out_i;
wire signed [24:0] pair_fastchain0_pre_out_i;
wire pair_fastchain0_out_i_update_en;
wire signed [24:0] pair_fastchain0_out_q;
reg [1:0] pair_fastchain0_y_tap_storage_full = 2'd0;
wire [1:0] pair_fastchain0_y_tap_storage;
reg pair_fastchain0_y_tap_re = 1'd0;
reg pair_fastchain0_invert_storage_full = 1'd0;
wire pair_fastchain0_invert_storage;
reg pair_fastchain0_invert_re = 1'd0;
wire signed [24:0] pair_fastchain0_x0;
wire signed [24:0] pair_fastchain0_dx;
wire signed [24:0] pair_fastchain0_dy;
wire signed [13:0] pair_fastchain0_x1;
wire signed [13:0] pair_fastchain0_i;
wire signed [13:0] pair_fastchain0_q0;
reg [31:0] pair_fastchain0_delay_storage_full = 32'd0;
wire [31:0] pair_fastchain0_delay_storage;
reg pair_fastchain0_delay_re = 1'd0;
reg [3:0] pair_fastchain0_multiplier_storage_full = 4'd1;
wire [3:0] pair_fastchain0_multiplier_storage;
reg pair_fastchain0_multiplier_re = 1'd0;
wire [13:0] pair_fastchain0_phase;
reg signed [14:0] pair_fastchain0_cordic0_xi;
reg signed [14:0] pair_fastchain0_cordic0_yi;
reg signed [14:0] pair_fastchain0_cordic0_zi;
wire signed [14:0] pair_fastchain0_cordic0_xo;
wire signed [14:0] pair_fastchain0_cordic0_yo;
wire signed [14:0] pair_fastchain0_cordic0_zo;
wire pair_fastchain0_cordic0_new_in;
wire pair_fastchain0_cordic0_new_out;
wire signed [16:0] pair_fastchain0_cordic00;
reg signed [16:0] pair_fastchain0_cordic01 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic02 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic03 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic04 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic05 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic06 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic07 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic08 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic09 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic010 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic011 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic012 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic013 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic014 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic015 = 17'sd0;
wire signed [16:0] pair_fastchain0_cordic016;
reg signed [16:0] pair_fastchain0_cordic017 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic018 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic019 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic020 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic021 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic022 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic023 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic024 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic025 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic026 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic027 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic028 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic029 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic030 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic031 = 17'sd0;
wire signed [16:0] pair_fastchain0_cordic032;
reg signed [16:0] pair_fastchain0_cordic033 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic034 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic035 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic036 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic037 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic038 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic039 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic040 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic041 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic042 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic043 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic044 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic045 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic046 = 17'sd0;
reg signed [16:0] pair_fastchain0_cordic047 = 17'sd0;
wire pair_fastchain0_cordic0_dir0;
wire pair_fastchain0_cordic0_dir1;
wire pair_fastchain0_cordic0_dir2;
wire pair_fastchain0_cordic0_dir3;
wire pair_fastchain0_cordic0_dir4;
wire pair_fastchain0_cordic0_dir5;
wire pair_fastchain0_cordic0_dir6;
wire pair_fastchain0_cordic0_dir7;
wire pair_fastchain0_cordic0_dir8;
wire pair_fastchain0_cordic0_dir9;
wire pair_fastchain0_cordic0_dir10;
wire pair_fastchain0_cordic0_dir11;
wire pair_fastchain0_cordic0_dir12;
wire pair_fastchain0_cordic0_dir13;
wire pair_fastchain0_cordic0_dir14;
wire signed [14:0] pair_fastchain0_xi;
reg signed [14:0] pair_fastchain0_yi = 15'sd0;
wire signed [14:0] pair_fastchain0_zi;
wire pair_fastchain0_q1;
reg signed [16:0] pair_fastchain0_ya = 17'sd0;
reg signed [24:0] pair_fastchain0_limitcsr0_limitcsr0_y0 = 25'sd0;
reg pair_fastchain0_limitcsr0_limitcsr0_error0 = 1'd0;
reg pair_fastchain0_limitcsr0_update_en0 = 1'd1;
wire signed [25:0] pair_fastchain0_limitcsr0_x0;
reg [24:0] pair_fastchain0_limitcsr0_min_storage_full0 = 25'd16777216;
wire [24:0] pair_fastchain0_limitcsr0_min_storage0;
reg pair_fastchain0_limitcsr0_min_re0 = 1'd0;
reg [24:0] pair_fastchain0_limitcsr0_max_storage_full0 = 25'd16777215;
wire [24:0] pair_fastchain0_limitcsr0_max_storage0;
reg pair_fastchain0_limitcsr0_max_re0 = 1'd0;
wire signed [25:0] pair_fastchain0_limitcsr0_limit_x0;
reg signed [25:0] pair_fastchain0_limitcsr0_limit_y0;
reg signed [25:0] pair_fastchain0_limitcsr0_limit_max0 = 26'sd0;
reg signed [25:0] pair_fastchain0_limitcsr0_limit_min0 = 26'sd0;
reg pair_fastchain0_limitcsr0_limit_railed0;
wire signed [24:0] pair_fastchain0_iir0_x0;
reg signed [24:0] pair_fastchain0_iir0_y0 = 25'sd0;
wire pair_fastchain0_iir0_hold0;
wire pair_fastchain0_iir0_clear0;
reg pair_fastchain0_iir0_error0 = 1'd0;
reg [26:0] pair_fastchain0_iir0_storage_full0 = 27'd0;
wire [26:0] pair_fastchain0_iir0_storage0;
reg pair_fastchain0_iir0_re0 = 1'd0;
reg signed [24:0] pair_fastchain0_iir0_a10 = 25'sd0;
reg [24:0] pair_fastchain0_iir0_csrstorage0_storage_full0 = 25'd0;
wire [24:0] pair_fastchain0_iir0_csrstorage0_storage0;
reg pair_fastchain0_iir0_csrstorage0_re0 = 1'd0;
reg signed [24:0] pair_fastchain0_iir0_b00 = 25'sd0;
reg [24:0] pair_fastchain0_iir0_csrstorage1_storage_full0 = 25'd0;
wire [24:0] pair_fastchain0_iir0_csrstorage1_storage0;
reg pair_fastchain0_iir0_csrstorage1_re0 = 1'd0;
reg signed [24:0] pair_fastchain0_iir0_b10 = 25'sd0;
reg [24:0] pair_fastchain0_iir0_csrstorage2_storage_full0 = 25'd0;
wire [24:0] pair_fastchain0_iir0_csrstorage2_storage0;
reg pair_fastchain0_iir0_csrstorage2_re0 = 1'd0;
reg signed [49:0] pair_fastchain0_iir0_z0r0 = 50'sd0;
reg signed [24:0] pair_fastchain0_iir0_y_lim0;
wire signed [49:0] pair_fastchain0_iir0_y_next0;
reg [2:0] pair_fastchain0_iir0_y_pat0 = 3'd7;
reg signed [24:0] pair_fastchain0_iir0_y1 = 25'sd0;
wire pair_fastchain0_iir0_railed0;
reg signed [49:0] pair_fastchain0_iir0_zr0 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir0_z0;
wire signed [17:0] pair_fastchain0_iir0_xlo0;
wire signed [7:0] pair_fastchain0_iir0_xhi0;
wire signed [47:0] pair_fastchain0_iir0_zlo0;
wire signed [1:0] pair_fastchain0_iir0_ztop0;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_low0;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_high0;
wire pair_fastchain0_iir00;
wire pair_fastchain0_iir01;
wire signed [3:0] pair_fastchain0_iir0_correction0;
wire [1:0] pair_fastchain0_iir0_top0;
wire signed [49:0] pair_fastchain0_iir0_result0;
reg signed [49:0] pair_fastchain0_iir0_zr1 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir0_z1;
wire signed [17:0] pair_fastchain0_iir0_xlo1;
wire signed [7:0] pair_fastchain0_iir0_xhi1;
wire signed [47:0] pair_fastchain0_iir0_zlo1;
wire signed [1:0] pair_fastchain0_iir0_ztop1;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_low1;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_high1;
wire pair_fastchain0_iir02;
wire pair_fastchain0_iir03;
wire signed [3:0] pair_fastchain0_iir0_correction1;
wire [1:0] pair_fastchain0_iir0_top1;
wire signed [49:0] pair_fastchain0_iir0_result1;
reg signed [49:0] pair_fastchain0_iir0_zr2 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir0_z2;
wire signed [17:0] pair_fastchain0_iir0_xlo2;
wire signed [7:0] pair_fastchain0_iir0_xhi2;
wire signed [47:0] pair_fastchain0_iir0_zlo2;
wire signed [1:0] pair_fastchain0_iir0_ztop2;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_low2;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_high2;
wire pair_fastchain0_iir04;
wire pair_fastchain0_iir05;
wire signed [3:0] pair_fastchain0_iir0_correction2;
wire [1:0] pair_fastchain0_iir0_top2;
wire signed [49:0] pair_fastchain0_iir0_result2;
wire signed [24:0] pair_fastchain0_iir0_x1;
reg signed [24:0] pair_fastchain0_iir0_y2 = 25'sd0;
wire pair_fastchain0_iir0_hold1;
wire pair_fastchain0_iir0_clear1;
reg pair_fastchain0_iir0_error1 = 1'd0;
reg [26:0] pair_fastchain0_iir0_storage_full1 = 27'd0;
wire [26:0] pair_fastchain0_iir0_storage1;
reg pair_fastchain0_iir0_re1 = 1'd0;
reg signed [24:0] pair_fastchain0_iir0_a11 = 25'sd0;
reg [24:0] pair_fastchain0_iir0_csrstorage0_storage_full1 = 25'd0;
wire [24:0] pair_fastchain0_iir0_csrstorage0_storage1;
reg pair_fastchain0_iir0_csrstorage0_re1 = 1'd0;
reg signed [24:0] pair_fastchain0_iir0_a2 = 25'sd0;
reg [24:0] pair_fastchain0_iir0_csrstorage1_storage_full1 = 25'd0;
wire [24:0] pair_fastchain0_iir0_csrstorage1_storage1;
reg pair_fastchain0_iir0_csrstorage1_re1 = 1'd0;
reg signed [24:0] pair_fastchain0_iir0_b01 = 25'sd0;
reg [24:0] pair_fastchain0_iir0_csrstorage2_storage_full1 = 25'd0;
wire [24:0] pair_fastchain0_iir0_csrstorage2_storage1;
reg pair_fastchain0_iir0_csrstorage2_re1 = 1'd0;
reg signed [24:0] pair_fastchain0_iir0_b11 = 25'sd0;
reg [24:0] pair_fastchain0_iir0_csrstorage3_storage_full = 25'd0;
wire [24:0] pair_fastchain0_iir0_csrstorage3_storage;
reg pair_fastchain0_iir0_csrstorage3_re = 1'd0;
reg signed [24:0] pair_fastchain0_iir0_b2 = 25'sd0;
reg [24:0] pair_fastchain0_iir0_csrstorage4_storage_full = 25'd0;
wire [24:0] pair_fastchain0_iir0_csrstorage4_storage;
reg pair_fastchain0_iir0_csrstorage4_re = 1'd0;
reg signed [49:0] pair_fastchain0_iir0_z0r1 = 50'sd0;
reg signed [24:0] pair_fastchain0_iir0_y_lim1;
wire signed [49:0] pair_fastchain0_iir0_y_next1;
reg [2:0] pair_fastchain0_iir0_y_pat1 = 3'd7;
reg signed [24:0] pair_fastchain0_iir0_y3 = 25'sd0;
wire pair_fastchain0_iir0_railed1;
reg signed [49:0] pair_fastchain0_iir0_zr3 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir0_z3;
wire signed [17:0] pair_fastchain0_iir0_xlo3;
wire signed [7:0] pair_fastchain0_iir0_xhi3;
wire signed [47:0] pair_fastchain0_iir0_zlo3;
wire signed [1:0] pair_fastchain0_iir0_ztop3;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_low3;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_high3;
wire pair_fastchain0_iir06;
wire pair_fastchain0_iir07;
wire signed [3:0] pair_fastchain0_iir0_correction3;
wire [1:0] pair_fastchain0_iir0_top3;
wire signed [49:0] pair_fastchain0_iir0_result3;
reg signed [49:0] pair_fastchain0_iir0_zr4 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir0_z4;
wire signed [17:0] pair_fastchain0_iir0_xlo4;
wire signed [7:0] pair_fastchain0_iir0_xhi4;
wire signed [47:0] pair_fastchain0_iir0_zlo4;
wire signed [1:0] pair_fastchain0_iir0_ztop4;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_low4;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_high4;
wire pair_fastchain0_iir08;
wire pair_fastchain0_iir09;
wire signed [3:0] pair_fastchain0_iir0_correction4;
wire [1:0] pair_fastchain0_iir0_top4;
wire signed [49:0] pair_fastchain0_iir0_result4;
reg signed [49:0] pair_fastchain0_iir0_zr5 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir0_z5;
wire signed [17:0] pair_fastchain0_iir0_xlo5;
wire signed [7:0] pair_fastchain0_iir0_xhi5;
wire signed [47:0] pair_fastchain0_iir0_zlo5;
wire signed [1:0] pair_fastchain0_iir0_ztop5;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_low5;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_high5;
wire pair_fastchain0_iir010;
wire pair_fastchain0_iir011;
wire signed [3:0] pair_fastchain0_iir0_correction5;
wire [1:0] pair_fastchain0_iir0_top5;
wire signed [49:0] pair_fastchain0_iir0_result5;
reg signed [49:0] pair_fastchain0_iir0_zr6 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir0_z6;
wire signed [17:0] pair_fastchain0_iir0_xlo6;
wire signed [7:0] pair_fastchain0_iir0_xhi6;
wire signed [47:0] pair_fastchain0_iir0_zlo6;
wire signed [1:0] pair_fastchain0_iir0_ztop6;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_low6;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_high6;
wire pair_fastchain0_iir012;
wire pair_fastchain0_iir013;
wire signed [3:0] pair_fastchain0_iir0_correction6;
wire [1:0] pair_fastchain0_iir0_top6;
wire signed [49:0] pair_fastchain0_iir0_result6;
reg signed [49:0] pair_fastchain0_iir0_zr7 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir0_z7;
wire signed [17:0] pair_fastchain0_iir0_xlo7;
wire signed [7:0] pair_fastchain0_iir0_xhi7;
wire signed [47:0] pair_fastchain0_iir0_zlo7;
wire signed [1:0] pair_fastchain0_iir0_ztop7;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_low7;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir0_high7;
wire pair_fastchain0_iir014;
wire pair_fastchain0_iir015;
wire signed [3:0] pair_fastchain0_iir0_correction7;
wire [1:0] pair_fastchain0_iir0_top7;
wire signed [49:0] pair_fastchain0_iir0_result7;
reg signed [24:0] pair_fastchain0_limitcsr0_limitcsr0_y1 = 25'sd0;
reg pair_fastchain0_limitcsr0_limitcsr0_error1 = 1'd0;
wire pair_fastchain0_limitcsr0_update_en1;
wire signed [27:0] pair_fastchain0_limitcsr0_x1;
reg [24:0] pair_fastchain0_limitcsr0_min_storage_full1 = 25'd16777216;
wire [24:0] pair_fastchain0_limitcsr0_min_storage1;
reg pair_fastchain0_limitcsr0_min_re1 = 1'd0;
reg [24:0] pair_fastchain0_limitcsr0_max_storage_full1 = 25'd16777215;
wire [24:0] pair_fastchain0_limitcsr0_max_storage1;
reg pair_fastchain0_limitcsr0_max_re1 = 1'd0;
wire signed [27:0] pair_fastchain0_limitcsr0_limit_x1;
reg signed [27:0] pair_fastchain0_limitcsr0_limit_y1;
reg signed [27:0] pair_fastchain0_limitcsr0_limit_max1 = 28'sd0;
reg signed [27:0] pair_fastchain0_limitcsr0_limit_min1 = 28'sd0;
reg pair_fastchain0_limitcsr0_limit_railed1;
reg signed [24:0] pair_fastchain0_limitcsr1_limitcsr1_y0 = 25'sd0;
reg pair_fastchain0_limitcsr1_limitcsr1_error0 = 1'd0;
reg pair_fastchain0_limitcsr1_update_en0 = 1'd1;
wire signed [25:0] pair_fastchain0_limitcsr1_x0;
reg [24:0] pair_fastchain0_limitcsr1_min_storage_full0 = 25'd16777216;
wire [24:0] pair_fastchain0_limitcsr1_min_storage0;
reg pair_fastchain0_limitcsr1_min_re0 = 1'd0;
reg [24:0] pair_fastchain0_limitcsr1_max_storage_full0 = 25'd16777215;
wire [24:0] pair_fastchain0_limitcsr1_max_storage0;
reg pair_fastchain0_limitcsr1_max_re0 = 1'd0;
wire signed [25:0] pair_fastchain0_limitcsr1_limit_x0;
reg signed [25:0] pair_fastchain0_limitcsr1_limit_y0;
reg signed [25:0] pair_fastchain0_limitcsr1_limit_max0 = 26'sd0;
reg signed [25:0] pair_fastchain0_limitcsr1_limit_min0 = 26'sd0;
reg pair_fastchain0_limitcsr1_limit_railed0;
wire signed [24:0] pair_fastchain0_iir1_x0;
reg signed [24:0] pair_fastchain0_iir1_y0 = 25'sd0;
wire pair_fastchain0_iir1_hold0;
wire pair_fastchain0_iir1_clear0;
reg pair_fastchain0_iir1_error0 = 1'd0;
reg [26:0] pair_fastchain0_iir1_storage_full0 = 27'd0;
wire [26:0] pair_fastchain0_iir1_storage0;
reg pair_fastchain0_iir1_re0 = 1'd0;
reg signed [24:0] pair_fastchain0_iir1_a10 = 25'sd0;
reg [24:0] pair_fastchain0_iir1_csrstorage3_storage_full = 25'd0;
wire [24:0] pair_fastchain0_iir1_csrstorage3_storage;
reg pair_fastchain0_iir1_csrstorage3_re = 1'd0;
reg signed [24:0] pair_fastchain0_iir1_b00 = 25'sd0;
reg [24:0] pair_fastchain0_iir1_csrstorage4_storage_full = 25'd0;
wire [24:0] pair_fastchain0_iir1_csrstorage4_storage;
reg pair_fastchain0_iir1_csrstorage4_re = 1'd0;
reg signed [24:0] pair_fastchain0_iir1_b10 = 25'sd0;
reg [24:0] pair_fastchain0_iir1_csrstorage5_storage_full0 = 25'd0;
wire [24:0] pair_fastchain0_iir1_csrstorage5_storage0;
reg pair_fastchain0_iir1_csrstorage5_re0 = 1'd0;
reg signed [49:0] pair_fastchain0_iir1_z0r0 = 50'sd0;
reg signed [24:0] pair_fastchain0_iir1_y_lim0;
wire signed [49:0] pair_fastchain0_iir1_y_next0;
reg [2:0] pair_fastchain0_iir1_y_pat0 = 3'd7;
reg signed [24:0] pair_fastchain0_iir1_y1 = 25'sd0;
wire pair_fastchain0_iir1_railed0;
reg signed [49:0] pair_fastchain0_iir1_zr0 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir1_z0;
wire signed [17:0] pair_fastchain0_iir1_xlo0;
wire signed [7:0] pair_fastchain0_iir1_xhi0;
wire signed [47:0] pair_fastchain0_iir1_zlo0;
wire signed [1:0] pair_fastchain0_iir1_ztop0;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_low0;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_high0;
wire pair_fastchain0_iir10;
wire pair_fastchain0_iir11;
wire signed [3:0] pair_fastchain0_iir1_correction0;
wire [1:0] pair_fastchain0_iir1_top0;
wire signed [49:0] pair_fastchain0_iir1_result0;
reg signed [49:0] pair_fastchain0_iir1_zr1 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir1_z1;
wire signed [17:0] pair_fastchain0_iir1_xlo1;
wire signed [7:0] pair_fastchain0_iir1_xhi1;
wire signed [47:0] pair_fastchain0_iir1_zlo1;
wire signed [1:0] pair_fastchain0_iir1_ztop1;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_low1;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_high1;
wire pair_fastchain0_iir12;
wire pair_fastchain0_iir13;
wire signed [3:0] pair_fastchain0_iir1_correction1;
wire [1:0] pair_fastchain0_iir1_top1;
wire signed [49:0] pair_fastchain0_iir1_result1;
reg signed [49:0] pair_fastchain0_iir1_zr2 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir1_z2;
wire signed [17:0] pair_fastchain0_iir1_xlo2;
wire signed [7:0] pair_fastchain0_iir1_xhi2;
wire signed [47:0] pair_fastchain0_iir1_zlo2;
wire signed [1:0] pair_fastchain0_iir1_ztop2;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_low2;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_high2;
wire pair_fastchain0_iir14;
wire pair_fastchain0_iir15;
wire signed [3:0] pair_fastchain0_iir1_correction2;
wire [1:0] pair_fastchain0_iir1_top2;
wire signed [49:0] pair_fastchain0_iir1_result2;
wire signed [24:0] pair_fastchain0_iir1_x1;
reg signed [24:0] pair_fastchain0_iir1_y2 = 25'sd0;
wire pair_fastchain0_iir1_hold1;
wire pair_fastchain0_iir1_clear1;
reg pair_fastchain0_iir1_error1 = 1'd0;
reg [26:0] pair_fastchain0_iir1_storage_full1 = 27'd0;
wire [26:0] pair_fastchain0_iir1_storage1;
reg pair_fastchain0_iir1_re1 = 1'd0;
reg signed [24:0] pair_fastchain0_iir1_a11 = 25'sd0;
reg [24:0] pair_fastchain0_iir1_csrstorage5_storage_full1 = 25'd0;
wire [24:0] pair_fastchain0_iir1_csrstorage5_storage1;
reg pair_fastchain0_iir1_csrstorage5_re1 = 1'd0;
reg signed [24:0] pair_fastchain0_iir1_a2 = 25'sd0;
reg [24:0] pair_fastchain0_iir1_csrstorage6_storage_full = 25'd0;
wire [24:0] pair_fastchain0_iir1_csrstorage6_storage;
reg pair_fastchain0_iir1_csrstorage6_re = 1'd0;
reg signed [24:0] pair_fastchain0_iir1_b01 = 25'sd0;
reg [24:0] pair_fastchain0_iir1_csrstorage7_storage_full = 25'd0;
wire [24:0] pair_fastchain0_iir1_csrstorage7_storage;
reg pair_fastchain0_iir1_csrstorage7_re = 1'd0;
reg signed [24:0] pair_fastchain0_iir1_b11 = 25'sd0;
reg [24:0] pair_fastchain0_iir1_csrstorage8_storage_full = 25'd0;
wire [24:0] pair_fastchain0_iir1_csrstorage8_storage;
reg pair_fastchain0_iir1_csrstorage8_re = 1'd0;
reg signed [24:0] pair_fastchain0_iir1_b2 = 25'sd0;
reg [24:0] pair_fastchain0_iir1_csrstorage9_storage_full = 25'd0;
wire [24:0] pair_fastchain0_iir1_csrstorage9_storage;
reg pair_fastchain0_iir1_csrstorage9_re = 1'd0;
reg signed [49:0] pair_fastchain0_iir1_z0r1 = 50'sd0;
reg signed [24:0] pair_fastchain0_iir1_y_lim1;
wire signed [49:0] pair_fastchain0_iir1_y_next1;
reg [2:0] pair_fastchain0_iir1_y_pat1 = 3'd7;
reg signed [24:0] pair_fastchain0_iir1_y3 = 25'sd0;
wire pair_fastchain0_iir1_railed1;
reg signed [49:0] pair_fastchain0_iir1_zr3 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir1_z3;
wire signed [17:0] pair_fastchain0_iir1_xlo3;
wire signed [7:0] pair_fastchain0_iir1_xhi3;
wire signed [47:0] pair_fastchain0_iir1_zlo3;
wire signed [1:0] pair_fastchain0_iir1_ztop3;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_low3;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_high3;
wire pair_fastchain0_iir16;
wire pair_fastchain0_iir17;
wire signed [3:0] pair_fastchain0_iir1_correction3;
wire [1:0] pair_fastchain0_iir1_top3;
wire signed [49:0] pair_fastchain0_iir1_result3;
reg signed [49:0] pair_fastchain0_iir1_zr4 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir1_z4;
wire signed [17:0] pair_fastchain0_iir1_xlo4;
wire signed [7:0] pair_fastchain0_iir1_xhi4;
wire signed [47:0] pair_fastchain0_iir1_zlo4;
wire signed [1:0] pair_fastchain0_iir1_ztop4;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_low4;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_high4;
wire pair_fastchain0_iir18;
wire pair_fastchain0_iir19;
wire signed [3:0] pair_fastchain0_iir1_correction4;
wire [1:0] pair_fastchain0_iir1_top4;
wire signed [49:0] pair_fastchain0_iir1_result4;
reg signed [49:0] pair_fastchain0_iir1_zr5 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir1_z5;
wire signed [17:0] pair_fastchain0_iir1_xlo5;
wire signed [7:0] pair_fastchain0_iir1_xhi5;
wire signed [47:0] pair_fastchain0_iir1_zlo5;
wire signed [1:0] pair_fastchain0_iir1_ztop5;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_low5;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_high5;
wire pair_fastchain0_iir110;
wire pair_fastchain0_iir111;
wire signed [3:0] pair_fastchain0_iir1_correction5;
wire [1:0] pair_fastchain0_iir1_top5;
wire signed [49:0] pair_fastchain0_iir1_result5;
reg signed [49:0] pair_fastchain0_iir1_zr6 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir1_z6;
wire signed [17:0] pair_fastchain0_iir1_xlo6;
wire signed [7:0] pair_fastchain0_iir1_xhi6;
wire signed [47:0] pair_fastchain0_iir1_zlo6;
wire signed [1:0] pair_fastchain0_iir1_ztop6;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_low6;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_high6;
wire pair_fastchain0_iir112;
wire pair_fastchain0_iir113;
wire signed [3:0] pair_fastchain0_iir1_correction6;
wire [1:0] pair_fastchain0_iir1_top6;
wire signed [49:0] pair_fastchain0_iir1_result6;
reg signed [49:0] pair_fastchain0_iir1_zr7 = 50'sd0;
wire signed [49:0] pair_fastchain0_iir1_z7;
wire signed [17:0] pair_fastchain0_iir1_xlo7;
wire signed [7:0] pair_fastchain0_iir1_xhi7;
wire signed [47:0] pair_fastchain0_iir1_zlo7;
wire signed [1:0] pair_fastchain0_iir1_ztop7;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_low7;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain0_iir1_high7;
wire pair_fastchain0_iir114;
wire pair_fastchain0_iir115;
wire signed [3:0] pair_fastchain0_iir1_correction7;
wire [1:0] pair_fastchain0_iir1_top7;
wire signed [49:0] pair_fastchain0_iir1_result7;
reg signed [24:0] pair_fastchain0_limitcsr1_limitcsr1_y1 = 25'sd0;
reg pair_fastchain0_limitcsr1_limitcsr1_error1 = 1'd0;
wire pair_fastchain0_limitcsr1_update_en1;
wire signed [27:0] pair_fastchain0_limitcsr1_x1;
reg [24:0] pair_fastchain0_limitcsr1_min_storage_full1 = 25'd16777216;
wire [24:0] pair_fastchain0_limitcsr1_min_storage1;
reg pair_fastchain0_limitcsr1_min_re1 = 1'd0;
reg [24:0] pair_fastchain0_limitcsr1_max_storage_full1 = 25'd16777215;
wire [24:0] pair_fastchain0_limitcsr1_max_storage1;
reg pair_fastchain0_limitcsr1_max_re1 = 1'd0;
wire signed [27:0] pair_fastchain0_limitcsr1_limit_x1;
reg signed [27:0] pair_fastchain0_limitcsr1_limit_y1;
reg signed [27:0] pair_fastchain0_limitcsr1_limit_max1 = 28'sd0;
reg signed [27:0] pair_fastchain0_limitcsr1_limit_min1 = 28'sd0;
reg pair_fastchain0_limitcsr1_limit_railed1;
wire [13:0] pair_csrbank0_bus_adr;
wire pair_csrbank0_bus_we;
wire [7:0] pair_csrbank0_bus_dat_w;
reg [7:0] pair_csrbank0_bus_dat_r = 8'd0;
wire pair_csrbank0_y_tap0_re;
wire [1:0] pair_csrbank0_y_tap0_r;
wire [1:0] pair_csrbank0_y_tap0_w;
wire pair_csrbank0_invert0_re;
wire pair_csrbank0_invert0_r;
wire pair_csrbank0_invert0_w;
wire pair_csrbank0_demod_delay3_re;
wire [7:0] pair_csrbank0_demod_delay3_r;
wire [7:0] pair_csrbank0_demod_delay3_w;
wire pair_csrbank0_demod_delay2_re;
wire [7:0] pair_csrbank0_demod_delay2_r;
wire [7:0] pair_csrbank0_demod_delay2_w;
wire pair_csrbank0_demod_delay1_re;
wire [7:0] pair_csrbank0_demod_delay1_r;
wire [7:0] pair_csrbank0_demod_delay1_w;
wire pair_csrbank0_demod_delay0_re;
wire [7:0] pair_csrbank0_demod_delay0_r;
wire [7:0] pair_csrbank0_demod_delay0_w;
wire pair_csrbank0_demod_multiplier0_re;
wire [3:0] pair_csrbank0_demod_multiplier0_r;
wire [3:0] pair_csrbank0_demod_multiplier0_w;
wire pair_csrbank0_x_limit_1_min3_re;
wire pair_csrbank0_x_limit_1_min3_r;
wire pair_csrbank0_x_limit_1_min3_w;
wire pair_csrbank0_x_limit_1_min2_re;
wire [7:0] pair_csrbank0_x_limit_1_min2_r;
wire [7:0] pair_csrbank0_x_limit_1_min2_w;
wire pair_csrbank0_x_limit_1_min1_re;
wire [7:0] pair_csrbank0_x_limit_1_min1_r;
wire [7:0] pair_csrbank0_x_limit_1_min1_w;
wire pair_csrbank0_x_limit_1_min0_re;
wire [7:0] pair_csrbank0_x_limit_1_min0_r;
wire [7:0] pair_csrbank0_x_limit_1_min0_w;
wire pair_csrbank0_x_limit_1_max3_re;
wire pair_csrbank0_x_limit_1_max3_r;
wire pair_csrbank0_x_limit_1_max3_w;
wire pair_csrbank0_x_limit_1_max2_re;
wire [7:0] pair_csrbank0_x_limit_1_max2_r;
wire [7:0] pair_csrbank0_x_limit_1_max2_w;
wire pair_csrbank0_x_limit_1_max1_re;
wire [7:0] pair_csrbank0_x_limit_1_max1_r;
wire [7:0] pair_csrbank0_x_limit_1_max1_w;
wire pair_csrbank0_x_limit_1_max0_re;
wire [7:0] pair_csrbank0_x_limit_1_max0_r;
wire [7:0] pair_csrbank0_x_limit_1_max0_w;
wire pair_csrbank0_iir_c_1_z03_re;
wire [2:0] pair_csrbank0_iir_c_1_z03_r;
wire [2:0] pair_csrbank0_iir_c_1_z03_w;
wire pair_csrbank0_iir_c_1_z02_re;
wire [7:0] pair_csrbank0_iir_c_1_z02_r;
wire [7:0] pair_csrbank0_iir_c_1_z02_w;
wire pair_csrbank0_iir_c_1_z01_re;
wire [7:0] pair_csrbank0_iir_c_1_z01_r;
wire [7:0] pair_csrbank0_iir_c_1_z01_w;
wire pair_csrbank0_iir_c_1_z00_re;
wire [7:0] pair_csrbank0_iir_c_1_z00_r;
wire [7:0] pair_csrbank0_iir_c_1_z00_w;
wire pair_csrbank0_iir_c_1_a13_re;
wire pair_csrbank0_iir_c_1_a13_r;
wire pair_csrbank0_iir_c_1_a13_w;
wire pair_csrbank0_iir_c_1_a12_re;
wire [7:0] pair_csrbank0_iir_c_1_a12_r;
wire [7:0] pair_csrbank0_iir_c_1_a12_w;
wire pair_csrbank0_iir_c_1_a11_re;
wire [7:0] pair_csrbank0_iir_c_1_a11_r;
wire [7:0] pair_csrbank0_iir_c_1_a11_w;
wire pair_csrbank0_iir_c_1_a10_re;
wire [7:0] pair_csrbank0_iir_c_1_a10_r;
wire [7:0] pair_csrbank0_iir_c_1_a10_w;
wire pair_csrbank0_iir_c_1_b03_re;
wire pair_csrbank0_iir_c_1_b03_r;
wire pair_csrbank0_iir_c_1_b03_w;
wire pair_csrbank0_iir_c_1_b02_re;
wire [7:0] pair_csrbank0_iir_c_1_b02_r;
wire [7:0] pair_csrbank0_iir_c_1_b02_w;
wire pair_csrbank0_iir_c_1_b01_re;
wire [7:0] pair_csrbank0_iir_c_1_b01_r;
wire [7:0] pair_csrbank0_iir_c_1_b01_w;
wire pair_csrbank0_iir_c_1_b00_re;
wire [7:0] pair_csrbank0_iir_c_1_b00_r;
wire [7:0] pair_csrbank0_iir_c_1_b00_w;
wire pair_csrbank0_iir_c_1_b13_re;
wire pair_csrbank0_iir_c_1_b13_r;
wire pair_csrbank0_iir_c_1_b13_w;
wire pair_csrbank0_iir_c_1_b12_re;
wire [7:0] pair_csrbank0_iir_c_1_b12_r;
wire [7:0] pair_csrbank0_iir_c_1_b12_w;
wire pair_csrbank0_iir_c_1_b11_re;
wire [7:0] pair_csrbank0_iir_c_1_b11_r;
wire [7:0] pair_csrbank0_iir_c_1_b11_w;
wire pair_csrbank0_iir_c_1_b10_re;
wire [7:0] pair_csrbank0_iir_c_1_b10_r;
wire [7:0] pair_csrbank0_iir_c_1_b10_w;
wire pair_csrbank0_iir_d_1_z03_re;
wire [2:0] pair_csrbank0_iir_d_1_z03_r;
wire [2:0] pair_csrbank0_iir_d_1_z03_w;
wire pair_csrbank0_iir_d_1_z02_re;
wire [7:0] pair_csrbank0_iir_d_1_z02_r;
wire [7:0] pair_csrbank0_iir_d_1_z02_w;
wire pair_csrbank0_iir_d_1_z01_re;
wire [7:0] pair_csrbank0_iir_d_1_z01_r;
wire [7:0] pair_csrbank0_iir_d_1_z01_w;
wire pair_csrbank0_iir_d_1_z00_re;
wire [7:0] pair_csrbank0_iir_d_1_z00_r;
wire [7:0] pair_csrbank0_iir_d_1_z00_w;
wire pair_csrbank0_iir_d_1_a13_re;
wire pair_csrbank0_iir_d_1_a13_r;
wire pair_csrbank0_iir_d_1_a13_w;
wire pair_csrbank0_iir_d_1_a12_re;
wire [7:0] pair_csrbank0_iir_d_1_a12_r;
wire [7:0] pair_csrbank0_iir_d_1_a12_w;
wire pair_csrbank0_iir_d_1_a11_re;
wire [7:0] pair_csrbank0_iir_d_1_a11_r;
wire [7:0] pair_csrbank0_iir_d_1_a11_w;
wire pair_csrbank0_iir_d_1_a10_re;
wire [7:0] pair_csrbank0_iir_d_1_a10_r;
wire [7:0] pair_csrbank0_iir_d_1_a10_w;
wire pair_csrbank0_iir_d_1_a23_re;
wire pair_csrbank0_iir_d_1_a23_r;
wire pair_csrbank0_iir_d_1_a23_w;
wire pair_csrbank0_iir_d_1_a22_re;
wire [7:0] pair_csrbank0_iir_d_1_a22_r;
wire [7:0] pair_csrbank0_iir_d_1_a22_w;
wire pair_csrbank0_iir_d_1_a21_re;
wire [7:0] pair_csrbank0_iir_d_1_a21_r;
wire [7:0] pair_csrbank0_iir_d_1_a21_w;
wire pair_csrbank0_iir_d_1_a20_re;
wire [7:0] pair_csrbank0_iir_d_1_a20_r;
wire [7:0] pair_csrbank0_iir_d_1_a20_w;
wire pair_csrbank0_iir_d_1_b03_re;
wire pair_csrbank0_iir_d_1_b03_r;
wire pair_csrbank0_iir_d_1_b03_w;
wire pair_csrbank0_iir_d_1_b02_re;
wire [7:0] pair_csrbank0_iir_d_1_b02_r;
wire [7:0] pair_csrbank0_iir_d_1_b02_w;
wire pair_csrbank0_iir_d_1_b01_re;
wire [7:0] pair_csrbank0_iir_d_1_b01_r;
wire [7:0] pair_csrbank0_iir_d_1_b01_w;
wire pair_csrbank0_iir_d_1_b00_re;
wire [7:0] pair_csrbank0_iir_d_1_b00_r;
wire [7:0] pair_csrbank0_iir_d_1_b00_w;
wire pair_csrbank0_iir_d_1_b13_re;
wire pair_csrbank0_iir_d_1_b13_r;
wire pair_csrbank0_iir_d_1_b13_w;
wire pair_csrbank0_iir_d_1_b12_re;
wire [7:0] pair_csrbank0_iir_d_1_b12_r;
wire [7:0] pair_csrbank0_iir_d_1_b12_w;
wire pair_csrbank0_iir_d_1_b11_re;
wire [7:0] pair_csrbank0_iir_d_1_b11_r;
wire [7:0] pair_csrbank0_iir_d_1_b11_w;
wire pair_csrbank0_iir_d_1_b10_re;
wire [7:0] pair_csrbank0_iir_d_1_b10_r;
wire [7:0] pair_csrbank0_iir_d_1_b10_w;
wire pair_csrbank0_iir_d_1_b23_re;
wire pair_csrbank0_iir_d_1_b23_r;
wire pair_csrbank0_iir_d_1_b23_w;
wire pair_csrbank0_iir_d_1_b22_re;
wire [7:0] pair_csrbank0_iir_d_1_b22_r;
wire [7:0] pair_csrbank0_iir_d_1_b22_w;
wire pair_csrbank0_iir_d_1_b21_re;
wire [7:0] pair_csrbank0_iir_d_1_b21_r;
wire [7:0] pair_csrbank0_iir_d_1_b21_w;
wire pair_csrbank0_iir_d_1_b20_re;
wire [7:0] pair_csrbank0_iir_d_1_b20_r;
wire [7:0] pair_csrbank0_iir_d_1_b20_w;
wire pair_csrbank0_y_limit_1_min3_re;
wire pair_csrbank0_y_limit_1_min3_r;
wire pair_csrbank0_y_limit_1_min3_w;
wire pair_csrbank0_y_limit_1_min2_re;
wire [7:0] pair_csrbank0_y_limit_1_min2_r;
wire [7:0] pair_csrbank0_y_limit_1_min2_w;
wire pair_csrbank0_y_limit_1_min1_re;
wire [7:0] pair_csrbank0_y_limit_1_min1_r;
wire [7:0] pair_csrbank0_y_limit_1_min1_w;
wire pair_csrbank0_y_limit_1_min0_re;
wire [7:0] pair_csrbank0_y_limit_1_min0_r;
wire [7:0] pair_csrbank0_y_limit_1_min0_w;
wire pair_csrbank0_y_limit_1_max3_re;
wire pair_csrbank0_y_limit_1_max3_r;
wire pair_csrbank0_y_limit_1_max3_w;
wire pair_csrbank0_y_limit_1_max2_re;
wire [7:0] pair_csrbank0_y_limit_1_max2_r;
wire [7:0] pair_csrbank0_y_limit_1_max2_w;
wire pair_csrbank0_y_limit_1_max1_re;
wire [7:0] pair_csrbank0_y_limit_1_max1_r;
wire [7:0] pair_csrbank0_y_limit_1_max1_w;
wire pair_csrbank0_y_limit_1_max0_re;
wire [7:0] pair_csrbank0_y_limit_1_max0_r;
wire [7:0] pair_csrbank0_y_limit_1_max0_w;
wire pair_csrbank0_x_limit_2_min3_re;
wire pair_csrbank0_x_limit_2_min3_r;
wire pair_csrbank0_x_limit_2_min3_w;
wire pair_csrbank0_x_limit_2_min2_re;
wire [7:0] pair_csrbank0_x_limit_2_min2_r;
wire [7:0] pair_csrbank0_x_limit_2_min2_w;
wire pair_csrbank0_x_limit_2_min1_re;
wire [7:0] pair_csrbank0_x_limit_2_min1_r;
wire [7:0] pair_csrbank0_x_limit_2_min1_w;
wire pair_csrbank0_x_limit_2_min0_re;
wire [7:0] pair_csrbank0_x_limit_2_min0_r;
wire [7:0] pair_csrbank0_x_limit_2_min0_w;
wire pair_csrbank0_x_limit_2_max3_re;
wire pair_csrbank0_x_limit_2_max3_r;
wire pair_csrbank0_x_limit_2_max3_w;
wire pair_csrbank0_x_limit_2_max2_re;
wire [7:0] pair_csrbank0_x_limit_2_max2_r;
wire [7:0] pair_csrbank0_x_limit_2_max2_w;
wire pair_csrbank0_x_limit_2_max1_re;
wire [7:0] pair_csrbank0_x_limit_2_max1_r;
wire [7:0] pair_csrbank0_x_limit_2_max1_w;
wire pair_csrbank0_x_limit_2_max0_re;
wire [7:0] pair_csrbank0_x_limit_2_max0_r;
wire [7:0] pair_csrbank0_x_limit_2_max0_w;
wire pair_csrbank0_iir_c_2_z03_re;
wire [2:0] pair_csrbank0_iir_c_2_z03_r;
wire [2:0] pair_csrbank0_iir_c_2_z03_w;
wire pair_csrbank0_iir_c_2_z02_re;
wire [7:0] pair_csrbank0_iir_c_2_z02_r;
wire [7:0] pair_csrbank0_iir_c_2_z02_w;
wire pair_csrbank0_iir_c_2_z01_re;
wire [7:0] pair_csrbank0_iir_c_2_z01_r;
wire [7:0] pair_csrbank0_iir_c_2_z01_w;
wire pair_csrbank0_iir_c_2_z00_re;
wire [7:0] pair_csrbank0_iir_c_2_z00_r;
wire [7:0] pair_csrbank0_iir_c_2_z00_w;
wire pair_csrbank0_iir_c_2_a13_re;
wire pair_csrbank0_iir_c_2_a13_r;
wire pair_csrbank0_iir_c_2_a13_w;
wire pair_csrbank0_iir_c_2_a12_re;
wire [7:0] pair_csrbank0_iir_c_2_a12_r;
wire [7:0] pair_csrbank0_iir_c_2_a12_w;
wire pair_csrbank0_iir_c_2_a11_re;
wire [7:0] pair_csrbank0_iir_c_2_a11_r;
wire [7:0] pair_csrbank0_iir_c_2_a11_w;
wire pair_csrbank0_iir_c_2_a10_re;
wire [7:0] pair_csrbank0_iir_c_2_a10_r;
wire [7:0] pair_csrbank0_iir_c_2_a10_w;
wire pair_csrbank0_iir_c_2_b03_re;
wire pair_csrbank0_iir_c_2_b03_r;
wire pair_csrbank0_iir_c_2_b03_w;
wire pair_csrbank0_iir_c_2_b02_re;
wire [7:0] pair_csrbank0_iir_c_2_b02_r;
wire [7:0] pair_csrbank0_iir_c_2_b02_w;
wire pair_csrbank0_iir_c_2_b01_re;
wire [7:0] pair_csrbank0_iir_c_2_b01_r;
wire [7:0] pair_csrbank0_iir_c_2_b01_w;
wire pair_csrbank0_iir_c_2_b00_re;
wire [7:0] pair_csrbank0_iir_c_2_b00_r;
wire [7:0] pair_csrbank0_iir_c_2_b00_w;
wire pair_csrbank0_iir_c_2_b13_re;
wire pair_csrbank0_iir_c_2_b13_r;
wire pair_csrbank0_iir_c_2_b13_w;
wire pair_csrbank0_iir_c_2_b12_re;
wire [7:0] pair_csrbank0_iir_c_2_b12_r;
wire [7:0] pair_csrbank0_iir_c_2_b12_w;
wire pair_csrbank0_iir_c_2_b11_re;
wire [7:0] pair_csrbank0_iir_c_2_b11_r;
wire [7:0] pair_csrbank0_iir_c_2_b11_w;
wire pair_csrbank0_iir_c_2_b10_re;
wire [7:0] pair_csrbank0_iir_c_2_b10_r;
wire [7:0] pair_csrbank0_iir_c_2_b10_w;
wire pair_csrbank0_iir_d_2_z03_re;
wire [2:0] pair_csrbank0_iir_d_2_z03_r;
wire [2:0] pair_csrbank0_iir_d_2_z03_w;
wire pair_csrbank0_iir_d_2_z02_re;
wire [7:0] pair_csrbank0_iir_d_2_z02_r;
wire [7:0] pair_csrbank0_iir_d_2_z02_w;
wire pair_csrbank0_iir_d_2_z01_re;
wire [7:0] pair_csrbank0_iir_d_2_z01_r;
wire [7:0] pair_csrbank0_iir_d_2_z01_w;
wire pair_csrbank0_iir_d_2_z00_re;
wire [7:0] pair_csrbank0_iir_d_2_z00_r;
wire [7:0] pair_csrbank0_iir_d_2_z00_w;
wire pair_csrbank0_iir_d_2_a13_re;
wire pair_csrbank0_iir_d_2_a13_r;
wire pair_csrbank0_iir_d_2_a13_w;
wire pair_csrbank0_iir_d_2_a12_re;
wire [7:0] pair_csrbank0_iir_d_2_a12_r;
wire [7:0] pair_csrbank0_iir_d_2_a12_w;
wire pair_csrbank0_iir_d_2_a11_re;
wire [7:0] pair_csrbank0_iir_d_2_a11_r;
wire [7:0] pair_csrbank0_iir_d_2_a11_w;
wire pair_csrbank0_iir_d_2_a10_re;
wire [7:0] pair_csrbank0_iir_d_2_a10_r;
wire [7:0] pair_csrbank0_iir_d_2_a10_w;
wire pair_csrbank0_iir_d_2_a23_re;
wire pair_csrbank0_iir_d_2_a23_r;
wire pair_csrbank0_iir_d_2_a23_w;
wire pair_csrbank0_iir_d_2_a22_re;
wire [7:0] pair_csrbank0_iir_d_2_a22_r;
wire [7:0] pair_csrbank0_iir_d_2_a22_w;
wire pair_csrbank0_iir_d_2_a21_re;
wire [7:0] pair_csrbank0_iir_d_2_a21_r;
wire [7:0] pair_csrbank0_iir_d_2_a21_w;
wire pair_csrbank0_iir_d_2_a20_re;
wire [7:0] pair_csrbank0_iir_d_2_a20_r;
wire [7:0] pair_csrbank0_iir_d_2_a20_w;
wire pair_csrbank0_iir_d_2_b03_re;
wire pair_csrbank0_iir_d_2_b03_r;
wire pair_csrbank0_iir_d_2_b03_w;
wire pair_csrbank0_iir_d_2_b02_re;
wire [7:0] pair_csrbank0_iir_d_2_b02_r;
wire [7:0] pair_csrbank0_iir_d_2_b02_w;
wire pair_csrbank0_iir_d_2_b01_re;
wire [7:0] pair_csrbank0_iir_d_2_b01_r;
wire [7:0] pair_csrbank0_iir_d_2_b01_w;
wire pair_csrbank0_iir_d_2_b00_re;
wire [7:0] pair_csrbank0_iir_d_2_b00_r;
wire [7:0] pair_csrbank0_iir_d_2_b00_w;
wire pair_csrbank0_iir_d_2_b13_re;
wire pair_csrbank0_iir_d_2_b13_r;
wire pair_csrbank0_iir_d_2_b13_w;
wire pair_csrbank0_iir_d_2_b12_re;
wire [7:0] pair_csrbank0_iir_d_2_b12_r;
wire [7:0] pair_csrbank0_iir_d_2_b12_w;
wire pair_csrbank0_iir_d_2_b11_re;
wire [7:0] pair_csrbank0_iir_d_2_b11_r;
wire [7:0] pair_csrbank0_iir_d_2_b11_w;
wire pair_csrbank0_iir_d_2_b10_re;
wire [7:0] pair_csrbank0_iir_d_2_b10_r;
wire [7:0] pair_csrbank0_iir_d_2_b10_w;
wire pair_csrbank0_iir_d_2_b23_re;
wire pair_csrbank0_iir_d_2_b23_r;
wire pair_csrbank0_iir_d_2_b23_w;
wire pair_csrbank0_iir_d_2_b22_re;
wire [7:0] pair_csrbank0_iir_d_2_b22_r;
wire [7:0] pair_csrbank0_iir_d_2_b22_w;
wire pair_csrbank0_iir_d_2_b21_re;
wire [7:0] pair_csrbank0_iir_d_2_b21_r;
wire [7:0] pair_csrbank0_iir_d_2_b21_w;
wire pair_csrbank0_iir_d_2_b20_re;
wire [7:0] pair_csrbank0_iir_d_2_b20_r;
wire [7:0] pair_csrbank0_iir_d_2_b20_w;
wire pair_csrbank0_y_limit_2_min3_re;
wire pair_csrbank0_y_limit_2_min3_r;
wire pair_csrbank0_y_limit_2_min3_w;
wire pair_csrbank0_y_limit_2_min2_re;
wire [7:0] pair_csrbank0_y_limit_2_min2_r;
wire [7:0] pair_csrbank0_y_limit_2_min2_w;
wire pair_csrbank0_y_limit_2_min1_re;
wire [7:0] pair_csrbank0_y_limit_2_min1_r;
wire [7:0] pair_csrbank0_y_limit_2_min1_w;
wire pair_csrbank0_y_limit_2_min0_re;
wire [7:0] pair_csrbank0_y_limit_2_min0_r;
wire [7:0] pair_csrbank0_y_limit_2_min0_w;
wire pair_csrbank0_y_limit_2_max3_re;
wire pair_csrbank0_y_limit_2_max3_r;
wire pair_csrbank0_y_limit_2_max3_w;
wire pair_csrbank0_y_limit_2_max2_re;
wire [7:0] pair_csrbank0_y_limit_2_max2_r;
wire [7:0] pair_csrbank0_y_limit_2_max2_w;
wire pair_csrbank0_y_limit_2_max1_re;
wire [7:0] pair_csrbank0_y_limit_2_max1_r;
wire [7:0] pair_csrbank0_y_limit_2_max1_w;
wire pair_csrbank0_y_limit_2_max0_re;
wire [7:0] pair_csrbank0_y_limit_2_max0_r;
wire [7:0] pair_csrbank0_y_limit_2_max0_w;
wire pair_csrbank0_sel;
wire signed [13:0] pair_fastchain1_adc;
wire signed [24:0] pair_fastchain1_out_i;
wire signed [24:0] pair_fastchain1_pre_out_i;
wire pair_fastchain1_out_i_update_en;
wire signed [24:0] pair_fastchain1_out_q;
reg [1:0] pair_fastchain1_y_tap_storage_full = 2'd0;
wire [1:0] pair_fastchain1_y_tap_storage;
reg pair_fastchain1_y_tap_re = 1'd0;
reg pair_fastchain1_invert_storage_full = 1'd0;
wire pair_fastchain1_invert_storage;
reg pair_fastchain1_invert_re = 1'd0;
wire signed [24:0] pair_fastchain1_x0;
wire signed [24:0] pair_fastchain1_dx;
wire signed [24:0] pair_fastchain1_dy;
wire signed [13:0] pair_fastchain1_x1;
wire signed [13:0] pair_fastchain1_i;
wire signed [13:0] pair_fastchain1_q0;
reg [31:0] pair_fastchain1_delay_storage_full = 32'd0;
wire [31:0] pair_fastchain1_delay_storage;
reg pair_fastchain1_delay_re = 1'd0;
reg [3:0] pair_fastchain1_multiplier_storage_full = 4'd1;
wire [3:0] pair_fastchain1_multiplier_storage;
reg pair_fastchain1_multiplier_re = 1'd0;
wire [13:0] pair_fastchain1_phase;
reg signed [14:0] pair_fastchain1_cordic1_xi;
reg signed [14:0] pair_fastchain1_cordic1_yi;
reg signed [14:0] pair_fastchain1_cordic1_zi;
wire signed [14:0] pair_fastchain1_cordic1_xo;
wire signed [14:0] pair_fastchain1_cordic1_yo;
wire signed [14:0] pair_fastchain1_cordic1_zo;
wire pair_fastchain1_cordic1_new_in;
wire pair_fastchain1_cordic1_new_out;
wire signed [16:0] pair_fastchain1_cordic10;
reg signed [16:0] pair_fastchain1_cordic11 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic12 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic13 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic14 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic15 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic16 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic17 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic18 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic19 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic110 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic111 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic112 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic113 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic114 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic115 = 17'sd0;
wire signed [16:0] pair_fastchain1_cordic116;
reg signed [16:0] pair_fastchain1_cordic117 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic118 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic119 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic120 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic121 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic122 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic123 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic124 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic125 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic126 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic127 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic128 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic129 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic130 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic131 = 17'sd0;
wire signed [16:0] pair_fastchain1_cordic132;
reg signed [16:0] pair_fastchain1_cordic133 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic134 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic135 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic136 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic137 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic138 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic139 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic140 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic141 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic142 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic143 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic144 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic145 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic146 = 17'sd0;
reg signed [16:0] pair_fastchain1_cordic147 = 17'sd0;
wire pair_fastchain1_cordic1_dir0;
wire pair_fastchain1_cordic1_dir1;
wire pair_fastchain1_cordic1_dir2;
wire pair_fastchain1_cordic1_dir3;
wire pair_fastchain1_cordic1_dir4;
wire pair_fastchain1_cordic1_dir5;
wire pair_fastchain1_cordic1_dir6;
wire pair_fastchain1_cordic1_dir7;
wire pair_fastchain1_cordic1_dir8;
wire pair_fastchain1_cordic1_dir9;
wire pair_fastchain1_cordic1_dir10;
wire pair_fastchain1_cordic1_dir11;
wire pair_fastchain1_cordic1_dir12;
wire pair_fastchain1_cordic1_dir13;
wire pair_fastchain1_cordic1_dir14;
wire signed [14:0] pair_fastchain1_xi;
reg signed [14:0] pair_fastchain1_yi = 15'sd0;
wire signed [14:0] pair_fastchain1_zi;
wire pair_fastchain1_q1;
reg signed [16:0] pair_fastchain1_ya = 17'sd0;
reg signed [24:0] pair_fastchain1_limitcsr2_limitcsr2_y = 25'sd0;
reg pair_fastchain1_limitcsr2_limitcsr2_error = 1'd0;
reg pair_fastchain1_limitcsr2_update_en = 1'd1;
wire signed [25:0] pair_fastchain1_limitcsr2_x;
reg [24:0] pair_fastchain1_limitcsr2_min_storage_full = 25'd16777216;
wire [24:0] pair_fastchain1_limitcsr2_min_storage;
reg pair_fastchain1_limitcsr2_min_re = 1'd0;
reg [24:0] pair_fastchain1_limitcsr2_max_storage_full = 25'd16777215;
wire [24:0] pair_fastchain1_limitcsr2_max_storage;
reg pair_fastchain1_limitcsr2_max_re = 1'd0;
wire signed [25:0] pair_fastchain1_limitcsr2_limit_x;
reg signed [25:0] pair_fastchain1_limitcsr2_limit_y;
reg signed [25:0] pair_fastchain1_limitcsr2_limit_max = 26'sd0;
reg signed [25:0] pair_fastchain1_limitcsr2_limit_min = 26'sd0;
reg pair_fastchain1_limitcsr2_limit_railed;
wire signed [24:0] pair_fastchain1_iir2_x0;
reg signed [24:0] pair_fastchain1_iir2_y0 = 25'sd0;
wire pair_fastchain1_iir2_hold0;
wire pair_fastchain1_iir2_clear0;
reg pair_fastchain1_iir2_error0 = 1'd0;
reg [26:0] pair_fastchain1_iir2_storage_full0 = 27'd0;
wire [26:0] pair_fastchain1_iir2_storage0;
reg pair_fastchain1_iir2_re0 = 1'd0;
reg signed [24:0] pair_fastchain1_iir2_a10 = 25'sd0;
reg [24:0] pair_fastchain1_iir2_csrstorage6_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir2_csrstorage6_storage;
reg pair_fastchain1_iir2_csrstorage6_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir2_b00 = 25'sd0;
reg [24:0] pair_fastchain1_iir2_csrstorage7_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir2_csrstorage7_storage;
reg pair_fastchain1_iir2_csrstorage7_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir2_b10 = 25'sd0;
reg [24:0] pair_fastchain1_iir2_csrstorage8_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir2_csrstorage8_storage;
reg pair_fastchain1_iir2_csrstorage8_re = 1'd0;
reg signed [49:0] pair_fastchain1_iir2_z0r0 = 50'sd0;
reg signed [24:0] pair_fastchain1_iir2_y_lim0;
wire signed [49:0] pair_fastchain1_iir2_y_next0;
reg [2:0] pair_fastchain1_iir2_y_pat0 = 3'd7;
reg signed [24:0] pair_fastchain1_iir2_y1 = 25'sd0;
wire pair_fastchain1_iir2_railed0;
reg signed [49:0] pair_fastchain1_iir2_zr0 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir2_z0;
wire signed [17:0] pair_fastchain1_iir2_xlo0;
wire signed [7:0] pair_fastchain1_iir2_xhi0;
wire signed [47:0] pair_fastchain1_iir2_zlo0;
wire signed [1:0] pair_fastchain1_iir2_ztop0;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_low0;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_high0;
wire pair_fastchain1_iir20;
wire pair_fastchain1_iir21;
wire signed [3:0] pair_fastchain1_iir2_correction0;
wire [1:0] pair_fastchain1_iir2_top0;
wire signed [49:0] pair_fastchain1_iir2_result0;
reg signed [49:0] pair_fastchain1_iir2_zr1 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir2_z1;
wire signed [17:0] pair_fastchain1_iir2_xlo1;
wire signed [7:0] pair_fastchain1_iir2_xhi1;
wire signed [47:0] pair_fastchain1_iir2_zlo1;
wire signed [1:0] pair_fastchain1_iir2_ztop1;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_low1;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_high1;
wire pair_fastchain1_iir22;
wire pair_fastchain1_iir23;
wire signed [3:0] pair_fastchain1_iir2_correction1;
wire [1:0] pair_fastchain1_iir2_top1;
wire signed [49:0] pair_fastchain1_iir2_result1;
reg signed [49:0] pair_fastchain1_iir2_zr2 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir2_z2;
wire signed [17:0] pair_fastchain1_iir2_xlo2;
wire signed [7:0] pair_fastchain1_iir2_xhi2;
wire signed [47:0] pair_fastchain1_iir2_zlo2;
wire signed [1:0] pair_fastchain1_iir2_ztop2;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_low2;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_high2;
wire pair_fastchain1_iir24;
wire pair_fastchain1_iir25;
wire signed [3:0] pair_fastchain1_iir2_correction2;
wire [1:0] pair_fastchain1_iir2_top2;
wire signed [49:0] pair_fastchain1_iir2_result2;
wire signed [24:0] pair_fastchain1_iir2_x1;
reg signed [24:0] pair_fastchain1_iir2_y2 = 25'sd0;
wire pair_fastchain1_iir2_hold1;
wire pair_fastchain1_iir2_clear1;
reg pair_fastchain1_iir2_error1 = 1'd0;
reg [26:0] pair_fastchain1_iir2_storage_full1 = 27'd0;
wire [26:0] pair_fastchain1_iir2_storage1;
reg pair_fastchain1_iir2_re1 = 1'd0;
reg signed [24:0] pair_fastchain1_iir2_a11 = 25'sd0;
reg [24:0] pair_fastchain1_iir2_csrstorage10_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir2_csrstorage10_storage;
reg pair_fastchain1_iir2_csrstorage10_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir2_a2 = 25'sd0;
reg [24:0] pair_fastchain1_iir2_csrstorage11_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir2_csrstorage11_storage;
reg pair_fastchain1_iir2_csrstorage11_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir2_b01 = 25'sd0;
reg [24:0] pair_fastchain1_iir2_csrstorage12_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir2_csrstorage12_storage;
reg pair_fastchain1_iir2_csrstorage12_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir2_b11 = 25'sd0;
reg [24:0] pair_fastchain1_iir2_csrstorage13_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir2_csrstorage13_storage;
reg pair_fastchain1_iir2_csrstorage13_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir2_b2 = 25'sd0;
reg [24:0] pair_fastchain1_iir2_csrstorage14_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir2_csrstorage14_storage;
reg pair_fastchain1_iir2_csrstorage14_re = 1'd0;
reg signed [49:0] pair_fastchain1_iir2_z0r1 = 50'sd0;
reg signed [24:0] pair_fastchain1_iir2_y_lim1;
wire signed [49:0] pair_fastchain1_iir2_y_next1;
reg [2:0] pair_fastchain1_iir2_y_pat1 = 3'd7;
reg signed [24:0] pair_fastchain1_iir2_y3 = 25'sd0;
wire pair_fastchain1_iir2_railed1;
reg signed [49:0] pair_fastchain1_iir2_zr3 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir2_z3;
wire signed [17:0] pair_fastchain1_iir2_xlo3;
wire signed [7:0] pair_fastchain1_iir2_xhi3;
wire signed [47:0] pair_fastchain1_iir2_zlo3;
wire signed [1:0] pair_fastchain1_iir2_ztop3;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_low3;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_high3;
wire pair_fastchain1_iir26;
wire pair_fastchain1_iir27;
wire signed [3:0] pair_fastchain1_iir2_correction3;
wire [1:0] pair_fastchain1_iir2_top3;
wire signed [49:0] pair_fastchain1_iir2_result3;
reg signed [49:0] pair_fastchain1_iir2_zr4 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir2_z4;
wire signed [17:0] pair_fastchain1_iir2_xlo4;
wire signed [7:0] pair_fastchain1_iir2_xhi4;
wire signed [47:0] pair_fastchain1_iir2_zlo4;
wire signed [1:0] pair_fastchain1_iir2_ztop4;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_low4;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_high4;
wire pair_fastchain1_iir28;
wire pair_fastchain1_iir29;
wire signed [3:0] pair_fastchain1_iir2_correction4;
wire [1:0] pair_fastchain1_iir2_top4;
wire signed [49:0] pair_fastchain1_iir2_result4;
reg signed [49:0] pair_fastchain1_iir2_zr5 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir2_z5;
wire signed [17:0] pair_fastchain1_iir2_xlo5;
wire signed [7:0] pair_fastchain1_iir2_xhi5;
wire signed [47:0] pair_fastchain1_iir2_zlo5;
wire signed [1:0] pair_fastchain1_iir2_ztop5;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_low5;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_high5;
wire pair_fastchain1_iir210;
wire pair_fastchain1_iir211;
wire signed [3:0] pair_fastchain1_iir2_correction5;
wire [1:0] pair_fastchain1_iir2_top5;
wire signed [49:0] pair_fastchain1_iir2_result5;
reg signed [49:0] pair_fastchain1_iir2_zr6 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir2_z6;
wire signed [17:0] pair_fastchain1_iir2_xlo6;
wire signed [7:0] pair_fastchain1_iir2_xhi6;
wire signed [47:0] pair_fastchain1_iir2_zlo6;
wire signed [1:0] pair_fastchain1_iir2_ztop6;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_low6;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_high6;
wire pair_fastchain1_iir212;
wire pair_fastchain1_iir213;
wire signed [3:0] pair_fastchain1_iir2_correction6;
wire [1:0] pair_fastchain1_iir2_top6;
wire signed [49:0] pair_fastchain1_iir2_result6;
reg signed [49:0] pair_fastchain1_iir2_zr7 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir2_z7;
wire signed [17:0] pair_fastchain1_iir2_xlo7;
wire signed [7:0] pair_fastchain1_iir2_xhi7;
wire signed [47:0] pair_fastchain1_iir2_zlo7;
wire signed [1:0] pair_fastchain1_iir2_ztop7;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_low7;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir2_high7;
wire pair_fastchain1_iir214;
wire pair_fastchain1_iir215;
wire signed [3:0] pair_fastchain1_iir2_correction7;
wire [1:0] pair_fastchain1_iir2_top7;
wire signed [49:0] pair_fastchain1_iir2_result7;
reg signed [24:0] pair_fastchain1_paralleltaplimitcsr0_y = 25'sd0;
reg pair_fastchain1_paralleltaplimitcsr0_error = 1'd0;
wire pair_fastchain1_paralleltaplimitcsr0_update_en;
wire signed [24:0] pair_fastchain1_paralleltaplimitcsr00;
wire signed [24:0] pair_fastchain1_paralleltaplimitcsr01;
wire signed [24:0] pair_fastchain1_paralleltaplimitcsr02;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_common_a;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_common_b;
wire [1:0] pair_fastchain1_paralleltaplimitcsr03;
wire pair_fastchain1_paralleltaplimitcsr04;
reg [24:0] pair_fastchain1_paralleltaplimitcsr0_min_storage_full = 25'd16777216;
wire [24:0] pair_fastchain1_paralleltaplimitcsr0_min_storage;
reg pair_fastchain1_paralleltaplimitcsr0_min_re = 1'd0;
reg [24:0] pair_fastchain1_paralleltaplimitcsr0_max_storage_full = 25'd16777215;
wire [24:0] pair_fastchain1_paralleltaplimitcsr0_max_storage;
reg pair_fastchain1_paralleltaplimitcsr0_max_re = 1'd0;
reg signed [27:0] pair_fastchain1_paralleltaplimitcsr0_bound_min = 28'sd0;
reg signed [27:0] pair_fastchain1_paralleltaplimitcsr0_bound_max = 28'sd0;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_total0;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit0_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit0_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit0_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit0_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr0_limit0_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit1_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit1_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit1_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit1_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr0_limit1_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_total1;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit2_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit2_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit2_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit2_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr0_limit2_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit3_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit3_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit3_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit3_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr0_limit3_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_total2;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit4_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit4_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit4_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit4_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr0_limit4_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit5_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit5_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit5_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_limit5_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr0_limit5_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr0_pre_y;
wire pair_fastchain1_paralleltaplimitcsr0_pre_rail;
reg signed [24:0] pair_fastchain1_limitcsr3_limitcsr3_y = 25'sd0;
reg pair_fastchain1_limitcsr3_limitcsr3_error = 1'd0;
reg pair_fastchain1_limitcsr3_update_en = 1'd1;
wire signed [25:0] pair_fastchain1_limitcsr3_x;
reg [24:0] pair_fastchain1_limitcsr3_min_storage_full = 25'd16777216;
wire [24:0] pair_fastchain1_limitcsr3_min_storage;
reg pair_fastchain1_limitcsr3_min_re = 1'd0;
reg [24:0] pair_fastchain1_limitcsr3_max_storage_full = 25'd16777215;
wire [24:0] pair_fastchain1_limitcsr3_max_storage;
reg pair_fastchain1_limitcsr3_max_re = 1'd0;
wire signed [25:0] pair_fastchain1_limitcsr3_limit_x;
reg signed [25:0] pair_fastchain1_limitcsr3_limit_y;
reg signed [25:0] pair_fastchain1_limitcsr3_limit_max = 26'sd0;
reg signed [25:0] pair_fastchain1_limitcsr3_limit_min = 26'sd0;
reg pair_fastchain1_limitcsr3_limit_railed;
wire signed [24:0] pair_fastchain1_iir3_x0;
reg signed [24:0] pair_fastchain1_iir3_y0 = 25'sd0;
wire pair_fastchain1_iir3_hold0;
wire pair_fastchain1_iir3_clear0;
reg pair_fastchain1_iir3_error0 = 1'd0;
reg [26:0] pair_fastchain1_iir3_storage_full0 = 27'd0;
wire [26:0] pair_fastchain1_iir3_storage0;
reg pair_fastchain1_iir3_re0 = 1'd0;
reg signed [24:0] pair_fastchain1_iir3_a10 = 25'sd0;
reg [24:0] pair_fastchain1_iir3_csrstorage9_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir3_csrstorage9_storage;
reg pair_fastchain1_iir3_csrstorage9_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir3_b00 = 25'sd0;
reg [24:0] pair_fastchain1_iir3_csrstorage10_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir3_csrstorage10_storage;
reg pair_fastchain1_iir3_csrstorage10_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir3_b10 = 25'sd0;
reg [24:0] pair_fastchain1_iir3_csrstorage11_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir3_csrstorage11_storage;
reg pair_fastchain1_iir3_csrstorage11_re = 1'd0;
reg signed [49:0] pair_fastchain1_iir3_z0r0 = 50'sd0;
reg signed [24:0] pair_fastchain1_iir3_y_lim0;
wire signed [49:0] pair_fastchain1_iir3_y_next0;
reg [2:0] pair_fastchain1_iir3_y_pat0 = 3'd7;
reg signed [24:0] pair_fastchain1_iir3_y1 = 25'sd0;
wire pair_fastchain1_iir3_railed0;
reg signed [49:0] pair_fastchain1_iir3_zr0 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir3_z0;
wire signed [17:0] pair_fastchain1_iir3_xlo0;
wire signed [7:0] pair_fastchain1_iir3_xhi0;
wire signed [47:0] pair_fastchain1_iir3_zlo0;
wire signed [1:0] pair_fastchain1_iir3_ztop0;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_low0;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_high0;
wire pair_fastchain1_iir30;
wire pair_fastchain1_iir31;
wire signed [3:0] pair_fastchain1_iir3_correction0;
wire [1:0] pair_fastchain1_iir3_top0;
wire signed [49:0] pair_fastchain1_iir3_result0;
reg signed [49:0] pair_fastchain1_iir3_zr1 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir3_z1;
wire signed [17:0] pair_fastchain1_iir3_xlo1;
wire signed [7:0] pair_fastchain1_iir3_xhi1;
wire signed [47:0] pair_fastchain1_iir3_zlo1;
wire signed [1:0] pair_fastchain1_iir3_ztop1;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_low1;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_high1;
wire pair_fastchain1_iir32;
wire pair_fastchain1_iir33;
wire signed [3:0] pair_fastchain1_iir3_correction1;
wire [1:0] pair_fastchain1_iir3_top1;
wire signed [49:0] pair_fastchain1_iir3_result1;
reg signed [49:0] pair_fastchain1_iir3_zr2 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir3_z2;
wire signed [17:0] pair_fastchain1_iir3_xlo2;
wire signed [7:0] pair_fastchain1_iir3_xhi2;
wire signed [47:0] pair_fastchain1_iir3_zlo2;
wire signed [1:0] pair_fastchain1_iir3_ztop2;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_low2;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_high2;
wire pair_fastchain1_iir34;
wire pair_fastchain1_iir35;
wire signed [3:0] pair_fastchain1_iir3_correction2;
wire [1:0] pair_fastchain1_iir3_top2;
wire signed [49:0] pair_fastchain1_iir3_result2;
wire signed [24:0] pair_fastchain1_iir3_x1;
reg signed [24:0] pair_fastchain1_iir3_y2 = 25'sd0;
wire pair_fastchain1_iir3_hold1;
wire pair_fastchain1_iir3_clear1;
reg pair_fastchain1_iir3_error1 = 1'd0;
reg [26:0] pair_fastchain1_iir3_storage_full1 = 27'd0;
wire [26:0] pair_fastchain1_iir3_storage1;
reg pair_fastchain1_iir3_re1 = 1'd0;
reg signed [24:0] pair_fastchain1_iir3_a11 = 25'sd0;
reg [24:0] pair_fastchain1_iir3_csrstorage15_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir3_csrstorage15_storage;
reg pair_fastchain1_iir3_csrstorage15_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir3_a2 = 25'sd0;
reg [24:0] pair_fastchain1_iir3_csrstorage16_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir3_csrstorage16_storage;
reg pair_fastchain1_iir3_csrstorage16_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir3_b01 = 25'sd0;
reg [24:0] pair_fastchain1_iir3_csrstorage17_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir3_csrstorage17_storage;
reg pair_fastchain1_iir3_csrstorage17_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir3_b11 = 25'sd0;
reg [24:0] pair_fastchain1_iir3_csrstorage18_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir3_csrstorage18_storage;
reg pair_fastchain1_iir3_csrstorage18_re = 1'd0;
reg signed [24:0] pair_fastchain1_iir3_b2 = 25'sd0;
reg [24:0] pair_fastchain1_iir3_csrstorage19_storage_full = 25'd0;
wire [24:0] pair_fastchain1_iir3_csrstorage19_storage;
reg pair_fastchain1_iir3_csrstorage19_re = 1'd0;
reg signed [49:0] pair_fastchain1_iir3_z0r1 = 50'sd0;
reg signed [24:0] pair_fastchain1_iir3_y_lim1;
wire signed [49:0] pair_fastchain1_iir3_y_next1;
reg [2:0] pair_fastchain1_iir3_y_pat1 = 3'd7;
reg signed [24:0] pair_fastchain1_iir3_y3 = 25'sd0;
wire pair_fastchain1_iir3_railed1;
reg signed [49:0] pair_fastchain1_iir3_zr3 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir3_z3;
wire signed [17:0] pair_fastchain1_iir3_xlo3;
wire signed [7:0] pair_fastchain1_iir3_xhi3;
wire signed [47:0] pair_fastchain1_iir3_zlo3;
wire signed [1:0] pair_fastchain1_iir3_ztop3;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_low3;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_high3;
wire pair_fastchain1_iir36;
wire pair_fastchain1_iir37;
wire signed [3:0] pair_fastchain1_iir3_correction3;
wire [1:0] pair_fastchain1_iir3_top3;
wire signed [49:0] pair_fastchain1_iir3_result3;
reg signed [49:0] pair_fastchain1_iir3_zr4 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir3_z4;
wire signed [17:0] pair_fastchain1_iir3_xlo4;
wire signed [7:0] pair_fastchain1_iir3_xhi4;
wire signed [47:0] pair_fastchain1_iir3_zlo4;
wire signed [1:0] pair_fastchain1_iir3_ztop4;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_low4;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_high4;
wire pair_fastchain1_iir38;
wire pair_fastchain1_iir39;
wire signed [3:0] pair_fastchain1_iir3_correction4;
wire [1:0] pair_fastchain1_iir3_top4;
wire signed [49:0] pair_fastchain1_iir3_result4;
reg signed [49:0] pair_fastchain1_iir3_zr5 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir3_z5;
wire signed [17:0] pair_fastchain1_iir3_xlo5;
wire signed [7:0] pair_fastchain1_iir3_xhi5;
wire signed [47:0] pair_fastchain1_iir3_zlo5;
wire signed [1:0] pair_fastchain1_iir3_ztop5;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_low5;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_high5;
wire pair_fastchain1_iir310;
wire pair_fastchain1_iir311;
wire signed [3:0] pair_fastchain1_iir3_correction5;
wire [1:0] pair_fastchain1_iir3_top5;
wire signed [49:0] pair_fastchain1_iir3_result5;
reg signed [49:0] pair_fastchain1_iir3_zr6 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir3_z6;
wire signed [17:0] pair_fastchain1_iir3_xlo6;
wire signed [7:0] pair_fastchain1_iir3_xhi6;
wire signed [47:0] pair_fastchain1_iir3_zlo6;
wire signed [1:0] pair_fastchain1_iir3_ztop6;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_low6;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_high6;
wire pair_fastchain1_iir312;
wire pair_fastchain1_iir313;
wire signed [3:0] pair_fastchain1_iir3_correction6;
wire [1:0] pair_fastchain1_iir3_top6;
wire signed [49:0] pair_fastchain1_iir3_result6;
reg signed [49:0] pair_fastchain1_iir3_zr7 = 50'sd0;
wire signed [49:0] pair_fastchain1_iir3_z7;
wire signed [17:0] pair_fastchain1_iir3_xlo7;
wire signed [7:0] pair_fastchain1_iir3_xhi7;
wire signed [47:0] pair_fastchain1_iir3_zlo7;
wire signed [1:0] pair_fastchain1_iir3_ztop7;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_low7;
(* use_dsp = "yes" *) wire signed [47:0] pair_fastchain1_iir3_high7;
wire pair_fastchain1_iir314;
wire pair_fastchain1_iir315;
wire signed [3:0] pair_fastchain1_iir3_correction7;
wire [1:0] pair_fastchain1_iir3_top7;
wire signed [49:0] pair_fastchain1_iir3_result7;
reg signed [24:0] pair_fastchain1_paralleltaplimitcsr1_y = 25'sd0;
reg pair_fastchain1_paralleltaplimitcsr1_error = 1'd0;
wire pair_fastchain1_paralleltaplimitcsr1_update_en;
wire signed [24:0] pair_fastchain1_paralleltaplimitcsr10;
wire signed [24:0] pair_fastchain1_paralleltaplimitcsr11;
wire signed [24:0] pair_fastchain1_paralleltaplimitcsr12;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_common_a;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_common_b;
wire [1:0] pair_fastchain1_paralleltaplimitcsr13;
wire pair_fastchain1_paralleltaplimitcsr14;
reg [24:0] pair_fastchain1_paralleltaplimitcsr1_min_storage_full = 25'd16777216;
wire [24:0] pair_fastchain1_paralleltaplimitcsr1_min_storage;
reg pair_fastchain1_paralleltaplimitcsr1_min_re = 1'd0;
reg [24:0] pair_fastchain1_paralleltaplimitcsr1_max_storage_full = 25'd16777215;
wire [24:0] pair_fastchain1_paralleltaplimitcsr1_max_storage;
reg pair_fastchain1_paralleltaplimitcsr1_max_re = 1'd0;
reg signed [27:0] pair_fastchain1_paralleltaplimitcsr1_bound_min = 28'sd0;
reg signed [27:0] pair_fastchain1_paralleltaplimitcsr1_bound_max = 28'sd0;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_total0;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit6_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit6_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit6_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit6_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr1_limit6_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit7_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit7_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit7_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit7_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr1_limit7_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_total1;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit8_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit8_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit8_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit8_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr1_limit8_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit9_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit9_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit9_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit9_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr1_limit9_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_total2;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit10_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit10_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit10_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit10_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr1_limit10_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit11_x;
(* keep = "true" *) reg signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit11_y;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit11_max;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_limit11_min;
(* keep = "true" *) reg pair_fastchain1_paralleltaplimitcsr1_limit11_railed;
wire signed [27:0] pair_fastchain1_paralleltaplimitcsr1_pre_y;
wire pair_fastchain1_paralleltaplimitcsr1_pre_rail;
wire [13:0] pair_csrbank1_bus_adr;
wire pair_csrbank1_bus_we;
wire [7:0] pair_csrbank1_bus_dat_w;
reg [7:0] pair_csrbank1_bus_dat_r = 8'd0;
wire pair_csrbank1_y_tap0_re;
wire [1:0] pair_csrbank1_y_tap0_r;
wire [1:0] pair_csrbank1_y_tap0_w;
wire pair_csrbank1_invert0_re;
wire pair_csrbank1_invert0_r;
wire pair_csrbank1_invert0_w;
wire pair_csrbank1_demod_delay3_re;
wire [7:0] pair_csrbank1_demod_delay3_r;
wire [7:0] pair_csrbank1_demod_delay3_w;
wire pair_csrbank1_demod_delay2_re;
wire [7:0] pair_csrbank1_demod_delay2_r;
wire [7:0] pair_csrbank1_demod_delay2_w;
wire pair_csrbank1_demod_delay1_re;
wire [7:0] pair_csrbank1_demod_delay1_r;
wire [7:0] pair_csrbank1_demod_delay1_w;
wire pair_csrbank1_demod_delay0_re;
wire [7:0] pair_csrbank1_demod_delay0_r;
wire [7:0] pair_csrbank1_demod_delay0_w;
wire pair_csrbank1_demod_multiplier0_re;
wire [3:0] pair_csrbank1_demod_multiplier0_r;
wire [3:0] pair_csrbank1_demod_multiplier0_w;
wire pair_csrbank1_x_limit_1_min3_re;
wire pair_csrbank1_x_limit_1_min3_r;
wire pair_csrbank1_x_limit_1_min3_w;
wire pair_csrbank1_x_limit_1_min2_re;
wire [7:0] pair_csrbank1_x_limit_1_min2_r;
wire [7:0] pair_csrbank1_x_limit_1_min2_w;
wire pair_csrbank1_x_limit_1_min1_re;
wire [7:0] pair_csrbank1_x_limit_1_min1_r;
wire [7:0] pair_csrbank1_x_limit_1_min1_w;
wire pair_csrbank1_x_limit_1_min0_re;
wire [7:0] pair_csrbank1_x_limit_1_min0_r;
wire [7:0] pair_csrbank1_x_limit_1_min0_w;
wire pair_csrbank1_x_limit_1_max3_re;
wire pair_csrbank1_x_limit_1_max3_r;
wire pair_csrbank1_x_limit_1_max3_w;
wire pair_csrbank1_x_limit_1_max2_re;
wire [7:0] pair_csrbank1_x_limit_1_max2_r;
wire [7:0] pair_csrbank1_x_limit_1_max2_w;
wire pair_csrbank1_x_limit_1_max1_re;
wire [7:0] pair_csrbank1_x_limit_1_max1_r;
wire [7:0] pair_csrbank1_x_limit_1_max1_w;
wire pair_csrbank1_x_limit_1_max0_re;
wire [7:0] pair_csrbank1_x_limit_1_max0_r;
wire [7:0] pair_csrbank1_x_limit_1_max0_w;
wire pair_csrbank1_iir_c_1_z03_re;
wire [2:0] pair_csrbank1_iir_c_1_z03_r;
wire [2:0] pair_csrbank1_iir_c_1_z03_w;
wire pair_csrbank1_iir_c_1_z02_re;
wire [7:0] pair_csrbank1_iir_c_1_z02_r;
wire [7:0] pair_csrbank1_iir_c_1_z02_w;
wire pair_csrbank1_iir_c_1_z01_re;
wire [7:0] pair_csrbank1_iir_c_1_z01_r;
wire [7:0] pair_csrbank1_iir_c_1_z01_w;
wire pair_csrbank1_iir_c_1_z00_re;
wire [7:0] pair_csrbank1_iir_c_1_z00_r;
wire [7:0] pair_csrbank1_iir_c_1_z00_w;
wire pair_csrbank1_iir_c_1_a13_re;
wire pair_csrbank1_iir_c_1_a13_r;
wire pair_csrbank1_iir_c_1_a13_w;
wire pair_csrbank1_iir_c_1_a12_re;
wire [7:0] pair_csrbank1_iir_c_1_a12_r;
wire [7:0] pair_csrbank1_iir_c_1_a12_w;
wire pair_csrbank1_iir_c_1_a11_re;
wire [7:0] pair_csrbank1_iir_c_1_a11_r;
wire [7:0] pair_csrbank1_iir_c_1_a11_w;
wire pair_csrbank1_iir_c_1_a10_re;
wire [7:0] pair_csrbank1_iir_c_1_a10_r;
wire [7:0] pair_csrbank1_iir_c_1_a10_w;
wire pair_csrbank1_iir_c_1_b03_re;
wire pair_csrbank1_iir_c_1_b03_r;
wire pair_csrbank1_iir_c_1_b03_w;
wire pair_csrbank1_iir_c_1_b02_re;
wire [7:0] pair_csrbank1_iir_c_1_b02_r;
wire [7:0] pair_csrbank1_iir_c_1_b02_w;
wire pair_csrbank1_iir_c_1_b01_re;
wire [7:0] pair_csrbank1_iir_c_1_b01_r;
wire [7:0] pair_csrbank1_iir_c_1_b01_w;
wire pair_csrbank1_iir_c_1_b00_re;
wire [7:0] pair_csrbank1_iir_c_1_b00_r;
wire [7:0] pair_csrbank1_iir_c_1_b00_w;
wire pair_csrbank1_iir_c_1_b13_re;
wire pair_csrbank1_iir_c_1_b13_r;
wire pair_csrbank1_iir_c_1_b13_w;
wire pair_csrbank1_iir_c_1_b12_re;
wire [7:0] pair_csrbank1_iir_c_1_b12_r;
wire [7:0] pair_csrbank1_iir_c_1_b12_w;
wire pair_csrbank1_iir_c_1_b11_re;
wire [7:0] pair_csrbank1_iir_c_1_b11_r;
wire [7:0] pair_csrbank1_iir_c_1_b11_w;
wire pair_csrbank1_iir_c_1_b10_re;
wire [7:0] pair_csrbank1_iir_c_1_b10_r;
wire [7:0] pair_csrbank1_iir_c_1_b10_w;
wire pair_csrbank1_iir_d_1_z03_re;
wire [2:0] pair_csrbank1_iir_d_1_z03_r;
wire [2:0] pair_csrbank1_iir_d_1_z03_w;
wire pair_csrbank1_iir_d_1_z02_re;
wire [7:0] pair_csrbank1_iir_d_1_z02_r;
wire [7:0] pair_csrbank1_iir_d_1_z02_w;
wire pair_csrbank1_iir_d_1_z01_re;
wire [7:0] pair_csrbank1_iir_d_1_z01_r;
wire [7:0] pair_csrbank1_iir_d_1_z01_w;
wire pair_csrbank1_iir_d_1_z00_re;
wire [7:0] pair_csrbank1_iir_d_1_z00_r;
wire [7:0] pair_csrbank1_iir_d_1_z00_w;
wire pair_csrbank1_iir_d_1_a13_re;
wire pair_csrbank1_iir_d_1_a13_r;
wire pair_csrbank1_iir_d_1_a13_w;
wire pair_csrbank1_iir_d_1_a12_re;
wire [7:0] pair_csrbank1_iir_d_1_a12_r;
wire [7:0] pair_csrbank1_iir_d_1_a12_w;
wire pair_csrbank1_iir_d_1_a11_re;
wire [7:0] pair_csrbank1_iir_d_1_a11_r;
wire [7:0] pair_csrbank1_iir_d_1_a11_w;
wire pair_csrbank1_iir_d_1_a10_re;
wire [7:0] pair_csrbank1_iir_d_1_a10_r;
wire [7:0] pair_csrbank1_iir_d_1_a10_w;
wire pair_csrbank1_iir_d_1_a23_re;
wire pair_csrbank1_iir_d_1_a23_r;
wire pair_csrbank1_iir_d_1_a23_w;
wire pair_csrbank1_iir_d_1_a22_re;
wire [7:0] pair_csrbank1_iir_d_1_a22_r;
wire [7:0] pair_csrbank1_iir_d_1_a22_w;
wire pair_csrbank1_iir_d_1_a21_re;
wire [7:0] pair_csrbank1_iir_d_1_a21_r;
wire [7:0] pair_csrbank1_iir_d_1_a21_w;
wire pair_csrbank1_iir_d_1_a20_re;
wire [7:0] pair_csrbank1_iir_d_1_a20_r;
wire [7:0] pair_csrbank1_iir_d_1_a20_w;
wire pair_csrbank1_iir_d_1_b03_re;
wire pair_csrbank1_iir_d_1_b03_r;
wire pair_csrbank1_iir_d_1_b03_w;
wire pair_csrbank1_iir_d_1_b02_re;
wire [7:0] pair_csrbank1_iir_d_1_b02_r;
wire [7:0] pair_csrbank1_iir_d_1_b02_w;
wire pair_csrbank1_iir_d_1_b01_re;
wire [7:0] pair_csrbank1_iir_d_1_b01_r;
wire [7:0] pair_csrbank1_iir_d_1_b01_w;
wire pair_csrbank1_iir_d_1_b00_re;
wire [7:0] pair_csrbank1_iir_d_1_b00_r;
wire [7:0] pair_csrbank1_iir_d_1_b00_w;
wire pair_csrbank1_iir_d_1_b13_re;
wire pair_csrbank1_iir_d_1_b13_r;
wire pair_csrbank1_iir_d_1_b13_w;
wire pair_csrbank1_iir_d_1_b12_re;
wire [7:0] pair_csrbank1_iir_d_1_b12_r;
wire [7:0] pair_csrbank1_iir_d_1_b12_w;
wire pair_csrbank1_iir_d_1_b11_re;
wire [7:0] pair_csrbank1_iir_d_1_b11_r;
wire [7:0] pair_csrbank1_iir_d_1_b11_w;
wire pair_csrbank1_iir_d_1_b10_re;
wire [7:0] pair_csrbank1_iir_d_1_b10_r;
wire [7:0] pair_csrbank1_iir_d_1_b10_w;
wire pair_csrbank1_iir_d_1_b23_re;
wire pair_csrbank1_iir_d_1_b23_r;
wire pair_csrbank1_iir_d_1_b23_w;
wire pair_csrbank1_iir_d_1_b22_re;
wire [7:0] pair_csrbank1_iir_d_1_b22_r;
wire [7:0] pair_csrbank1_iir_d_1_b22_w;
wire pair_csrbank1_iir_d_1_b21_re;
wire [7:0] pair_csrbank1_iir_d_1_b21_r;
wire [7:0] pair_csrbank1_iir_d_1_b21_w;
wire pair_csrbank1_iir_d_1_b20_re;
wire [7:0] pair_csrbank1_iir_d_1_b20_r;
wire [7:0] pair_csrbank1_iir_d_1_b20_w;
wire pair_csrbank1_y_limit_1_min3_re;
wire pair_csrbank1_y_limit_1_min3_r;
wire pair_csrbank1_y_limit_1_min3_w;
wire pair_csrbank1_y_limit_1_min2_re;
wire [7:0] pair_csrbank1_y_limit_1_min2_r;
wire [7:0] pair_csrbank1_y_limit_1_min2_w;
wire pair_csrbank1_y_limit_1_min1_re;
wire [7:0] pair_csrbank1_y_limit_1_min1_r;
wire [7:0] pair_csrbank1_y_limit_1_min1_w;
wire pair_csrbank1_y_limit_1_min0_re;
wire [7:0] pair_csrbank1_y_limit_1_min0_r;
wire [7:0] pair_csrbank1_y_limit_1_min0_w;
wire pair_csrbank1_y_limit_1_max3_re;
wire pair_csrbank1_y_limit_1_max3_r;
wire pair_csrbank1_y_limit_1_max3_w;
wire pair_csrbank1_y_limit_1_max2_re;
wire [7:0] pair_csrbank1_y_limit_1_max2_r;
wire [7:0] pair_csrbank1_y_limit_1_max2_w;
wire pair_csrbank1_y_limit_1_max1_re;
wire [7:0] pair_csrbank1_y_limit_1_max1_r;
wire [7:0] pair_csrbank1_y_limit_1_max1_w;
wire pair_csrbank1_y_limit_1_max0_re;
wire [7:0] pair_csrbank1_y_limit_1_max0_r;
wire [7:0] pair_csrbank1_y_limit_1_max0_w;
wire pair_csrbank1_x_limit_2_min3_re;
wire pair_csrbank1_x_limit_2_min3_r;
wire pair_csrbank1_x_limit_2_min3_w;
wire pair_csrbank1_x_limit_2_min2_re;
wire [7:0] pair_csrbank1_x_limit_2_min2_r;
wire [7:0] pair_csrbank1_x_limit_2_min2_w;
wire pair_csrbank1_x_limit_2_min1_re;
wire [7:0] pair_csrbank1_x_limit_2_min1_r;
wire [7:0] pair_csrbank1_x_limit_2_min1_w;
wire pair_csrbank1_x_limit_2_min0_re;
wire [7:0] pair_csrbank1_x_limit_2_min0_r;
wire [7:0] pair_csrbank1_x_limit_2_min0_w;
wire pair_csrbank1_x_limit_2_max3_re;
wire pair_csrbank1_x_limit_2_max3_r;
wire pair_csrbank1_x_limit_2_max3_w;
wire pair_csrbank1_x_limit_2_max2_re;
wire [7:0] pair_csrbank1_x_limit_2_max2_r;
wire [7:0] pair_csrbank1_x_limit_2_max2_w;
wire pair_csrbank1_x_limit_2_max1_re;
wire [7:0] pair_csrbank1_x_limit_2_max1_r;
wire [7:0] pair_csrbank1_x_limit_2_max1_w;
wire pair_csrbank1_x_limit_2_max0_re;
wire [7:0] pair_csrbank1_x_limit_2_max0_r;
wire [7:0] pair_csrbank1_x_limit_2_max0_w;
wire pair_csrbank1_iir_c_2_z03_re;
wire [2:0] pair_csrbank1_iir_c_2_z03_r;
wire [2:0] pair_csrbank1_iir_c_2_z03_w;
wire pair_csrbank1_iir_c_2_z02_re;
wire [7:0] pair_csrbank1_iir_c_2_z02_r;
wire [7:0] pair_csrbank1_iir_c_2_z02_w;
wire pair_csrbank1_iir_c_2_z01_re;
wire [7:0] pair_csrbank1_iir_c_2_z01_r;
wire [7:0] pair_csrbank1_iir_c_2_z01_w;
wire pair_csrbank1_iir_c_2_z00_re;
wire [7:0] pair_csrbank1_iir_c_2_z00_r;
wire [7:0] pair_csrbank1_iir_c_2_z00_w;
wire pair_csrbank1_iir_c_2_a13_re;
wire pair_csrbank1_iir_c_2_a13_r;
wire pair_csrbank1_iir_c_2_a13_w;
wire pair_csrbank1_iir_c_2_a12_re;
wire [7:0] pair_csrbank1_iir_c_2_a12_r;
wire [7:0] pair_csrbank1_iir_c_2_a12_w;
wire pair_csrbank1_iir_c_2_a11_re;
wire [7:0] pair_csrbank1_iir_c_2_a11_r;
wire [7:0] pair_csrbank1_iir_c_2_a11_w;
wire pair_csrbank1_iir_c_2_a10_re;
wire [7:0] pair_csrbank1_iir_c_2_a10_r;
wire [7:0] pair_csrbank1_iir_c_2_a10_w;
wire pair_csrbank1_iir_c_2_b03_re;
wire pair_csrbank1_iir_c_2_b03_r;
wire pair_csrbank1_iir_c_2_b03_w;
wire pair_csrbank1_iir_c_2_b02_re;
wire [7:0] pair_csrbank1_iir_c_2_b02_r;
wire [7:0] pair_csrbank1_iir_c_2_b02_w;
wire pair_csrbank1_iir_c_2_b01_re;
wire [7:0] pair_csrbank1_iir_c_2_b01_r;
wire [7:0] pair_csrbank1_iir_c_2_b01_w;
wire pair_csrbank1_iir_c_2_b00_re;
wire [7:0] pair_csrbank1_iir_c_2_b00_r;
wire [7:0] pair_csrbank1_iir_c_2_b00_w;
wire pair_csrbank1_iir_c_2_b13_re;
wire pair_csrbank1_iir_c_2_b13_r;
wire pair_csrbank1_iir_c_2_b13_w;
wire pair_csrbank1_iir_c_2_b12_re;
wire [7:0] pair_csrbank1_iir_c_2_b12_r;
wire [7:0] pair_csrbank1_iir_c_2_b12_w;
wire pair_csrbank1_iir_c_2_b11_re;
wire [7:0] pair_csrbank1_iir_c_2_b11_r;
wire [7:0] pair_csrbank1_iir_c_2_b11_w;
wire pair_csrbank1_iir_c_2_b10_re;
wire [7:0] pair_csrbank1_iir_c_2_b10_r;
wire [7:0] pair_csrbank1_iir_c_2_b10_w;
wire pair_csrbank1_iir_d_2_z03_re;
wire [2:0] pair_csrbank1_iir_d_2_z03_r;
wire [2:0] pair_csrbank1_iir_d_2_z03_w;
wire pair_csrbank1_iir_d_2_z02_re;
wire [7:0] pair_csrbank1_iir_d_2_z02_r;
wire [7:0] pair_csrbank1_iir_d_2_z02_w;
wire pair_csrbank1_iir_d_2_z01_re;
wire [7:0] pair_csrbank1_iir_d_2_z01_r;
wire [7:0] pair_csrbank1_iir_d_2_z01_w;
wire pair_csrbank1_iir_d_2_z00_re;
wire [7:0] pair_csrbank1_iir_d_2_z00_r;
wire [7:0] pair_csrbank1_iir_d_2_z00_w;
wire pair_csrbank1_iir_d_2_a13_re;
wire pair_csrbank1_iir_d_2_a13_r;
wire pair_csrbank1_iir_d_2_a13_w;
wire pair_csrbank1_iir_d_2_a12_re;
wire [7:0] pair_csrbank1_iir_d_2_a12_r;
wire [7:0] pair_csrbank1_iir_d_2_a12_w;
wire pair_csrbank1_iir_d_2_a11_re;
wire [7:0] pair_csrbank1_iir_d_2_a11_r;
wire [7:0] pair_csrbank1_iir_d_2_a11_w;
wire pair_csrbank1_iir_d_2_a10_re;
wire [7:0] pair_csrbank1_iir_d_2_a10_r;
wire [7:0] pair_csrbank1_iir_d_2_a10_w;
wire pair_csrbank1_iir_d_2_a23_re;
wire pair_csrbank1_iir_d_2_a23_r;
wire pair_csrbank1_iir_d_2_a23_w;
wire pair_csrbank1_iir_d_2_a22_re;
wire [7:0] pair_csrbank1_iir_d_2_a22_r;
wire [7:0] pair_csrbank1_iir_d_2_a22_w;
wire pair_csrbank1_iir_d_2_a21_re;
wire [7:0] pair_csrbank1_iir_d_2_a21_r;
wire [7:0] pair_csrbank1_iir_d_2_a21_w;
wire pair_csrbank1_iir_d_2_a20_re;
wire [7:0] pair_csrbank1_iir_d_2_a20_r;
wire [7:0] pair_csrbank1_iir_d_2_a20_w;
wire pair_csrbank1_iir_d_2_b03_re;
wire pair_csrbank1_iir_d_2_b03_r;
wire pair_csrbank1_iir_d_2_b03_w;
wire pair_csrbank1_iir_d_2_b02_re;
wire [7:0] pair_csrbank1_iir_d_2_b02_r;
wire [7:0] pair_csrbank1_iir_d_2_b02_w;
wire pair_csrbank1_iir_d_2_b01_re;
wire [7:0] pair_csrbank1_iir_d_2_b01_r;
wire [7:0] pair_csrbank1_iir_d_2_b01_w;
wire pair_csrbank1_iir_d_2_b00_re;
wire [7:0] pair_csrbank1_iir_d_2_b00_r;
wire [7:0] pair_csrbank1_iir_d_2_b00_w;
wire pair_csrbank1_iir_d_2_b13_re;
wire pair_csrbank1_iir_d_2_b13_r;
wire pair_csrbank1_iir_d_2_b13_w;
wire pair_csrbank1_iir_d_2_b12_re;
wire [7:0] pair_csrbank1_iir_d_2_b12_r;
wire [7:0] pair_csrbank1_iir_d_2_b12_w;
wire pair_csrbank1_iir_d_2_b11_re;
wire [7:0] pair_csrbank1_iir_d_2_b11_r;
wire [7:0] pair_csrbank1_iir_d_2_b11_w;
wire pair_csrbank1_iir_d_2_b10_re;
wire [7:0] pair_csrbank1_iir_d_2_b10_r;
wire [7:0] pair_csrbank1_iir_d_2_b10_w;
wire pair_csrbank1_iir_d_2_b23_re;
wire pair_csrbank1_iir_d_2_b23_r;
wire pair_csrbank1_iir_d_2_b23_w;
wire pair_csrbank1_iir_d_2_b22_re;
wire [7:0] pair_csrbank1_iir_d_2_b22_r;
wire [7:0] pair_csrbank1_iir_d_2_b22_w;
wire pair_csrbank1_iir_d_2_b21_re;
wire [7:0] pair_csrbank1_iir_d_2_b21_r;
wire [7:0] pair_csrbank1_iir_d_2_b21_w;
wire pair_csrbank1_iir_d_2_b20_re;
wire [7:0] pair_csrbank1_iir_d_2_b20_r;
wire [7:0] pair_csrbank1_iir_d_2_b20_w;
wire pair_csrbank1_y_limit_2_min3_re;
wire pair_csrbank1_y_limit_2_min3_r;
wire pair_csrbank1_y_limit_2_min3_w;
wire pair_csrbank1_y_limit_2_min2_re;
wire [7:0] pair_csrbank1_y_limit_2_min2_r;
wire [7:0] pair_csrbank1_y_limit_2_min2_w;
wire pair_csrbank1_y_limit_2_min1_re;
wire [7:0] pair_csrbank1_y_limit_2_min1_r;
wire [7:0] pair_csrbank1_y_limit_2_min1_w;
wire pair_csrbank1_y_limit_2_min0_re;
wire [7:0] pair_csrbank1_y_limit_2_min0_r;
wire [7:0] pair_csrbank1_y_limit_2_min0_w;
wire pair_csrbank1_y_limit_2_max3_re;
wire pair_csrbank1_y_limit_2_max3_r;
wire pair_csrbank1_y_limit_2_max3_w;
wire pair_csrbank1_y_limit_2_max2_re;
wire [7:0] pair_csrbank1_y_limit_2_max2_r;
wire [7:0] pair_csrbank1_y_limit_2_max2_w;
wire pair_csrbank1_y_limit_2_max1_re;
wire [7:0] pair_csrbank1_y_limit_2_max1_r;
wire [7:0] pair_csrbank1_y_limit_2_max1_w;
wire pair_csrbank1_y_limit_2_max0_re;
wire [7:0] pair_csrbank1_y_limit_2_max0_r;
wire [7:0] pair_csrbank1_y_limit_2_max0_w;
wire pair_csrbank1_sel;
reg signed [24:0] array_muxed0;
reg signed [24:0] array_muxed1;
reg signed [27:0] array_muxed2;
reg signed [27:0] array_muxed3;
reg array_muxed4;
reg array_muxed5;
reg signed [27:0] array_muxed6;
reg signed [27:0] array_muxed7;
reg array_muxed8;
reg array_muxed9;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign pair_fastchain0_adc = adc;
assign pair_fastchain0_dx = dx;
assign pair_fastchain0_dy = dy;
assign pair_fastchain0_limitcsr0_update_en1 = cei;
assign pair_fastchain0_limitcsr1_update_en1 = ceq;
assign pair_csrbank0_bus_adr = csr_adr;
assign pair_csrbank0_bus_we = csr_we;
assign pair_csrbank0_bus_dat_w = csr_dat_w;
assign ref_i = pair_fastchain0_out_i;
assign ref_q = pair_fastchain0_out_q;
assign ref_pre = pair_fastchain0_pre_out_i;
assign ref_ei = pair_fastchain0_limitcsr0_limitcsr0_error1;
assign ref_eq = pair_fastchain0_limitcsr1_limitcsr1_error1;
assign ref_read = pair_csrbank0_bus_dat_r;
assign pair_fastchain1_adc = adc;
assign pair_fastchain1_dx = dx;
assign pair_fastchain1_dy = dy;
assign pair_fastchain1_paralleltaplimitcsr0_update_en = cei;
assign pair_fastchain1_paralleltaplimitcsr1_update_en = ceq;
assign pair_csrbank1_bus_adr = csr_adr;
assign pair_csrbank1_bus_we = csr_we;
assign pair_csrbank1_bus_dat_w = csr_dat_w;
assign cand_i = pair_fastchain1_out_i;
assign cand_q = pair_fastchain1_out_q;
assign cand_pre = pair_fastchain1_pre_out_i;
assign cand_ei = pair_fastchain1_paralleltaplimitcsr0_error;
assign cand_eq = pair_fastchain1_paralleltaplimitcsr1_error;
assign cand_read = pair_csrbank1_bus_dat_r;
assign pair_fastchain0_x0 = (pair_fastchain0_adc <<< 4'd11);
assign pair_fastchain0_x1 = pair_fastchain0_adc;
assign pair_fastchain0_phase = phase;
assign pair_fastchain0_pre_out_i = pair_fastchain0_limitcsr0_limit_y1;
assign pair_fastchain0_out_i_update_en = pair_fastchain0_limitcsr0_update_en1;
assign pair_fastchain0_limitcsr0_x0 = ((pair_fastchain0_i <<< 4'd11) + pair_fastchain0_dx);
assign pair_fastchain0_iir0_x0 = pair_fastchain0_limitcsr0_limitcsr0_y0;
assign pair_fastchain0_iir0_hold0 = 1'd0;
assign pair_fastchain0_iir0_clear0 = 1'd0;
assign pair_fastchain0_iir0_x1 = pair_fastchain0_iir0_y0;
assign pair_fastchain0_iir0_hold1 = 1'd0;
assign pair_fastchain0_iir0_clear1 = 1'd0;
assign pair_fastchain0_limitcsr0_x1 = ((pair_fastchain0_invert_storage ? 1'sd1 : $signed({1'd0, 1'd1})) * ((array_muxed0 + (pair_fastchain0_ya <<< 4'd11)) + (offset <<< 4'd11)));
assign pair_fastchain0_out_i = pair_fastchain0_limitcsr0_limitcsr0_y1;
assign pair_fastchain0_limitcsr1_x0 = ((pair_fastchain0_q0 <<< 4'd11) + pair_fastchain0_dx);
assign pair_fastchain0_iir1_x0 = pair_fastchain0_limitcsr1_limitcsr1_y0;
assign pair_fastchain0_iir1_hold0 = 1'd0;
assign pair_fastchain0_iir1_clear0 = 1'd0;
assign pair_fastchain0_iir1_x1 = pair_fastchain0_iir1_y0;
assign pair_fastchain0_iir1_hold1 = 1'd0;
assign pair_fastchain0_iir1_clear1 = 1'd0;
assign pair_fastchain0_limitcsr1_x1 = ((pair_fastchain0_invert_storage ? 1'sd1 : $signed({1'd0, 1'd1})) * ((array_muxed1 + (pair_fastchain0_ya <<< 4'd11)) + (offset <<< 4'd11)));
assign pair_fastchain0_out_q = pair_fastchain0_limitcsr1_limitcsr1_y1;
assign pair_fastchain0_xi = pair_fastchain0_x1;
assign pair_fastchain0_zi = (((pair_fastchain0_phase * pair_fastchain0_multiplier_storage) + pair_fastchain0_delay_storage) <<< 1'd1);
assign pair_fastchain0_i = (pair_fastchain0_cordic0_xo >>> 1'd1);
assign pair_fastchain0_q0 = (pair_fastchain0_cordic0_yo >>> 1'd1);
assign pair_fastchain0_cordic00 = (pair_fastchain0_cordic0_xi <<< 2'd2);
assign pair_fastchain0_cordic016 = (pair_fastchain0_cordic0_yi <<< 2'd2);
assign pair_fastchain0_cordic032 = (pair_fastchain0_cordic0_zi <<< 2'd2);
assign pair_fastchain0_cordic0_xo = (pair_fastchain0_cordic015 >>> 2'd2);
assign pair_fastchain0_cordic0_yo = (pair_fastchain0_cordic031 >>> 2'd2);
assign pair_fastchain0_cordic0_zo = (pair_fastchain0_cordic047 >>> 2'd2);
assign pair_fastchain0_cordic0_new_out = 1'd1;
assign pair_fastchain0_cordic0_new_in = 1'd1;
assign pair_fastchain0_cordic0_dir0 = (pair_fastchain0_cordic032 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir1 = (pair_fastchain0_cordic033 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir2 = (pair_fastchain0_cordic034 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir3 = (pair_fastchain0_cordic035 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir4 = (pair_fastchain0_cordic036 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir5 = (pair_fastchain0_cordic037 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir6 = (pair_fastchain0_cordic038 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir7 = (pair_fastchain0_cordic039 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir8 = (pair_fastchain0_cordic040 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir9 = (pair_fastchain0_cordic041 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir10 = (pair_fastchain0_cordic042 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir11 = (pair_fastchain0_cordic043 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir12 = (pair_fastchain0_cordic044 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir13 = (pair_fastchain0_cordic045 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_cordic0_dir14 = (pair_fastchain0_cordic046 < $signed({1'd0, 1'd0}));
assign pair_fastchain0_q1 = (pair_fastchain0_zi[13] ^ pair_fastchain0_zi[14]);

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	pair_fastchain0_cordic0_xi <= 15'sd0;
	pair_fastchain0_cordic0_yi <= 15'sd0;
	pair_fastchain0_cordic0_zi <= 15'sd0;
	if (pair_fastchain0_q1) begin
		{pair_fastchain0_cordic0_zi, pair_fastchain0_cordic0_yi, pair_fastchain0_cordic0_xi} <= {(pair_fastchain0_zi + $signed({1'd0, 15'd16384})), (-pair_fastchain0_yi), (-pair_fastchain0_xi)};
	end else begin
		{pair_fastchain0_cordic0_zi, pair_fastchain0_cordic0_yi, pair_fastchain0_cordic0_xi} <= {pair_fastchain0_zi, pair_fastchain0_yi, pair_fastchain0_xi};
	end
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain0_limitcsr0_limit_x0 = pair_fastchain0_limitcsr0_x0;

// synthesis translate_off
reg dummy_d_1;
// synthesis translate_on
always @(*) begin
	pair_fastchain0_limitcsr0_limit_y0 <= 26'sd0;
	pair_fastchain0_limitcsr0_limit_railed0 <= 1'd0;
	if ((pair_fastchain0_limitcsr0_limit_x0 >= pair_fastchain0_limitcsr0_limit_max0)) begin
		pair_fastchain0_limitcsr0_limit_y0 <= pair_fastchain0_limitcsr0_limit_max0;
		pair_fastchain0_limitcsr0_limit_railed0 <= 1'd1;
	end else begin
		if ((pair_fastchain0_limitcsr0_limit_x0 <= pair_fastchain0_limitcsr0_limit_min0)) begin
			pair_fastchain0_limitcsr0_limit_y0 <= pair_fastchain0_limitcsr0_limit_min0;
			pair_fastchain0_limitcsr0_limit_railed0 <= 1'd1;
		end else begin
			pair_fastchain0_limitcsr0_limit_y0 <= pair_fastchain0_limitcsr0_limit_x0;
			pair_fastchain0_limitcsr0_limit_railed0 <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_1 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain0_iir0_railed0 = (~((pair_fastchain0_iir0_y_next0[49:47] == $signed({1'd0, pair_fastchain0_iir0_y_pat0})) | (pair_fastchain0_iir0_y_next0[49:47] == $signed({1'd0, (~pair_fastchain0_iir0_y_pat0)}))));

// synthesis translate_off
reg dummy_d_2;
// synthesis translate_on
always @(*) begin
	pair_fastchain0_iir0_y_lim0 <= 25'sd0;
	if (pair_fastchain0_iir0_railed0) begin
		pair_fastchain0_iir0_y_lim0 <= pair_fastchain0_iir0_y0;
	end else begin
		pair_fastchain0_iir0_y_lim0 <= pair_fastchain0_iir0_y_next0[49:23];
	end
// synthesis translate_off
	dummy_d_2 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain0_iir0_xlo0 = {1'd0, pair_fastchain0_iir0_x0[16:0]};
assign pair_fastchain0_iir0_xhi0 = pair_fastchain0_iir0_x0[24:17];
assign pair_fastchain0_iir0_zlo0 = pair_fastchain0_iir0_zr0[47:0];
assign pair_fastchain0_iir0_ztop0 = pair_fastchain0_iir0_zr0[49:48];
assign pair_fastchain0_iir0_low0 = ((pair_fastchain0_iir0_b10 * pair_fastchain0_iir0_xlo0) + pair_fastchain0_iir0_zlo0);
assign pair_fastchain0_iir0_high0 = ((pair_fastchain0_iir0_b10 * pair_fastchain0_iir0_xhi0) + (pair_fastchain0_iir0_low0 >>> 5'd17));
assign pair_fastchain0_iir00 = (((~pair_fastchain0_iir0_zlo0[47]) & (~pair_fastchain0_iir0_b10[24])) & pair_fastchain0_iir0_low0[47]);
assign pair_fastchain0_iir01 = ((pair_fastchain0_iir0_zlo0[47] & pair_fastchain0_iir0_b10[24]) & (~pair_fastchain0_iir0_low0[47]));
assign pair_fastchain0_iir0_correction0 = (((pair_fastchain0_iir0_ztop0 + pair_fastchain0_iir0_zlo0[47]) + $signed({1'd0, pair_fastchain0_iir00})) - $signed({1'd0, pair_fastchain0_iir01}));
assign pair_fastchain0_iir0_top0 = (pair_fastchain0_iir0_high0[32:31] + pair_fastchain0_iir0_correction0);
assign pair_fastchain0_iir0_result0 = {pair_fastchain0_iir0_top0, pair_fastchain0_iir0_high0[30:0], pair_fastchain0_iir0_low0[16:0]};
assign pair_fastchain0_iir0_z0 = pair_fastchain0_iir0_result0;
assign pair_fastchain0_iir0_xlo1 = {1'd0, pair_fastchain0_iir0_x0[16:0]};
assign pair_fastchain0_iir0_xhi1 = pair_fastchain0_iir0_x0[24:17];
assign pair_fastchain0_iir0_zlo1 = pair_fastchain0_iir0_zr1[47:0];
assign pair_fastchain0_iir0_ztop1 = pair_fastchain0_iir0_zr1[49:48];
assign pair_fastchain0_iir0_low1 = ((pair_fastchain0_iir0_b00 * pair_fastchain0_iir0_xlo1) + pair_fastchain0_iir0_zlo1);
assign pair_fastchain0_iir0_high1 = ((pair_fastchain0_iir0_b00 * pair_fastchain0_iir0_xhi1) + (pair_fastchain0_iir0_low1 >>> 5'd17));
assign pair_fastchain0_iir02 = (((~pair_fastchain0_iir0_zlo1[47]) & (~pair_fastchain0_iir0_b00[24])) & pair_fastchain0_iir0_low1[47]);
assign pair_fastchain0_iir03 = ((pair_fastchain0_iir0_zlo1[47] & pair_fastchain0_iir0_b00[24]) & (~pair_fastchain0_iir0_low1[47]));
assign pair_fastchain0_iir0_correction1 = (((pair_fastchain0_iir0_ztop1 + pair_fastchain0_iir0_zlo1[47]) + $signed({1'd0, pair_fastchain0_iir02})) - $signed({1'd0, pair_fastchain0_iir03}));
assign pair_fastchain0_iir0_top1 = (pair_fastchain0_iir0_high1[32:31] + pair_fastchain0_iir0_correction1);
assign pair_fastchain0_iir0_result1 = {pair_fastchain0_iir0_top1, pair_fastchain0_iir0_high1[30:0], pair_fastchain0_iir0_low1[16:0]};
assign pair_fastchain0_iir0_z1 = pair_fastchain0_iir0_result1;
assign pair_fastchain0_iir0_xlo2 = {1'd0, pair_fastchain0_iir0_y1[16:0]};
assign pair_fastchain0_iir0_xhi2 = pair_fastchain0_iir0_y1[24:17];
assign pair_fastchain0_iir0_zlo2 = pair_fastchain0_iir0_zr2[47:0];
assign pair_fastchain0_iir0_ztop2 = pair_fastchain0_iir0_zr2[49:48];
assign pair_fastchain0_iir0_low2 = ((pair_fastchain0_iir0_a10 * pair_fastchain0_iir0_xlo2) + pair_fastchain0_iir0_zlo2);
assign pair_fastchain0_iir0_high2 = ((pair_fastchain0_iir0_a10 * pair_fastchain0_iir0_xhi2) + (pair_fastchain0_iir0_low2 >>> 5'd17));
assign pair_fastchain0_iir04 = (((~pair_fastchain0_iir0_zlo2[47]) & (~pair_fastchain0_iir0_a10[24])) & pair_fastchain0_iir0_low2[47]);
assign pair_fastchain0_iir05 = ((pair_fastchain0_iir0_zlo2[47] & pair_fastchain0_iir0_a10[24]) & (~pair_fastchain0_iir0_low2[47]));
assign pair_fastchain0_iir0_correction2 = (((pair_fastchain0_iir0_ztop2 + pair_fastchain0_iir0_zlo2[47]) + $signed({1'd0, pair_fastchain0_iir04})) - $signed({1'd0, pair_fastchain0_iir05}));
assign pair_fastchain0_iir0_top2 = (pair_fastchain0_iir0_high2[32:31] + pair_fastchain0_iir0_correction2);
assign pair_fastchain0_iir0_result2 = {pair_fastchain0_iir0_top2, pair_fastchain0_iir0_high2[30:0], pair_fastchain0_iir0_low2[16:0]};
assign pair_fastchain0_iir0_z2 = pair_fastchain0_iir0_result2;
assign pair_fastchain0_iir0_y_next0 = pair_fastchain0_iir0_z2;
assign pair_fastchain0_iir0_railed1 = (~((pair_fastchain0_iir0_y_next1[49:47] == $signed({1'd0, pair_fastchain0_iir0_y_pat1})) | (pair_fastchain0_iir0_y_next1[49:47] == $signed({1'd0, (~pair_fastchain0_iir0_y_pat1)}))));

// synthesis translate_off
reg dummy_d_3;
// synthesis translate_on
always @(*) begin
	pair_fastchain0_iir0_y_lim1 <= 25'sd0;
	if (pair_fastchain0_iir0_railed1) begin
		pair_fastchain0_iir0_y_lim1 <= pair_fastchain0_iir0_y2;
	end else begin
		pair_fastchain0_iir0_y_lim1 <= pair_fastchain0_iir0_y_next1[49:23];
	end
// synthesis translate_off
	dummy_d_3 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain0_iir0_xlo3 = {1'd0, pair_fastchain0_iir0_x1[16:0]};
assign pair_fastchain0_iir0_xhi3 = pair_fastchain0_iir0_x1[24:17];
assign pair_fastchain0_iir0_zlo3 = pair_fastchain0_iir0_zr3[47:0];
assign pair_fastchain0_iir0_ztop3 = pair_fastchain0_iir0_zr3[49:48];
assign pair_fastchain0_iir0_low3 = ((pair_fastchain0_iir0_b2 * pair_fastchain0_iir0_xlo3) + pair_fastchain0_iir0_zlo3);
assign pair_fastchain0_iir0_high3 = ((pair_fastchain0_iir0_b2 * pair_fastchain0_iir0_xhi3) + (pair_fastchain0_iir0_low3 >>> 5'd17));
assign pair_fastchain0_iir06 = (((~pair_fastchain0_iir0_zlo3[47]) & (~pair_fastchain0_iir0_b2[24])) & pair_fastchain0_iir0_low3[47]);
assign pair_fastchain0_iir07 = ((pair_fastchain0_iir0_zlo3[47] & pair_fastchain0_iir0_b2[24]) & (~pair_fastchain0_iir0_low3[47]));
assign pair_fastchain0_iir0_correction3 = (((pair_fastchain0_iir0_ztop3 + pair_fastchain0_iir0_zlo3[47]) + $signed({1'd0, pair_fastchain0_iir06})) - $signed({1'd0, pair_fastchain0_iir07}));
assign pair_fastchain0_iir0_top3 = (pair_fastchain0_iir0_high3[32:31] + pair_fastchain0_iir0_correction3);
assign pair_fastchain0_iir0_result3 = {pair_fastchain0_iir0_top3, pair_fastchain0_iir0_high3[30:0], pair_fastchain0_iir0_low3[16:0]};
assign pair_fastchain0_iir0_z3 = pair_fastchain0_iir0_result3;
assign pair_fastchain0_iir0_xlo4 = {1'd0, pair_fastchain0_iir0_x1[16:0]};
assign pair_fastchain0_iir0_xhi4 = pair_fastchain0_iir0_x1[24:17];
assign pair_fastchain0_iir0_zlo4 = pair_fastchain0_iir0_zr4[47:0];
assign pair_fastchain0_iir0_ztop4 = pair_fastchain0_iir0_zr4[49:48];
assign pair_fastchain0_iir0_low4 = ((pair_fastchain0_iir0_b11 * pair_fastchain0_iir0_xlo4) + pair_fastchain0_iir0_zlo4);
assign pair_fastchain0_iir0_high4 = ((pair_fastchain0_iir0_b11 * pair_fastchain0_iir0_xhi4) + (pair_fastchain0_iir0_low4 >>> 5'd17));
assign pair_fastchain0_iir08 = (((~pair_fastchain0_iir0_zlo4[47]) & (~pair_fastchain0_iir0_b11[24])) & pair_fastchain0_iir0_low4[47]);
assign pair_fastchain0_iir09 = ((pair_fastchain0_iir0_zlo4[47] & pair_fastchain0_iir0_b11[24]) & (~pair_fastchain0_iir0_low4[47]));
assign pair_fastchain0_iir0_correction4 = (((pair_fastchain0_iir0_ztop4 + pair_fastchain0_iir0_zlo4[47]) + $signed({1'd0, pair_fastchain0_iir08})) - $signed({1'd0, pair_fastchain0_iir09}));
assign pair_fastchain0_iir0_top4 = (pair_fastchain0_iir0_high4[32:31] + pair_fastchain0_iir0_correction4);
assign pair_fastchain0_iir0_result4 = {pair_fastchain0_iir0_top4, pair_fastchain0_iir0_high4[30:0], pair_fastchain0_iir0_low4[16:0]};
assign pair_fastchain0_iir0_z4 = pair_fastchain0_iir0_result4;
assign pair_fastchain0_iir0_xlo5 = {1'd0, pair_fastchain0_iir0_x1[16:0]};
assign pair_fastchain0_iir0_xhi5 = pair_fastchain0_iir0_x1[24:17];
assign pair_fastchain0_iir0_zlo5 = pair_fastchain0_iir0_zr5[47:0];
assign pair_fastchain0_iir0_ztop5 = pair_fastchain0_iir0_zr5[49:48];
assign pair_fastchain0_iir0_low5 = ((pair_fastchain0_iir0_b01 * pair_fastchain0_iir0_xlo5) + pair_fastchain0_iir0_zlo5);
assign pair_fastchain0_iir0_high5 = ((pair_fastchain0_iir0_b01 * pair_fastchain0_iir0_xhi5) + (pair_fastchain0_iir0_low5 >>> 5'd17));
assign pair_fastchain0_iir010 = (((~pair_fastchain0_iir0_zlo5[47]) & (~pair_fastchain0_iir0_b01[24])) & pair_fastchain0_iir0_low5[47]);
assign pair_fastchain0_iir011 = ((pair_fastchain0_iir0_zlo5[47] & pair_fastchain0_iir0_b01[24]) & (~pair_fastchain0_iir0_low5[47]));
assign pair_fastchain0_iir0_correction5 = (((pair_fastchain0_iir0_ztop5 + pair_fastchain0_iir0_zlo5[47]) + $signed({1'd0, pair_fastchain0_iir010})) - $signed({1'd0, pair_fastchain0_iir011}));
assign pair_fastchain0_iir0_top5 = (pair_fastchain0_iir0_high5[32:31] + pair_fastchain0_iir0_correction5);
assign pair_fastchain0_iir0_result5 = {pair_fastchain0_iir0_top5, pair_fastchain0_iir0_high5[30:0], pair_fastchain0_iir0_low5[16:0]};
assign pair_fastchain0_iir0_z5 = pair_fastchain0_iir0_result5;
assign pair_fastchain0_iir0_xlo6 = {1'd0, pair_fastchain0_iir0_y3[16:0]};
assign pair_fastchain0_iir0_xhi6 = pair_fastchain0_iir0_y3[24:17];
assign pair_fastchain0_iir0_zlo6 = pair_fastchain0_iir0_zr6[47:0];
assign pair_fastchain0_iir0_ztop6 = pair_fastchain0_iir0_zr6[49:48];
assign pair_fastchain0_iir0_low6 = ((pair_fastchain0_iir0_a2 * pair_fastchain0_iir0_xlo6) + pair_fastchain0_iir0_zlo6);
assign pair_fastchain0_iir0_high6 = ((pair_fastchain0_iir0_a2 * pair_fastchain0_iir0_xhi6) + (pair_fastchain0_iir0_low6 >>> 5'd17));
assign pair_fastchain0_iir012 = (((~pair_fastchain0_iir0_zlo6[47]) & (~pair_fastchain0_iir0_a2[24])) & pair_fastchain0_iir0_low6[47]);
assign pair_fastchain0_iir013 = ((pair_fastchain0_iir0_zlo6[47] & pair_fastchain0_iir0_a2[24]) & (~pair_fastchain0_iir0_low6[47]));
assign pair_fastchain0_iir0_correction6 = (((pair_fastchain0_iir0_ztop6 + pair_fastchain0_iir0_zlo6[47]) + $signed({1'd0, pair_fastchain0_iir012})) - $signed({1'd0, pair_fastchain0_iir013}));
assign pair_fastchain0_iir0_top6 = (pair_fastchain0_iir0_high6[32:31] + pair_fastchain0_iir0_correction6);
assign pair_fastchain0_iir0_result6 = {pair_fastchain0_iir0_top6, pair_fastchain0_iir0_high6[30:0], pair_fastchain0_iir0_low6[16:0]};
assign pair_fastchain0_iir0_z6 = pair_fastchain0_iir0_result6;
assign pair_fastchain0_iir0_xlo7 = {1'd0, pair_fastchain0_iir0_y3[16:0]};
assign pair_fastchain0_iir0_xhi7 = pair_fastchain0_iir0_y3[24:17];
assign pair_fastchain0_iir0_zlo7 = pair_fastchain0_iir0_zr7[47:0];
assign pair_fastchain0_iir0_ztop7 = pair_fastchain0_iir0_zr7[49:48];
assign pair_fastchain0_iir0_low7 = ((pair_fastchain0_iir0_a11 * pair_fastchain0_iir0_xlo7) + pair_fastchain0_iir0_zlo7);
assign pair_fastchain0_iir0_high7 = ((pair_fastchain0_iir0_a11 * pair_fastchain0_iir0_xhi7) + (pair_fastchain0_iir0_low7 >>> 5'd17));
assign pair_fastchain0_iir014 = (((~pair_fastchain0_iir0_zlo7[47]) & (~pair_fastchain0_iir0_a11[24])) & pair_fastchain0_iir0_low7[47]);
assign pair_fastchain0_iir015 = ((pair_fastchain0_iir0_zlo7[47] & pair_fastchain0_iir0_a11[24]) & (~pair_fastchain0_iir0_low7[47]));
assign pair_fastchain0_iir0_correction7 = (((pair_fastchain0_iir0_ztop7 + pair_fastchain0_iir0_zlo7[47]) + $signed({1'd0, pair_fastchain0_iir014})) - $signed({1'd0, pair_fastchain0_iir015}));
assign pair_fastchain0_iir0_top7 = (pair_fastchain0_iir0_high7[32:31] + pair_fastchain0_iir0_correction7);
assign pair_fastchain0_iir0_result7 = {pair_fastchain0_iir0_top7, pair_fastchain0_iir0_high7[30:0], pair_fastchain0_iir0_low7[16:0]};
assign pair_fastchain0_iir0_z7 = pair_fastchain0_iir0_result7;
assign pair_fastchain0_iir0_y_next1 = pair_fastchain0_iir0_z7;
assign pair_fastchain0_limitcsr0_limit_x1 = pair_fastchain0_limitcsr0_x1;

// synthesis translate_off
reg dummy_d_4;
// synthesis translate_on
always @(*) begin
	pair_fastchain0_limitcsr0_limit_y1 <= 28'sd0;
	pair_fastchain0_limitcsr0_limit_railed1 <= 1'd0;
	if ((pair_fastchain0_limitcsr0_limit_x1 >= pair_fastchain0_limitcsr0_limit_max1)) begin
		pair_fastchain0_limitcsr0_limit_y1 <= pair_fastchain0_limitcsr0_limit_max1;
		pair_fastchain0_limitcsr0_limit_railed1 <= 1'd1;
	end else begin
		if ((pair_fastchain0_limitcsr0_limit_x1 <= pair_fastchain0_limitcsr0_limit_min1)) begin
			pair_fastchain0_limitcsr0_limit_y1 <= pair_fastchain0_limitcsr0_limit_min1;
			pair_fastchain0_limitcsr0_limit_railed1 <= 1'd1;
		end else begin
			pair_fastchain0_limitcsr0_limit_y1 <= pair_fastchain0_limitcsr0_limit_x1;
			pair_fastchain0_limitcsr0_limit_railed1 <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_4 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain0_limitcsr1_limit_x0 = pair_fastchain0_limitcsr1_x0;

// synthesis translate_off
reg dummy_d_5;
// synthesis translate_on
always @(*) begin
	pair_fastchain0_limitcsr1_limit_y0 <= 26'sd0;
	pair_fastchain0_limitcsr1_limit_railed0 <= 1'd0;
	if ((pair_fastchain0_limitcsr1_limit_x0 >= pair_fastchain0_limitcsr1_limit_max0)) begin
		pair_fastchain0_limitcsr1_limit_y0 <= pair_fastchain0_limitcsr1_limit_max0;
		pair_fastchain0_limitcsr1_limit_railed0 <= 1'd1;
	end else begin
		if ((pair_fastchain0_limitcsr1_limit_x0 <= pair_fastchain0_limitcsr1_limit_min0)) begin
			pair_fastchain0_limitcsr1_limit_y0 <= pair_fastchain0_limitcsr1_limit_min0;
			pair_fastchain0_limitcsr1_limit_railed0 <= 1'd1;
		end else begin
			pair_fastchain0_limitcsr1_limit_y0 <= pair_fastchain0_limitcsr1_limit_x0;
			pair_fastchain0_limitcsr1_limit_railed0 <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_5 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain0_iir1_railed0 = (~((pair_fastchain0_iir1_y_next0[49:47] == $signed({1'd0, pair_fastchain0_iir1_y_pat0})) | (pair_fastchain0_iir1_y_next0[49:47] == $signed({1'd0, (~pair_fastchain0_iir1_y_pat0)}))));

// synthesis translate_off
reg dummy_d_6;
// synthesis translate_on
always @(*) begin
	pair_fastchain0_iir1_y_lim0 <= 25'sd0;
	if (pair_fastchain0_iir1_railed0) begin
		pair_fastchain0_iir1_y_lim0 <= pair_fastchain0_iir1_y0;
	end else begin
		pair_fastchain0_iir1_y_lim0 <= pair_fastchain0_iir1_y_next0[49:23];
	end
// synthesis translate_off
	dummy_d_6 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain0_iir1_xlo0 = {1'd0, pair_fastchain0_iir1_x0[16:0]};
assign pair_fastchain0_iir1_xhi0 = pair_fastchain0_iir1_x0[24:17];
assign pair_fastchain0_iir1_zlo0 = pair_fastchain0_iir1_zr0[47:0];
assign pair_fastchain0_iir1_ztop0 = pair_fastchain0_iir1_zr0[49:48];
assign pair_fastchain0_iir1_low0 = ((pair_fastchain0_iir1_b10 * pair_fastchain0_iir1_xlo0) + pair_fastchain0_iir1_zlo0);
assign pair_fastchain0_iir1_high0 = ((pair_fastchain0_iir1_b10 * pair_fastchain0_iir1_xhi0) + (pair_fastchain0_iir1_low0 >>> 5'd17));
assign pair_fastchain0_iir10 = (((~pair_fastchain0_iir1_zlo0[47]) & (~pair_fastchain0_iir1_b10[24])) & pair_fastchain0_iir1_low0[47]);
assign pair_fastchain0_iir11 = ((pair_fastchain0_iir1_zlo0[47] & pair_fastchain0_iir1_b10[24]) & (~pair_fastchain0_iir1_low0[47]));
assign pair_fastchain0_iir1_correction0 = (((pair_fastchain0_iir1_ztop0 + pair_fastchain0_iir1_zlo0[47]) + $signed({1'd0, pair_fastchain0_iir10})) - $signed({1'd0, pair_fastchain0_iir11}));
assign pair_fastchain0_iir1_top0 = (pair_fastchain0_iir1_high0[32:31] + pair_fastchain0_iir1_correction0);
assign pair_fastchain0_iir1_result0 = {pair_fastchain0_iir1_top0, pair_fastchain0_iir1_high0[30:0], pair_fastchain0_iir1_low0[16:0]};
assign pair_fastchain0_iir1_z0 = pair_fastchain0_iir1_result0;
assign pair_fastchain0_iir1_xlo1 = {1'd0, pair_fastchain0_iir1_x0[16:0]};
assign pair_fastchain0_iir1_xhi1 = pair_fastchain0_iir1_x0[24:17];
assign pair_fastchain0_iir1_zlo1 = pair_fastchain0_iir1_zr1[47:0];
assign pair_fastchain0_iir1_ztop1 = pair_fastchain0_iir1_zr1[49:48];
assign pair_fastchain0_iir1_low1 = ((pair_fastchain0_iir1_b00 * pair_fastchain0_iir1_xlo1) + pair_fastchain0_iir1_zlo1);
assign pair_fastchain0_iir1_high1 = ((pair_fastchain0_iir1_b00 * pair_fastchain0_iir1_xhi1) + (pair_fastchain0_iir1_low1 >>> 5'd17));
assign pair_fastchain0_iir12 = (((~pair_fastchain0_iir1_zlo1[47]) & (~pair_fastchain0_iir1_b00[24])) & pair_fastchain0_iir1_low1[47]);
assign pair_fastchain0_iir13 = ((pair_fastchain0_iir1_zlo1[47] & pair_fastchain0_iir1_b00[24]) & (~pair_fastchain0_iir1_low1[47]));
assign pair_fastchain0_iir1_correction1 = (((pair_fastchain0_iir1_ztop1 + pair_fastchain0_iir1_zlo1[47]) + $signed({1'd0, pair_fastchain0_iir12})) - $signed({1'd0, pair_fastchain0_iir13}));
assign pair_fastchain0_iir1_top1 = (pair_fastchain0_iir1_high1[32:31] + pair_fastchain0_iir1_correction1);
assign pair_fastchain0_iir1_result1 = {pair_fastchain0_iir1_top1, pair_fastchain0_iir1_high1[30:0], pair_fastchain0_iir1_low1[16:0]};
assign pair_fastchain0_iir1_z1 = pair_fastchain0_iir1_result1;
assign pair_fastchain0_iir1_xlo2 = {1'd0, pair_fastchain0_iir1_y1[16:0]};
assign pair_fastchain0_iir1_xhi2 = pair_fastchain0_iir1_y1[24:17];
assign pair_fastchain0_iir1_zlo2 = pair_fastchain0_iir1_zr2[47:0];
assign pair_fastchain0_iir1_ztop2 = pair_fastchain0_iir1_zr2[49:48];
assign pair_fastchain0_iir1_low2 = ((pair_fastchain0_iir1_a10 * pair_fastchain0_iir1_xlo2) + pair_fastchain0_iir1_zlo2);
assign pair_fastchain0_iir1_high2 = ((pair_fastchain0_iir1_a10 * pair_fastchain0_iir1_xhi2) + (pair_fastchain0_iir1_low2 >>> 5'd17));
assign pair_fastchain0_iir14 = (((~pair_fastchain0_iir1_zlo2[47]) & (~pair_fastchain0_iir1_a10[24])) & pair_fastchain0_iir1_low2[47]);
assign pair_fastchain0_iir15 = ((pair_fastchain0_iir1_zlo2[47] & pair_fastchain0_iir1_a10[24]) & (~pair_fastchain0_iir1_low2[47]));
assign pair_fastchain0_iir1_correction2 = (((pair_fastchain0_iir1_ztop2 + pair_fastchain0_iir1_zlo2[47]) + $signed({1'd0, pair_fastchain0_iir14})) - $signed({1'd0, pair_fastchain0_iir15}));
assign pair_fastchain0_iir1_top2 = (pair_fastchain0_iir1_high2[32:31] + pair_fastchain0_iir1_correction2);
assign pair_fastchain0_iir1_result2 = {pair_fastchain0_iir1_top2, pair_fastchain0_iir1_high2[30:0], pair_fastchain0_iir1_low2[16:0]};
assign pair_fastchain0_iir1_z2 = pair_fastchain0_iir1_result2;
assign pair_fastchain0_iir1_y_next0 = pair_fastchain0_iir1_z2;
assign pair_fastchain0_iir1_railed1 = (~((pair_fastchain0_iir1_y_next1[49:47] == $signed({1'd0, pair_fastchain0_iir1_y_pat1})) | (pair_fastchain0_iir1_y_next1[49:47] == $signed({1'd0, (~pair_fastchain0_iir1_y_pat1)}))));

// synthesis translate_off
reg dummy_d_7;
// synthesis translate_on
always @(*) begin
	pair_fastchain0_iir1_y_lim1 <= 25'sd0;
	if (pair_fastchain0_iir1_railed1) begin
		pair_fastchain0_iir1_y_lim1 <= pair_fastchain0_iir1_y2;
	end else begin
		pair_fastchain0_iir1_y_lim1 <= pair_fastchain0_iir1_y_next1[49:23];
	end
// synthesis translate_off
	dummy_d_7 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain0_iir1_xlo3 = {1'd0, pair_fastchain0_iir1_x1[16:0]};
assign pair_fastchain0_iir1_xhi3 = pair_fastchain0_iir1_x1[24:17];
assign pair_fastchain0_iir1_zlo3 = pair_fastchain0_iir1_zr3[47:0];
assign pair_fastchain0_iir1_ztop3 = pair_fastchain0_iir1_zr3[49:48];
assign pair_fastchain0_iir1_low3 = ((pair_fastchain0_iir1_b2 * pair_fastchain0_iir1_xlo3) + pair_fastchain0_iir1_zlo3);
assign pair_fastchain0_iir1_high3 = ((pair_fastchain0_iir1_b2 * pair_fastchain0_iir1_xhi3) + (pair_fastchain0_iir1_low3 >>> 5'd17));
assign pair_fastchain0_iir16 = (((~pair_fastchain0_iir1_zlo3[47]) & (~pair_fastchain0_iir1_b2[24])) & pair_fastchain0_iir1_low3[47]);
assign pair_fastchain0_iir17 = ((pair_fastchain0_iir1_zlo3[47] & pair_fastchain0_iir1_b2[24]) & (~pair_fastchain0_iir1_low3[47]));
assign pair_fastchain0_iir1_correction3 = (((pair_fastchain0_iir1_ztop3 + pair_fastchain0_iir1_zlo3[47]) + $signed({1'd0, pair_fastchain0_iir16})) - $signed({1'd0, pair_fastchain0_iir17}));
assign pair_fastchain0_iir1_top3 = (pair_fastchain0_iir1_high3[32:31] + pair_fastchain0_iir1_correction3);
assign pair_fastchain0_iir1_result3 = {pair_fastchain0_iir1_top3, pair_fastchain0_iir1_high3[30:0], pair_fastchain0_iir1_low3[16:0]};
assign pair_fastchain0_iir1_z3 = pair_fastchain0_iir1_result3;
assign pair_fastchain0_iir1_xlo4 = {1'd0, pair_fastchain0_iir1_x1[16:0]};
assign pair_fastchain0_iir1_xhi4 = pair_fastchain0_iir1_x1[24:17];
assign pair_fastchain0_iir1_zlo4 = pair_fastchain0_iir1_zr4[47:0];
assign pair_fastchain0_iir1_ztop4 = pair_fastchain0_iir1_zr4[49:48];
assign pair_fastchain0_iir1_low4 = ((pair_fastchain0_iir1_b11 * pair_fastchain0_iir1_xlo4) + pair_fastchain0_iir1_zlo4);
assign pair_fastchain0_iir1_high4 = ((pair_fastchain0_iir1_b11 * pair_fastchain0_iir1_xhi4) + (pair_fastchain0_iir1_low4 >>> 5'd17));
assign pair_fastchain0_iir18 = (((~pair_fastchain0_iir1_zlo4[47]) & (~pair_fastchain0_iir1_b11[24])) & pair_fastchain0_iir1_low4[47]);
assign pair_fastchain0_iir19 = ((pair_fastchain0_iir1_zlo4[47] & pair_fastchain0_iir1_b11[24]) & (~pair_fastchain0_iir1_low4[47]));
assign pair_fastchain0_iir1_correction4 = (((pair_fastchain0_iir1_ztop4 + pair_fastchain0_iir1_zlo4[47]) + $signed({1'd0, pair_fastchain0_iir18})) - $signed({1'd0, pair_fastchain0_iir19}));
assign pair_fastchain0_iir1_top4 = (pair_fastchain0_iir1_high4[32:31] + pair_fastchain0_iir1_correction4);
assign pair_fastchain0_iir1_result4 = {pair_fastchain0_iir1_top4, pair_fastchain0_iir1_high4[30:0], pair_fastchain0_iir1_low4[16:0]};
assign pair_fastchain0_iir1_z4 = pair_fastchain0_iir1_result4;
assign pair_fastchain0_iir1_xlo5 = {1'd0, pair_fastchain0_iir1_x1[16:0]};
assign pair_fastchain0_iir1_xhi5 = pair_fastchain0_iir1_x1[24:17];
assign pair_fastchain0_iir1_zlo5 = pair_fastchain0_iir1_zr5[47:0];
assign pair_fastchain0_iir1_ztop5 = pair_fastchain0_iir1_zr5[49:48];
assign pair_fastchain0_iir1_low5 = ((pair_fastchain0_iir1_b01 * pair_fastchain0_iir1_xlo5) + pair_fastchain0_iir1_zlo5);
assign pair_fastchain0_iir1_high5 = ((pair_fastchain0_iir1_b01 * pair_fastchain0_iir1_xhi5) + (pair_fastchain0_iir1_low5 >>> 5'd17));
assign pair_fastchain0_iir110 = (((~pair_fastchain0_iir1_zlo5[47]) & (~pair_fastchain0_iir1_b01[24])) & pair_fastchain0_iir1_low5[47]);
assign pair_fastchain0_iir111 = ((pair_fastchain0_iir1_zlo5[47] & pair_fastchain0_iir1_b01[24]) & (~pair_fastchain0_iir1_low5[47]));
assign pair_fastchain0_iir1_correction5 = (((pair_fastchain0_iir1_ztop5 + pair_fastchain0_iir1_zlo5[47]) + $signed({1'd0, pair_fastchain0_iir110})) - $signed({1'd0, pair_fastchain0_iir111}));
assign pair_fastchain0_iir1_top5 = (pair_fastchain0_iir1_high5[32:31] + pair_fastchain0_iir1_correction5);
assign pair_fastchain0_iir1_result5 = {pair_fastchain0_iir1_top5, pair_fastchain0_iir1_high5[30:0], pair_fastchain0_iir1_low5[16:0]};
assign pair_fastchain0_iir1_z5 = pair_fastchain0_iir1_result5;
assign pair_fastchain0_iir1_xlo6 = {1'd0, pair_fastchain0_iir1_y3[16:0]};
assign pair_fastchain0_iir1_xhi6 = pair_fastchain0_iir1_y3[24:17];
assign pair_fastchain0_iir1_zlo6 = pair_fastchain0_iir1_zr6[47:0];
assign pair_fastchain0_iir1_ztop6 = pair_fastchain0_iir1_zr6[49:48];
assign pair_fastchain0_iir1_low6 = ((pair_fastchain0_iir1_a2 * pair_fastchain0_iir1_xlo6) + pair_fastchain0_iir1_zlo6);
assign pair_fastchain0_iir1_high6 = ((pair_fastchain0_iir1_a2 * pair_fastchain0_iir1_xhi6) + (pair_fastchain0_iir1_low6 >>> 5'd17));
assign pair_fastchain0_iir112 = (((~pair_fastchain0_iir1_zlo6[47]) & (~pair_fastchain0_iir1_a2[24])) & pair_fastchain0_iir1_low6[47]);
assign pair_fastchain0_iir113 = ((pair_fastchain0_iir1_zlo6[47] & pair_fastchain0_iir1_a2[24]) & (~pair_fastchain0_iir1_low6[47]));
assign pair_fastchain0_iir1_correction6 = (((pair_fastchain0_iir1_ztop6 + pair_fastchain0_iir1_zlo6[47]) + $signed({1'd0, pair_fastchain0_iir112})) - $signed({1'd0, pair_fastchain0_iir113}));
assign pair_fastchain0_iir1_top6 = (pair_fastchain0_iir1_high6[32:31] + pair_fastchain0_iir1_correction6);
assign pair_fastchain0_iir1_result6 = {pair_fastchain0_iir1_top6, pair_fastchain0_iir1_high6[30:0], pair_fastchain0_iir1_low6[16:0]};
assign pair_fastchain0_iir1_z6 = pair_fastchain0_iir1_result6;
assign pair_fastchain0_iir1_xlo7 = {1'd0, pair_fastchain0_iir1_y3[16:0]};
assign pair_fastchain0_iir1_xhi7 = pair_fastchain0_iir1_y3[24:17];
assign pair_fastchain0_iir1_zlo7 = pair_fastchain0_iir1_zr7[47:0];
assign pair_fastchain0_iir1_ztop7 = pair_fastchain0_iir1_zr7[49:48];
assign pair_fastchain0_iir1_low7 = ((pair_fastchain0_iir1_a11 * pair_fastchain0_iir1_xlo7) + pair_fastchain0_iir1_zlo7);
assign pair_fastchain0_iir1_high7 = ((pair_fastchain0_iir1_a11 * pair_fastchain0_iir1_xhi7) + (pair_fastchain0_iir1_low7 >>> 5'd17));
assign pair_fastchain0_iir114 = (((~pair_fastchain0_iir1_zlo7[47]) & (~pair_fastchain0_iir1_a11[24])) & pair_fastchain0_iir1_low7[47]);
assign pair_fastchain0_iir115 = ((pair_fastchain0_iir1_zlo7[47] & pair_fastchain0_iir1_a11[24]) & (~pair_fastchain0_iir1_low7[47]));
assign pair_fastchain0_iir1_correction7 = (((pair_fastchain0_iir1_ztop7 + pair_fastchain0_iir1_zlo7[47]) + $signed({1'd0, pair_fastchain0_iir114})) - $signed({1'd0, pair_fastchain0_iir115}));
assign pair_fastchain0_iir1_top7 = (pair_fastchain0_iir1_high7[32:31] + pair_fastchain0_iir1_correction7);
assign pair_fastchain0_iir1_result7 = {pair_fastchain0_iir1_top7, pair_fastchain0_iir1_high7[30:0], pair_fastchain0_iir1_low7[16:0]};
assign pair_fastchain0_iir1_z7 = pair_fastchain0_iir1_result7;
assign pair_fastchain0_iir1_y_next1 = pair_fastchain0_iir1_z7;
assign pair_fastchain0_limitcsr1_limit_x1 = pair_fastchain0_limitcsr1_x1;

// synthesis translate_off
reg dummy_d_8;
// synthesis translate_on
always @(*) begin
	pair_fastchain0_limitcsr1_limit_y1 <= 28'sd0;
	pair_fastchain0_limitcsr1_limit_railed1 <= 1'd0;
	if ((pair_fastchain0_limitcsr1_limit_x1 >= pair_fastchain0_limitcsr1_limit_max1)) begin
		pair_fastchain0_limitcsr1_limit_y1 <= pair_fastchain0_limitcsr1_limit_max1;
		pair_fastchain0_limitcsr1_limit_railed1 <= 1'd1;
	end else begin
		if ((pair_fastchain0_limitcsr1_limit_x1 <= pair_fastchain0_limitcsr1_limit_min1)) begin
			pair_fastchain0_limitcsr1_limit_y1 <= pair_fastchain0_limitcsr1_limit_min1;
			pair_fastchain0_limitcsr1_limit_railed1 <= 1'd1;
		end else begin
			pair_fastchain0_limitcsr1_limit_y1 <= pair_fastchain0_limitcsr1_limit_x1;
			pair_fastchain0_limitcsr1_limit_railed1 <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_8 <= dummy_s;
// synthesis translate_on
end
assign pair_csrbank0_sel = (pair_csrbank0_bus_adr[13:9] == 1'd0);
assign pair_csrbank0_y_tap0_r = pair_csrbank0_bus_dat_w[1:0];
assign pair_csrbank0_y_tap0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 1'd0));
assign pair_csrbank0_invert0_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_invert0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 1'd1));
assign pair_csrbank0_demod_delay3_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_demod_delay3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 2'd2));
assign pair_csrbank0_demod_delay2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_demod_delay2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 2'd3));
assign pair_csrbank0_demod_delay1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_demod_delay1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 3'd4));
assign pair_csrbank0_demod_delay0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_demod_delay0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 3'd5));
assign pair_csrbank0_demod_multiplier0_r = pair_csrbank0_bus_dat_w[3:0];
assign pair_csrbank0_demod_multiplier0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 3'd6));
assign pair_csrbank0_x_limit_1_min3_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_x_limit_1_min3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 3'd7));
assign pair_csrbank0_x_limit_1_min2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_1_min2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 4'd8));
assign pair_csrbank0_x_limit_1_min1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_1_min1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 4'd9));
assign pair_csrbank0_x_limit_1_min0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_1_min0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 4'd10));
assign pair_csrbank0_x_limit_1_max3_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_x_limit_1_max3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 4'd11));
assign pair_csrbank0_x_limit_1_max2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_1_max2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 4'd12));
assign pair_csrbank0_x_limit_1_max1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_1_max1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 4'd13));
assign pair_csrbank0_x_limit_1_max0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_1_max0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 4'd14));
assign pair_csrbank0_iir_c_1_z03_r = pair_csrbank0_bus_dat_w[2:0];
assign pair_csrbank0_iir_c_1_z03_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 4'd15));
assign pair_csrbank0_iir_c_1_z02_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_z02_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd16));
assign pair_csrbank0_iir_c_1_z01_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_z01_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd17));
assign pair_csrbank0_iir_c_1_z00_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_z00_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd18));
assign pair_csrbank0_iir_c_1_a13_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_c_1_a13_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd19));
assign pair_csrbank0_iir_c_1_a12_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_a12_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd20));
assign pair_csrbank0_iir_c_1_a11_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_a11_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd21));
assign pair_csrbank0_iir_c_1_a10_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_a10_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd22));
assign pair_csrbank0_iir_c_1_b03_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_c_1_b03_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd23));
assign pair_csrbank0_iir_c_1_b02_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_b02_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd24));
assign pair_csrbank0_iir_c_1_b01_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_b01_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd25));
assign pair_csrbank0_iir_c_1_b00_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_b00_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd26));
assign pair_csrbank0_iir_c_1_b13_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_c_1_b13_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd27));
assign pair_csrbank0_iir_c_1_b12_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_b12_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd28));
assign pair_csrbank0_iir_c_1_b11_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_b11_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd29));
assign pair_csrbank0_iir_c_1_b10_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_1_b10_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd30));
assign pair_csrbank0_iir_d_1_z03_r = pair_csrbank0_bus_dat_w[2:0];
assign pair_csrbank0_iir_d_1_z03_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 5'd31));
assign pair_csrbank0_iir_d_1_z02_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_z02_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd32));
assign pair_csrbank0_iir_d_1_z01_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_z01_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd33));
assign pair_csrbank0_iir_d_1_z00_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_z00_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd34));
assign pair_csrbank0_iir_d_1_a13_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_1_a13_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd35));
assign pair_csrbank0_iir_d_1_a12_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_a12_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd36));
assign pair_csrbank0_iir_d_1_a11_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_a11_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd37));
assign pair_csrbank0_iir_d_1_a10_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_a10_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd38));
assign pair_csrbank0_iir_d_1_a23_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_1_a23_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd39));
assign pair_csrbank0_iir_d_1_a22_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_a22_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd40));
assign pair_csrbank0_iir_d_1_a21_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_a21_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd41));
assign pair_csrbank0_iir_d_1_a20_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_a20_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd42));
assign pair_csrbank0_iir_d_1_b03_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_1_b03_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd43));
assign pair_csrbank0_iir_d_1_b02_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_b02_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd44));
assign pair_csrbank0_iir_d_1_b01_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_b01_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd45));
assign pair_csrbank0_iir_d_1_b00_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_b00_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd46));
assign pair_csrbank0_iir_d_1_b13_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_1_b13_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd47));
assign pair_csrbank0_iir_d_1_b12_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_b12_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd48));
assign pair_csrbank0_iir_d_1_b11_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_b11_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd49));
assign pair_csrbank0_iir_d_1_b10_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_b10_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd50));
assign pair_csrbank0_iir_d_1_b23_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_1_b23_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd51));
assign pair_csrbank0_iir_d_1_b22_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_b22_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd52));
assign pair_csrbank0_iir_d_1_b21_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_b21_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd53));
assign pair_csrbank0_iir_d_1_b20_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_1_b20_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd54));
assign pair_csrbank0_y_limit_1_min3_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_y_limit_1_min3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd55));
assign pair_csrbank0_y_limit_1_min2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_1_min2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd56));
assign pair_csrbank0_y_limit_1_min1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_1_min1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd57));
assign pair_csrbank0_y_limit_1_min0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_1_min0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd58));
assign pair_csrbank0_y_limit_1_max3_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_y_limit_1_max3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd59));
assign pair_csrbank0_y_limit_1_max2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_1_max2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd60));
assign pair_csrbank0_y_limit_1_max1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_1_max1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd61));
assign pair_csrbank0_y_limit_1_max0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_1_max0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd62));
assign pair_csrbank0_x_limit_2_min3_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_x_limit_2_min3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 6'd63));
assign pair_csrbank0_x_limit_2_min2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_2_min2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd64));
assign pair_csrbank0_x_limit_2_min1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_2_min1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd65));
assign pair_csrbank0_x_limit_2_min0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_2_min0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd66));
assign pair_csrbank0_x_limit_2_max3_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_x_limit_2_max3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd67));
assign pair_csrbank0_x_limit_2_max2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_2_max2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd68));
assign pair_csrbank0_x_limit_2_max1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_2_max1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd69));
assign pair_csrbank0_x_limit_2_max0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_x_limit_2_max0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd70));
assign pair_csrbank0_iir_c_2_z03_r = pair_csrbank0_bus_dat_w[2:0];
assign pair_csrbank0_iir_c_2_z03_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd71));
assign pair_csrbank0_iir_c_2_z02_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_z02_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd72));
assign pair_csrbank0_iir_c_2_z01_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_z01_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd73));
assign pair_csrbank0_iir_c_2_z00_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_z00_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd74));
assign pair_csrbank0_iir_c_2_a13_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_c_2_a13_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd75));
assign pair_csrbank0_iir_c_2_a12_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_a12_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd76));
assign pair_csrbank0_iir_c_2_a11_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_a11_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd77));
assign pair_csrbank0_iir_c_2_a10_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_a10_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd78));
assign pair_csrbank0_iir_c_2_b03_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_c_2_b03_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd79));
assign pair_csrbank0_iir_c_2_b02_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_b02_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd80));
assign pair_csrbank0_iir_c_2_b01_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_b01_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd81));
assign pair_csrbank0_iir_c_2_b00_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_b00_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd82));
assign pair_csrbank0_iir_c_2_b13_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_c_2_b13_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd83));
assign pair_csrbank0_iir_c_2_b12_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_b12_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd84));
assign pair_csrbank0_iir_c_2_b11_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_b11_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd85));
assign pair_csrbank0_iir_c_2_b10_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_c_2_b10_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd86));
assign pair_csrbank0_iir_d_2_z03_r = pair_csrbank0_bus_dat_w[2:0];
assign pair_csrbank0_iir_d_2_z03_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd87));
assign pair_csrbank0_iir_d_2_z02_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_z02_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd88));
assign pair_csrbank0_iir_d_2_z01_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_z01_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd89));
assign pair_csrbank0_iir_d_2_z00_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_z00_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd90));
assign pair_csrbank0_iir_d_2_a13_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_2_a13_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd91));
assign pair_csrbank0_iir_d_2_a12_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_a12_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd92));
assign pair_csrbank0_iir_d_2_a11_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_a11_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd93));
assign pair_csrbank0_iir_d_2_a10_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_a10_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd94));
assign pair_csrbank0_iir_d_2_a23_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_2_a23_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd95));
assign pair_csrbank0_iir_d_2_a22_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_a22_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd96));
assign pair_csrbank0_iir_d_2_a21_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_a21_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd97));
assign pair_csrbank0_iir_d_2_a20_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_a20_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd98));
assign pair_csrbank0_iir_d_2_b03_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_2_b03_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd99));
assign pair_csrbank0_iir_d_2_b02_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_b02_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd100));
assign pair_csrbank0_iir_d_2_b01_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_b01_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd101));
assign pair_csrbank0_iir_d_2_b00_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_b00_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd102));
assign pair_csrbank0_iir_d_2_b13_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_2_b13_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd103));
assign pair_csrbank0_iir_d_2_b12_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_b12_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd104));
assign pair_csrbank0_iir_d_2_b11_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_b11_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd105));
assign pair_csrbank0_iir_d_2_b10_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_b10_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd106));
assign pair_csrbank0_iir_d_2_b23_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_iir_d_2_b23_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd107));
assign pair_csrbank0_iir_d_2_b22_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_b22_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd108));
assign pair_csrbank0_iir_d_2_b21_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_b21_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd109));
assign pair_csrbank0_iir_d_2_b20_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_iir_d_2_b20_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd110));
assign pair_csrbank0_y_limit_2_min3_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_y_limit_2_min3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd111));
assign pair_csrbank0_y_limit_2_min2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_2_min2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd112));
assign pair_csrbank0_y_limit_2_min1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_2_min1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd113));
assign pair_csrbank0_y_limit_2_min0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_2_min0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd114));
assign pair_csrbank0_y_limit_2_max3_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_y_limit_2_max3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd115));
assign pair_csrbank0_y_limit_2_max2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_2_max2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd116));
assign pair_csrbank0_y_limit_2_max1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_2_max1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd117));
assign pair_csrbank0_y_limit_2_max0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_y_limit_2_max0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[6:0] == 7'd118));
assign pair_fastchain0_y_tap_storage = pair_fastchain0_y_tap_storage_full[1:0];
assign pair_csrbank0_y_tap0_w = pair_fastchain0_y_tap_storage_full[1:0];
assign pair_fastchain0_invert_storage = pair_fastchain0_invert_storage_full;
assign pair_csrbank0_invert0_w = pair_fastchain0_invert_storage_full;
assign pair_fastchain0_delay_storage = pair_fastchain0_delay_storage_full[31:0];
assign pair_csrbank0_demod_delay3_w = pair_fastchain0_delay_storage_full[31:24];
assign pair_csrbank0_demod_delay2_w = pair_fastchain0_delay_storage_full[23:16];
assign pair_csrbank0_demod_delay1_w = pair_fastchain0_delay_storage_full[15:8];
assign pair_csrbank0_demod_delay0_w = pair_fastchain0_delay_storage_full[7:0];
assign pair_fastchain0_multiplier_storage = pair_fastchain0_multiplier_storage_full[3:0];
assign pair_csrbank0_demod_multiplier0_w = pair_fastchain0_multiplier_storage_full[3:0];
assign pair_fastchain0_limitcsr0_min_storage0 = pair_fastchain0_limitcsr0_min_storage_full0[24:0];
assign pair_csrbank0_x_limit_1_min3_w = pair_fastchain0_limitcsr0_min_storage_full0[24];
assign pair_csrbank0_x_limit_1_min2_w = pair_fastchain0_limitcsr0_min_storage_full0[23:16];
assign pair_csrbank0_x_limit_1_min1_w = pair_fastchain0_limitcsr0_min_storage_full0[15:8];
assign pair_csrbank0_x_limit_1_min0_w = pair_fastchain0_limitcsr0_min_storage_full0[7:0];
assign pair_fastchain0_limitcsr0_max_storage0 = pair_fastchain0_limitcsr0_max_storage_full0[24:0];
assign pair_csrbank0_x_limit_1_max3_w = pair_fastchain0_limitcsr0_max_storage_full0[24];
assign pair_csrbank0_x_limit_1_max2_w = pair_fastchain0_limitcsr0_max_storage_full0[23:16];
assign pair_csrbank0_x_limit_1_max1_w = pair_fastchain0_limitcsr0_max_storage_full0[15:8];
assign pair_csrbank0_x_limit_1_max0_w = pair_fastchain0_limitcsr0_max_storage_full0[7:0];
assign pair_fastchain0_iir0_storage0 = pair_fastchain0_iir0_storage_full0[26:0];
assign pair_csrbank0_iir_c_1_z03_w = pair_fastchain0_iir0_storage_full0[26:24];
assign pair_csrbank0_iir_c_1_z02_w = pair_fastchain0_iir0_storage_full0[23:16];
assign pair_csrbank0_iir_c_1_z01_w = pair_fastchain0_iir0_storage_full0[15:8];
assign pair_csrbank0_iir_c_1_z00_w = pair_fastchain0_iir0_storage_full0[7:0];
assign pair_fastchain0_iir0_csrstorage0_storage0 = pair_fastchain0_iir0_csrstorage0_storage_full0[24:0];
assign pair_csrbank0_iir_c_1_a13_w = pair_fastchain0_iir0_csrstorage0_storage_full0[24];
assign pair_csrbank0_iir_c_1_a12_w = pair_fastchain0_iir0_csrstorage0_storage_full0[23:16];
assign pair_csrbank0_iir_c_1_a11_w = pair_fastchain0_iir0_csrstorage0_storage_full0[15:8];
assign pair_csrbank0_iir_c_1_a10_w = pair_fastchain0_iir0_csrstorage0_storage_full0[7:0];
assign pair_fastchain0_iir0_csrstorage1_storage0 = pair_fastchain0_iir0_csrstorage1_storage_full0[24:0];
assign pair_csrbank0_iir_c_1_b03_w = pair_fastchain0_iir0_csrstorage1_storage_full0[24];
assign pair_csrbank0_iir_c_1_b02_w = pair_fastchain0_iir0_csrstorage1_storage_full0[23:16];
assign pair_csrbank0_iir_c_1_b01_w = pair_fastchain0_iir0_csrstorage1_storage_full0[15:8];
assign pair_csrbank0_iir_c_1_b00_w = pair_fastchain0_iir0_csrstorage1_storage_full0[7:0];
assign pair_fastchain0_iir0_csrstorage2_storage0 = pair_fastchain0_iir0_csrstorage2_storage_full0[24:0];
assign pair_csrbank0_iir_c_1_b13_w = pair_fastchain0_iir0_csrstorage2_storage_full0[24];
assign pair_csrbank0_iir_c_1_b12_w = pair_fastchain0_iir0_csrstorage2_storage_full0[23:16];
assign pair_csrbank0_iir_c_1_b11_w = pair_fastchain0_iir0_csrstorage2_storage_full0[15:8];
assign pair_csrbank0_iir_c_1_b10_w = pair_fastchain0_iir0_csrstorage2_storage_full0[7:0];
assign pair_fastchain0_iir0_storage1 = pair_fastchain0_iir0_storage_full1[26:0];
assign pair_csrbank0_iir_d_1_z03_w = pair_fastchain0_iir0_storage_full1[26:24];
assign pair_csrbank0_iir_d_1_z02_w = pair_fastchain0_iir0_storage_full1[23:16];
assign pair_csrbank0_iir_d_1_z01_w = pair_fastchain0_iir0_storage_full1[15:8];
assign pair_csrbank0_iir_d_1_z00_w = pair_fastchain0_iir0_storage_full1[7:0];
assign pair_fastchain0_iir0_csrstorage0_storage1 = pair_fastchain0_iir0_csrstorage0_storage_full1[24:0];
assign pair_csrbank0_iir_d_1_a13_w = pair_fastchain0_iir0_csrstorage0_storage_full1[24];
assign pair_csrbank0_iir_d_1_a12_w = pair_fastchain0_iir0_csrstorage0_storage_full1[23:16];
assign pair_csrbank0_iir_d_1_a11_w = pair_fastchain0_iir0_csrstorage0_storage_full1[15:8];
assign pair_csrbank0_iir_d_1_a10_w = pair_fastchain0_iir0_csrstorage0_storage_full1[7:0];
assign pair_fastchain0_iir0_csrstorage1_storage1 = pair_fastchain0_iir0_csrstorage1_storage_full1[24:0];
assign pair_csrbank0_iir_d_1_a23_w = pair_fastchain0_iir0_csrstorage1_storage_full1[24];
assign pair_csrbank0_iir_d_1_a22_w = pair_fastchain0_iir0_csrstorage1_storage_full1[23:16];
assign pair_csrbank0_iir_d_1_a21_w = pair_fastchain0_iir0_csrstorage1_storage_full1[15:8];
assign pair_csrbank0_iir_d_1_a20_w = pair_fastchain0_iir0_csrstorage1_storage_full1[7:0];
assign pair_fastchain0_iir0_csrstorage2_storage1 = pair_fastchain0_iir0_csrstorage2_storage_full1[24:0];
assign pair_csrbank0_iir_d_1_b03_w = pair_fastchain0_iir0_csrstorage2_storage_full1[24];
assign pair_csrbank0_iir_d_1_b02_w = pair_fastchain0_iir0_csrstorage2_storage_full1[23:16];
assign pair_csrbank0_iir_d_1_b01_w = pair_fastchain0_iir0_csrstorage2_storage_full1[15:8];
assign pair_csrbank0_iir_d_1_b00_w = pair_fastchain0_iir0_csrstorage2_storage_full1[7:0];
assign pair_fastchain0_iir0_csrstorage3_storage = pair_fastchain0_iir0_csrstorage3_storage_full[24:0];
assign pair_csrbank0_iir_d_1_b13_w = pair_fastchain0_iir0_csrstorage3_storage_full[24];
assign pair_csrbank0_iir_d_1_b12_w = pair_fastchain0_iir0_csrstorage3_storage_full[23:16];
assign pair_csrbank0_iir_d_1_b11_w = pair_fastchain0_iir0_csrstorage3_storage_full[15:8];
assign pair_csrbank0_iir_d_1_b10_w = pair_fastchain0_iir0_csrstorage3_storage_full[7:0];
assign pair_fastchain0_iir0_csrstorage4_storage = pair_fastchain0_iir0_csrstorage4_storage_full[24:0];
assign pair_csrbank0_iir_d_1_b23_w = pair_fastchain0_iir0_csrstorage4_storage_full[24];
assign pair_csrbank0_iir_d_1_b22_w = pair_fastchain0_iir0_csrstorage4_storage_full[23:16];
assign pair_csrbank0_iir_d_1_b21_w = pair_fastchain0_iir0_csrstorage4_storage_full[15:8];
assign pair_csrbank0_iir_d_1_b20_w = pair_fastchain0_iir0_csrstorage4_storage_full[7:0];
assign pair_fastchain0_limitcsr0_min_storage1 = pair_fastchain0_limitcsr0_min_storage_full1[24:0];
assign pair_csrbank0_y_limit_1_min3_w = pair_fastchain0_limitcsr0_min_storage_full1[24];
assign pair_csrbank0_y_limit_1_min2_w = pair_fastchain0_limitcsr0_min_storage_full1[23:16];
assign pair_csrbank0_y_limit_1_min1_w = pair_fastchain0_limitcsr0_min_storage_full1[15:8];
assign pair_csrbank0_y_limit_1_min0_w = pair_fastchain0_limitcsr0_min_storage_full1[7:0];
assign pair_fastchain0_limitcsr0_max_storage1 = pair_fastchain0_limitcsr0_max_storage_full1[24:0];
assign pair_csrbank0_y_limit_1_max3_w = pair_fastchain0_limitcsr0_max_storage_full1[24];
assign pair_csrbank0_y_limit_1_max2_w = pair_fastchain0_limitcsr0_max_storage_full1[23:16];
assign pair_csrbank0_y_limit_1_max1_w = pair_fastchain0_limitcsr0_max_storage_full1[15:8];
assign pair_csrbank0_y_limit_1_max0_w = pair_fastchain0_limitcsr0_max_storage_full1[7:0];
assign pair_fastchain0_limitcsr1_min_storage0 = pair_fastchain0_limitcsr1_min_storage_full0[24:0];
assign pair_csrbank0_x_limit_2_min3_w = pair_fastchain0_limitcsr1_min_storage_full0[24];
assign pair_csrbank0_x_limit_2_min2_w = pair_fastchain0_limitcsr1_min_storage_full0[23:16];
assign pair_csrbank0_x_limit_2_min1_w = pair_fastchain0_limitcsr1_min_storage_full0[15:8];
assign pair_csrbank0_x_limit_2_min0_w = pair_fastchain0_limitcsr1_min_storage_full0[7:0];
assign pair_fastchain0_limitcsr1_max_storage0 = pair_fastchain0_limitcsr1_max_storage_full0[24:0];
assign pair_csrbank0_x_limit_2_max3_w = pair_fastchain0_limitcsr1_max_storage_full0[24];
assign pair_csrbank0_x_limit_2_max2_w = pair_fastchain0_limitcsr1_max_storage_full0[23:16];
assign pair_csrbank0_x_limit_2_max1_w = pair_fastchain0_limitcsr1_max_storage_full0[15:8];
assign pair_csrbank0_x_limit_2_max0_w = pair_fastchain0_limitcsr1_max_storage_full0[7:0];
assign pair_fastchain0_iir1_storage0 = pair_fastchain0_iir1_storage_full0[26:0];
assign pair_csrbank0_iir_c_2_z03_w = pair_fastchain0_iir1_storage_full0[26:24];
assign pair_csrbank0_iir_c_2_z02_w = pair_fastchain0_iir1_storage_full0[23:16];
assign pair_csrbank0_iir_c_2_z01_w = pair_fastchain0_iir1_storage_full0[15:8];
assign pair_csrbank0_iir_c_2_z00_w = pair_fastchain0_iir1_storage_full0[7:0];
assign pair_fastchain0_iir1_csrstorage3_storage = pair_fastchain0_iir1_csrstorage3_storage_full[24:0];
assign pair_csrbank0_iir_c_2_a13_w = pair_fastchain0_iir1_csrstorage3_storage_full[24];
assign pair_csrbank0_iir_c_2_a12_w = pair_fastchain0_iir1_csrstorage3_storage_full[23:16];
assign pair_csrbank0_iir_c_2_a11_w = pair_fastchain0_iir1_csrstorage3_storage_full[15:8];
assign pair_csrbank0_iir_c_2_a10_w = pair_fastchain0_iir1_csrstorage3_storage_full[7:0];
assign pair_fastchain0_iir1_csrstorage4_storage = pair_fastchain0_iir1_csrstorage4_storage_full[24:0];
assign pair_csrbank0_iir_c_2_b03_w = pair_fastchain0_iir1_csrstorage4_storage_full[24];
assign pair_csrbank0_iir_c_2_b02_w = pair_fastchain0_iir1_csrstorage4_storage_full[23:16];
assign pair_csrbank0_iir_c_2_b01_w = pair_fastchain0_iir1_csrstorage4_storage_full[15:8];
assign pair_csrbank0_iir_c_2_b00_w = pair_fastchain0_iir1_csrstorage4_storage_full[7:0];
assign pair_fastchain0_iir1_csrstorage5_storage0 = pair_fastchain0_iir1_csrstorage5_storage_full0[24:0];
assign pair_csrbank0_iir_c_2_b13_w = pair_fastchain0_iir1_csrstorage5_storage_full0[24];
assign pair_csrbank0_iir_c_2_b12_w = pair_fastchain0_iir1_csrstorage5_storage_full0[23:16];
assign pair_csrbank0_iir_c_2_b11_w = pair_fastchain0_iir1_csrstorage5_storage_full0[15:8];
assign pair_csrbank0_iir_c_2_b10_w = pair_fastchain0_iir1_csrstorage5_storage_full0[7:0];
assign pair_fastchain0_iir1_storage1 = pair_fastchain0_iir1_storage_full1[26:0];
assign pair_csrbank0_iir_d_2_z03_w = pair_fastchain0_iir1_storage_full1[26:24];
assign pair_csrbank0_iir_d_2_z02_w = pair_fastchain0_iir1_storage_full1[23:16];
assign pair_csrbank0_iir_d_2_z01_w = pair_fastchain0_iir1_storage_full1[15:8];
assign pair_csrbank0_iir_d_2_z00_w = pair_fastchain0_iir1_storage_full1[7:0];
assign pair_fastchain0_iir1_csrstorage5_storage1 = pair_fastchain0_iir1_csrstorage5_storage_full1[24:0];
assign pair_csrbank0_iir_d_2_a13_w = pair_fastchain0_iir1_csrstorage5_storage_full1[24];
assign pair_csrbank0_iir_d_2_a12_w = pair_fastchain0_iir1_csrstorage5_storage_full1[23:16];
assign pair_csrbank0_iir_d_2_a11_w = pair_fastchain0_iir1_csrstorage5_storage_full1[15:8];
assign pair_csrbank0_iir_d_2_a10_w = pair_fastchain0_iir1_csrstorage5_storage_full1[7:0];
assign pair_fastchain0_iir1_csrstorage6_storage = pair_fastchain0_iir1_csrstorage6_storage_full[24:0];
assign pair_csrbank0_iir_d_2_a23_w = pair_fastchain0_iir1_csrstorage6_storage_full[24];
assign pair_csrbank0_iir_d_2_a22_w = pair_fastchain0_iir1_csrstorage6_storage_full[23:16];
assign pair_csrbank0_iir_d_2_a21_w = pair_fastchain0_iir1_csrstorage6_storage_full[15:8];
assign pair_csrbank0_iir_d_2_a20_w = pair_fastchain0_iir1_csrstorage6_storage_full[7:0];
assign pair_fastchain0_iir1_csrstorage7_storage = pair_fastchain0_iir1_csrstorage7_storage_full[24:0];
assign pair_csrbank0_iir_d_2_b03_w = pair_fastchain0_iir1_csrstorage7_storage_full[24];
assign pair_csrbank0_iir_d_2_b02_w = pair_fastchain0_iir1_csrstorage7_storage_full[23:16];
assign pair_csrbank0_iir_d_2_b01_w = pair_fastchain0_iir1_csrstorage7_storage_full[15:8];
assign pair_csrbank0_iir_d_2_b00_w = pair_fastchain0_iir1_csrstorage7_storage_full[7:0];
assign pair_fastchain0_iir1_csrstorage8_storage = pair_fastchain0_iir1_csrstorage8_storage_full[24:0];
assign pair_csrbank0_iir_d_2_b13_w = pair_fastchain0_iir1_csrstorage8_storage_full[24];
assign pair_csrbank0_iir_d_2_b12_w = pair_fastchain0_iir1_csrstorage8_storage_full[23:16];
assign pair_csrbank0_iir_d_2_b11_w = pair_fastchain0_iir1_csrstorage8_storage_full[15:8];
assign pair_csrbank0_iir_d_2_b10_w = pair_fastchain0_iir1_csrstorage8_storage_full[7:0];
assign pair_fastchain0_iir1_csrstorage9_storage = pair_fastchain0_iir1_csrstorage9_storage_full[24:0];
assign pair_csrbank0_iir_d_2_b23_w = pair_fastchain0_iir1_csrstorage9_storage_full[24];
assign pair_csrbank0_iir_d_2_b22_w = pair_fastchain0_iir1_csrstorage9_storage_full[23:16];
assign pair_csrbank0_iir_d_2_b21_w = pair_fastchain0_iir1_csrstorage9_storage_full[15:8];
assign pair_csrbank0_iir_d_2_b20_w = pair_fastchain0_iir1_csrstorage9_storage_full[7:0];
assign pair_fastchain0_limitcsr1_min_storage1 = pair_fastchain0_limitcsr1_min_storage_full1[24:0];
assign pair_csrbank0_y_limit_2_min3_w = pair_fastchain0_limitcsr1_min_storage_full1[24];
assign pair_csrbank0_y_limit_2_min2_w = pair_fastchain0_limitcsr1_min_storage_full1[23:16];
assign pair_csrbank0_y_limit_2_min1_w = pair_fastchain0_limitcsr1_min_storage_full1[15:8];
assign pair_csrbank0_y_limit_2_min0_w = pair_fastchain0_limitcsr1_min_storage_full1[7:0];
assign pair_fastchain0_limitcsr1_max_storage1 = pair_fastchain0_limitcsr1_max_storage_full1[24:0];
assign pair_csrbank0_y_limit_2_max3_w = pair_fastchain0_limitcsr1_max_storage_full1[24];
assign pair_csrbank0_y_limit_2_max2_w = pair_fastchain0_limitcsr1_max_storage_full1[23:16];
assign pair_csrbank0_y_limit_2_max1_w = pair_fastchain0_limitcsr1_max_storage_full1[15:8];
assign pair_csrbank0_y_limit_2_max0_w = pair_fastchain0_limitcsr1_max_storage_full1[7:0];
assign pair_fastchain1_x0 = (pair_fastchain1_adc <<< 4'd11);
assign pair_fastchain1_x1 = pair_fastchain1_adc;
assign pair_fastchain1_phase = phase;
assign pair_fastchain1_pre_out_i = pair_fastchain1_paralleltaplimitcsr0_pre_y;
assign pair_fastchain1_out_i_update_en = pair_fastchain1_paralleltaplimitcsr0_update_en;
assign pair_fastchain1_limitcsr2_x = ((pair_fastchain1_i <<< 4'd11) + pair_fastchain1_dx);
assign pair_fastchain1_iir2_x0 = pair_fastchain1_limitcsr2_limitcsr2_y;
assign pair_fastchain1_iir2_hold0 = 1'd0;
assign pair_fastchain1_iir2_clear0 = 1'd0;
assign pair_fastchain1_iir2_x1 = pair_fastchain1_iir2_y0;
assign pair_fastchain1_iir2_hold1 = 1'd0;
assign pair_fastchain1_iir2_clear1 = 1'd0;
assign pair_fastchain1_paralleltaplimitcsr0_common_a = (pair_fastchain1_ya <<< 4'd11);
assign pair_fastchain1_paralleltaplimitcsr0_common_b = (offset <<< 4'd11);
assign pair_fastchain1_paralleltaplimitcsr03 = pair_fastchain1_y_tap_storage;
assign pair_fastchain1_paralleltaplimitcsr04 = pair_fastchain1_invert_storage;
assign pair_fastchain1_paralleltaplimitcsr00 = pair_fastchain1_iir2_x0;
assign pair_fastchain1_paralleltaplimitcsr01 = pair_fastchain1_iir2_y0;
assign pair_fastchain1_paralleltaplimitcsr02 = pair_fastchain1_iir2_y2;
assign pair_fastchain1_out_i = pair_fastchain1_paralleltaplimitcsr0_y;
assign pair_fastchain1_limitcsr3_x = ((pair_fastchain1_q0 <<< 4'd11) + pair_fastchain1_dx);
assign pair_fastchain1_iir3_x0 = pair_fastchain1_limitcsr3_limitcsr3_y;
assign pair_fastchain1_iir3_hold0 = 1'd0;
assign pair_fastchain1_iir3_clear0 = 1'd0;
assign pair_fastchain1_iir3_x1 = pair_fastchain1_iir3_y0;
assign pair_fastchain1_iir3_hold1 = 1'd0;
assign pair_fastchain1_iir3_clear1 = 1'd0;
assign pair_fastchain1_paralleltaplimitcsr1_common_a = (pair_fastchain1_ya <<< 4'd11);
assign pair_fastchain1_paralleltaplimitcsr1_common_b = (offset <<< 4'd11);
assign pair_fastchain1_paralleltaplimitcsr13 = pair_fastchain1_y_tap_storage;
assign pair_fastchain1_paralleltaplimitcsr14 = pair_fastchain1_invert_storage;
assign pair_fastchain1_paralleltaplimitcsr10 = pair_fastchain1_iir3_x0;
assign pair_fastchain1_paralleltaplimitcsr11 = pair_fastchain1_iir3_y0;
assign pair_fastchain1_paralleltaplimitcsr12 = pair_fastchain1_iir3_y2;
assign pair_fastchain1_out_q = pair_fastchain1_paralleltaplimitcsr1_y;
assign pair_fastchain1_xi = pair_fastchain1_x1;
assign pair_fastchain1_zi = (((pair_fastchain1_phase * pair_fastchain1_multiplier_storage) + pair_fastchain1_delay_storage) <<< 1'd1);
assign pair_fastchain1_i = (pair_fastchain1_cordic1_xo >>> 1'd1);
assign pair_fastchain1_q0 = (pair_fastchain1_cordic1_yo >>> 1'd1);
assign pair_fastchain1_cordic10 = (pair_fastchain1_cordic1_xi <<< 2'd2);
assign pair_fastchain1_cordic116 = (pair_fastchain1_cordic1_yi <<< 2'd2);
assign pair_fastchain1_cordic132 = (pair_fastchain1_cordic1_zi <<< 2'd2);
assign pair_fastchain1_cordic1_xo = (pair_fastchain1_cordic115 >>> 2'd2);
assign pair_fastchain1_cordic1_yo = (pair_fastchain1_cordic131 >>> 2'd2);
assign pair_fastchain1_cordic1_zo = (pair_fastchain1_cordic147 >>> 2'd2);
assign pair_fastchain1_cordic1_new_out = 1'd1;
assign pair_fastchain1_cordic1_new_in = 1'd1;
assign pair_fastchain1_cordic1_dir0 = (pair_fastchain1_cordic132 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir1 = (pair_fastchain1_cordic133 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir2 = (pair_fastchain1_cordic134 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir3 = (pair_fastchain1_cordic135 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir4 = (pair_fastchain1_cordic136 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir5 = (pair_fastchain1_cordic137 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir6 = (pair_fastchain1_cordic138 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir7 = (pair_fastchain1_cordic139 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir8 = (pair_fastchain1_cordic140 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir9 = (pair_fastchain1_cordic141 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir10 = (pair_fastchain1_cordic142 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir11 = (pair_fastchain1_cordic143 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir12 = (pair_fastchain1_cordic144 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir13 = (pair_fastchain1_cordic145 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_cordic1_dir14 = (pair_fastchain1_cordic146 < $signed({1'd0, 1'd0}));
assign pair_fastchain1_q1 = (pair_fastchain1_zi[13] ^ pair_fastchain1_zi[14]);

// synthesis translate_off
reg dummy_d_9;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_cordic1_xi <= 15'sd0;
	pair_fastchain1_cordic1_yi <= 15'sd0;
	pair_fastchain1_cordic1_zi <= 15'sd0;
	if (pair_fastchain1_q1) begin
		{pair_fastchain1_cordic1_zi, pair_fastchain1_cordic1_yi, pair_fastchain1_cordic1_xi} <= {(pair_fastchain1_zi + $signed({1'd0, 15'd16384})), (-pair_fastchain1_yi), (-pair_fastchain1_xi)};
	end else begin
		{pair_fastchain1_cordic1_zi, pair_fastchain1_cordic1_yi, pair_fastchain1_cordic1_xi} <= {pair_fastchain1_zi, pair_fastchain1_yi, pair_fastchain1_xi};
	end
// synthesis translate_off
	dummy_d_9 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain1_limitcsr2_limit_x = pair_fastchain1_limitcsr2_x;

// synthesis translate_off
reg dummy_d_10;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_limitcsr2_limit_y <= 26'sd0;
	pair_fastchain1_limitcsr2_limit_railed <= 1'd0;
	if ((pair_fastchain1_limitcsr2_limit_x >= pair_fastchain1_limitcsr2_limit_max)) begin
		pair_fastchain1_limitcsr2_limit_y <= pair_fastchain1_limitcsr2_limit_max;
		pair_fastchain1_limitcsr2_limit_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_limitcsr2_limit_x <= pair_fastchain1_limitcsr2_limit_min)) begin
			pair_fastchain1_limitcsr2_limit_y <= pair_fastchain1_limitcsr2_limit_min;
			pair_fastchain1_limitcsr2_limit_railed <= 1'd1;
		end else begin
			pair_fastchain1_limitcsr2_limit_y <= pair_fastchain1_limitcsr2_limit_x;
			pair_fastchain1_limitcsr2_limit_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_10 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain1_iir2_railed0 = (~((pair_fastchain1_iir2_y_next0[49:47] == $signed({1'd0, pair_fastchain1_iir2_y_pat0})) | (pair_fastchain1_iir2_y_next0[49:47] == $signed({1'd0, (~pair_fastchain1_iir2_y_pat0)}))));

// synthesis translate_off
reg dummy_d_11;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_iir2_y_lim0 <= 25'sd0;
	if (pair_fastchain1_iir2_railed0) begin
		pair_fastchain1_iir2_y_lim0 <= pair_fastchain1_iir2_y0;
	end else begin
		pair_fastchain1_iir2_y_lim0 <= pair_fastchain1_iir2_y_next0[49:23];
	end
// synthesis translate_off
	dummy_d_11 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain1_iir2_xlo0 = {1'd0, pair_fastchain1_iir2_x0[16:0]};
assign pair_fastchain1_iir2_xhi0 = pair_fastchain1_iir2_x0[24:17];
assign pair_fastchain1_iir2_zlo0 = pair_fastchain1_iir2_zr0[47:0];
assign pair_fastchain1_iir2_ztop0 = pair_fastchain1_iir2_zr0[49:48];
assign pair_fastchain1_iir2_low0 = ((pair_fastchain1_iir2_b10 * pair_fastchain1_iir2_xlo0) + pair_fastchain1_iir2_zlo0);
assign pair_fastchain1_iir2_high0 = ((pair_fastchain1_iir2_b10 * pair_fastchain1_iir2_xhi0) + (pair_fastchain1_iir2_low0 >>> 5'd17));
assign pair_fastchain1_iir20 = (((~pair_fastchain1_iir2_zlo0[47]) & (~pair_fastchain1_iir2_b10[24])) & pair_fastchain1_iir2_low0[47]);
assign pair_fastchain1_iir21 = ((pair_fastchain1_iir2_zlo0[47] & pair_fastchain1_iir2_b10[24]) & (~pair_fastchain1_iir2_low0[47]));
assign pair_fastchain1_iir2_correction0 = (((pair_fastchain1_iir2_ztop0 + pair_fastchain1_iir2_zlo0[47]) + $signed({1'd0, pair_fastchain1_iir20})) - $signed({1'd0, pair_fastchain1_iir21}));
assign pair_fastchain1_iir2_top0 = (pair_fastchain1_iir2_high0[32:31] + pair_fastchain1_iir2_correction0);
assign pair_fastchain1_iir2_result0 = {pair_fastchain1_iir2_top0, pair_fastchain1_iir2_high0[30:0], pair_fastchain1_iir2_low0[16:0]};
assign pair_fastchain1_iir2_z0 = pair_fastchain1_iir2_result0;
assign pair_fastchain1_iir2_xlo1 = {1'd0, pair_fastchain1_iir2_x0[16:0]};
assign pair_fastchain1_iir2_xhi1 = pair_fastchain1_iir2_x0[24:17];
assign pair_fastchain1_iir2_zlo1 = pair_fastchain1_iir2_zr1[47:0];
assign pair_fastchain1_iir2_ztop1 = pair_fastchain1_iir2_zr1[49:48];
assign pair_fastchain1_iir2_low1 = ((pair_fastchain1_iir2_b00 * pair_fastchain1_iir2_xlo1) + pair_fastchain1_iir2_zlo1);
assign pair_fastchain1_iir2_high1 = ((pair_fastchain1_iir2_b00 * pair_fastchain1_iir2_xhi1) + (pair_fastchain1_iir2_low1 >>> 5'd17));
assign pair_fastchain1_iir22 = (((~pair_fastchain1_iir2_zlo1[47]) & (~pair_fastchain1_iir2_b00[24])) & pair_fastchain1_iir2_low1[47]);
assign pair_fastchain1_iir23 = ((pair_fastchain1_iir2_zlo1[47] & pair_fastchain1_iir2_b00[24]) & (~pair_fastchain1_iir2_low1[47]));
assign pair_fastchain1_iir2_correction1 = (((pair_fastchain1_iir2_ztop1 + pair_fastchain1_iir2_zlo1[47]) + $signed({1'd0, pair_fastchain1_iir22})) - $signed({1'd0, pair_fastchain1_iir23}));
assign pair_fastchain1_iir2_top1 = (pair_fastchain1_iir2_high1[32:31] + pair_fastchain1_iir2_correction1);
assign pair_fastchain1_iir2_result1 = {pair_fastchain1_iir2_top1, pair_fastchain1_iir2_high1[30:0], pair_fastchain1_iir2_low1[16:0]};
assign pair_fastchain1_iir2_z1 = pair_fastchain1_iir2_result1;
assign pair_fastchain1_iir2_xlo2 = {1'd0, pair_fastchain1_iir2_y1[16:0]};
assign pair_fastchain1_iir2_xhi2 = pair_fastchain1_iir2_y1[24:17];
assign pair_fastchain1_iir2_zlo2 = pair_fastchain1_iir2_zr2[47:0];
assign pair_fastchain1_iir2_ztop2 = pair_fastchain1_iir2_zr2[49:48];
assign pair_fastchain1_iir2_low2 = ((pair_fastchain1_iir2_a10 * pair_fastchain1_iir2_xlo2) + pair_fastchain1_iir2_zlo2);
assign pair_fastchain1_iir2_high2 = ((pair_fastchain1_iir2_a10 * pair_fastchain1_iir2_xhi2) + (pair_fastchain1_iir2_low2 >>> 5'd17));
assign pair_fastchain1_iir24 = (((~pair_fastchain1_iir2_zlo2[47]) & (~pair_fastchain1_iir2_a10[24])) & pair_fastchain1_iir2_low2[47]);
assign pair_fastchain1_iir25 = ((pair_fastchain1_iir2_zlo2[47] & pair_fastchain1_iir2_a10[24]) & (~pair_fastchain1_iir2_low2[47]));
assign pair_fastchain1_iir2_correction2 = (((pair_fastchain1_iir2_ztop2 + pair_fastchain1_iir2_zlo2[47]) + $signed({1'd0, pair_fastchain1_iir24})) - $signed({1'd0, pair_fastchain1_iir25}));
assign pair_fastchain1_iir2_top2 = (pair_fastchain1_iir2_high2[32:31] + pair_fastchain1_iir2_correction2);
assign pair_fastchain1_iir2_result2 = {pair_fastchain1_iir2_top2, pair_fastchain1_iir2_high2[30:0], pair_fastchain1_iir2_low2[16:0]};
assign pair_fastchain1_iir2_z2 = pair_fastchain1_iir2_result2;
assign pair_fastchain1_iir2_y_next0 = pair_fastchain1_iir2_z2;
assign pair_fastchain1_iir2_railed1 = (~((pair_fastchain1_iir2_y_next1[49:47] == $signed({1'd0, pair_fastchain1_iir2_y_pat1})) | (pair_fastchain1_iir2_y_next1[49:47] == $signed({1'd0, (~pair_fastchain1_iir2_y_pat1)}))));

// synthesis translate_off
reg dummy_d_12;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_iir2_y_lim1 <= 25'sd0;
	if (pair_fastchain1_iir2_railed1) begin
		pair_fastchain1_iir2_y_lim1 <= pair_fastchain1_iir2_y2;
	end else begin
		pair_fastchain1_iir2_y_lim1 <= pair_fastchain1_iir2_y_next1[49:23];
	end
// synthesis translate_off
	dummy_d_12 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain1_iir2_xlo3 = {1'd0, pair_fastchain1_iir2_x1[16:0]};
assign pair_fastchain1_iir2_xhi3 = pair_fastchain1_iir2_x1[24:17];
assign pair_fastchain1_iir2_zlo3 = pair_fastchain1_iir2_zr3[47:0];
assign pair_fastchain1_iir2_ztop3 = pair_fastchain1_iir2_zr3[49:48];
assign pair_fastchain1_iir2_low3 = ((pair_fastchain1_iir2_b2 * pair_fastchain1_iir2_xlo3) + pair_fastchain1_iir2_zlo3);
assign pair_fastchain1_iir2_high3 = ((pair_fastchain1_iir2_b2 * pair_fastchain1_iir2_xhi3) + (pair_fastchain1_iir2_low3 >>> 5'd17));
assign pair_fastchain1_iir26 = (((~pair_fastchain1_iir2_zlo3[47]) & (~pair_fastchain1_iir2_b2[24])) & pair_fastchain1_iir2_low3[47]);
assign pair_fastchain1_iir27 = ((pair_fastchain1_iir2_zlo3[47] & pair_fastchain1_iir2_b2[24]) & (~pair_fastchain1_iir2_low3[47]));
assign pair_fastchain1_iir2_correction3 = (((pair_fastchain1_iir2_ztop3 + pair_fastchain1_iir2_zlo3[47]) + $signed({1'd0, pair_fastchain1_iir26})) - $signed({1'd0, pair_fastchain1_iir27}));
assign pair_fastchain1_iir2_top3 = (pair_fastchain1_iir2_high3[32:31] + pair_fastchain1_iir2_correction3);
assign pair_fastchain1_iir2_result3 = {pair_fastchain1_iir2_top3, pair_fastchain1_iir2_high3[30:0], pair_fastchain1_iir2_low3[16:0]};
assign pair_fastchain1_iir2_z3 = pair_fastchain1_iir2_result3;
assign pair_fastchain1_iir2_xlo4 = {1'd0, pair_fastchain1_iir2_x1[16:0]};
assign pair_fastchain1_iir2_xhi4 = pair_fastchain1_iir2_x1[24:17];
assign pair_fastchain1_iir2_zlo4 = pair_fastchain1_iir2_zr4[47:0];
assign pair_fastchain1_iir2_ztop4 = pair_fastchain1_iir2_zr4[49:48];
assign pair_fastchain1_iir2_low4 = ((pair_fastchain1_iir2_b11 * pair_fastchain1_iir2_xlo4) + pair_fastchain1_iir2_zlo4);
assign pair_fastchain1_iir2_high4 = ((pair_fastchain1_iir2_b11 * pair_fastchain1_iir2_xhi4) + (pair_fastchain1_iir2_low4 >>> 5'd17));
assign pair_fastchain1_iir28 = (((~pair_fastchain1_iir2_zlo4[47]) & (~pair_fastchain1_iir2_b11[24])) & pair_fastchain1_iir2_low4[47]);
assign pair_fastchain1_iir29 = ((pair_fastchain1_iir2_zlo4[47] & pair_fastchain1_iir2_b11[24]) & (~pair_fastchain1_iir2_low4[47]));
assign pair_fastchain1_iir2_correction4 = (((pair_fastchain1_iir2_ztop4 + pair_fastchain1_iir2_zlo4[47]) + $signed({1'd0, pair_fastchain1_iir28})) - $signed({1'd0, pair_fastchain1_iir29}));
assign pair_fastchain1_iir2_top4 = (pair_fastchain1_iir2_high4[32:31] + pair_fastchain1_iir2_correction4);
assign pair_fastchain1_iir2_result4 = {pair_fastchain1_iir2_top4, pair_fastchain1_iir2_high4[30:0], pair_fastchain1_iir2_low4[16:0]};
assign pair_fastchain1_iir2_z4 = pair_fastchain1_iir2_result4;
assign pair_fastchain1_iir2_xlo5 = {1'd0, pair_fastchain1_iir2_x1[16:0]};
assign pair_fastchain1_iir2_xhi5 = pair_fastchain1_iir2_x1[24:17];
assign pair_fastchain1_iir2_zlo5 = pair_fastchain1_iir2_zr5[47:0];
assign pair_fastchain1_iir2_ztop5 = pair_fastchain1_iir2_zr5[49:48];
assign pair_fastchain1_iir2_low5 = ((pair_fastchain1_iir2_b01 * pair_fastchain1_iir2_xlo5) + pair_fastchain1_iir2_zlo5);
assign pair_fastchain1_iir2_high5 = ((pair_fastchain1_iir2_b01 * pair_fastchain1_iir2_xhi5) + (pair_fastchain1_iir2_low5 >>> 5'd17));
assign pair_fastchain1_iir210 = (((~pair_fastchain1_iir2_zlo5[47]) & (~pair_fastchain1_iir2_b01[24])) & pair_fastchain1_iir2_low5[47]);
assign pair_fastchain1_iir211 = ((pair_fastchain1_iir2_zlo5[47] & pair_fastchain1_iir2_b01[24]) & (~pair_fastchain1_iir2_low5[47]));
assign pair_fastchain1_iir2_correction5 = (((pair_fastchain1_iir2_ztop5 + pair_fastchain1_iir2_zlo5[47]) + $signed({1'd0, pair_fastchain1_iir210})) - $signed({1'd0, pair_fastchain1_iir211}));
assign pair_fastchain1_iir2_top5 = (pair_fastchain1_iir2_high5[32:31] + pair_fastchain1_iir2_correction5);
assign pair_fastchain1_iir2_result5 = {pair_fastchain1_iir2_top5, pair_fastchain1_iir2_high5[30:0], pair_fastchain1_iir2_low5[16:0]};
assign pair_fastchain1_iir2_z5 = pair_fastchain1_iir2_result5;
assign pair_fastchain1_iir2_xlo6 = {1'd0, pair_fastchain1_iir2_y3[16:0]};
assign pair_fastchain1_iir2_xhi6 = pair_fastchain1_iir2_y3[24:17];
assign pair_fastchain1_iir2_zlo6 = pair_fastchain1_iir2_zr6[47:0];
assign pair_fastchain1_iir2_ztop6 = pair_fastchain1_iir2_zr6[49:48];
assign pair_fastchain1_iir2_low6 = ((pair_fastchain1_iir2_a2 * pair_fastchain1_iir2_xlo6) + pair_fastchain1_iir2_zlo6);
assign pair_fastchain1_iir2_high6 = ((pair_fastchain1_iir2_a2 * pair_fastchain1_iir2_xhi6) + (pair_fastchain1_iir2_low6 >>> 5'd17));
assign pair_fastchain1_iir212 = (((~pair_fastchain1_iir2_zlo6[47]) & (~pair_fastchain1_iir2_a2[24])) & pair_fastchain1_iir2_low6[47]);
assign pair_fastchain1_iir213 = ((pair_fastchain1_iir2_zlo6[47] & pair_fastchain1_iir2_a2[24]) & (~pair_fastchain1_iir2_low6[47]));
assign pair_fastchain1_iir2_correction6 = (((pair_fastchain1_iir2_ztop6 + pair_fastchain1_iir2_zlo6[47]) + $signed({1'd0, pair_fastchain1_iir212})) - $signed({1'd0, pair_fastchain1_iir213}));
assign pair_fastchain1_iir2_top6 = (pair_fastchain1_iir2_high6[32:31] + pair_fastchain1_iir2_correction6);
assign pair_fastchain1_iir2_result6 = {pair_fastchain1_iir2_top6, pair_fastchain1_iir2_high6[30:0], pair_fastchain1_iir2_low6[16:0]};
assign pair_fastchain1_iir2_z6 = pair_fastchain1_iir2_result6;
assign pair_fastchain1_iir2_xlo7 = {1'd0, pair_fastchain1_iir2_y3[16:0]};
assign pair_fastchain1_iir2_xhi7 = pair_fastchain1_iir2_y3[24:17];
assign pair_fastchain1_iir2_zlo7 = pair_fastchain1_iir2_zr7[47:0];
assign pair_fastchain1_iir2_ztop7 = pair_fastchain1_iir2_zr7[49:48];
assign pair_fastchain1_iir2_low7 = ((pair_fastchain1_iir2_a11 * pair_fastchain1_iir2_xlo7) + pair_fastchain1_iir2_zlo7);
assign pair_fastchain1_iir2_high7 = ((pair_fastchain1_iir2_a11 * pair_fastchain1_iir2_xhi7) + (pair_fastchain1_iir2_low7 >>> 5'd17));
assign pair_fastchain1_iir214 = (((~pair_fastchain1_iir2_zlo7[47]) & (~pair_fastchain1_iir2_a11[24])) & pair_fastchain1_iir2_low7[47]);
assign pair_fastchain1_iir215 = ((pair_fastchain1_iir2_zlo7[47] & pair_fastchain1_iir2_a11[24]) & (~pair_fastchain1_iir2_low7[47]));
assign pair_fastchain1_iir2_correction7 = (((pair_fastchain1_iir2_ztop7 + pair_fastchain1_iir2_zlo7[47]) + $signed({1'd0, pair_fastchain1_iir214})) - $signed({1'd0, pair_fastchain1_iir215}));
assign pair_fastchain1_iir2_top7 = (pair_fastchain1_iir2_high7[32:31] + pair_fastchain1_iir2_correction7);
assign pair_fastchain1_iir2_result7 = {pair_fastchain1_iir2_top7, pair_fastchain1_iir2_high7[30:0], pair_fastchain1_iir2_low7[16:0]};
assign pair_fastchain1_iir2_z7 = pair_fastchain1_iir2_result7;
assign pair_fastchain1_iir2_y_next1 = pair_fastchain1_iir2_z7;
assign pair_fastchain1_paralleltaplimitcsr0_total0 = ((pair_fastchain1_paralleltaplimitcsr00 + pair_fastchain1_paralleltaplimitcsr0_common_a) + pair_fastchain1_paralleltaplimitcsr0_common_b);
assign pair_fastchain1_paralleltaplimitcsr0_limit0_x = pair_fastchain1_paralleltaplimitcsr0_total0;
assign pair_fastchain1_paralleltaplimitcsr0_limit0_min = pair_fastchain1_paralleltaplimitcsr0_bound_min;
assign pair_fastchain1_paralleltaplimitcsr0_limit0_max = pair_fastchain1_paralleltaplimitcsr0_bound_max;
assign pair_fastchain1_paralleltaplimitcsr0_limit1_x = (-pair_fastchain1_paralleltaplimitcsr0_total0);
assign pair_fastchain1_paralleltaplimitcsr0_limit1_min = pair_fastchain1_paralleltaplimitcsr0_bound_min;
assign pair_fastchain1_paralleltaplimitcsr0_limit1_max = pair_fastchain1_paralleltaplimitcsr0_bound_max;
assign pair_fastchain1_paralleltaplimitcsr0_total1 = ((pair_fastchain1_paralleltaplimitcsr01 + pair_fastchain1_paralleltaplimitcsr0_common_a) + pair_fastchain1_paralleltaplimitcsr0_common_b);
assign pair_fastchain1_paralleltaplimitcsr0_limit2_x = pair_fastchain1_paralleltaplimitcsr0_total1;
assign pair_fastchain1_paralleltaplimitcsr0_limit2_min = pair_fastchain1_paralleltaplimitcsr0_bound_min;
assign pair_fastchain1_paralleltaplimitcsr0_limit2_max = pair_fastchain1_paralleltaplimitcsr0_bound_max;
assign pair_fastchain1_paralleltaplimitcsr0_limit3_x = (-pair_fastchain1_paralleltaplimitcsr0_total1);
assign pair_fastchain1_paralleltaplimitcsr0_limit3_min = pair_fastchain1_paralleltaplimitcsr0_bound_min;
assign pair_fastchain1_paralleltaplimitcsr0_limit3_max = pair_fastchain1_paralleltaplimitcsr0_bound_max;
assign pair_fastchain1_paralleltaplimitcsr0_total2 = ((pair_fastchain1_paralleltaplimitcsr02 + pair_fastchain1_paralleltaplimitcsr0_common_a) + pair_fastchain1_paralleltaplimitcsr0_common_b);
assign pair_fastchain1_paralleltaplimitcsr0_limit4_x = pair_fastchain1_paralleltaplimitcsr0_total2;
assign pair_fastchain1_paralleltaplimitcsr0_limit4_min = pair_fastchain1_paralleltaplimitcsr0_bound_min;
assign pair_fastchain1_paralleltaplimitcsr0_limit4_max = pair_fastchain1_paralleltaplimitcsr0_bound_max;
assign pair_fastchain1_paralleltaplimitcsr0_limit5_x = (-pair_fastchain1_paralleltaplimitcsr0_total2);
assign pair_fastchain1_paralleltaplimitcsr0_limit5_min = pair_fastchain1_paralleltaplimitcsr0_bound_min;
assign pair_fastchain1_paralleltaplimitcsr0_limit5_max = pair_fastchain1_paralleltaplimitcsr0_bound_max;
assign pair_fastchain1_paralleltaplimitcsr0_pre_y = (pair_fastchain1_paralleltaplimitcsr04 ? array_muxed2 : array_muxed3);
assign pair_fastchain1_paralleltaplimitcsr0_pre_rail = (pair_fastchain1_paralleltaplimitcsr04 ? array_muxed4 : array_muxed5);

// synthesis translate_off
reg dummy_d_13;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr0_limit0_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr0_limit0_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr0_limit0_x >= pair_fastchain1_paralleltaplimitcsr0_limit0_max)) begin
		pair_fastchain1_paralleltaplimitcsr0_limit0_y <= pair_fastchain1_paralleltaplimitcsr0_limit0_max;
		pair_fastchain1_paralleltaplimitcsr0_limit0_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr0_limit0_x <= pair_fastchain1_paralleltaplimitcsr0_limit0_min)) begin
			pair_fastchain1_paralleltaplimitcsr0_limit0_y <= pair_fastchain1_paralleltaplimitcsr0_limit0_min;
			pair_fastchain1_paralleltaplimitcsr0_limit0_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr0_limit0_y <= pair_fastchain1_paralleltaplimitcsr0_limit0_x;
			pair_fastchain1_paralleltaplimitcsr0_limit0_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_13 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_14;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr0_limit1_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr0_limit1_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr0_limit1_x >= pair_fastchain1_paralleltaplimitcsr0_limit1_max)) begin
		pair_fastchain1_paralleltaplimitcsr0_limit1_y <= pair_fastchain1_paralleltaplimitcsr0_limit1_max;
		pair_fastchain1_paralleltaplimitcsr0_limit1_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr0_limit1_x <= pair_fastchain1_paralleltaplimitcsr0_limit1_min)) begin
			pair_fastchain1_paralleltaplimitcsr0_limit1_y <= pair_fastchain1_paralleltaplimitcsr0_limit1_min;
			pair_fastchain1_paralleltaplimitcsr0_limit1_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr0_limit1_y <= pair_fastchain1_paralleltaplimitcsr0_limit1_x;
			pair_fastchain1_paralleltaplimitcsr0_limit1_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_14 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_15;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr0_limit2_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr0_limit2_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr0_limit2_x >= pair_fastchain1_paralleltaplimitcsr0_limit2_max)) begin
		pair_fastchain1_paralleltaplimitcsr0_limit2_y <= pair_fastchain1_paralleltaplimitcsr0_limit2_max;
		pair_fastchain1_paralleltaplimitcsr0_limit2_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr0_limit2_x <= pair_fastchain1_paralleltaplimitcsr0_limit2_min)) begin
			pair_fastchain1_paralleltaplimitcsr0_limit2_y <= pair_fastchain1_paralleltaplimitcsr0_limit2_min;
			pair_fastchain1_paralleltaplimitcsr0_limit2_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr0_limit2_y <= pair_fastchain1_paralleltaplimitcsr0_limit2_x;
			pair_fastchain1_paralleltaplimitcsr0_limit2_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_15 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_16;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr0_limit3_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr0_limit3_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr0_limit3_x >= pair_fastchain1_paralleltaplimitcsr0_limit3_max)) begin
		pair_fastchain1_paralleltaplimitcsr0_limit3_y <= pair_fastchain1_paralleltaplimitcsr0_limit3_max;
		pair_fastchain1_paralleltaplimitcsr0_limit3_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr0_limit3_x <= pair_fastchain1_paralleltaplimitcsr0_limit3_min)) begin
			pair_fastchain1_paralleltaplimitcsr0_limit3_y <= pair_fastchain1_paralleltaplimitcsr0_limit3_min;
			pair_fastchain1_paralleltaplimitcsr0_limit3_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr0_limit3_y <= pair_fastchain1_paralleltaplimitcsr0_limit3_x;
			pair_fastchain1_paralleltaplimitcsr0_limit3_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_16 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_17;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr0_limit4_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr0_limit4_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr0_limit4_x >= pair_fastchain1_paralleltaplimitcsr0_limit4_max)) begin
		pair_fastchain1_paralleltaplimitcsr0_limit4_y <= pair_fastchain1_paralleltaplimitcsr0_limit4_max;
		pair_fastchain1_paralleltaplimitcsr0_limit4_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr0_limit4_x <= pair_fastchain1_paralleltaplimitcsr0_limit4_min)) begin
			pair_fastchain1_paralleltaplimitcsr0_limit4_y <= pair_fastchain1_paralleltaplimitcsr0_limit4_min;
			pair_fastchain1_paralleltaplimitcsr0_limit4_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr0_limit4_y <= pair_fastchain1_paralleltaplimitcsr0_limit4_x;
			pair_fastchain1_paralleltaplimitcsr0_limit4_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_17 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_18;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr0_limit5_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr0_limit5_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr0_limit5_x >= pair_fastchain1_paralleltaplimitcsr0_limit5_max)) begin
		pair_fastchain1_paralleltaplimitcsr0_limit5_y <= pair_fastchain1_paralleltaplimitcsr0_limit5_max;
		pair_fastchain1_paralleltaplimitcsr0_limit5_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr0_limit5_x <= pair_fastchain1_paralleltaplimitcsr0_limit5_min)) begin
			pair_fastchain1_paralleltaplimitcsr0_limit5_y <= pair_fastchain1_paralleltaplimitcsr0_limit5_min;
			pair_fastchain1_paralleltaplimitcsr0_limit5_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr0_limit5_y <= pair_fastchain1_paralleltaplimitcsr0_limit5_x;
			pair_fastchain1_paralleltaplimitcsr0_limit5_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_18 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain1_limitcsr3_limit_x = pair_fastchain1_limitcsr3_x;

// synthesis translate_off
reg dummy_d_19;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_limitcsr3_limit_y <= 26'sd0;
	pair_fastchain1_limitcsr3_limit_railed <= 1'd0;
	if ((pair_fastchain1_limitcsr3_limit_x >= pair_fastchain1_limitcsr3_limit_max)) begin
		pair_fastchain1_limitcsr3_limit_y <= pair_fastchain1_limitcsr3_limit_max;
		pair_fastchain1_limitcsr3_limit_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_limitcsr3_limit_x <= pair_fastchain1_limitcsr3_limit_min)) begin
			pair_fastchain1_limitcsr3_limit_y <= pair_fastchain1_limitcsr3_limit_min;
			pair_fastchain1_limitcsr3_limit_railed <= 1'd1;
		end else begin
			pair_fastchain1_limitcsr3_limit_y <= pair_fastchain1_limitcsr3_limit_x;
			pair_fastchain1_limitcsr3_limit_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_19 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain1_iir3_railed0 = (~((pair_fastchain1_iir3_y_next0[49:47] == $signed({1'd0, pair_fastchain1_iir3_y_pat0})) | (pair_fastchain1_iir3_y_next0[49:47] == $signed({1'd0, (~pair_fastchain1_iir3_y_pat0)}))));

// synthesis translate_off
reg dummy_d_20;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_iir3_y_lim0 <= 25'sd0;
	if (pair_fastchain1_iir3_railed0) begin
		pair_fastchain1_iir3_y_lim0 <= pair_fastchain1_iir3_y0;
	end else begin
		pair_fastchain1_iir3_y_lim0 <= pair_fastchain1_iir3_y_next0[49:23];
	end
// synthesis translate_off
	dummy_d_20 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain1_iir3_xlo0 = {1'd0, pair_fastchain1_iir3_x0[16:0]};
assign pair_fastchain1_iir3_xhi0 = pair_fastchain1_iir3_x0[24:17];
assign pair_fastchain1_iir3_zlo0 = pair_fastchain1_iir3_zr0[47:0];
assign pair_fastchain1_iir3_ztop0 = pair_fastchain1_iir3_zr0[49:48];
assign pair_fastchain1_iir3_low0 = ((pair_fastchain1_iir3_b10 * pair_fastchain1_iir3_xlo0) + pair_fastchain1_iir3_zlo0);
assign pair_fastchain1_iir3_high0 = ((pair_fastchain1_iir3_b10 * pair_fastchain1_iir3_xhi0) + (pair_fastchain1_iir3_low0 >>> 5'd17));
assign pair_fastchain1_iir30 = (((~pair_fastchain1_iir3_zlo0[47]) & (~pair_fastchain1_iir3_b10[24])) & pair_fastchain1_iir3_low0[47]);
assign pair_fastchain1_iir31 = ((pair_fastchain1_iir3_zlo0[47] & pair_fastchain1_iir3_b10[24]) & (~pair_fastchain1_iir3_low0[47]));
assign pair_fastchain1_iir3_correction0 = (((pair_fastchain1_iir3_ztop0 + pair_fastchain1_iir3_zlo0[47]) + $signed({1'd0, pair_fastchain1_iir30})) - $signed({1'd0, pair_fastchain1_iir31}));
assign pair_fastchain1_iir3_top0 = (pair_fastchain1_iir3_high0[32:31] + pair_fastchain1_iir3_correction0);
assign pair_fastchain1_iir3_result0 = {pair_fastchain1_iir3_top0, pair_fastchain1_iir3_high0[30:0], pair_fastchain1_iir3_low0[16:0]};
assign pair_fastchain1_iir3_z0 = pair_fastchain1_iir3_result0;
assign pair_fastchain1_iir3_xlo1 = {1'd0, pair_fastchain1_iir3_x0[16:0]};
assign pair_fastchain1_iir3_xhi1 = pair_fastchain1_iir3_x0[24:17];
assign pair_fastchain1_iir3_zlo1 = pair_fastchain1_iir3_zr1[47:0];
assign pair_fastchain1_iir3_ztop1 = pair_fastchain1_iir3_zr1[49:48];
assign pair_fastchain1_iir3_low1 = ((pair_fastchain1_iir3_b00 * pair_fastchain1_iir3_xlo1) + pair_fastchain1_iir3_zlo1);
assign pair_fastchain1_iir3_high1 = ((pair_fastchain1_iir3_b00 * pair_fastchain1_iir3_xhi1) + (pair_fastchain1_iir3_low1 >>> 5'd17));
assign pair_fastchain1_iir32 = (((~pair_fastchain1_iir3_zlo1[47]) & (~pair_fastchain1_iir3_b00[24])) & pair_fastchain1_iir3_low1[47]);
assign pair_fastchain1_iir33 = ((pair_fastchain1_iir3_zlo1[47] & pair_fastchain1_iir3_b00[24]) & (~pair_fastchain1_iir3_low1[47]));
assign pair_fastchain1_iir3_correction1 = (((pair_fastchain1_iir3_ztop1 + pair_fastchain1_iir3_zlo1[47]) + $signed({1'd0, pair_fastchain1_iir32})) - $signed({1'd0, pair_fastchain1_iir33}));
assign pair_fastchain1_iir3_top1 = (pair_fastchain1_iir3_high1[32:31] + pair_fastchain1_iir3_correction1);
assign pair_fastchain1_iir3_result1 = {pair_fastchain1_iir3_top1, pair_fastchain1_iir3_high1[30:0], pair_fastchain1_iir3_low1[16:0]};
assign pair_fastchain1_iir3_z1 = pair_fastchain1_iir3_result1;
assign pair_fastchain1_iir3_xlo2 = {1'd0, pair_fastchain1_iir3_y1[16:0]};
assign pair_fastchain1_iir3_xhi2 = pair_fastchain1_iir3_y1[24:17];
assign pair_fastchain1_iir3_zlo2 = pair_fastchain1_iir3_zr2[47:0];
assign pair_fastchain1_iir3_ztop2 = pair_fastchain1_iir3_zr2[49:48];
assign pair_fastchain1_iir3_low2 = ((pair_fastchain1_iir3_a10 * pair_fastchain1_iir3_xlo2) + pair_fastchain1_iir3_zlo2);
assign pair_fastchain1_iir3_high2 = ((pair_fastchain1_iir3_a10 * pair_fastchain1_iir3_xhi2) + (pair_fastchain1_iir3_low2 >>> 5'd17));
assign pair_fastchain1_iir34 = (((~pair_fastchain1_iir3_zlo2[47]) & (~pair_fastchain1_iir3_a10[24])) & pair_fastchain1_iir3_low2[47]);
assign pair_fastchain1_iir35 = ((pair_fastchain1_iir3_zlo2[47] & pair_fastchain1_iir3_a10[24]) & (~pair_fastchain1_iir3_low2[47]));
assign pair_fastchain1_iir3_correction2 = (((pair_fastchain1_iir3_ztop2 + pair_fastchain1_iir3_zlo2[47]) + $signed({1'd0, pair_fastchain1_iir34})) - $signed({1'd0, pair_fastchain1_iir35}));
assign pair_fastchain1_iir3_top2 = (pair_fastchain1_iir3_high2[32:31] + pair_fastchain1_iir3_correction2);
assign pair_fastchain1_iir3_result2 = {pair_fastchain1_iir3_top2, pair_fastchain1_iir3_high2[30:0], pair_fastchain1_iir3_low2[16:0]};
assign pair_fastchain1_iir3_z2 = pair_fastchain1_iir3_result2;
assign pair_fastchain1_iir3_y_next0 = pair_fastchain1_iir3_z2;
assign pair_fastchain1_iir3_railed1 = (~((pair_fastchain1_iir3_y_next1[49:47] == $signed({1'd0, pair_fastchain1_iir3_y_pat1})) | (pair_fastchain1_iir3_y_next1[49:47] == $signed({1'd0, (~pair_fastchain1_iir3_y_pat1)}))));

// synthesis translate_off
reg dummy_d_21;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_iir3_y_lim1 <= 25'sd0;
	if (pair_fastchain1_iir3_railed1) begin
		pair_fastchain1_iir3_y_lim1 <= pair_fastchain1_iir3_y2;
	end else begin
		pair_fastchain1_iir3_y_lim1 <= pair_fastchain1_iir3_y_next1[49:23];
	end
// synthesis translate_off
	dummy_d_21 <= dummy_s;
// synthesis translate_on
end
assign pair_fastchain1_iir3_xlo3 = {1'd0, pair_fastchain1_iir3_x1[16:0]};
assign pair_fastchain1_iir3_xhi3 = pair_fastchain1_iir3_x1[24:17];
assign pair_fastchain1_iir3_zlo3 = pair_fastchain1_iir3_zr3[47:0];
assign pair_fastchain1_iir3_ztop3 = pair_fastchain1_iir3_zr3[49:48];
assign pair_fastchain1_iir3_low3 = ((pair_fastchain1_iir3_b2 * pair_fastchain1_iir3_xlo3) + pair_fastchain1_iir3_zlo3);
assign pair_fastchain1_iir3_high3 = ((pair_fastchain1_iir3_b2 * pair_fastchain1_iir3_xhi3) + (pair_fastchain1_iir3_low3 >>> 5'd17));
assign pair_fastchain1_iir36 = (((~pair_fastchain1_iir3_zlo3[47]) & (~pair_fastchain1_iir3_b2[24])) & pair_fastchain1_iir3_low3[47]);
assign pair_fastchain1_iir37 = ((pair_fastchain1_iir3_zlo3[47] & pair_fastchain1_iir3_b2[24]) & (~pair_fastchain1_iir3_low3[47]));
assign pair_fastchain1_iir3_correction3 = (((pair_fastchain1_iir3_ztop3 + pair_fastchain1_iir3_zlo3[47]) + $signed({1'd0, pair_fastchain1_iir36})) - $signed({1'd0, pair_fastchain1_iir37}));
assign pair_fastchain1_iir3_top3 = (pair_fastchain1_iir3_high3[32:31] + pair_fastchain1_iir3_correction3);
assign pair_fastchain1_iir3_result3 = {pair_fastchain1_iir3_top3, pair_fastchain1_iir3_high3[30:0], pair_fastchain1_iir3_low3[16:0]};
assign pair_fastchain1_iir3_z3 = pair_fastchain1_iir3_result3;
assign pair_fastchain1_iir3_xlo4 = {1'd0, pair_fastchain1_iir3_x1[16:0]};
assign pair_fastchain1_iir3_xhi4 = pair_fastchain1_iir3_x1[24:17];
assign pair_fastchain1_iir3_zlo4 = pair_fastchain1_iir3_zr4[47:0];
assign pair_fastchain1_iir3_ztop4 = pair_fastchain1_iir3_zr4[49:48];
assign pair_fastchain1_iir3_low4 = ((pair_fastchain1_iir3_b11 * pair_fastchain1_iir3_xlo4) + pair_fastchain1_iir3_zlo4);
assign pair_fastchain1_iir3_high4 = ((pair_fastchain1_iir3_b11 * pair_fastchain1_iir3_xhi4) + (pair_fastchain1_iir3_low4 >>> 5'd17));
assign pair_fastchain1_iir38 = (((~pair_fastchain1_iir3_zlo4[47]) & (~pair_fastchain1_iir3_b11[24])) & pair_fastchain1_iir3_low4[47]);
assign pair_fastchain1_iir39 = ((pair_fastchain1_iir3_zlo4[47] & pair_fastchain1_iir3_b11[24]) & (~pair_fastchain1_iir3_low4[47]));
assign pair_fastchain1_iir3_correction4 = (((pair_fastchain1_iir3_ztop4 + pair_fastchain1_iir3_zlo4[47]) + $signed({1'd0, pair_fastchain1_iir38})) - $signed({1'd0, pair_fastchain1_iir39}));
assign pair_fastchain1_iir3_top4 = (pair_fastchain1_iir3_high4[32:31] + pair_fastchain1_iir3_correction4);
assign pair_fastchain1_iir3_result4 = {pair_fastchain1_iir3_top4, pair_fastchain1_iir3_high4[30:0], pair_fastchain1_iir3_low4[16:0]};
assign pair_fastchain1_iir3_z4 = pair_fastchain1_iir3_result4;
assign pair_fastchain1_iir3_xlo5 = {1'd0, pair_fastchain1_iir3_x1[16:0]};
assign pair_fastchain1_iir3_xhi5 = pair_fastchain1_iir3_x1[24:17];
assign pair_fastchain1_iir3_zlo5 = pair_fastchain1_iir3_zr5[47:0];
assign pair_fastchain1_iir3_ztop5 = pair_fastchain1_iir3_zr5[49:48];
assign pair_fastchain1_iir3_low5 = ((pair_fastchain1_iir3_b01 * pair_fastchain1_iir3_xlo5) + pair_fastchain1_iir3_zlo5);
assign pair_fastchain1_iir3_high5 = ((pair_fastchain1_iir3_b01 * pair_fastchain1_iir3_xhi5) + (pair_fastchain1_iir3_low5 >>> 5'd17));
assign pair_fastchain1_iir310 = (((~pair_fastchain1_iir3_zlo5[47]) & (~pair_fastchain1_iir3_b01[24])) & pair_fastchain1_iir3_low5[47]);
assign pair_fastchain1_iir311 = ((pair_fastchain1_iir3_zlo5[47] & pair_fastchain1_iir3_b01[24]) & (~pair_fastchain1_iir3_low5[47]));
assign pair_fastchain1_iir3_correction5 = (((pair_fastchain1_iir3_ztop5 + pair_fastchain1_iir3_zlo5[47]) + $signed({1'd0, pair_fastchain1_iir310})) - $signed({1'd0, pair_fastchain1_iir311}));
assign pair_fastchain1_iir3_top5 = (pair_fastchain1_iir3_high5[32:31] + pair_fastchain1_iir3_correction5);
assign pair_fastchain1_iir3_result5 = {pair_fastchain1_iir3_top5, pair_fastchain1_iir3_high5[30:0], pair_fastchain1_iir3_low5[16:0]};
assign pair_fastchain1_iir3_z5 = pair_fastchain1_iir3_result5;
assign pair_fastchain1_iir3_xlo6 = {1'd0, pair_fastchain1_iir3_y3[16:0]};
assign pair_fastchain1_iir3_xhi6 = pair_fastchain1_iir3_y3[24:17];
assign pair_fastchain1_iir3_zlo6 = pair_fastchain1_iir3_zr6[47:0];
assign pair_fastchain1_iir3_ztop6 = pair_fastchain1_iir3_zr6[49:48];
assign pair_fastchain1_iir3_low6 = ((pair_fastchain1_iir3_a2 * pair_fastchain1_iir3_xlo6) + pair_fastchain1_iir3_zlo6);
assign pair_fastchain1_iir3_high6 = ((pair_fastchain1_iir3_a2 * pair_fastchain1_iir3_xhi6) + (pair_fastchain1_iir3_low6 >>> 5'd17));
assign pair_fastchain1_iir312 = (((~pair_fastchain1_iir3_zlo6[47]) & (~pair_fastchain1_iir3_a2[24])) & pair_fastchain1_iir3_low6[47]);
assign pair_fastchain1_iir313 = ((pair_fastchain1_iir3_zlo6[47] & pair_fastchain1_iir3_a2[24]) & (~pair_fastchain1_iir3_low6[47]));
assign pair_fastchain1_iir3_correction6 = (((pair_fastchain1_iir3_ztop6 + pair_fastchain1_iir3_zlo6[47]) + $signed({1'd0, pair_fastchain1_iir312})) - $signed({1'd0, pair_fastchain1_iir313}));
assign pair_fastchain1_iir3_top6 = (pair_fastchain1_iir3_high6[32:31] + pair_fastchain1_iir3_correction6);
assign pair_fastchain1_iir3_result6 = {pair_fastchain1_iir3_top6, pair_fastchain1_iir3_high6[30:0], pair_fastchain1_iir3_low6[16:0]};
assign pair_fastchain1_iir3_z6 = pair_fastchain1_iir3_result6;
assign pair_fastchain1_iir3_xlo7 = {1'd0, pair_fastchain1_iir3_y3[16:0]};
assign pair_fastchain1_iir3_xhi7 = pair_fastchain1_iir3_y3[24:17];
assign pair_fastchain1_iir3_zlo7 = pair_fastchain1_iir3_zr7[47:0];
assign pair_fastchain1_iir3_ztop7 = pair_fastchain1_iir3_zr7[49:48];
assign pair_fastchain1_iir3_low7 = ((pair_fastchain1_iir3_a11 * pair_fastchain1_iir3_xlo7) + pair_fastchain1_iir3_zlo7);
assign pair_fastchain1_iir3_high7 = ((pair_fastchain1_iir3_a11 * pair_fastchain1_iir3_xhi7) + (pair_fastchain1_iir3_low7 >>> 5'd17));
assign pair_fastchain1_iir314 = (((~pair_fastchain1_iir3_zlo7[47]) & (~pair_fastchain1_iir3_a11[24])) & pair_fastchain1_iir3_low7[47]);
assign pair_fastchain1_iir315 = ((pair_fastchain1_iir3_zlo7[47] & pair_fastchain1_iir3_a11[24]) & (~pair_fastchain1_iir3_low7[47]));
assign pair_fastchain1_iir3_correction7 = (((pair_fastchain1_iir3_ztop7 + pair_fastchain1_iir3_zlo7[47]) + $signed({1'd0, pair_fastchain1_iir314})) - $signed({1'd0, pair_fastchain1_iir315}));
assign pair_fastchain1_iir3_top7 = (pair_fastchain1_iir3_high7[32:31] + pair_fastchain1_iir3_correction7);
assign pair_fastchain1_iir3_result7 = {pair_fastchain1_iir3_top7, pair_fastchain1_iir3_high7[30:0], pair_fastchain1_iir3_low7[16:0]};
assign pair_fastchain1_iir3_z7 = pair_fastchain1_iir3_result7;
assign pair_fastchain1_iir3_y_next1 = pair_fastchain1_iir3_z7;
assign pair_fastchain1_paralleltaplimitcsr1_total0 = ((pair_fastchain1_paralleltaplimitcsr10 + pair_fastchain1_paralleltaplimitcsr1_common_a) + pair_fastchain1_paralleltaplimitcsr1_common_b);
assign pair_fastchain1_paralleltaplimitcsr1_limit6_x = pair_fastchain1_paralleltaplimitcsr1_total0;
assign pair_fastchain1_paralleltaplimitcsr1_limit6_min = pair_fastchain1_paralleltaplimitcsr1_bound_min;
assign pair_fastchain1_paralleltaplimitcsr1_limit6_max = pair_fastchain1_paralleltaplimitcsr1_bound_max;
assign pair_fastchain1_paralleltaplimitcsr1_limit7_x = (-pair_fastchain1_paralleltaplimitcsr1_total0);
assign pair_fastchain1_paralleltaplimitcsr1_limit7_min = pair_fastchain1_paralleltaplimitcsr1_bound_min;
assign pair_fastchain1_paralleltaplimitcsr1_limit7_max = pair_fastchain1_paralleltaplimitcsr1_bound_max;
assign pair_fastchain1_paralleltaplimitcsr1_total1 = ((pair_fastchain1_paralleltaplimitcsr11 + pair_fastchain1_paralleltaplimitcsr1_common_a) + pair_fastchain1_paralleltaplimitcsr1_common_b);
assign pair_fastchain1_paralleltaplimitcsr1_limit8_x = pair_fastchain1_paralleltaplimitcsr1_total1;
assign pair_fastchain1_paralleltaplimitcsr1_limit8_min = pair_fastchain1_paralleltaplimitcsr1_bound_min;
assign pair_fastchain1_paralleltaplimitcsr1_limit8_max = pair_fastchain1_paralleltaplimitcsr1_bound_max;
assign pair_fastchain1_paralleltaplimitcsr1_limit9_x = (-pair_fastchain1_paralleltaplimitcsr1_total1);
assign pair_fastchain1_paralleltaplimitcsr1_limit9_min = pair_fastchain1_paralleltaplimitcsr1_bound_min;
assign pair_fastchain1_paralleltaplimitcsr1_limit9_max = pair_fastchain1_paralleltaplimitcsr1_bound_max;
assign pair_fastchain1_paralleltaplimitcsr1_total2 = ((pair_fastchain1_paralleltaplimitcsr12 + pair_fastchain1_paralleltaplimitcsr1_common_a) + pair_fastchain1_paralleltaplimitcsr1_common_b);
assign pair_fastchain1_paralleltaplimitcsr1_limit10_x = pair_fastchain1_paralleltaplimitcsr1_total2;
assign pair_fastchain1_paralleltaplimitcsr1_limit10_min = pair_fastchain1_paralleltaplimitcsr1_bound_min;
assign pair_fastchain1_paralleltaplimitcsr1_limit10_max = pair_fastchain1_paralleltaplimitcsr1_bound_max;
assign pair_fastchain1_paralleltaplimitcsr1_limit11_x = (-pair_fastchain1_paralleltaplimitcsr1_total2);
assign pair_fastchain1_paralleltaplimitcsr1_limit11_min = pair_fastchain1_paralleltaplimitcsr1_bound_min;
assign pair_fastchain1_paralleltaplimitcsr1_limit11_max = pair_fastchain1_paralleltaplimitcsr1_bound_max;
assign pair_fastchain1_paralleltaplimitcsr1_pre_y = (pair_fastchain1_paralleltaplimitcsr14 ? array_muxed6 : array_muxed7);
assign pair_fastchain1_paralleltaplimitcsr1_pre_rail = (pair_fastchain1_paralleltaplimitcsr14 ? array_muxed8 : array_muxed9);

// synthesis translate_off
reg dummy_d_22;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr1_limit6_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr1_limit6_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr1_limit6_x >= pair_fastchain1_paralleltaplimitcsr1_limit6_max)) begin
		pair_fastchain1_paralleltaplimitcsr1_limit6_y <= pair_fastchain1_paralleltaplimitcsr1_limit6_max;
		pair_fastchain1_paralleltaplimitcsr1_limit6_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr1_limit6_x <= pair_fastchain1_paralleltaplimitcsr1_limit6_min)) begin
			pair_fastchain1_paralleltaplimitcsr1_limit6_y <= pair_fastchain1_paralleltaplimitcsr1_limit6_min;
			pair_fastchain1_paralleltaplimitcsr1_limit6_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr1_limit6_y <= pair_fastchain1_paralleltaplimitcsr1_limit6_x;
			pair_fastchain1_paralleltaplimitcsr1_limit6_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_22 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_23;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr1_limit7_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr1_limit7_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr1_limit7_x >= pair_fastchain1_paralleltaplimitcsr1_limit7_max)) begin
		pair_fastchain1_paralleltaplimitcsr1_limit7_y <= pair_fastchain1_paralleltaplimitcsr1_limit7_max;
		pair_fastchain1_paralleltaplimitcsr1_limit7_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr1_limit7_x <= pair_fastchain1_paralleltaplimitcsr1_limit7_min)) begin
			pair_fastchain1_paralleltaplimitcsr1_limit7_y <= pair_fastchain1_paralleltaplimitcsr1_limit7_min;
			pair_fastchain1_paralleltaplimitcsr1_limit7_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr1_limit7_y <= pair_fastchain1_paralleltaplimitcsr1_limit7_x;
			pair_fastchain1_paralleltaplimitcsr1_limit7_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_23 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_24;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr1_limit8_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr1_limit8_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr1_limit8_x >= pair_fastchain1_paralleltaplimitcsr1_limit8_max)) begin
		pair_fastchain1_paralleltaplimitcsr1_limit8_y <= pair_fastchain1_paralleltaplimitcsr1_limit8_max;
		pair_fastchain1_paralleltaplimitcsr1_limit8_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr1_limit8_x <= pair_fastchain1_paralleltaplimitcsr1_limit8_min)) begin
			pair_fastchain1_paralleltaplimitcsr1_limit8_y <= pair_fastchain1_paralleltaplimitcsr1_limit8_min;
			pair_fastchain1_paralleltaplimitcsr1_limit8_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr1_limit8_y <= pair_fastchain1_paralleltaplimitcsr1_limit8_x;
			pair_fastchain1_paralleltaplimitcsr1_limit8_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_24 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_25;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr1_limit9_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr1_limit9_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr1_limit9_x >= pair_fastchain1_paralleltaplimitcsr1_limit9_max)) begin
		pair_fastchain1_paralleltaplimitcsr1_limit9_y <= pair_fastchain1_paralleltaplimitcsr1_limit9_max;
		pair_fastchain1_paralleltaplimitcsr1_limit9_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr1_limit9_x <= pair_fastchain1_paralleltaplimitcsr1_limit9_min)) begin
			pair_fastchain1_paralleltaplimitcsr1_limit9_y <= pair_fastchain1_paralleltaplimitcsr1_limit9_min;
			pair_fastchain1_paralleltaplimitcsr1_limit9_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr1_limit9_y <= pair_fastchain1_paralleltaplimitcsr1_limit9_x;
			pair_fastchain1_paralleltaplimitcsr1_limit9_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_25 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_26;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr1_limit10_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr1_limit10_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr1_limit10_x >= pair_fastchain1_paralleltaplimitcsr1_limit10_max)) begin
		pair_fastchain1_paralleltaplimitcsr1_limit10_y <= pair_fastchain1_paralleltaplimitcsr1_limit10_max;
		pair_fastchain1_paralleltaplimitcsr1_limit10_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr1_limit10_x <= pair_fastchain1_paralleltaplimitcsr1_limit10_min)) begin
			pair_fastchain1_paralleltaplimitcsr1_limit10_y <= pair_fastchain1_paralleltaplimitcsr1_limit10_min;
			pair_fastchain1_paralleltaplimitcsr1_limit10_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr1_limit10_y <= pair_fastchain1_paralleltaplimitcsr1_limit10_x;
			pair_fastchain1_paralleltaplimitcsr1_limit10_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_26 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_27;
// synthesis translate_on
always @(*) begin
	pair_fastchain1_paralleltaplimitcsr1_limit11_y <= 28'sd0;
	pair_fastchain1_paralleltaplimitcsr1_limit11_railed <= 1'd0;
	if ((pair_fastchain1_paralleltaplimitcsr1_limit11_x >= pair_fastchain1_paralleltaplimitcsr1_limit11_max)) begin
		pair_fastchain1_paralleltaplimitcsr1_limit11_y <= pair_fastchain1_paralleltaplimitcsr1_limit11_max;
		pair_fastchain1_paralleltaplimitcsr1_limit11_railed <= 1'd1;
	end else begin
		if ((pair_fastchain1_paralleltaplimitcsr1_limit11_x <= pair_fastchain1_paralleltaplimitcsr1_limit11_min)) begin
			pair_fastchain1_paralleltaplimitcsr1_limit11_y <= pair_fastchain1_paralleltaplimitcsr1_limit11_min;
			pair_fastchain1_paralleltaplimitcsr1_limit11_railed <= 1'd1;
		end else begin
			pair_fastchain1_paralleltaplimitcsr1_limit11_y <= pair_fastchain1_paralleltaplimitcsr1_limit11_x;
			pair_fastchain1_paralleltaplimitcsr1_limit11_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_27 <= dummy_s;
// synthesis translate_on
end
assign pair_csrbank1_sel = (pair_csrbank1_bus_adr[13:9] == 1'd0);
assign pair_csrbank1_y_tap0_r = pair_csrbank1_bus_dat_w[1:0];
assign pair_csrbank1_y_tap0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 1'd0));
assign pair_csrbank1_invert0_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_invert0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 1'd1));
assign pair_csrbank1_demod_delay3_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_demod_delay3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 2'd2));
assign pair_csrbank1_demod_delay2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_demod_delay2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 2'd3));
assign pair_csrbank1_demod_delay1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_demod_delay1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 3'd4));
assign pair_csrbank1_demod_delay0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_demod_delay0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 3'd5));
assign pair_csrbank1_demod_multiplier0_r = pair_csrbank1_bus_dat_w[3:0];
assign pair_csrbank1_demod_multiplier0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 3'd6));
assign pair_csrbank1_x_limit_1_min3_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_x_limit_1_min3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 3'd7));
assign pair_csrbank1_x_limit_1_min2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_1_min2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 4'd8));
assign pair_csrbank1_x_limit_1_min1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_1_min1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 4'd9));
assign pair_csrbank1_x_limit_1_min0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_1_min0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 4'd10));
assign pair_csrbank1_x_limit_1_max3_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_x_limit_1_max3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 4'd11));
assign pair_csrbank1_x_limit_1_max2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_1_max2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 4'd12));
assign pair_csrbank1_x_limit_1_max1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_1_max1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 4'd13));
assign pair_csrbank1_x_limit_1_max0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_1_max0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 4'd14));
assign pair_csrbank1_iir_c_1_z03_r = pair_csrbank1_bus_dat_w[2:0];
assign pair_csrbank1_iir_c_1_z03_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 4'd15));
assign pair_csrbank1_iir_c_1_z02_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_z02_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd16));
assign pair_csrbank1_iir_c_1_z01_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_z01_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd17));
assign pair_csrbank1_iir_c_1_z00_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_z00_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd18));
assign pair_csrbank1_iir_c_1_a13_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_c_1_a13_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd19));
assign pair_csrbank1_iir_c_1_a12_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_a12_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd20));
assign pair_csrbank1_iir_c_1_a11_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_a11_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd21));
assign pair_csrbank1_iir_c_1_a10_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_a10_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd22));
assign pair_csrbank1_iir_c_1_b03_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_c_1_b03_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd23));
assign pair_csrbank1_iir_c_1_b02_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_b02_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd24));
assign pair_csrbank1_iir_c_1_b01_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_b01_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd25));
assign pair_csrbank1_iir_c_1_b00_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_b00_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd26));
assign pair_csrbank1_iir_c_1_b13_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_c_1_b13_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd27));
assign pair_csrbank1_iir_c_1_b12_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_b12_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd28));
assign pair_csrbank1_iir_c_1_b11_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_b11_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd29));
assign pair_csrbank1_iir_c_1_b10_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_1_b10_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd30));
assign pair_csrbank1_iir_d_1_z03_r = pair_csrbank1_bus_dat_w[2:0];
assign pair_csrbank1_iir_d_1_z03_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 5'd31));
assign pair_csrbank1_iir_d_1_z02_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_z02_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd32));
assign pair_csrbank1_iir_d_1_z01_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_z01_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd33));
assign pair_csrbank1_iir_d_1_z00_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_z00_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd34));
assign pair_csrbank1_iir_d_1_a13_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_1_a13_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd35));
assign pair_csrbank1_iir_d_1_a12_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_a12_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd36));
assign pair_csrbank1_iir_d_1_a11_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_a11_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd37));
assign pair_csrbank1_iir_d_1_a10_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_a10_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd38));
assign pair_csrbank1_iir_d_1_a23_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_1_a23_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd39));
assign pair_csrbank1_iir_d_1_a22_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_a22_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd40));
assign pair_csrbank1_iir_d_1_a21_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_a21_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd41));
assign pair_csrbank1_iir_d_1_a20_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_a20_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd42));
assign pair_csrbank1_iir_d_1_b03_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_1_b03_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd43));
assign pair_csrbank1_iir_d_1_b02_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_b02_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd44));
assign pair_csrbank1_iir_d_1_b01_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_b01_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd45));
assign pair_csrbank1_iir_d_1_b00_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_b00_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd46));
assign pair_csrbank1_iir_d_1_b13_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_1_b13_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd47));
assign pair_csrbank1_iir_d_1_b12_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_b12_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd48));
assign pair_csrbank1_iir_d_1_b11_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_b11_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd49));
assign pair_csrbank1_iir_d_1_b10_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_b10_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd50));
assign pair_csrbank1_iir_d_1_b23_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_1_b23_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd51));
assign pair_csrbank1_iir_d_1_b22_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_b22_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd52));
assign pair_csrbank1_iir_d_1_b21_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_b21_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd53));
assign pair_csrbank1_iir_d_1_b20_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_1_b20_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd54));
assign pair_csrbank1_y_limit_1_min3_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_y_limit_1_min3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd55));
assign pair_csrbank1_y_limit_1_min2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_1_min2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd56));
assign pair_csrbank1_y_limit_1_min1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_1_min1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd57));
assign pair_csrbank1_y_limit_1_min0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_1_min0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd58));
assign pair_csrbank1_y_limit_1_max3_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_y_limit_1_max3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd59));
assign pair_csrbank1_y_limit_1_max2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_1_max2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd60));
assign pair_csrbank1_y_limit_1_max1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_1_max1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd61));
assign pair_csrbank1_y_limit_1_max0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_1_max0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd62));
assign pair_csrbank1_x_limit_2_min3_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_x_limit_2_min3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 6'd63));
assign pair_csrbank1_x_limit_2_min2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_2_min2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd64));
assign pair_csrbank1_x_limit_2_min1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_2_min1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd65));
assign pair_csrbank1_x_limit_2_min0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_2_min0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd66));
assign pair_csrbank1_x_limit_2_max3_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_x_limit_2_max3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd67));
assign pair_csrbank1_x_limit_2_max2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_2_max2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd68));
assign pair_csrbank1_x_limit_2_max1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_2_max1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd69));
assign pair_csrbank1_x_limit_2_max0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_x_limit_2_max0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd70));
assign pair_csrbank1_iir_c_2_z03_r = pair_csrbank1_bus_dat_w[2:0];
assign pair_csrbank1_iir_c_2_z03_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd71));
assign pair_csrbank1_iir_c_2_z02_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_z02_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd72));
assign pair_csrbank1_iir_c_2_z01_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_z01_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd73));
assign pair_csrbank1_iir_c_2_z00_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_z00_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd74));
assign pair_csrbank1_iir_c_2_a13_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_c_2_a13_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd75));
assign pair_csrbank1_iir_c_2_a12_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_a12_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd76));
assign pair_csrbank1_iir_c_2_a11_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_a11_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd77));
assign pair_csrbank1_iir_c_2_a10_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_a10_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd78));
assign pair_csrbank1_iir_c_2_b03_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_c_2_b03_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd79));
assign pair_csrbank1_iir_c_2_b02_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_b02_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd80));
assign pair_csrbank1_iir_c_2_b01_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_b01_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd81));
assign pair_csrbank1_iir_c_2_b00_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_b00_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd82));
assign pair_csrbank1_iir_c_2_b13_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_c_2_b13_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd83));
assign pair_csrbank1_iir_c_2_b12_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_b12_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd84));
assign pair_csrbank1_iir_c_2_b11_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_b11_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd85));
assign pair_csrbank1_iir_c_2_b10_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_c_2_b10_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd86));
assign pair_csrbank1_iir_d_2_z03_r = pair_csrbank1_bus_dat_w[2:0];
assign pair_csrbank1_iir_d_2_z03_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd87));
assign pair_csrbank1_iir_d_2_z02_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_z02_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd88));
assign pair_csrbank1_iir_d_2_z01_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_z01_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd89));
assign pair_csrbank1_iir_d_2_z00_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_z00_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd90));
assign pair_csrbank1_iir_d_2_a13_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_2_a13_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd91));
assign pair_csrbank1_iir_d_2_a12_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_a12_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd92));
assign pair_csrbank1_iir_d_2_a11_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_a11_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd93));
assign pair_csrbank1_iir_d_2_a10_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_a10_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd94));
assign pair_csrbank1_iir_d_2_a23_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_2_a23_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd95));
assign pair_csrbank1_iir_d_2_a22_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_a22_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd96));
assign pair_csrbank1_iir_d_2_a21_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_a21_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd97));
assign pair_csrbank1_iir_d_2_a20_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_a20_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd98));
assign pair_csrbank1_iir_d_2_b03_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_2_b03_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd99));
assign pair_csrbank1_iir_d_2_b02_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_b02_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd100));
assign pair_csrbank1_iir_d_2_b01_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_b01_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd101));
assign pair_csrbank1_iir_d_2_b00_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_b00_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd102));
assign pair_csrbank1_iir_d_2_b13_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_2_b13_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd103));
assign pair_csrbank1_iir_d_2_b12_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_b12_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd104));
assign pair_csrbank1_iir_d_2_b11_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_b11_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd105));
assign pair_csrbank1_iir_d_2_b10_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_b10_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd106));
assign pair_csrbank1_iir_d_2_b23_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_iir_d_2_b23_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd107));
assign pair_csrbank1_iir_d_2_b22_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_b22_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd108));
assign pair_csrbank1_iir_d_2_b21_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_b21_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd109));
assign pair_csrbank1_iir_d_2_b20_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_iir_d_2_b20_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd110));
assign pair_csrbank1_y_limit_2_min3_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_y_limit_2_min3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd111));
assign pair_csrbank1_y_limit_2_min2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_2_min2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd112));
assign pair_csrbank1_y_limit_2_min1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_2_min1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd113));
assign pair_csrbank1_y_limit_2_min0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_2_min0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd114));
assign pair_csrbank1_y_limit_2_max3_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_y_limit_2_max3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd115));
assign pair_csrbank1_y_limit_2_max2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_2_max2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd116));
assign pair_csrbank1_y_limit_2_max1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_2_max1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd117));
assign pair_csrbank1_y_limit_2_max0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_y_limit_2_max0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[6:0] == 7'd118));
assign pair_fastchain1_y_tap_storage = pair_fastchain1_y_tap_storage_full[1:0];
assign pair_csrbank1_y_tap0_w = pair_fastchain1_y_tap_storage_full[1:0];
assign pair_fastchain1_invert_storage = pair_fastchain1_invert_storage_full;
assign pair_csrbank1_invert0_w = pair_fastchain1_invert_storage_full;
assign pair_fastchain1_delay_storage = pair_fastchain1_delay_storage_full[31:0];
assign pair_csrbank1_demod_delay3_w = pair_fastchain1_delay_storage_full[31:24];
assign pair_csrbank1_demod_delay2_w = pair_fastchain1_delay_storage_full[23:16];
assign pair_csrbank1_demod_delay1_w = pair_fastchain1_delay_storage_full[15:8];
assign pair_csrbank1_demod_delay0_w = pair_fastchain1_delay_storage_full[7:0];
assign pair_fastchain1_multiplier_storage = pair_fastchain1_multiplier_storage_full[3:0];
assign pair_csrbank1_demod_multiplier0_w = pair_fastchain1_multiplier_storage_full[3:0];
assign pair_fastchain1_limitcsr2_min_storage = pair_fastchain1_limitcsr2_min_storage_full[24:0];
assign pair_csrbank1_x_limit_1_min3_w = pair_fastchain1_limitcsr2_min_storage_full[24];
assign pair_csrbank1_x_limit_1_min2_w = pair_fastchain1_limitcsr2_min_storage_full[23:16];
assign pair_csrbank1_x_limit_1_min1_w = pair_fastchain1_limitcsr2_min_storage_full[15:8];
assign pair_csrbank1_x_limit_1_min0_w = pair_fastchain1_limitcsr2_min_storage_full[7:0];
assign pair_fastchain1_limitcsr2_max_storage = pair_fastchain1_limitcsr2_max_storage_full[24:0];
assign pair_csrbank1_x_limit_1_max3_w = pair_fastchain1_limitcsr2_max_storage_full[24];
assign pair_csrbank1_x_limit_1_max2_w = pair_fastchain1_limitcsr2_max_storage_full[23:16];
assign pair_csrbank1_x_limit_1_max1_w = pair_fastchain1_limitcsr2_max_storage_full[15:8];
assign pair_csrbank1_x_limit_1_max0_w = pair_fastchain1_limitcsr2_max_storage_full[7:0];
assign pair_fastchain1_iir2_storage0 = pair_fastchain1_iir2_storage_full0[26:0];
assign pair_csrbank1_iir_c_1_z03_w = pair_fastchain1_iir2_storage_full0[26:24];
assign pair_csrbank1_iir_c_1_z02_w = pair_fastchain1_iir2_storage_full0[23:16];
assign pair_csrbank1_iir_c_1_z01_w = pair_fastchain1_iir2_storage_full0[15:8];
assign pair_csrbank1_iir_c_1_z00_w = pair_fastchain1_iir2_storage_full0[7:0];
assign pair_fastchain1_iir2_csrstorage6_storage = pair_fastchain1_iir2_csrstorage6_storage_full[24:0];
assign pair_csrbank1_iir_c_1_a13_w = pair_fastchain1_iir2_csrstorage6_storage_full[24];
assign pair_csrbank1_iir_c_1_a12_w = pair_fastchain1_iir2_csrstorage6_storage_full[23:16];
assign pair_csrbank1_iir_c_1_a11_w = pair_fastchain1_iir2_csrstorage6_storage_full[15:8];
assign pair_csrbank1_iir_c_1_a10_w = pair_fastchain1_iir2_csrstorage6_storage_full[7:0];
assign pair_fastchain1_iir2_csrstorage7_storage = pair_fastchain1_iir2_csrstorage7_storage_full[24:0];
assign pair_csrbank1_iir_c_1_b03_w = pair_fastchain1_iir2_csrstorage7_storage_full[24];
assign pair_csrbank1_iir_c_1_b02_w = pair_fastchain1_iir2_csrstorage7_storage_full[23:16];
assign pair_csrbank1_iir_c_1_b01_w = pair_fastchain1_iir2_csrstorage7_storage_full[15:8];
assign pair_csrbank1_iir_c_1_b00_w = pair_fastchain1_iir2_csrstorage7_storage_full[7:0];
assign pair_fastchain1_iir2_csrstorage8_storage = pair_fastchain1_iir2_csrstorage8_storage_full[24:0];
assign pair_csrbank1_iir_c_1_b13_w = pair_fastchain1_iir2_csrstorage8_storage_full[24];
assign pair_csrbank1_iir_c_1_b12_w = pair_fastchain1_iir2_csrstorage8_storage_full[23:16];
assign pair_csrbank1_iir_c_1_b11_w = pair_fastchain1_iir2_csrstorage8_storage_full[15:8];
assign pair_csrbank1_iir_c_1_b10_w = pair_fastchain1_iir2_csrstorage8_storage_full[7:0];
assign pair_fastchain1_iir2_storage1 = pair_fastchain1_iir2_storage_full1[26:0];
assign pair_csrbank1_iir_d_1_z03_w = pair_fastchain1_iir2_storage_full1[26:24];
assign pair_csrbank1_iir_d_1_z02_w = pair_fastchain1_iir2_storage_full1[23:16];
assign pair_csrbank1_iir_d_1_z01_w = pair_fastchain1_iir2_storage_full1[15:8];
assign pair_csrbank1_iir_d_1_z00_w = pair_fastchain1_iir2_storage_full1[7:0];
assign pair_fastchain1_iir2_csrstorage10_storage = pair_fastchain1_iir2_csrstorage10_storage_full[24:0];
assign pair_csrbank1_iir_d_1_a13_w = pair_fastchain1_iir2_csrstorage10_storage_full[24];
assign pair_csrbank1_iir_d_1_a12_w = pair_fastchain1_iir2_csrstorage10_storage_full[23:16];
assign pair_csrbank1_iir_d_1_a11_w = pair_fastchain1_iir2_csrstorage10_storage_full[15:8];
assign pair_csrbank1_iir_d_1_a10_w = pair_fastchain1_iir2_csrstorage10_storage_full[7:0];
assign pair_fastchain1_iir2_csrstorage11_storage = pair_fastchain1_iir2_csrstorage11_storage_full[24:0];
assign pair_csrbank1_iir_d_1_a23_w = pair_fastchain1_iir2_csrstorage11_storage_full[24];
assign pair_csrbank1_iir_d_1_a22_w = pair_fastchain1_iir2_csrstorage11_storage_full[23:16];
assign pair_csrbank1_iir_d_1_a21_w = pair_fastchain1_iir2_csrstorage11_storage_full[15:8];
assign pair_csrbank1_iir_d_1_a20_w = pair_fastchain1_iir2_csrstorage11_storage_full[7:0];
assign pair_fastchain1_iir2_csrstorage12_storage = pair_fastchain1_iir2_csrstorage12_storage_full[24:0];
assign pair_csrbank1_iir_d_1_b03_w = pair_fastchain1_iir2_csrstorage12_storage_full[24];
assign pair_csrbank1_iir_d_1_b02_w = pair_fastchain1_iir2_csrstorage12_storage_full[23:16];
assign pair_csrbank1_iir_d_1_b01_w = pair_fastchain1_iir2_csrstorage12_storage_full[15:8];
assign pair_csrbank1_iir_d_1_b00_w = pair_fastchain1_iir2_csrstorage12_storage_full[7:0];
assign pair_fastchain1_iir2_csrstorage13_storage = pair_fastchain1_iir2_csrstorage13_storage_full[24:0];
assign pair_csrbank1_iir_d_1_b13_w = pair_fastchain1_iir2_csrstorage13_storage_full[24];
assign pair_csrbank1_iir_d_1_b12_w = pair_fastchain1_iir2_csrstorage13_storage_full[23:16];
assign pair_csrbank1_iir_d_1_b11_w = pair_fastchain1_iir2_csrstorage13_storage_full[15:8];
assign pair_csrbank1_iir_d_1_b10_w = pair_fastchain1_iir2_csrstorage13_storage_full[7:0];
assign pair_fastchain1_iir2_csrstorage14_storage = pair_fastchain1_iir2_csrstorage14_storage_full[24:0];
assign pair_csrbank1_iir_d_1_b23_w = pair_fastchain1_iir2_csrstorage14_storage_full[24];
assign pair_csrbank1_iir_d_1_b22_w = pair_fastchain1_iir2_csrstorage14_storage_full[23:16];
assign pair_csrbank1_iir_d_1_b21_w = pair_fastchain1_iir2_csrstorage14_storage_full[15:8];
assign pair_csrbank1_iir_d_1_b20_w = pair_fastchain1_iir2_csrstorage14_storage_full[7:0];
assign pair_fastchain1_paralleltaplimitcsr0_min_storage = pair_fastchain1_paralleltaplimitcsr0_min_storage_full[24:0];
assign pair_csrbank1_y_limit_1_min3_w = pair_fastchain1_paralleltaplimitcsr0_min_storage_full[24];
assign pair_csrbank1_y_limit_1_min2_w = pair_fastchain1_paralleltaplimitcsr0_min_storage_full[23:16];
assign pair_csrbank1_y_limit_1_min1_w = pair_fastchain1_paralleltaplimitcsr0_min_storage_full[15:8];
assign pair_csrbank1_y_limit_1_min0_w = pair_fastchain1_paralleltaplimitcsr0_min_storage_full[7:0];
assign pair_fastchain1_paralleltaplimitcsr0_max_storage = pair_fastchain1_paralleltaplimitcsr0_max_storage_full[24:0];
assign pair_csrbank1_y_limit_1_max3_w = pair_fastchain1_paralleltaplimitcsr0_max_storage_full[24];
assign pair_csrbank1_y_limit_1_max2_w = pair_fastchain1_paralleltaplimitcsr0_max_storage_full[23:16];
assign pair_csrbank1_y_limit_1_max1_w = pair_fastchain1_paralleltaplimitcsr0_max_storage_full[15:8];
assign pair_csrbank1_y_limit_1_max0_w = pair_fastchain1_paralleltaplimitcsr0_max_storage_full[7:0];
assign pair_fastchain1_limitcsr3_min_storage = pair_fastchain1_limitcsr3_min_storage_full[24:0];
assign pair_csrbank1_x_limit_2_min3_w = pair_fastchain1_limitcsr3_min_storage_full[24];
assign pair_csrbank1_x_limit_2_min2_w = pair_fastchain1_limitcsr3_min_storage_full[23:16];
assign pair_csrbank1_x_limit_2_min1_w = pair_fastchain1_limitcsr3_min_storage_full[15:8];
assign pair_csrbank1_x_limit_2_min0_w = pair_fastchain1_limitcsr3_min_storage_full[7:0];
assign pair_fastchain1_limitcsr3_max_storage = pair_fastchain1_limitcsr3_max_storage_full[24:0];
assign pair_csrbank1_x_limit_2_max3_w = pair_fastchain1_limitcsr3_max_storage_full[24];
assign pair_csrbank1_x_limit_2_max2_w = pair_fastchain1_limitcsr3_max_storage_full[23:16];
assign pair_csrbank1_x_limit_2_max1_w = pair_fastchain1_limitcsr3_max_storage_full[15:8];
assign pair_csrbank1_x_limit_2_max0_w = pair_fastchain1_limitcsr3_max_storage_full[7:0];
assign pair_fastchain1_iir3_storage0 = pair_fastchain1_iir3_storage_full0[26:0];
assign pair_csrbank1_iir_c_2_z03_w = pair_fastchain1_iir3_storage_full0[26:24];
assign pair_csrbank1_iir_c_2_z02_w = pair_fastchain1_iir3_storage_full0[23:16];
assign pair_csrbank1_iir_c_2_z01_w = pair_fastchain1_iir3_storage_full0[15:8];
assign pair_csrbank1_iir_c_2_z00_w = pair_fastchain1_iir3_storage_full0[7:0];
assign pair_fastchain1_iir3_csrstorage9_storage = pair_fastchain1_iir3_csrstorage9_storage_full[24:0];
assign pair_csrbank1_iir_c_2_a13_w = pair_fastchain1_iir3_csrstorage9_storage_full[24];
assign pair_csrbank1_iir_c_2_a12_w = pair_fastchain1_iir3_csrstorage9_storage_full[23:16];
assign pair_csrbank1_iir_c_2_a11_w = pair_fastchain1_iir3_csrstorage9_storage_full[15:8];
assign pair_csrbank1_iir_c_2_a10_w = pair_fastchain1_iir3_csrstorage9_storage_full[7:0];
assign pair_fastchain1_iir3_csrstorage10_storage = pair_fastchain1_iir3_csrstorage10_storage_full[24:0];
assign pair_csrbank1_iir_c_2_b03_w = pair_fastchain1_iir3_csrstorage10_storage_full[24];
assign pair_csrbank1_iir_c_2_b02_w = pair_fastchain1_iir3_csrstorage10_storage_full[23:16];
assign pair_csrbank1_iir_c_2_b01_w = pair_fastchain1_iir3_csrstorage10_storage_full[15:8];
assign pair_csrbank1_iir_c_2_b00_w = pair_fastchain1_iir3_csrstorage10_storage_full[7:0];
assign pair_fastchain1_iir3_csrstorage11_storage = pair_fastchain1_iir3_csrstorage11_storage_full[24:0];
assign pair_csrbank1_iir_c_2_b13_w = pair_fastchain1_iir3_csrstorage11_storage_full[24];
assign pair_csrbank1_iir_c_2_b12_w = pair_fastchain1_iir3_csrstorage11_storage_full[23:16];
assign pair_csrbank1_iir_c_2_b11_w = pair_fastchain1_iir3_csrstorage11_storage_full[15:8];
assign pair_csrbank1_iir_c_2_b10_w = pair_fastchain1_iir3_csrstorage11_storage_full[7:0];
assign pair_fastchain1_iir3_storage1 = pair_fastchain1_iir3_storage_full1[26:0];
assign pair_csrbank1_iir_d_2_z03_w = pair_fastchain1_iir3_storage_full1[26:24];
assign pair_csrbank1_iir_d_2_z02_w = pair_fastchain1_iir3_storage_full1[23:16];
assign pair_csrbank1_iir_d_2_z01_w = pair_fastchain1_iir3_storage_full1[15:8];
assign pair_csrbank1_iir_d_2_z00_w = pair_fastchain1_iir3_storage_full1[7:0];
assign pair_fastchain1_iir3_csrstorage15_storage = pair_fastchain1_iir3_csrstorage15_storage_full[24:0];
assign pair_csrbank1_iir_d_2_a13_w = pair_fastchain1_iir3_csrstorage15_storage_full[24];
assign pair_csrbank1_iir_d_2_a12_w = pair_fastchain1_iir3_csrstorage15_storage_full[23:16];
assign pair_csrbank1_iir_d_2_a11_w = pair_fastchain1_iir3_csrstorage15_storage_full[15:8];
assign pair_csrbank1_iir_d_2_a10_w = pair_fastchain1_iir3_csrstorage15_storage_full[7:0];
assign pair_fastchain1_iir3_csrstorage16_storage = pair_fastchain1_iir3_csrstorage16_storage_full[24:0];
assign pair_csrbank1_iir_d_2_a23_w = pair_fastchain1_iir3_csrstorage16_storage_full[24];
assign pair_csrbank1_iir_d_2_a22_w = pair_fastchain1_iir3_csrstorage16_storage_full[23:16];
assign pair_csrbank1_iir_d_2_a21_w = pair_fastchain1_iir3_csrstorage16_storage_full[15:8];
assign pair_csrbank1_iir_d_2_a20_w = pair_fastchain1_iir3_csrstorage16_storage_full[7:0];
assign pair_fastchain1_iir3_csrstorage17_storage = pair_fastchain1_iir3_csrstorage17_storage_full[24:0];
assign pair_csrbank1_iir_d_2_b03_w = pair_fastchain1_iir3_csrstorage17_storage_full[24];
assign pair_csrbank1_iir_d_2_b02_w = pair_fastchain1_iir3_csrstorage17_storage_full[23:16];
assign pair_csrbank1_iir_d_2_b01_w = pair_fastchain1_iir3_csrstorage17_storage_full[15:8];
assign pair_csrbank1_iir_d_2_b00_w = pair_fastchain1_iir3_csrstorage17_storage_full[7:0];
assign pair_fastchain1_iir3_csrstorage18_storage = pair_fastchain1_iir3_csrstorage18_storage_full[24:0];
assign pair_csrbank1_iir_d_2_b13_w = pair_fastchain1_iir3_csrstorage18_storage_full[24];
assign pair_csrbank1_iir_d_2_b12_w = pair_fastchain1_iir3_csrstorage18_storage_full[23:16];
assign pair_csrbank1_iir_d_2_b11_w = pair_fastchain1_iir3_csrstorage18_storage_full[15:8];
assign pair_csrbank1_iir_d_2_b10_w = pair_fastchain1_iir3_csrstorage18_storage_full[7:0];
assign pair_fastchain1_iir3_csrstorage19_storage = pair_fastchain1_iir3_csrstorage19_storage_full[24:0];
assign pair_csrbank1_iir_d_2_b23_w = pair_fastchain1_iir3_csrstorage19_storage_full[24];
assign pair_csrbank1_iir_d_2_b22_w = pair_fastchain1_iir3_csrstorage19_storage_full[23:16];
assign pair_csrbank1_iir_d_2_b21_w = pair_fastchain1_iir3_csrstorage19_storage_full[15:8];
assign pair_csrbank1_iir_d_2_b20_w = pair_fastchain1_iir3_csrstorage19_storage_full[7:0];
assign pair_fastchain1_paralleltaplimitcsr1_min_storage = pair_fastchain1_paralleltaplimitcsr1_min_storage_full[24:0];
assign pair_csrbank1_y_limit_2_min3_w = pair_fastchain1_paralleltaplimitcsr1_min_storage_full[24];
assign pair_csrbank1_y_limit_2_min2_w = pair_fastchain1_paralleltaplimitcsr1_min_storage_full[23:16];
assign pair_csrbank1_y_limit_2_min1_w = pair_fastchain1_paralleltaplimitcsr1_min_storage_full[15:8];
assign pair_csrbank1_y_limit_2_min0_w = pair_fastchain1_paralleltaplimitcsr1_min_storage_full[7:0];
assign pair_fastchain1_paralleltaplimitcsr1_max_storage = pair_fastchain1_paralleltaplimitcsr1_max_storage_full[24:0];
assign pair_csrbank1_y_limit_2_max3_w = pair_fastchain1_paralleltaplimitcsr1_max_storage_full[24];
assign pair_csrbank1_y_limit_2_max2_w = pair_fastchain1_paralleltaplimitcsr1_max_storage_full[23:16];
assign pair_csrbank1_y_limit_2_max1_w = pair_fastchain1_paralleltaplimitcsr1_max_storage_full[15:8];
assign pair_csrbank1_y_limit_2_max0_w = pair_fastchain1_paralleltaplimitcsr1_max_storage_full[7:0];

// synthesis translate_off
reg dummy_d_28;
// synthesis translate_on
always @(*) begin
	array_muxed0 <= 25'sd0;
	case (pair_fastchain0_y_tap_storage)
		1'd0: begin
			array_muxed0 <= pair_fastchain0_iir0_x0;
		end
		1'd1: begin
			array_muxed0 <= pair_fastchain0_iir0_y0;
		end
		default: begin
			array_muxed0 <= pair_fastchain0_iir0_y2;
		end
	endcase
// synthesis translate_off
	dummy_d_28 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_29;
// synthesis translate_on
always @(*) begin
	array_muxed1 <= 25'sd0;
	case (pair_fastchain0_y_tap_storage)
		1'd0: begin
			array_muxed1 <= pair_fastchain0_iir1_x0;
		end
		1'd1: begin
			array_muxed1 <= pair_fastchain0_iir1_y0;
		end
		default: begin
			array_muxed1 <= pair_fastchain0_iir1_y2;
		end
	endcase
// synthesis translate_off
	dummy_d_29 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_30;
// synthesis translate_on
always @(*) begin
	array_muxed2 <= 28'sd0;
	case (pair_fastchain1_paralleltaplimitcsr03)
		1'd0: begin
			array_muxed2 <= pair_fastchain1_paralleltaplimitcsr0_limit1_y;
		end
		1'd1: begin
			array_muxed2 <= pair_fastchain1_paralleltaplimitcsr0_limit3_y;
		end
		default: begin
			array_muxed2 <= pair_fastchain1_paralleltaplimitcsr0_limit5_y;
		end
	endcase
// synthesis translate_off
	dummy_d_30 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_31;
// synthesis translate_on
always @(*) begin
	array_muxed3 <= 28'sd0;
	case (pair_fastchain1_paralleltaplimitcsr03)
		1'd0: begin
			array_muxed3 <= pair_fastchain1_paralleltaplimitcsr0_limit0_y;
		end
		1'd1: begin
			array_muxed3 <= pair_fastchain1_paralleltaplimitcsr0_limit2_y;
		end
		default: begin
			array_muxed3 <= pair_fastchain1_paralleltaplimitcsr0_limit4_y;
		end
	endcase
// synthesis translate_off
	dummy_d_31 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_32;
// synthesis translate_on
always @(*) begin
	array_muxed4 <= 1'd0;
	case (pair_fastchain1_paralleltaplimitcsr03)
		1'd0: begin
			array_muxed4 <= pair_fastchain1_paralleltaplimitcsr0_limit1_railed;
		end
		1'd1: begin
			array_muxed4 <= pair_fastchain1_paralleltaplimitcsr0_limit3_railed;
		end
		default: begin
			array_muxed4 <= pair_fastchain1_paralleltaplimitcsr0_limit5_railed;
		end
	endcase
// synthesis translate_off
	dummy_d_32 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_33;
// synthesis translate_on
always @(*) begin
	array_muxed5 <= 1'd0;
	case (pair_fastchain1_paralleltaplimitcsr03)
		1'd0: begin
			array_muxed5 <= pair_fastchain1_paralleltaplimitcsr0_limit0_railed;
		end
		1'd1: begin
			array_muxed5 <= pair_fastchain1_paralleltaplimitcsr0_limit2_railed;
		end
		default: begin
			array_muxed5 <= pair_fastchain1_paralleltaplimitcsr0_limit4_railed;
		end
	endcase
// synthesis translate_off
	dummy_d_33 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_34;
// synthesis translate_on
always @(*) begin
	array_muxed6 <= 28'sd0;
	case (pair_fastchain1_paralleltaplimitcsr13)
		1'd0: begin
			array_muxed6 <= pair_fastchain1_paralleltaplimitcsr1_limit7_y;
		end
		1'd1: begin
			array_muxed6 <= pair_fastchain1_paralleltaplimitcsr1_limit9_y;
		end
		default: begin
			array_muxed6 <= pair_fastchain1_paralleltaplimitcsr1_limit11_y;
		end
	endcase
// synthesis translate_off
	dummy_d_34 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_35;
// synthesis translate_on
always @(*) begin
	array_muxed7 <= 28'sd0;
	case (pair_fastchain1_paralleltaplimitcsr13)
		1'd0: begin
			array_muxed7 <= pair_fastchain1_paralleltaplimitcsr1_limit6_y;
		end
		1'd1: begin
			array_muxed7 <= pair_fastchain1_paralleltaplimitcsr1_limit8_y;
		end
		default: begin
			array_muxed7 <= pair_fastchain1_paralleltaplimitcsr1_limit10_y;
		end
	endcase
// synthesis translate_off
	dummy_d_35 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_36;
// synthesis translate_on
always @(*) begin
	array_muxed8 <= 1'd0;
	case (pair_fastchain1_paralleltaplimitcsr13)
		1'd0: begin
			array_muxed8 <= pair_fastchain1_paralleltaplimitcsr1_limit7_railed;
		end
		1'd1: begin
			array_muxed8 <= pair_fastchain1_paralleltaplimitcsr1_limit9_railed;
		end
		default: begin
			array_muxed8 <= pair_fastchain1_paralleltaplimitcsr1_limit11_railed;
		end
	endcase
// synthesis translate_off
	dummy_d_36 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_37;
// synthesis translate_on
always @(*) begin
	array_muxed9 <= 1'd0;
	case (pair_fastchain1_paralleltaplimitcsr13)
		1'd0: begin
			array_muxed9 <= pair_fastchain1_paralleltaplimitcsr1_limit6_railed;
		end
		1'd1: begin
			array_muxed9 <= pair_fastchain1_paralleltaplimitcsr1_limit8_railed;
		end
		default: begin
			array_muxed9 <= pair_fastchain1_paralleltaplimitcsr1_limit10_railed;
		end
	endcase
// synthesis translate_off
	dummy_d_37 <= dummy_s;
// synthesis translate_on
end

always @(posedge sys_clk) begin
	pair_fastchain0_ya <= (pair_fastchain0_dy >>> 4'd11);
	pair_fastchain0_cordic01 <= (pair_fastchain0_cordic00 + (pair_fastchain0_cordic0_dir0 ? (pair_fastchain0_cordic016 >>> 1'd0) : (-(pair_fastchain0_cordic016 >>> 1'd0))));
	pair_fastchain0_cordic017 <= (pair_fastchain0_cordic016 + (pair_fastchain0_cordic0_dir0 ? (-(pair_fastchain0_cordic00 >>> 1'd0)) : (pair_fastchain0_cordic00 >>> 1'd0)));
	pair_fastchain0_cordic033 <= (pair_fastchain0_cordic032 + (pair_fastchain0_cordic0_dir0 ? $signed({1'd0, 15'd16384}) : 15'sd16384));
	pair_fastchain0_cordic02 <= (pair_fastchain0_cordic01 + (pair_fastchain0_cordic0_dir1 ? (pair_fastchain0_cordic017 >>> 1'd1) : (-(pair_fastchain0_cordic017 >>> 1'd1))));
	pair_fastchain0_cordic018 <= (pair_fastchain0_cordic017 + (pair_fastchain0_cordic0_dir1 ? (-(pair_fastchain0_cordic01 >>> 1'd1)) : (pair_fastchain0_cordic01 >>> 1'd1)));
	pair_fastchain0_cordic034 <= (pair_fastchain0_cordic033 + (pair_fastchain0_cordic0_dir1 ? $signed({1'd0, 14'd9672}) : 15'sd23096));
	pair_fastchain0_cordic03 <= (pair_fastchain0_cordic02 + (pair_fastchain0_cordic0_dir2 ? (pair_fastchain0_cordic018 >>> 2'd2) : (-(pair_fastchain0_cordic018 >>> 2'd2))));
	pair_fastchain0_cordic019 <= (pair_fastchain0_cordic018 + (pair_fastchain0_cordic0_dir2 ? (-(pair_fastchain0_cordic02 >>> 2'd2)) : (pair_fastchain0_cordic02 >>> 2'd2)));
	pair_fastchain0_cordic035 <= (pair_fastchain0_cordic034 + (pair_fastchain0_cordic0_dir2 ? $signed({1'd0, 13'd5110}) : 14'sd11274));
	pair_fastchain0_cordic04 <= (pair_fastchain0_cordic03 + (pair_fastchain0_cordic0_dir3 ? (pair_fastchain0_cordic019 >>> 2'd3) : (-(pair_fastchain0_cordic019 >>> 2'd3))));
	pair_fastchain0_cordic020 <= (pair_fastchain0_cordic019 + (pair_fastchain0_cordic0_dir3 ? (-(pair_fastchain0_cordic03 >>> 2'd3)) : (pair_fastchain0_cordic03 >>> 2'd3)));
	pair_fastchain0_cordic036 <= (pair_fastchain0_cordic035 + (pair_fastchain0_cordic0_dir3 ? $signed({1'd0, 12'd2594}) : 13'sd5598));
	pair_fastchain0_cordic05 <= (pair_fastchain0_cordic04 + (pair_fastchain0_cordic0_dir4 ? (pair_fastchain0_cordic020 >>> 3'd4) : (-(pair_fastchain0_cordic020 >>> 3'd4))));
	pair_fastchain0_cordic021 <= (pair_fastchain0_cordic020 + (pair_fastchain0_cordic0_dir4 ? (-(pair_fastchain0_cordic04 >>> 3'd4)) : (pair_fastchain0_cordic04 >>> 3'd4)));
	pair_fastchain0_cordic037 <= (pair_fastchain0_cordic036 + (pair_fastchain0_cordic0_dir4 ? $signed({1'd0, 11'd1302}) : 12'sd2794));
	pair_fastchain0_cordic06 <= (pair_fastchain0_cordic05 + (pair_fastchain0_cordic0_dir5 ? (pair_fastchain0_cordic021 >>> 3'd5) : (-(pair_fastchain0_cordic021 >>> 3'd5))));
	pair_fastchain0_cordic022 <= (pair_fastchain0_cordic021 + (pair_fastchain0_cordic0_dir5 ? (-(pair_fastchain0_cordic05 >>> 3'd5)) : (pair_fastchain0_cordic05 >>> 3'd5)));
	pair_fastchain0_cordic038 <= (pair_fastchain0_cordic037 + (pair_fastchain0_cordic0_dir5 ? $signed({1'd0, 10'd652}) : 11'sd1396));
	pair_fastchain0_cordic07 <= (pair_fastchain0_cordic06 + (pair_fastchain0_cordic0_dir6 ? (pair_fastchain0_cordic022 >>> 3'd6) : (-(pair_fastchain0_cordic022 >>> 3'd6))));
	pair_fastchain0_cordic023 <= (pair_fastchain0_cordic022 + (pair_fastchain0_cordic0_dir6 ? (-(pair_fastchain0_cordic06 >>> 3'd6)) : (pair_fastchain0_cordic06 >>> 3'd6)));
	pair_fastchain0_cordic039 <= (pair_fastchain0_cordic038 + (pair_fastchain0_cordic0_dir6 ? $signed({1'd0, 9'd326}) : 10'sd698));
	pair_fastchain0_cordic08 <= (pair_fastchain0_cordic07 + (pair_fastchain0_cordic0_dir7 ? (pair_fastchain0_cordic023 >>> 3'd7) : (-(pair_fastchain0_cordic023 >>> 3'd7))));
	pair_fastchain0_cordic024 <= (pair_fastchain0_cordic023 + (pair_fastchain0_cordic0_dir7 ? (-(pair_fastchain0_cordic07 >>> 3'd7)) : (pair_fastchain0_cordic07 >>> 3'd7)));
	pair_fastchain0_cordic040 <= (pair_fastchain0_cordic039 + (pair_fastchain0_cordic0_dir7 ? $signed({1'd0, 8'd163}) : 9'sd349));
	pair_fastchain0_cordic09 <= (pair_fastchain0_cordic08 + (pair_fastchain0_cordic0_dir8 ? (pair_fastchain0_cordic024 >>> 4'd8) : (-(pair_fastchain0_cordic024 >>> 4'd8))));
	pair_fastchain0_cordic025 <= (pair_fastchain0_cordic024 + (pair_fastchain0_cordic0_dir8 ? (-(pair_fastchain0_cordic08 >>> 4'd8)) : (pair_fastchain0_cordic08 >>> 4'd8)));
	pair_fastchain0_cordic041 <= (pair_fastchain0_cordic040 + (pair_fastchain0_cordic0_dir8 ? $signed({1'd0, 7'd81}) : 8'sd175));
	pair_fastchain0_cordic010 <= (pair_fastchain0_cordic09 + (pair_fastchain0_cordic0_dir9 ? (pair_fastchain0_cordic025 >>> 4'd9) : (-(pair_fastchain0_cordic025 >>> 4'd9))));
	pair_fastchain0_cordic026 <= (pair_fastchain0_cordic025 + (pair_fastchain0_cordic0_dir9 ? (-(pair_fastchain0_cordic09 >>> 4'd9)) : (pair_fastchain0_cordic09 >>> 4'd9)));
	pair_fastchain0_cordic042 <= (pair_fastchain0_cordic041 + (pair_fastchain0_cordic0_dir9 ? $signed({1'd0, 6'd41}) : 7'sd87));
	pair_fastchain0_cordic011 <= (pair_fastchain0_cordic010 + (pair_fastchain0_cordic0_dir10 ? (pair_fastchain0_cordic026 >>> 4'd10) : (-(pair_fastchain0_cordic026 >>> 4'd10))));
	pair_fastchain0_cordic027 <= (pair_fastchain0_cordic026 + (pair_fastchain0_cordic0_dir10 ? (-(pair_fastchain0_cordic010 >>> 4'd10)) : (pair_fastchain0_cordic010 >>> 4'd10)));
	pair_fastchain0_cordic043 <= (pair_fastchain0_cordic042 + (pair_fastchain0_cordic0_dir10 ? $signed({1'd0, 5'd20}) : 6'sd44));
	pair_fastchain0_cordic012 <= (pair_fastchain0_cordic011 + (pair_fastchain0_cordic0_dir11 ? (pair_fastchain0_cordic027 >>> 4'd11) : (-(pair_fastchain0_cordic027 >>> 4'd11))));
	pair_fastchain0_cordic028 <= (pair_fastchain0_cordic027 + (pair_fastchain0_cordic0_dir11 ? (-(pair_fastchain0_cordic011 >>> 4'd11)) : (pair_fastchain0_cordic011 >>> 4'd11)));
	pair_fastchain0_cordic044 <= (pair_fastchain0_cordic043 + (pair_fastchain0_cordic0_dir11 ? $signed({1'd0, 4'd10}) : 5'sd22));
	pair_fastchain0_cordic013 <= (pair_fastchain0_cordic012 + (pair_fastchain0_cordic0_dir12 ? (pair_fastchain0_cordic028 >>> 4'd12) : (-(pair_fastchain0_cordic028 >>> 4'd12))));
	pair_fastchain0_cordic029 <= (pair_fastchain0_cordic028 + (pair_fastchain0_cordic0_dir12 ? (-(pair_fastchain0_cordic012 >>> 4'd12)) : (pair_fastchain0_cordic012 >>> 4'd12)));
	pair_fastchain0_cordic045 <= (pair_fastchain0_cordic044 + (pair_fastchain0_cordic0_dir12 ? $signed({1'd0, 3'd5}) : 4'sd11));
	pair_fastchain0_cordic014 <= (pair_fastchain0_cordic013 + (pair_fastchain0_cordic0_dir13 ? (pair_fastchain0_cordic029 >>> 4'd13) : (-(pair_fastchain0_cordic029 >>> 4'd13))));
	pair_fastchain0_cordic030 <= (pair_fastchain0_cordic029 + (pair_fastchain0_cordic0_dir13 ? (-(pair_fastchain0_cordic013 >>> 4'd13)) : (pair_fastchain0_cordic013 >>> 4'd13)));
	pair_fastchain0_cordic046 <= (pair_fastchain0_cordic045 + (pair_fastchain0_cordic0_dir13 ? $signed({1'd0, 2'd3}) : 3'sd5));
	pair_fastchain0_cordic015 <= (pair_fastchain0_cordic014 + (pair_fastchain0_cordic0_dir14 ? (pair_fastchain0_cordic030 >>> 4'd14) : (-(pair_fastchain0_cordic030 >>> 4'd14))));
	pair_fastchain0_cordic031 <= (pair_fastchain0_cordic030 + (pair_fastchain0_cordic0_dir14 ? (-(pair_fastchain0_cordic014 >>> 4'd14)) : (pair_fastchain0_cordic014 >>> 4'd14)));
	pair_fastchain0_cordic047 <= (pair_fastchain0_cordic046 + (pair_fastchain0_cordic0_dir14 ? $signed({1'd0, 1'd1}) : 1'sd1));
	if (pair_fastchain0_limitcsr0_update_en0) begin
		pair_fastchain0_limitcsr0_limit_min0 <= {{1{pair_fastchain0_limitcsr0_min_storage0[24]}}, pair_fastchain0_limitcsr0_min_storage0};
		pair_fastchain0_limitcsr0_limit_max0 <= {{1{pair_fastchain0_limitcsr0_max_storage0[24]}}, pair_fastchain0_limitcsr0_max_storage0};
		pair_fastchain0_limitcsr0_limitcsr0_y0 <= pair_fastchain0_limitcsr0_limit_y0;
		pair_fastchain0_limitcsr0_limitcsr0_error0 <= pair_fastchain0_limitcsr0_limit_railed0;
	end
	pair_fastchain0_iir0_a10 <= pair_fastchain0_iir0_csrstorage0_storage0;
	pair_fastchain0_iir0_b00 <= pair_fastchain0_iir0_csrstorage1_storage0;
	pair_fastchain0_iir0_b10 <= pair_fastchain0_iir0_csrstorage2_storage0;
	pair_fastchain0_iir0_z0r0 <= (pair_fastchain0_iir0_storage0 <<< 5'd23);
	pair_fastchain0_iir0_error0 <= pair_fastchain0_iir0_railed0;
	pair_fastchain0_iir0_y0 <= pair_fastchain0_iir0_y_lim0;
	if (pair_fastchain0_iir0_clear0) begin
		pair_fastchain0_iir0_y1 <= 1'd0;
	end else begin
		if ((~pair_fastchain0_iir0_hold0)) begin
			pair_fastchain0_iir0_y1 <= pair_fastchain0_iir0_y_lim0;
		end
	end
	pair_fastchain0_iir0_zr0 <= pair_fastchain0_iir0_z0r0;
	pair_fastchain0_iir0_zr1 <= pair_fastchain0_iir0_z0;
	pair_fastchain0_iir0_zr2 <= pair_fastchain0_iir0_z1;
	pair_fastchain0_iir0_a11 <= pair_fastchain0_iir0_csrstorage0_storage1;
	pair_fastchain0_iir0_a2 <= pair_fastchain0_iir0_csrstorage1_storage1;
	pair_fastchain0_iir0_b01 <= pair_fastchain0_iir0_csrstorage2_storage1;
	pair_fastchain0_iir0_b11 <= pair_fastchain0_iir0_csrstorage3_storage;
	pair_fastchain0_iir0_b2 <= pair_fastchain0_iir0_csrstorage4_storage;
	pair_fastchain0_iir0_z0r1 <= (pair_fastchain0_iir0_storage1 <<< 5'd23);
	pair_fastchain0_iir0_error1 <= pair_fastchain0_iir0_railed1;
	pair_fastchain0_iir0_y2 <= pair_fastchain0_iir0_y_lim1;
	if (pair_fastchain0_iir0_clear1) begin
		pair_fastchain0_iir0_y3 <= 1'd0;
	end else begin
		if ((~pair_fastchain0_iir0_hold1)) begin
			pair_fastchain0_iir0_y3 <= pair_fastchain0_iir0_y_lim1;
		end
	end
	pair_fastchain0_iir0_zr3 <= pair_fastchain0_iir0_z0r1;
	pair_fastchain0_iir0_zr4 <= pair_fastchain0_iir0_z3;
	pair_fastchain0_iir0_zr5 <= pair_fastchain0_iir0_z4;
	pair_fastchain0_iir0_zr6 <= pair_fastchain0_iir0_z5;
	pair_fastchain0_iir0_zr7 <= pair_fastchain0_iir0_z6;
	if (pair_fastchain0_limitcsr0_update_en1) begin
		pair_fastchain0_limitcsr0_limit_min1 <= {{3{pair_fastchain0_limitcsr0_min_storage1[24]}}, pair_fastchain0_limitcsr0_min_storage1};
		pair_fastchain0_limitcsr0_limit_max1 <= {{3{pair_fastchain0_limitcsr0_max_storage1[24]}}, pair_fastchain0_limitcsr0_max_storage1};
		pair_fastchain0_limitcsr0_limitcsr0_y1 <= pair_fastchain0_limitcsr0_limit_y1;
		pair_fastchain0_limitcsr0_limitcsr0_error1 <= pair_fastchain0_limitcsr0_limit_railed1;
	end
	if (pair_fastchain0_limitcsr1_update_en0) begin
		pair_fastchain0_limitcsr1_limit_min0 <= {{1{pair_fastchain0_limitcsr1_min_storage0[24]}}, pair_fastchain0_limitcsr1_min_storage0};
		pair_fastchain0_limitcsr1_limit_max0 <= {{1{pair_fastchain0_limitcsr1_max_storage0[24]}}, pair_fastchain0_limitcsr1_max_storage0};
		pair_fastchain0_limitcsr1_limitcsr1_y0 <= pair_fastchain0_limitcsr1_limit_y0;
		pair_fastchain0_limitcsr1_limitcsr1_error0 <= pair_fastchain0_limitcsr1_limit_railed0;
	end
	pair_fastchain0_iir1_a10 <= pair_fastchain0_iir1_csrstorage3_storage;
	pair_fastchain0_iir1_b00 <= pair_fastchain0_iir1_csrstorage4_storage;
	pair_fastchain0_iir1_b10 <= pair_fastchain0_iir1_csrstorage5_storage0;
	pair_fastchain0_iir1_z0r0 <= (pair_fastchain0_iir1_storage0 <<< 5'd23);
	pair_fastchain0_iir1_error0 <= pair_fastchain0_iir1_railed0;
	pair_fastchain0_iir1_y0 <= pair_fastchain0_iir1_y_lim0;
	if (pair_fastchain0_iir1_clear0) begin
		pair_fastchain0_iir1_y1 <= 1'd0;
	end else begin
		if ((~pair_fastchain0_iir1_hold0)) begin
			pair_fastchain0_iir1_y1 <= pair_fastchain0_iir1_y_lim0;
		end
	end
	pair_fastchain0_iir1_zr0 <= pair_fastchain0_iir1_z0r0;
	pair_fastchain0_iir1_zr1 <= pair_fastchain0_iir1_z0;
	pair_fastchain0_iir1_zr2 <= pair_fastchain0_iir1_z1;
	pair_fastchain0_iir1_a11 <= pair_fastchain0_iir1_csrstorage5_storage1;
	pair_fastchain0_iir1_a2 <= pair_fastchain0_iir1_csrstorage6_storage;
	pair_fastchain0_iir1_b01 <= pair_fastchain0_iir1_csrstorage7_storage;
	pair_fastchain0_iir1_b11 <= pair_fastchain0_iir1_csrstorage8_storage;
	pair_fastchain0_iir1_b2 <= pair_fastchain0_iir1_csrstorage9_storage;
	pair_fastchain0_iir1_z0r1 <= (pair_fastchain0_iir1_storage1 <<< 5'd23);
	pair_fastchain0_iir1_error1 <= pair_fastchain0_iir1_railed1;
	pair_fastchain0_iir1_y2 <= pair_fastchain0_iir1_y_lim1;
	if (pair_fastchain0_iir1_clear1) begin
		pair_fastchain0_iir1_y3 <= 1'd0;
	end else begin
		if ((~pair_fastchain0_iir1_hold1)) begin
			pair_fastchain0_iir1_y3 <= pair_fastchain0_iir1_y_lim1;
		end
	end
	pair_fastchain0_iir1_zr3 <= pair_fastchain0_iir1_z0r1;
	pair_fastchain0_iir1_zr4 <= pair_fastchain0_iir1_z3;
	pair_fastchain0_iir1_zr5 <= pair_fastchain0_iir1_z4;
	pair_fastchain0_iir1_zr6 <= pair_fastchain0_iir1_z5;
	pair_fastchain0_iir1_zr7 <= pair_fastchain0_iir1_z6;
	if (pair_fastchain0_limitcsr1_update_en1) begin
		pair_fastchain0_limitcsr1_limit_min1 <= {{3{pair_fastchain0_limitcsr1_min_storage1[24]}}, pair_fastchain0_limitcsr1_min_storage1};
		pair_fastchain0_limitcsr1_limit_max1 <= {{3{pair_fastchain0_limitcsr1_max_storage1[24]}}, pair_fastchain0_limitcsr1_max_storage1};
		pair_fastchain0_limitcsr1_limitcsr1_y1 <= pair_fastchain0_limitcsr1_limit_y1;
		pair_fastchain0_limitcsr1_limitcsr1_error1 <= pair_fastchain0_limitcsr1_limit_railed1;
	end
	pair_csrbank0_bus_dat_r <= 1'd0;
	if (pair_csrbank0_sel) begin
		case (pair_csrbank0_bus_adr[6:0])
			1'd0: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_tap0_w;
			end
			1'd1: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_invert0_w;
			end
			2'd2: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_demod_delay3_w;
			end
			2'd3: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_demod_delay2_w;
			end
			3'd4: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_demod_delay1_w;
			end
			3'd5: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_demod_delay0_w;
			end
			3'd6: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_demod_multiplier0_w;
			end
			3'd7: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_1_min3_w;
			end
			4'd8: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_1_min2_w;
			end
			4'd9: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_1_min1_w;
			end
			4'd10: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_1_min0_w;
			end
			4'd11: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_1_max3_w;
			end
			4'd12: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_1_max2_w;
			end
			4'd13: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_1_max1_w;
			end
			4'd14: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_1_max0_w;
			end
			4'd15: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_z03_w;
			end
			5'd16: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_z02_w;
			end
			5'd17: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_z01_w;
			end
			5'd18: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_z00_w;
			end
			5'd19: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_a13_w;
			end
			5'd20: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_a12_w;
			end
			5'd21: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_a11_w;
			end
			5'd22: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_a10_w;
			end
			5'd23: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_b03_w;
			end
			5'd24: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_b02_w;
			end
			5'd25: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_b01_w;
			end
			5'd26: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_b00_w;
			end
			5'd27: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_b13_w;
			end
			5'd28: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_b12_w;
			end
			5'd29: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_b11_w;
			end
			5'd30: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_1_b10_w;
			end
			5'd31: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_z03_w;
			end
			6'd32: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_z02_w;
			end
			6'd33: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_z01_w;
			end
			6'd34: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_z00_w;
			end
			6'd35: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_a13_w;
			end
			6'd36: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_a12_w;
			end
			6'd37: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_a11_w;
			end
			6'd38: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_a10_w;
			end
			6'd39: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_a23_w;
			end
			6'd40: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_a22_w;
			end
			6'd41: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_a21_w;
			end
			6'd42: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_a20_w;
			end
			6'd43: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b03_w;
			end
			6'd44: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b02_w;
			end
			6'd45: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b01_w;
			end
			6'd46: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b00_w;
			end
			6'd47: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b13_w;
			end
			6'd48: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b12_w;
			end
			6'd49: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b11_w;
			end
			6'd50: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b10_w;
			end
			6'd51: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b23_w;
			end
			6'd52: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b22_w;
			end
			6'd53: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b21_w;
			end
			6'd54: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_1_b20_w;
			end
			6'd55: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_1_min3_w;
			end
			6'd56: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_1_min2_w;
			end
			6'd57: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_1_min1_w;
			end
			6'd58: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_1_min0_w;
			end
			6'd59: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_1_max3_w;
			end
			6'd60: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_1_max2_w;
			end
			6'd61: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_1_max1_w;
			end
			6'd62: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_1_max0_w;
			end
			6'd63: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_2_min3_w;
			end
			7'd64: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_2_min2_w;
			end
			7'd65: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_2_min1_w;
			end
			7'd66: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_2_min0_w;
			end
			7'd67: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_2_max3_w;
			end
			7'd68: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_2_max2_w;
			end
			7'd69: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_2_max1_w;
			end
			7'd70: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_x_limit_2_max0_w;
			end
			7'd71: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_z03_w;
			end
			7'd72: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_z02_w;
			end
			7'd73: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_z01_w;
			end
			7'd74: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_z00_w;
			end
			7'd75: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_a13_w;
			end
			7'd76: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_a12_w;
			end
			7'd77: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_a11_w;
			end
			7'd78: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_a10_w;
			end
			7'd79: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_b03_w;
			end
			7'd80: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_b02_w;
			end
			7'd81: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_b01_w;
			end
			7'd82: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_b00_w;
			end
			7'd83: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_b13_w;
			end
			7'd84: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_b12_w;
			end
			7'd85: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_b11_w;
			end
			7'd86: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_c_2_b10_w;
			end
			7'd87: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_z03_w;
			end
			7'd88: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_z02_w;
			end
			7'd89: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_z01_w;
			end
			7'd90: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_z00_w;
			end
			7'd91: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_a13_w;
			end
			7'd92: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_a12_w;
			end
			7'd93: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_a11_w;
			end
			7'd94: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_a10_w;
			end
			7'd95: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_a23_w;
			end
			7'd96: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_a22_w;
			end
			7'd97: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_a21_w;
			end
			7'd98: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_a20_w;
			end
			7'd99: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b03_w;
			end
			7'd100: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b02_w;
			end
			7'd101: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b01_w;
			end
			7'd102: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b00_w;
			end
			7'd103: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b13_w;
			end
			7'd104: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b12_w;
			end
			7'd105: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b11_w;
			end
			7'd106: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b10_w;
			end
			7'd107: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b23_w;
			end
			7'd108: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b22_w;
			end
			7'd109: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b21_w;
			end
			7'd110: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_iir_d_2_b20_w;
			end
			7'd111: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_2_min3_w;
			end
			7'd112: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_2_min2_w;
			end
			7'd113: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_2_min1_w;
			end
			7'd114: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_2_min0_w;
			end
			7'd115: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_2_max3_w;
			end
			7'd116: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_2_max2_w;
			end
			7'd117: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_2_max1_w;
			end
			7'd118: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_y_limit_2_max0_w;
			end
		endcase
	end
	if (pair_csrbank0_y_tap0_re) begin
		pair_fastchain0_y_tap_storage_full[1:0] <= pair_csrbank0_y_tap0_r;
	end
	pair_fastchain0_y_tap_re <= pair_csrbank0_y_tap0_re;
	if (pair_csrbank0_invert0_re) begin
		pair_fastchain0_invert_storage_full <= pair_csrbank0_invert0_r;
	end
	pair_fastchain0_invert_re <= pair_csrbank0_invert0_re;
	if (pair_csrbank0_demod_delay3_re) begin
		pair_fastchain0_delay_storage_full[31:24] <= pair_csrbank0_demod_delay3_r;
	end
	if (pair_csrbank0_demod_delay2_re) begin
		pair_fastchain0_delay_storage_full[23:16] <= pair_csrbank0_demod_delay2_r;
	end
	if (pair_csrbank0_demod_delay1_re) begin
		pair_fastchain0_delay_storage_full[15:8] <= pair_csrbank0_demod_delay1_r;
	end
	if (pair_csrbank0_demod_delay0_re) begin
		pair_fastchain0_delay_storage_full[7:0] <= pair_csrbank0_demod_delay0_r;
	end
	pair_fastchain0_delay_re <= pair_csrbank0_demod_delay0_re;
	if (pair_csrbank0_demod_multiplier0_re) begin
		pair_fastchain0_multiplier_storage_full[3:0] <= pair_csrbank0_demod_multiplier0_r;
	end
	pair_fastchain0_multiplier_re <= pair_csrbank0_demod_multiplier0_re;
	if (pair_csrbank0_x_limit_1_min3_re) begin
		pair_fastchain0_limitcsr0_min_storage_full0[24] <= pair_csrbank0_x_limit_1_min3_r;
	end
	if (pair_csrbank0_x_limit_1_min2_re) begin
		pair_fastchain0_limitcsr0_min_storage_full0[23:16] <= pair_csrbank0_x_limit_1_min2_r;
	end
	if (pair_csrbank0_x_limit_1_min1_re) begin
		pair_fastchain0_limitcsr0_min_storage_full0[15:8] <= pair_csrbank0_x_limit_1_min1_r;
	end
	if (pair_csrbank0_x_limit_1_min0_re) begin
		pair_fastchain0_limitcsr0_min_storage_full0[7:0] <= pair_csrbank0_x_limit_1_min0_r;
	end
	pair_fastchain0_limitcsr0_min_re0 <= pair_csrbank0_x_limit_1_min0_re;
	if (pair_csrbank0_x_limit_1_max3_re) begin
		pair_fastchain0_limitcsr0_max_storage_full0[24] <= pair_csrbank0_x_limit_1_max3_r;
	end
	if (pair_csrbank0_x_limit_1_max2_re) begin
		pair_fastchain0_limitcsr0_max_storage_full0[23:16] <= pair_csrbank0_x_limit_1_max2_r;
	end
	if (pair_csrbank0_x_limit_1_max1_re) begin
		pair_fastchain0_limitcsr0_max_storage_full0[15:8] <= pair_csrbank0_x_limit_1_max1_r;
	end
	if (pair_csrbank0_x_limit_1_max0_re) begin
		pair_fastchain0_limitcsr0_max_storage_full0[7:0] <= pair_csrbank0_x_limit_1_max0_r;
	end
	pair_fastchain0_limitcsr0_max_re0 <= pair_csrbank0_x_limit_1_max0_re;
	if (pair_csrbank0_iir_c_1_z03_re) begin
		pair_fastchain0_iir0_storage_full0[26:24] <= pair_csrbank0_iir_c_1_z03_r;
	end
	if (pair_csrbank0_iir_c_1_z02_re) begin
		pair_fastchain0_iir0_storage_full0[23:16] <= pair_csrbank0_iir_c_1_z02_r;
	end
	if (pair_csrbank0_iir_c_1_z01_re) begin
		pair_fastchain0_iir0_storage_full0[15:8] <= pair_csrbank0_iir_c_1_z01_r;
	end
	if (pair_csrbank0_iir_c_1_z00_re) begin
		pair_fastchain0_iir0_storage_full0[7:0] <= pair_csrbank0_iir_c_1_z00_r;
	end
	pair_fastchain0_iir0_re0 <= pair_csrbank0_iir_c_1_z00_re;
	if (pair_csrbank0_iir_c_1_a13_re) begin
		pair_fastchain0_iir0_csrstorage0_storage_full0[24] <= pair_csrbank0_iir_c_1_a13_r;
	end
	if (pair_csrbank0_iir_c_1_a12_re) begin
		pair_fastchain0_iir0_csrstorage0_storage_full0[23:16] <= pair_csrbank0_iir_c_1_a12_r;
	end
	if (pair_csrbank0_iir_c_1_a11_re) begin
		pair_fastchain0_iir0_csrstorage0_storage_full0[15:8] <= pair_csrbank0_iir_c_1_a11_r;
	end
	if (pair_csrbank0_iir_c_1_a10_re) begin
		pair_fastchain0_iir0_csrstorage0_storage_full0[7:0] <= pair_csrbank0_iir_c_1_a10_r;
	end
	pair_fastchain0_iir0_csrstorage0_re0 <= pair_csrbank0_iir_c_1_a10_re;
	if (pair_csrbank0_iir_c_1_b03_re) begin
		pair_fastchain0_iir0_csrstorage1_storage_full0[24] <= pair_csrbank0_iir_c_1_b03_r;
	end
	if (pair_csrbank0_iir_c_1_b02_re) begin
		pair_fastchain0_iir0_csrstorage1_storage_full0[23:16] <= pair_csrbank0_iir_c_1_b02_r;
	end
	if (pair_csrbank0_iir_c_1_b01_re) begin
		pair_fastchain0_iir0_csrstorage1_storage_full0[15:8] <= pair_csrbank0_iir_c_1_b01_r;
	end
	if (pair_csrbank0_iir_c_1_b00_re) begin
		pair_fastchain0_iir0_csrstorage1_storage_full0[7:0] <= pair_csrbank0_iir_c_1_b00_r;
	end
	pair_fastchain0_iir0_csrstorage1_re0 <= pair_csrbank0_iir_c_1_b00_re;
	if (pair_csrbank0_iir_c_1_b13_re) begin
		pair_fastchain0_iir0_csrstorage2_storage_full0[24] <= pair_csrbank0_iir_c_1_b13_r;
	end
	if (pair_csrbank0_iir_c_1_b12_re) begin
		pair_fastchain0_iir0_csrstorage2_storage_full0[23:16] <= pair_csrbank0_iir_c_1_b12_r;
	end
	if (pair_csrbank0_iir_c_1_b11_re) begin
		pair_fastchain0_iir0_csrstorage2_storage_full0[15:8] <= pair_csrbank0_iir_c_1_b11_r;
	end
	if (pair_csrbank0_iir_c_1_b10_re) begin
		pair_fastchain0_iir0_csrstorage2_storage_full0[7:0] <= pair_csrbank0_iir_c_1_b10_r;
	end
	pair_fastchain0_iir0_csrstorage2_re0 <= pair_csrbank0_iir_c_1_b10_re;
	if (pair_csrbank0_iir_d_1_z03_re) begin
		pair_fastchain0_iir0_storage_full1[26:24] <= pair_csrbank0_iir_d_1_z03_r;
	end
	if (pair_csrbank0_iir_d_1_z02_re) begin
		pair_fastchain0_iir0_storage_full1[23:16] <= pair_csrbank0_iir_d_1_z02_r;
	end
	if (pair_csrbank0_iir_d_1_z01_re) begin
		pair_fastchain0_iir0_storage_full1[15:8] <= pair_csrbank0_iir_d_1_z01_r;
	end
	if (pair_csrbank0_iir_d_1_z00_re) begin
		pair_fastchain0_iir0_storage_full1[7:0] <= pair_csrbank0_iir_d_1_z00_r;
	end
	pair_fastchain0_iir0_re1 <= pair_csrbank0_iir_d_1_z00_re;
	if (pair_csrbank0_iir_d_1_a13_re) begin
		pair_fastchain0_iir0_csrstorage0_storage_full1[24] <= pair_csrbank0_iir_d_1_a13_r;
	end
	if (pair_csrbank0_iir_d_1_a12_re) begin
		pair_fastchain0_iir0_csrstorage0_storage_full1[23:16] <= pair_csrbank0_iir_d_1_a12_r;
	end
	if (pair_csrbank0_iir_d_1_a11_re) begin
		pair_fastchain0_iir0_csrstorage0_storage_full1[15:8] <= pair_csrbank0_iir_d_1_a11_r;
	end
	if (pair_csrbank0_iir_d_1_a10_re) begin
		pair_fastchain0_iir0_csrstorage0_storage_full1[7:0] <= pair_csrbank0_iir_d_1_a10_r;
	end
	pair_fastchain0_iir0_csrstorage0_re1 <= pair_csrbank0_iir_d_1_a10_re;
	if (pair_csrbank0_iir_d_1_a23_re) begin
		pair_fastchain0_iir0_csrstorage1_storage_full1[24] <= pair_csrbank0_iir_d_1_a23_r;
	end
	if (pair_csrbank0_iir_d_1_a22_re) begin
		pair_fastchain0_iir0_csrstorage1_storage_full1[23:16] <= pair_csrbank0_iir_d_1_a22_r;
	end
	if (pair_csrbank0_iir_d_1_a21_re) begin
		pair_fastchain0_iir0_csrstorage1_storage_full1[15:8] <= pair_csrbank0_iir_d_1_a21_r;
	end
	if (pair_csrbank0_iir_d_1_a20_re) begin
		pair_fastchain0_iir0_csrstorage1_storage_full1[7:0] <= pair_csrbank0_iir_d_1_a20_r;
	end
	pair_fastchain0_iir0_csrstorage1_re1 <= pair_csrbank0_iir_d_1_a20_re;
	if (pair_csrbank0_iir_d_1_b03_re) begin
		pair_fastchain0_iir0_csrstorage2_storage_full1[24] <= pair_csrbank0_iir_d_1_b03_r;
	end
	if (pair_csrbank0_iir_d_1_b02_re) begin
		pair_fastchain0_iir0_csrstorage2_storage_full1[23:16] <= pair_csrbank0_iir_d_1_b02_r;
	end
	if (pair_csrbank0_iir_d_1_b01_re) begin
		pair_fastchain0_iir0_csrstorage2_storage_full1[15:8] <= pair_csrbank0_iir_d_1_b01_r;
	end
	if (pair_csrbank0_iir_d_1_b00_re) begin
		pair_fastchain0_iir0_csrstorage2_storage_full1[7:0] <= pair_csrbank0_iir_d_1_b00_r;
	end
	pair_fastchain0_iir0_csrstorage2_re1 <= pair_csrbank0_iir_d_1_b00_re;
	if (pair_csrbank0_iir_d_1_b13_re) begin
		pair_fastchain0_iir0_csrstorage3_storage_full[24] <= pair_csrbank0_iir_d_1_b13_r;
	end
	if (pair_csrbank0_iir_d_1_b12_re) begin
		pair_fastchain0_iir0_csrstorage3_storage_full[23:16] <= pair_csrbank0_iir_d_1_b12_r;
	end
	if (pair_csrbank0_iir_d_1_b11_re) begin
		pair_fastchain0_iir0_csrstorage3_storage_full[15:8] <= pair_csrbank0_iir_d_1_b11_r;
	end
	if (pair_csrbank0_iir_d_1_b10_re) begin
		pair_fastchain0_iir0_csrstorage3_storage_full[7:0] <= pair_csrbank0_iir_d_1_b10_r;
	end
	pair_fastchain0_iir0_csrstorage3_re <= pair_csrbank0_iir_d_1_b10_re;
	if (pair_csrbank0_iir_d_1_b23_re) begin
		pair_fastchain0_iir0_csrstorage4_storage_full[24] <= pair_csrbank0_iir_d_1_b23_r;
	end
	if (pair_csrbank0_iir_d_1_b22_re) begin
		pair_fastchain0_iir0_csrstorage4_storage_full[23:16] <= pair_csrbank0_iir_d_1_b22_r;
	end
	if (pair_csrbank0_iir_d_1_b21_re) begin
		pair_fastchain0_iir0_csrstorage4_storage_full[15:8] <= pair_csrbank0_iir_d_1_b21_r;
	end
	if (pair_csrbank0_iir_d_1_b20_re) begin
		pair_fastchain0_iir0_csrstorage4_storage_full[7:0] <= pair_csrbank0_iir_d_1_b20_r;
	end
	pair_fastchain0_iir0_csrstorage4_re <= pair_csrbank0_iir_d_1_b20_re;
	if (pair_csrbank0_y_limit_1_min3_re) begin
		pair_fastchain0_limitcsr0_min_storage_full1[24] <= pair_csrbank0_y_limit_1_min3_r;
	end
	if (pair_csrbank0_y_limit_1_min2_re) begin
		pair_fastchain0_limitcsr0_min_storage_full1[23:16] <= pair_csrbank0_y_limit_1_min2_r;
	end
	if (pair_csrbank0_y_limit_1_min1_re) begin
		pair_fastchain0_limitcsr0_min_storage_full1[15:8] <= pair_csrbank0_y_limit_1_min1_r;
	end
	if (pair_csrbank0_y_limit_1_min0_re) begin
		pair_fastchain0_limitcsr0_min_storage_full1[7:0] <= pair_csrbank0_y_limit_1_min0_r;
	end
	pair_fastchain0_limitcsr0_min_re1 <= pair_csrbank0_y_limit_1_min0_re;
	if (pair_csrbank0_y_limit_1_max3_re) begin
		pair_fastchain0_limitcsr0_max_storage_full1[24] <= pair_csrbank0_y_limit_1_max3_r;
	end
	if (pair_csrbank0_y_limit_1_max2_re) begin
		pair_fastchain0_limitcsr0_max_storage_full1[23:16] <= pair_csrbank0_y_limit_1_max2_r;
	end
	if (pair_csrbank0_y_limit_1_max1_re) begin
		pair_fastchain0_limitcsr0_max_storage_full1[15:8] <= pair_csrbank0_y_limit_1_max1_r;
	end
	if (pair_csrbank0_y_limit_1_max0_re) begin
		pair_fastchain0_limitcsr0_max_storage_full1[7:0] <= pair_csrbank0_y_limit_1_max0_r;
	end
	pair_fastchain0_limitcsr0_max_re1 <= pair_csrbank0_y_limit_1_max0_re;
	if (pair_csrbank0_x_limit_2_min3_re) begin
		pair_fastchain0_limitcsr1_min_storage_full0[24] <= pair_csrbank0_x_limit_2_min3_r;
	end
	if (pair_csrbank0_x_limit_2_min2_re) begin
		pair_fastchain0_limitcsr1_min_storage_full0[23:16] <= pair_csrbank0_x_limit_2_min2_r;
	end
	if (pair_csrbank0_x_limit_2_min1_re) begin
		pair_fastchain0_limitcsr1_min_storage_full0[15:8] <= pair_csrbank0_x_limit_2_min1_r;
	end
	if (pair_csrbank0_x_limit_2_min0_re) begin
		pair_fastchain0_limitcsr1_min_storage_full0[7:0] <= pair_csrbank0_x_limit_2_min0_r;
	end
	pair_fastchain0_limitcsr1_min_re0 <= pair_csrbank0_x_limit_2_min0_re;
	if (pair_csrbank0_x_limit_2_max3_re) begin
		pair_fastchain0_limitcsr1_max_storage_full0[24] <= pair_csrbank0_x_limit_2_max3_r;
	end
	if (pair_csrbank0_x_limit_2_max2_re) begin
		pair_fastchain0_limitcsr1_max_storage_full0[23:16] <= pair_csrbank0_x_limit_2_max2_r;
	end
	if (pair_csrbank0_x_limit_2_max1_re) begin
		pair_fastchain0_limitcsr1_max_storage_full0[15:8] <= pair_csrbank0_x_limit_2_max1_r;
	end
	if (pair_csrbank0_x_limit_2_max0_re) begin
		pair_fastchain0_limitcsr1_max_storage_full0[7:0] <= pair_csrbank0_x_limit_2_max0_r;
	end
	pair_fastchain0_limitcsr1_max_re0 <= pair_csrbank0_x_limit_2_max0_re;
	if (pair_csrbank0_iir_c_2_z03_re) begin
		pair_fastchain0_iir1_storage_full0[26:24] <= pair_csrbank0_iir_c_2_z03_r;
	end
	if (pair_csrbank0_iir_c_2_z02_re) begin
		pair_fastchain0_iir1_storage_full0[23:16] <= pair_csrbank0_iir_c_2_z02_r;
	end
	if (pair_csrbank0_iir_c_2_z01_re) begin
		pair_fastchain0_iir1_storage_full0[15:8] <= pair_csrbank0_iir_c_2_z01_r;
	end
	if (pair_csrbank0_iir_c_2_z00_re) begin
		pair_fastchain0_iir1_storage_full0[7:0] <= pair_csrbank0_iir_c_2_z00_r;
	end
	pair_fastchain0_iir1_re0 <= pair_csrbank0_iir_c_2_z00_re;
	if (pair_csrbank0_iir_c_2_a13_re) begin
		pair_fastchain0_iir1_csrstorage3_storage_full[24] <= pair_csrbank0_iir_c_2_a13_r;
	end
	if (pair_csrbank0_iir_c_2_a12_re) begin
		pair_fastchain0_iir1_csrstorage3_storage_full[23:16] <= pair_csrbank0_iir_c_2_a12_r;
	end
	if (pair_csrbank0_iir_c_2_a11_re) begin
		pair_fastchain0_iir1_csrstorage3_storage_full[15:8] <= pair_csrbank0_iir_c_2_a11_r;
	end
	if (pair_csrbank0_iir_c_2_a10_re) begin
		pair_fastchain0_iir1_csrstorage3_storage_full[7:0] <= pair_csrbank0_iir_c_2_a10_r;
	end
	pair_fastchain0_iir1_csrstorage3_re <= pair_csrbank0_iir_c_2_a10_re;
	if (pair_csrbank0_iir_c_2_b03_re) begin
		pair_fastchain0_iir1_csrstorage4_storage_full[24] <= pair_csrbank0_iir_c_2_b03_r;
	end
	if (pair_csrbank0_iir_c_2_b02_re) begin
		pair_fastchain0_iir1_csrstorage4_storage_full[23:16] <= pair_csrbank0_iir_c_2_b02_r;
	end
	if (pair_csrbank0_iir_c_2_b01_re) begin
		pair_fastchain0_iir1_csrstorage4_storage_full[15:8] <= pair_csrbank0_iir_c_2_b01_r;
	end
	if (pair_csrbank0_iir_c_2_b00_re) begin
		pair_fastchain0_iir1_csrstorage4_storage_full[7:0] <= pair_csrbank0_iir_c_2_b00_r;
	end
	pair_fastchain0_iir1_csrstorage4_re <= pair_csrbank0_iir_c_2_b00_re;
	if (pair_csrbank0_iir_c_2_b13_re) begin
		pair_fastchain0_iir1_csrstorage5_storage_full0[24] <= pair_csrbank0_iir_c_2_b13_r;
	end
	if (pair_csrbank0_iir_c_2_b12_re) begin
		pair_fastchain0_iir1_csrstorage5_storage_full0[23:16] <= pair_csrbank0_iir_c_2_b12_r;
	end
	if (pair_csrbank0_iir_c_2_b11_re) begin
		pair_fastchain0_iir1_csrstorage5_storage_full0[15:8] <= pair_csrbank0_iir_c_2_b11_r;
	end
	if (pair_csrbank0_iir_c_2_b10_re) begin
		pair_fastchain0_iir1_csrstorage5_storage_full0[7:0] <= pair_csrbank0_iir_c_2_b10_r;
	end
	pair_fastchain0_iir1_csrstorage5_re0 <= pair_csrbank0_iir_c_2_b10_re;
	if (pair_csrbank0_iir_d_2_z03_re) begin
		pair_fastchain0_iir1_storage_full1[26:24] <= pair_csrbank0_iir_d_2_z03_r;
	end
	if (pair_csrbank0_iir_d_2_z02_re) begin
		pair_fastchain0_iir1_storage_full1[23:16] <= pair_csrbank0_iir_d_2_z02_r;
	end
	if (pair_csrbank0_iir_d_2_z01_re) begin
		pair_fastchain0_iir1_storage_full1[15:8] <= pair_csrbank0_iir_d_2_z01_r;
	end
	if (pair_csrbank0_iir_d_2_z00_re) begin
		pair_fastchain0_iir1_storage_full1[7:0] <= pair_csrbank0_iir_d_2_z00_r;
	end
	pair_fastchain0_iir1_re1 <= pair_csrbank0_iir_d_2_z00_re;
	if (pair_csrbank0_iir_d_2_a13_re) begin
		pair_fastchain0_iir1_csrstorage5_storage_full1[24] <= pair_csrbank0_iir_d_2_a13_r;
	end
	if (pair_csrbank0_iir_d_2_a12_re) begin
		pair_fastchain0_iir1_csrstorage5_storage_full1[23:16] <= pair_csrbank0_iir_d_2_a12_r;
	end
	if (pair_csrbank0_iir_d_2_a11_re) begin
		pair_fastchain0_iir1_csrstorage5_storage_full1[15:8] <= pair_csrbank0_iir_d_2_a11_r;
	end
	if (pair_csrbank0_iir_d_2_a10_re) begin
		pair_fastchain0_iir1_csrstorage5_storage_full1[7:0] <= pair_csrbank0_iir_d_2_a10_r;
	end
	pair_fastchain0_iir1_csrstorage5_re1 <= pair_csrbank0_iir_d_2_a10_re;
	if (pair_csrbank0_iir_d_2_a23_re) begin
		pair_fastchain0_iir1_csrstorage6_storage_full[24] <= pair_csrbank0_iir_d_2_a23_r;
	end
	if (pair_csrbank0_iir_d_2_a22_re) begin
		pair_fastchain0_iir1_csrstorage6_storage_full[23:16] <= pair_csrbank0_iir_d_2_a22_r;
	end
	if (pair_csrbank0_iir_d_2_a21_re) begin
		pair_fastchain0_iir1_csrstorage6_storage_full[15:8] <= pair_csrbank0_iir_d_2_a21_r;
	end
	if (pair_csrbank0_iir_d_2_a20_re) begin
		pair_fastchain0_iir1_csrstorage6_storage_full[7:0] <= pair_csrbank0_iir_d_2_a20_r;
	end
	pair_fastchain0_iir1_csrstorage6_re <= pair_csrbank0_iir_d_2_a20_re;
	if (pair_csrbank0_iir_d_2_b03_re) begin
		pair_fastchain0_iir1_csrstorage7_storage_full[24] <= pair_csrbank0_iir_d_2_b03_r;
	end
	if (pair_csrbank0_iir_d_2_b02_re) begin
		pair_fastchain0_iir1_csrstorage7_storage_full[23:16] <= pair_csrbank0_iir_d_2_b02_r;
	end
	if (pair_csrbank0_iir_d_2_b01_re) begin
		pair_fastchain0_iir1_csrstorage7_storage_full[15:8] <= pair_csrbank0_iir_d_2_b01_r;
	end
	if (pair_csrbank0_iir_d_2_b00_re) begin
		pair_fastchain0_iir1_csrstorage7_storage_full[7:0] <= pair_csrbank0_iir_d_2_b00_r;
	end
	pair_fastchain0_iir1_csrstorage7_re <= pair_csrbank0_iir_d_2_b00_re;
	if (pair_csrbank0_iir_d_2_b13_re) begin
		pair_fastchain0_iir1_csrstorage8_storage_full[24] <= pair_csrbank0_iir_d_2_b13_r;
	end
	if (pair_csrbank0_iir_d_2_b12_re) begin
		pair_fastchain0_iir1_csrstorage8_storage_full[23:16] <= pair_csrbank0_iir_d_2_b12_r;
	end
	if (pair_csrbank0_iir_d_2_b11_re) begin
		pair_fastchain0_iir1_csrstorage8_storage_full[15:8] <= pair_csrbank0_iir_d_2_b11_r;
	end
	if (pair_csrbank0_iir_d_2_b10_re) begin
		pair_fastchain0_iir1_csrstorage8_storage_full[7:0] <= pair_csrbank0_iir_d_2_b10_r;
	end
	pair_fastchain0_iir1_csrstorage8_re <= pair_csrbank0_iir_d_2_b10_re;
	if (pair_csrbank0_iir_d_2_b23_re) begin
		pair_fastchain0_iir1_csrstorage9_storage_full[24] <= pair_csrbank0_iir_d_2_b23_r;
	end
	if (pair_csrbank0_iir_d_2_b22_re) begin
		pair_fastchain0_iir1_csrstorage9_storage_full[23:16] <= pair_csrbank0_iir_d_2_b22_r;
	end
	if (pair_csrbank0_iir_d_2_b21_re) begin
		pair_fastchain0_iir1_csrstorage9_storage_full[15:8] <= pair_csrbank0_iir_d_2_b21_r;
	end
	if (pair_csrbank0_iir_d_2_b20_re) begin
		pair_fastchain0_iir1_csrstorage9_storage_full[7:0] <= pair_csrbank0_iir_d_2_b20_r;
	end
	pair_fastchain0_iir1_csrstorage9_re <= pair_csrbank0_iir_d_2_b20_re;
	if (pair_csrbank0_y_limit_2_min3_re) begin
		pair_fastchain0_limitcsr1_min_storage_full1[24] <= pair_csrbank0_y_limit_2_min3_r;
	end
	if (pair_csrbank0_y_limit_2_min2_re) begin
		pair_fastchain0_limitcsr1_min_storage_full1[23:16] <= pair_csrbank0_y_limit_2_min2_r;
	end
	if (pair_csrbank0_y_limit_2_min1_re) begin
		pair_fastchain0_limitcsr1_min_storage_full1[15:8] <= pair_csrbank0_y_limit_2_min1_r;
	end
	if (pair_csrbank0_y_limit_2_min0_re) begin
		pair_fastchain0_limitcsr1_min_storage_full1[7:0] <= pair_csrbank0_y_limit_2_min0_r;
	end
	pair_fastchain0_limitcsr1_min_re1 <= pair_csrbank0_y_limit_2_min0_re;
	if (pair_csrbank0_y_limit_2_max3_re) begin
		pair_fastchain0_limitcsr1_max_storage_full1[24] <= pair_csrbank0_y_limit_2_max3_r;
	end
	if (pair_csrbank0_y_limit_2_max2_re) begin
		pair_fastchain0_limitcsr1_max_storage_full1[23:16] <= pair_csrbank0_y_limit_2_max2_r;
	end
	if (pair_csrbank0_y_limit_2_max1_re) begin
		pair_fastchain0_limitcsr1_max_storage_full1[15:8] <= pair_csrbank0_y_limit_2_max1_r;
	end
	if (pair_csrbank0_y_limit_2_max0_re) begin
		pair_fastchain0_limitcsr1_max_storage_full1[7:0] <= pair_csrbank0_y_limit_2_max0_r;
	end
	pair_fastchain0_limitcsr1_max_re1 <= pair_csrbank0_y_limit_2_max0_re;
	pair_fastchain1_ya <= (pair_fastchain1_dy >>> 4'd11);
	pair_fastchain1_cordic11 <= (pair_fastchain1_cordic10 + (pair_fastchain1_cordic1_dir0 ? (pair_fastchain1_cordic116 >>> 1'd0) : (-(pair_fastchain1_cordic116 >>> 1'd0))));
	pair_fastchain1_cordic117 <= (pair_fastchain1_cordic116 + (pair_fastchain1_cordic1_dir0 ? (-(pair_fastchain1_cordic10 >>> 1'd0)) : (pair_fastchain1_cordic10 >>> 1'd0)));
	pair_fastchain1_cordic133 <= (pair_fastchain1_cordic132 + (pair_fastchain1_cordic1_dir0 ? $signed({1'd0, 15'd16384}) : 15'sd16384));
	pair_fastchain1_cordic12 <= (pair_fastchain1_cordic11 + (pair_fastchain1_cordic1_dir1 ? (pair_fastchain1_cordic117 >>> 1'd1) : (-(pair_fastchain1_cordic117 >>> 1'd1))));
	pair_fastchain1_cordic118 <= (pair_fastchain1_cordic117 + (pair_fastchain1_cordic1_dir1 ? (-(pair_fastchain1_cordic11 >>> 1'd1)) : (pair_fastchain1_cordic11 >>> 1'd1)));
	pair_fastchain1_cordic134 <= (pair_fastchain1_cordic133 + (pair_fastchain1_cordic1_dir1 ? $signed({1'd0, 14'd9672}) : 15'sd23096));
	pair_fastchain1_cordic13 <= (pair_fastchain1_cordic12 + (pair_fastchain1_cordic1_dir2 ? (pair_fastchain1_cordic118 >>> 2'd2) : (-(pair_fastchain1_cordic118 >>> 2'd2))));
	pair_fastchain1_cordic119 <= (pair_fastchain1_cordic118 + (pair_fastchain1_cordic1_dir2 ? (-(pair_fastchain1_cordic12 >>> 2'd2)) : (pair_fastchain1_cordic12 >>> 2'd2)));
	pair_fastchain1_cordic135 <= (pair_fastchain1_cordic134 + (pair_fastchain1_cordic1_dir2 ? $signed({1'd0, 13'd5110}) : 14'sd11274));
	pair_fastchain1_cordic14 <= (pair_fastchain1_cordic13 + (pair_fastchain1_cordic1_dir3 ? (pair_fastchain1_cordic119 >>> 2'd3) : (-(pair_fastchain1_cordic119 >>> 2'd3))));
	pair_fastchain1_cordic120 <= (pair_fastchain1_cordic119 + (pair_fastchain1_cordic1_dir3 ? (-(pair_fastchain1_cordic13 >>> 2'd3)) : (pair_fastchain1_cordic13 >>> 2'd3)));
	pair_fastchain1_cordic136 <= (pair_fastchain1_cordic135 + (pair_fastchain1_cordic1_dir3 ? $signed({1'd0, 12'd2594}) : 13'sd5598));
	pair_fastchain1_cordic15 <= (pair_fastchain1_cordic14 + (pair_fastchain1_cordic1_dir4 ? (pair_fastchain1_cordic120 >>> 3'd4) : (-(pair_fastchain1_cordic120 >>> 3'd4))));
	pair_fastchain1_cordic121 <= (pair_fastchain1_cordic120 + (pair_fastchain1_cordic1_dir4 ? (-(pair_fastchain1_cordic14 >>> 3'd4)) : (pair_fastchain1_cordic14 >>> 3'd4)));
	pair_fastchain1_cordic137 <= (pair_fastchain1_cordic136 + (pair_fastchain1_cordic1_dir4 ? $signed({1'd0, 11'd1302}) : 12'sd2794));
	pair_fastchain1_cordic16 <= (pair_fastchain1_cordic15 + (pair_fastchain1_cordic1_dir5 ? (pair_fastchain1_cordic121 >>> 3'd5) : (-(pair_fastchain1_cordic121 >>> 3'd5))));
	pair_fastchain1_cordic122 <= (pair_fastchain1_cordic121 + (pair_fastchain1_cordic1_dir5 ? (-(pair_fastchain1_cordic15 >>> 3'd5)) : (pair_fastchain1_cordic15 >>> 3'd5)));
	pair_fastchain1_cordic138 <= (pair_fastchain1_cordic137 + (pair_fastchain1_cordic1_dir5 ? $signed({1'd0, 10'd652}) : 11'sd1396));
	pair_fastchain1_cordic17 <= (pair_fastchain1_cordic16 + (pair_fastchain1_cordic1_dir6 ? (pair_fastchain1_cordic122 >>> 3'd6) : (-(pair_fastchain1_cordic122 >>> 3'd6))));
	pair_fastchain1_cordic123 <= (pair_fastchain1_cordic122 + (pair_fastchain1_cordic1_dir6 ? (-(pair_fastchain1_cordic16 >>> 3'd6)) : (pair_fastchain1_cordic16 >>> 3'd6)));
	pair_fastchain1_cordic139 <= (pair_fastchain1_cordic138 + (pair_fastchain1_cordic1_dir6 ? $signed({1'd0, 9'd326}) : 10'sd698));
	pair_fastchain1_cordic18 <= (pair_fastchain1_cordic17 + (pair_fastchain1_cordic1_dir7 ? (pair_fastchain1_cordic123 >>> 3'd7) : (-(pair_fastchain1_cordic123 >>> 3'd7))));
	pair_fastchain1_cordic124 <= (pair_fastchain1_cordic123 + (pair_fastchain1_cordic1_dir7 ? (-(pair_fastchain1_cordic17 >>> 3'd7)) : (pair_fastchain1_cordic17 >>> 3'd7)));
	pair_fastchain1_cordic140 <= (pair_fastchain1_cordic139 + (pair_fastchain1_cordic1_dir7 ? $signed({1'd0, 8'd163}) : 9'sd349));
	pair_fastchain1_cordic19 <= (pair_fastchain1_cordic18 + (pair_fastchain1_cordic1_dir8 ? (pair_fastchain1_cordic124 >>> 4'd8) : (-(pair_fastchain1_cordic124 >>> 4'd8))));
	pair_fastchain1_cordic125 <= (pair_fastchain1_cordic124 + (pair_fastchain1_cordic1_dir8 ? (-(pair_fastchain1_cordic18 >>> 4'd8)) : (pair_fastchain1_cordic18 >>> 4'd8)));
	pair_fastchain1_cordic141 <= (pair_fastchain1_cordic140 + (pair_fastchain1_cordic1_dir8 ? $signed({1'd0, 7'd81}) : 8'sd175));
	pair_fastchain1_cordic110 <= (pair_fastchain1_cordic19 + (pair_fastchain1_cordic1_dir9 ? (pair_fastchain1_cordic125 >>> 4'd9) : (-(pair_fastchain1_cordic125 >>> 4'd9))));
	pair_fastchain1_cordic126 <= (pair_fastchain1_cordic125 + (pair_fastchain1_cordic1_dir9 ? (-(pair_fastchain1_cordic19 >>> 4'd9)) : (pair_fastchain1_cordic19 >>> 4'd9)));
	pair_fastchain1_cordic142 <= (pair_fastchain1_cordic141 + (pair_fastchain1_cordic1_dir9 ? $signed({1'd0, 6'd41}) : 7'sd87));
	pair_fastchain1_cordic111 <= (pair_fastchain1_cordic110 + (pair_fastchain1_cordic1_dir10 ? (pair_fastchain1_cordic126 >>> 4'd10) : (-(pair_fastchain1_cordic126 >>> 4'd10))));
	pair_fastchain1_cordic127 <= (pair_fastchain1_cordic126 + (pair_fastchain1_cordic1_dir10 ? (-(pair_fastchain1_cordic110 >>> 4'd10)) : (pair_fastchain1_cordic110 >>> 4'd10)));
	pair_fastchain1_cordic143 <= (pair_fastchain1_cordic142 + (pair_fastchain1_cordic1_dir10 ? $signed({1'd0, 5'd20}) : 6'sd44));
	pair_fastchain1_cordic112 <= (pair_fastchain1_cordic111 + (pair_fastchain1_cordic1_dir11 ? (pair_fastchain1_cordic127 >>> 4'd11) : (-(pair_fastchain1_cordic127 >>> 4'd11))));
	pair_fastchain1_cordic128 <= (pair_fastchain1_cordic127 + (pair_fastchain1_cordic1_dir11 ? (-(pair_fastchain1_cordic111 >>> 4'd11)) : (pair_fastchain1_cordic111 >>> 4'd11)));
	pair_fastchain1_cordic144 <= (pair_fastchain1_cordic143 + (pair_fastchain1_cordic1_dir11 ? $signed({1'd0, 4'd10}) : 5'sd22));
	pair_fastchain1_cordic113 <= (pair_fastchain1_cordic112 + (pair_fastchain1_cordic1_dir12 ? (pair_fastchain1_cordic128 >>> 4'd12) : (-(pair_fastchain1_cordic128 >>> 4'd12))));
	pair_fastchain1_cordic129 <= (pair_fastchain1_cordic128 + (pair_fastchain1_cordic1_dir12 ? (-(pair_fastchain1_cordic112 >>> 4'd12)) : (pair_fastchain1_cordic112 >>> 4'd12)));
	pair_fastchain1_cordic145 <= (pair_fastchain1_cordic144 + (pair_fastchain1_cordic1_dir12 ? $signed({1'd0, 3'd5}) : 4'sd11));
	pair_fastchain1_cordic114 <= (pair_fastchain1_cordic113 + (pair_fastchain1_cordic1_dir13 ? (pair_fastchain1_cordic129 >>> 4'd13) : (-(pair_fastchain1_cordic129 >>> 4'd13))));
	pair_fastchain1_cordic130 <= (pair_fastchain1_cordic129 + (pair_fastchain1_cordic1_dir13 ? (-(pair_fastchain1_cordic113 >>> 4'd13)) : (pair_fastchain1_cordic113 >>> 4'd13)));
	pair_fastchain1_cordic146 <= (pair_fastchain1_cordic145 + (pair_fastchain1_cordic1_dir13 ? $signed({1'd0, 2'd3}) : 3'sd5));
	pair_fastchain1_cordic115 <= (pair_fastchain1_cordic114 + (pair_fastchain1_cordic1_dir14 ? (pair_fastchain1_cordic130 >>> 4'd14) : (-(pair_fastchain1_cordic130 >>> 4'd14))));
	pair_fastchain1_cordic131 <= (pair_fastchain1_cordic130 + (pair_fastchain1_cordic1_dir14 ? (-(pair_fastchain1_cordic114 >>> 4'd14)) : (pair_fastchain1_cordic114 >>> 4'd14)));
	pair_fastchain1_cordic147 <= (pair_fastchain1_cordic146 + (pair_fastchain1_cordic1_dir14 ? $signed({1'd0, 1'd1}) : 1'sd1));
	if (pair_fastchain1_limitcsr2_update_en) begin
		pair_fastchain1_limitcsr2_limit_min <= {{1{pair_fastchain1_limitcsr2_min_storage[24]}}, pair_fastchain1_limitcsr2_min_storage};
		pair_fastchain1_limitcsr2_limit_max <= {{1{pair_fastchain1_limitcsr2_max_storage[24]}}, pair_fastchain1_limitcsr2_max_storage};
		pair_fastchain1_limitcsr2_limitcsr2_y <= pair_fastchain1_limitcsr2_limit_y;
		pair_fastchain1_limitcsr2_limitcsr2_error <= pair_fastchain1_limitcsr2_limit_railed;
	end
	pair_fastchain1_iir2_a10 <= pair_fastchain1_iir2_csrstorage6_storage;
	pair_fastchain1_iir2_b00 <= pair_fastchain1_iir2_csrstorage7_storage;
	pair_fastchain1_iir2_b10 <= pair_fastchain1_iir2_csrstorage8_storage;
	pair_fastchain1_iir2_z0r0 <= (pair_fastchain1_iir2_storage0 <<< 5'd23);
	pair_fastchain1_iir2_error0 <= pair_fastchain1_iir2_railed0;
	pair_fastchain1_iir2_y0 <= pair_fastchain1_iir2_y_lim0;
	if (pair_fastchain1_iir2_clear0) begin
		pair_fastchain1_iir2_y1 <= 1'd0;
	end else begin
		if ((~pair_fastchain1_iir2_hold0)) begin
			pair_fastchain1_iir2_y1 <= pair_fastchain1_iir2_y_lim0;
		end
	end
	pair_fastchain1_iir2_zr0 <= pair_fastchain1_iir2_z0r0;
	pair_fastchain1_iir2_zr1 <= pair_fastchain1_iir2_z0;
	pair_fastchain1_iir2_zr2 <= pair_fastchain1_iir2_z1;
	pair_fastchain1_iir2_a11 <= pair_fastchain1_iir2_csrstorage10_storage;
	pair_fastchain1_iir2_a2 <= pair_fastchain1_iir2_csrstorage11_storage;
	pair_fastchain1_iir2_b01 <= pair_fastchain1_iir2_csrstorage12_storage;
	pair_fastchain1_iir2_b11 <= pair_fastchain1_iir2_csrstorage13_storage;
	pair_fastchain1_iir2_b2 <= pair_fastchain1_iir2_csrstorage14_storage;
	pair_fastchain1_iir2_z0r1 <= (pair_fastchain1_iir2_storage1 <<< 5'd23);
	pair_fastchain1_iir2_error1 <= pair_fastchain1_iir2_railed1;
	pair_fastchain1_iir2_y2 <= pair_fastchain1_iir2_y_lim1;
	if (pair_fastchain1_iir2_clear1) begin
		pair_fastchain1_iir2_y3 <= 1'd0;
	end else begin
		if ((~pair_fastchain1_iir2_hold1)) begin
			pair_fastchain1_iir2_y3 <= pair_fastchain1_iir2_y_lim1;
		end
	end
	pair_fastchain1_iir2_zr3 <= pair_fastchain1_iir2_z0r1;
	pair_fastchain1_iir2_zr4 <= pair_fastchain1_iir2_z3;
	pair_fastchain1_iir2_zr5 <= pair_fastchain1_iir2_z4;
	pair_fastchain1_iir2_zr6 <= pair_fastchain1_iir2_z5;
	pair_fastchain1_iir2_zr7 <= pair_fastchain1_iir2_z6;
	if (pair_fastchain1_paralleltaplimitcsr0_update_en) begin
		pair_fastchain1_paralleltaplimitcsr0_bound_min <= {{3{pair_fastchain1_paralleltaplimitcsr0_min_storage[24]}}, pair_fastchain1_paralleltaplimitcsr0_min_storage};
		pair_fastchain1_paralleltaplimitcsr0_bound_max <= {{3{pair_fastchain1_paralleltaplimitcsr0_max_storage[24]}}, pair_fastchain1_paralleltaplimitcsr0_max_storage};
		pair_fastchain1_paralleltaplimitcsr0_y <= pair_fastchain1_paralleltaplimitcsr0_pre_y;
		pair_fastchain1_paralleltaplimitcsr0_error <= pair_fastchain1_paralleltaplimitcsr0_pre_rail;
	end
	if (pair_fastchain1_limitcsr3_update_en) begin
		pair_fastchain1_limitcsr3_limit_min <= {{1{pair_fastchain1_limitcsr3_min_storage[24]}}, pair_fastchain1_limitcsr3_min_storage};
		pair_fastchain1_limitcsr3_limit_max <= {{1{pair_fastchain1_limitcsr3_max_storage[24]}}, pair_fastchain1_limitcsr3_max_storage};
		pair_fastchain1_limitcsr3_limitcsr3_y <= pair_fastchain1_limitcsr3_limit_y;
		pair_fastchain1_limitcsr3_limitcsr3_error <= pair_fastchain1_limitcsr3_limit_railed;
	end
	pair_fastchain1_iir3_a10 <= pair_fastchain1_iir3_csrstorage9_storage;
	pair_fastchain1_iir3_b00 <= pair_fastchain1_iir3_csrstorage10_storage;
	pair_fastchain1_iir3_b10 <= pair_fastchain1_iir3_csrstorage11_storage;
	pair_fastchain1_iir3_z0r0 <= (pair_fastchain1_iir3_storage0 <<< 5'd23);
	pair_fastchain1_iir3_error0 <= pair_fastchain1_iir3_railed0;
	pair_fastchain1_iir3_y0 <= pair_fastchain1_iir3_y_lim0;
	if (pair_fastchain1_iir3_clear0) begin
		pair_fastchain1_iir3_y1 <= 1'd0;
	end else begin
		if ((~pair_fastchain1_iir3_hold0)) begin
			pair_fastchain1_iir3_y1 <= pair_fastchain1_iir3_y_lim0;
		end
	end
	pair_fastchain1_iir3_zr0 <= pair_fastchain1_iir3_z0r0;
	pair_fastchain1_iir3_zr1 <= pair_fastchain1_iir3_z0;
	pair_fastchain1_iir3_zr2 <= pair_fastchain1_iir3_z1;
	pair_fastchain1_iir3_a11 <= pair_fastchain1_iir3_csrstorage15_storage;
	pair_fastchain1_iir3_a2 <= pair_fastchain1_iir3_csrstorage16_storage;
	pair_fastchain1_iir3_b01 <= pair_fastchain1_iir3_csrstorage17_storage;
	pair_fastchain1_iir3_b11 <= pair_fastchain1_iir3_csrstorage18_storage;
	pair_fastchain1_iir3_b2 <= pair_fastchain1_iir3_csrstorage19_storage;
	pair_fastchain1_iir3_z0r1 <= (pair_fastchain1_iir3_storage1 <<< 5'd23);
	pair_fastchain1_iir3_error1 <= pair_fastchain1_iir3_railed1;
	pair_fastchain1_iir3_y2 <= pair_fastchain1_iir3_y_lim1;
	if (pair_fastchain1_iir3_clear1) begin
		pair_fastchain1_iir3_y3 <= 1'd0;
	end else begin
		if ((~pair_fastchain1_iir3_hold1)) begin
			pair_fastchain1_iir3_y3 <= pair_fastchain1_iir3_y_lim1;
		end
	end
	pair_fastchain1_iir3_zr3 <= pair_fastchain1_iir3_z0r1;
	pair_fastchain1_iir3_zr4 <= pair_fastchain1_iir3_z3;
	pair_fastchain1_iir3_zr5 <= pair_fastchain1_iir3_z4;
	pair_fastchain1_iir3_zr6 <= pair_fastchain1_iir3_z5;
	pair_fastchain1_iir3_zr7 <= pair_fastchain1_iir3_z6;
	if (pair_fastchain1_paralleltaplimitcsr1_update_en) begin
		pair_fastchain1_paralleltaplimitcsr1_bound_min <= {{3{pair_fastchain1_paralleltaplimitcsr1_min_storage[24]}}, pair_fastchain1_paralleltaplimitcsr1_min_storage};
		pair_fastchain1_paralleltaplimitcsr1_bound_max <= {{3{pair_fastchain1_paralleltaplimitcsr1_max_storage[24]}}, pair_fastchain1_paralleltaplimitcsr1_max_storage};
		pair_fastchain1_paralleltaplimitcsr1_y <= pair_fastchain1_paralleltaplimitcsr1_pre_y;
		pair_fastchain1_paralleltaplimitcsr1_error <= pair_fastchain1_paralleltaplimitcsr1_pre_rail;
	end
	pair_csrbank1_bus_dat_r <= 1'd0;
	if (pair_csrbank1_sel) begin
		case (pair_csrbank1_bus_adr[6:0])
			1'd0: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_tap0_w;
			end
			1'd1: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_invert0_w;
			end
			2'd2: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_demod_delay3_w;
			end
			2'd3: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_demod_delay2_w;
			end
			3'd4: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_demod_delay1_w;
			end
			3'd5: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_demod_delay0_w;
			end
			3'd6: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_demod_multiplier0_w;
			end
			3'd7: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_1_min3_w;
			end
			4'd8: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_1_min2_w;
			end
			4'd9: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_1_min1_w;
			end
			4'd10: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_1_min0_w;
			end
			4'd11: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_1_max3_w;
			end
			4'd12: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_1_max2_w;
			end
			4'd13: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_1_max1_w;
			end
			4'd14: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_1_max0_w;
			end
			4'd15: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_z03_w;
			end
			5'd16: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_z02_w;
			end
			5'd17: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_z01_w;
			end
			5'd18: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_z00_w;
			end
			5'd19: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_a13_w;
			end
			5'd20: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_a12_w;
			end
			5'd21: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_a11_w;
			end
			5'd22: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_a10_w;
			end
			5'd23: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_b03_w;
			end
			5'd24: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_b02_w;
			end
			5'd25: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_b01_w;
			end
			5'd26: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_b00_w;
			end
			5'd27: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_b13_w;
			end
			5'd28: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_b12_w;
			end
			5'd29: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_b11_w;
			end
			5'd30: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_1_b10_w;
			end
			5'd31: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_z03_w;
			end
			6'd32: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_z02_w;
			end
			6'd33: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_z01_w;
			end
			6'd34: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_z00_w;
			end
			6'd35: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_a13_w;
			end
			6'd36: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_a12_w;
			end
			6'd37: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_a11_w;
			end
			6'd38: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_a10_w;
			end
			6'd39: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_a23_w;
			end
			6'd40: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_a22_w;
			end
			6'd41: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_a21_w;
			end
			6'd42: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_a20_w;
			end
			6'd43: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b03_w;
			end
			6'd44: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b02_w;
			end
			6'd45: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b01_w;
			end
			6'd46: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b00_w;
			end
			6'd47: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b13_w;
			end
			6'd48: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b12_w;
			end
			6'd49: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b11_w;
			end
			6'd50: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b10_w;
			end
			6'd51: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b23_w;
			end
			6'd52: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b22_w;
			end
			6'd53: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b21_w;
			end
			6'd54: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_1_b20_w;
			end
			6'd55: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_1_min3_w;
			end
			6'd56: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_1_min2_w;
			end
			6'd57: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_1_min1_w;
			end
			6'd58: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_1_min0_w;
			end
			6'd59: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_1_max3_w;
			end
			6'd60: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_1_max2_w;
			end
			6'd61: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_1_max1_w;
			end
			6'd62: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_1_max0_w;
			end
			6'd63: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_2_min3_w;
			end
			7'd64: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_2_min2_w;
			end
			7'd65: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_2_min1_w;
			end
			7'd66: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_2_min0_w;
			end
			7'd67: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_2_max3_w;
			end
			7'd68: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_2_max2_w;
			end
			7'd69: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_2_max1_w;
			end
			7'd70: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_x_limit_2_max0_w;
			end
			7'd71: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_z03_w;
			end
			7'd72: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_z02_w;
			end
			7'd73: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_z01_w;
			end
			7'd74: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_z00_w;
			end
			7'd75: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_a13_w;
			end
			7'd76: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_a12_w;
			end
			7'd77: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_a11_w;
			end
			7'd78: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_a10_w;
			end
			7'd79: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_b03_w;
			end
			7'd80: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_b02_w;
			end
			7'd81: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_b01_w;
			end
			7'd82: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_b00_w;
			end
			7'd83: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_b13_w;
			end
			7'd84: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_b12_w;
			end
			7'd85: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_b11_w;
			end
			7'd86: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_c_2_b10_w;
			end
			7'd87: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_z03_w;
			end
			7'd88: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_z02_w;
			end
			7'd89: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_z01_w;
			end
			7'd90: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_z00_w;
			end
			7'd91: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_a13_w;
			end
			7'd92: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_a12_w;
			end
			7'd93: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_a11_w;
			end
			7'd94: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_a10_w;
			end
			7'd95: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_a23_w;
			end
			7'd96: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_a22_w;
			end
			7'd97: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_a21_w;
			end
			7'd98: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_a20_w;
			end
			7'd99: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b03_w;
			end
			7'd100: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b02_w;
			end
			7'd101: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b01_w;
			end
			7'd102: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b00_w;
			end
			7'd103: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b13_w;
			end
			7'd104: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b12_w;
			end
			7'd105: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b11_w;
			end
			7'd106: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b10_w;
			end
			7'd107: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b23_w;
			end
			7'd108: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b22_w;
			end
			7'd109: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b21_w;
			end
			7'd110: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_iir_d_2_b20_w;
			end
			7'd111: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_2_min3_w;
			end
			7'd112: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_2_min2_w;
			end
			7'd113: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_2_min1_w;
			end
			7'd114: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_2_min0_w;
			end
			7'd115: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_2_max3_w;
			end
			7'd116: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_2_max2_w;
			end
			7'd117: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_2_max1_w;
			end
			7'd118: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_y_limit_2_max0_w;
			end
		endcase
	end
	if (pair_csrbank1_y_tap0_re) begin
		pair_fastchain1_y_tap_storage_full[1:0] <= pair_csrbank1_y_tap0_r;
	end
	pair_fastchain1_y_tap_re <= pair_csrbank1_y_tap0_re;
	if (pair_csrbank1_invert0_re) begin
		pair_fastchain1_invert_storage_full <= pair_csrbank1_invert0_r;
	end
	pair_fastchain1_invert_re <= pair_csrbank1_invert0_re;
	if (pair_csrbank1_demod_delay3_re) begin
		pair_fastchain1_delay_storage_full[31:24] <= pair_csrbank1_demod_delay3_r;
	end
	if (pair_csrbank1_demod_delay2_re) begin
		pair_fastchain1_delay_storage_full[23:16] <= pair_csrbank1_demod_delay2_r;
	end
	if (pair_csrbank1_demod_delay1_re) begin
		pair_fastchain1_delay_storage_full[15:8] <= pair_csrbank1_demod_delay1_r;
	end
	if (pair_csrbank1_demod_delay0_re) begin
		pair_fastchain1_delay_storage_full[7:0] <= pair_csrbank1_demod_delay0_r;
	end
	pair_fastchain1_delay_re <= pair_csrbank1_demod_delay0_re;
	if (pair_csrbank1_demod_multiplier0_re) begin
		pair_fastchain1_multiplier_storage_full[3:0] <= pair_csrbank1_demod_multiplier0_r;
	end
	pair_fastchain1_multiplier_re <= pair_csrbank1_demod_multiplier0_re;
	if (pair_csrbank1_x_limit_1_min3_re) begin
		pair_fastchain1_limitcsr2_min_storage_full[24] <= pair_csrbank1_x_limit_1_min3_r;
	end
	if (pair_csrbank1_x_limit_1_min2_re) begin
		pair_fastchain1_limitcsr2_min_storage_full[23:16] <= pair_csrbank1_x_limit_1_min2_r;
	end
	if (pair_csrbank1_x_limit_1_min1_re) begin
		pair_fastchain1_limitcsr2_min_storage_full[15:8] <= pair_csrbank1_x_limit_1_min1_r;
	end
	if (pair_csrbank1_x_limit_1_min0_re) begin
		pair_fastchain1_limitcsr2_min_storage_full[7:0] <= pair_csrbank1_x_limit_1_min0_r;
	end
	pair_fastchain1_limitcsr2_min_re <= pair_csrbank1_x_limit_1_min0_re;
	if (pair_csrbank1_x_limit_1_max3_re) begin
		pair_fastchain1_limitcsr2_max_storage_full[24] <= pair_csrbank1_x_limit_1_max3_r;
	end
	if (pair_csrbank1_x_limit_1_max2_re) begin
		pair_fastchain1_limitcsr2_max_storage_full[23:16] <= pair_csrbank1_x_limit_1_max2_r;
	end
	if (pair_csrbank1_x_limit_1_max1_re) begin
		pair_fastchain1_limitcsr2_max_storage_full[15:8] <= pair_csrbank1_x_limit_1_max1_r;
	end
	if (pair_csrbank1_x_limit_1_max0_re) begin
		pair_fastchain1_limitcsr2_max_storage_full[7:0] <= pair_csrbank1_x_limit_1_max0_r;
	end
	pair_fastchain1_limitcsr2_max_re <= pair_csrbank1_x_limit_1_max0_re;
	if (pair_csrbank1_iir_c_1_z03_re) begin
		pair_fastchain1_iir2_storage_full0[26:24] <= pair_csrbank1_iir_c_1_z03_r;
	end
	if (pair_csrbank1_iir_c_1_z02_re) begin
		pair_fastchain1_iir2_storage_full0[23:16] <= pair_csrbank1_iir_c_1_z02_r;
	end
	if (pair_csrbank1_iir_c_1_z01_re) begin
		pair_fastchain1_iir2_storage_full0[15:8] <= pair_csrbank1_iir_c_1_z01_r;
	end
	if (pair_csrbank1_iir_c_1_z00_re) begin
		pair_fastchain1_iir2_storage_full0[7:0] <= pair_csrbank1_iir_c_1_z00_r;
	end
	pair_fastchain1_iir2_re0 <= pair_csrbank1_iir_c_1_z00_re;
	if (pair_csrbank1_iir_c_1_a13_re) begin
		pair_fastchain1_iir2_csrstorage6_storage_full[24] <= pair_csrbank1_iir_c_1_a13_r;
	end
	if (pair_csrbank1_iir_c_1_a12_re) begin
		pair_fastchain1_iir2_csrstorage6_storage_full[23:16] <= pair_csrbank1_iir_c_1_a12_r;
	end
	if (pair_csrbank1_iir_c_1_a11_re) begin
		pair_fastchain1_iir2_csrstorage6_storage_full[15:8] <= pair_csrbank1_iir_c_1_a11_r;
	end
	if (pair_csrbank1_iir_c_1_a10_re) begin
		pair_fastchain1_iir2_csrstorage6_storage_full[7:0] <= pair_csrbank1_iir_c_1_a10_r;
	end
	pair_fastchain1_iir2_csrstorage6_re <= pair_csrbank1_iir_c_1_a10_re;
	if (pair_csrbank1_iir_c_1_b03_re) begin
		pair_fastchain1_iir2_csrstorage7_storage_full[24] <= pair_csrbank1_iir_c_1_b03_r;
	end
	if (pair_csrbank1_iir_c_1_b02_re) begin
		pair_fastchain1_iir2_csrstorage7_storage_full[23:16] <= pair_csrbank1_iir_c_1_b02_r;
	end
	if (pair_csrbank1_iir_c_1_b01_re) begin
		pair_fastchain1_iir2_csrstorage7_storage_full[15:8] <= pair_csrbank1_iir_c_1_b01_r;
	end
	if (pair_csrbank1_iir_c_1_b00_re) begin
		pair_fastchain1_iir2_csrstorage7_storage_full[7:0] <= pair_csrbank1_iir_c_1_b00_r;
	end
	pair_fastchain1_iir2_csrstorage7_re <= pair_csrbank1_iir_c_1_b00_re;
	if (pair_csrbank1_iir_c_1_b13_re) begin
		pair_fastchain1_iir2_csrstorage8_storage_full[24] <= pair_csrbank1_iir_c_1_b13_r;
	end
	if (pair_csrbank1_iir_c_1_b12_re) begin
		pair_fastchain1_iir2_csrstorage8_storage_full[23:16] <= pair_csrbank1_iir_c_1_b12_r;
	end
	if (pair_csrbank1_iir_c_1_b11_re) begin
		pair_fastchain1_iir2_csrstorage8_storage_full[15:8] <= pair_csrbank1_iir_c_1_b11_r;
	end
	if (pair_csrbank1_iir_c_1_b10_re) begin
		pair_fastchain1_iir2_csrstorage8_storage_full[7:0] <= pair_csrbank1_iir_c_1_b10_r;
	end
	pair_fastchain1_iir2_csrstorage8_re <= pair_csrbank1_iir_c_1_b10_re;
	if (pair_csrbank1_iir_d_1_z03_re) begin
		pair_fastchain1_iir2_storage_full1[26:24] <= pair_csrbank1_iir_d_1_z03_r;
	end
	if (pair_csrbank1_iir_d_1_z02_re) begin
		pair_fastchain1_iir2_storage_full1[23:16] <= pair_csrbank1_iir_d_1_z02_r;
	end
	if (pair_csrbank1_iir_d_1_z01_re) begin
		pair_fastchain1_iir2_storage_full1[15:8] <= pair_csrbank1_iir_d_1_z01_r;
	end
	if (pair_csrbank1_iir_d_1_z00_re) begin
		pair_fastchain1_iir2_storage_full1[7:0] <= pair_csrbank1_iir_d_1_z00_r;
	end
	pair_fastchain1_iir2_re1 <= pair_csrbank1_iir_d_1_z00_re;
	if (pair_csrbank1_iir_d_1_a13_re) begin
		pair_fastchain1_iir2_csrstorage10_storage_full[24] <= pair_csrbank1_iir_d_1_a13_r;
	end
	if (pair_csrbank1_iir_d_1_a12_re) begin
		pair_fastchain1_iir2_csrstorage10_storage_full[23:16] <= pair_csrbank1_iir_d_1_a12_r;
	end
	if (pair_csrbank1_iir_d_1_a11_re) begin
		pair_fastchain1_iir2_csrstorage10_storage_full[15:8] <= pair_csrbank1_iir_d_1_a11_r;
	end
	if (pair_csrbank1_iir_d_1_a10_re) begin
		pair_fastchain1_iir2_csrstorage10_storage_full[7:0] <= pair_csrbank1_iir_d_1_a10_r;
	end
	pair_fastchain1_iir2_csrstorage10_re <= pair_csrbank1_iir_d_1_a10_re;
	if (pair_csrbank1_iir_d_1_a23_re) begin
		pair_fastchain1_iir2_csrstorage11_storage_full[24] <= pair_csrbank1_iir_d_1_a23_r;
	end
	if (pair_csrbank1_iir_d_1_a22_re) begin
		pair_fastchain1_iir2_csrstorage11_storage_full[23:16] <= pair_csrbank1_iir_d_1_a22_r;
	end
	if (pair_csrbank1_iir_d_1_a21_re) begin
		pair_fastchain1_iir2_csrstorage11_storage_full[15:8] <= pair_csrbank1_iir_d_1_a21_r;
	end
	if (pair_csrbank1_iir_d_1_a20_re) begin
		pair_fastchain1_iir2_csrstorage11_storage_full[7:0] <= pair_csrbank1_iir_d_1_a20_r;
	end
	pair_fastchain1_iir2_csrstorage11_re <= pair_csrbank1_iir_d_1_a20_re;
	if (pair_csrbank1_iir_d_1_b03_re) begin
		pair_fastchain1_iir2_csrstorage12_storage_full[24] <= pair_csrbank1_iir_d_1_b03_r;
	end
	if (pair_csrbank1_iir_d_1_b02_re) begin
		pair_fastchain1_iir2_csrstorage12_storage_full[23:16] <= pair_csrbank1_iir_d_1_b02_r;
	end
	if (pair_csrbank1_iir_d_1_b01_re) begin
		pair_fastchain1_iir2_csrstorage12_storage_full[15:8] <= pair_csrbank1_iir_d_1_b01_r;
	end
	if (pair_csrbank1_iir_d_1_b00_re) begin
		pair_fastchain1_iir2_csrstorage12_storage_full[7:0] <= pair_csrbank1_iir_d_1_b00_r;
	end
	pair_fastchain1_iir2_csrstorage12_re <= pair_csrbank1_iir_d_1_b00_re;
	if (pair_csrbank1_iir_d_1_b13_re) begin
		pair_fastchain1_iir2_csrstorage13_storage_full[24] <= pair_csrbank1_iir_d_1_b13_r;
	end
	if (pair_csrbank1_iir_d_1_b12_re) begin
		pair_fastchain1_iir2_csrstorage13_storage_full[23:16] <= pair_csrbank1_iir_d_1_b12_r;
	end
	if (pair_csrbank1_iir_d_1_b11_re) begin
		pair_fastchain1_iir2_csrstorage13_storage_full[15:8] <= pair_csrbank1_iir_d_1_b11_r;
	end
	if (pair_csrbank1_iir_d_1_b10_re) begin
		pair_fastchain1_iir2_csrstorage13_storage_full[7:0] <= pair_csrbank1_iir_d_1_b10_r;
	end
	pair_fastchain1_iir2_csrstorage13_re <= pair_csrbank1_iir_d_1_b10_re;
	if (pair_csrbank1_iir_d_1_b23_re) begin
		pair_fastchain1_iir2_csrstorage14_storage_full[24] <= pair_csrbank1_iir_d_1_b23_r;
	end
	if (pair_csrbank1_iir_d_1_b22_re) begin
		pair_fastchain1_iir2_csrstorage14_storage_full[23:16] <= pair_csrbank1_iir_d_1_b22_r;
	end
	if (pair_csrbank1_iir_d_1_b21_re) begin
		pair_fastchain1_iir2_csrstorage14_storage_full[15:8] <= pair_csrbank1_iir_d_1_b21_r;
	end
	if (pair_csrbank1_iir_d_1_b20_re) begin
		pair_fastchain1_iir2_csrstorage14_storage_full[7:0] <= pair_csrbank1_iir_d_1_b20_r;
	end
	pair_fastchain1_iir2_csrstorage14_re <= pair_csrbank1_iir_d_1_b20_re;
	if (pair_csrbank1_y_limit_1_min3_re) begin
		pair_fastchain1_paralleltaplimitcsr0_min_storage_full[24] <= pair_csrbank1_y_limit_1_min3_r;
	end
	if (pair_csrbank1_y_limit_1_min2_re) begin
		pair_fastchain1_paralleltaplimitcsr0_min_storage_full[23:16] <= pair_csrbank1_y_limit_1_min2_r;
	end
	if (pair_csrbank1_y_limit_1_min1_re) begin
		pair_fastchain1_paralleltaplimitcsr0_min_storage_full[15:8] <= pair_csrbank1_y_limit_1_min1_r;
	end
	if (pair_csrbank1_y_limit_1_min0_re) begin
		pair_fastchain1_paralleltaplimitcsr0_min_storage_full[7:0] <= pair_csrbank1_y_limit_1_min0_r;
	end
	pair_fastchain1_paralleltaplimitcsr0_min_re <= pair_csrbank1_y_limit_1_min0_re;
	if (pair_csrbank1_y_limit_1_max3_re) begin
		pair_fastchain1_paralleltaplimitcsr0_max_storage_full[24] <= pair_csrbank1_y_limit_1_max3_r;
	end
	if (pair_csrbank1_y_limit_1_max2_re) begin
		pair_fastchain1_paralleltaplimitcsr0_max_storage_full[23:16] <= pair_csrbank1_y_limit_1_max2_r;
	end
	if (pair_csrbank1_y_limit_1_max1_re) begin
		pair_fastchain1_paralleltaplimitcsr0_max_storage_full[15:8] <= pair_csrbank1_y_limit_1_max1_r;
	end
	if (pair_csrbank1_y_limit_1_max0_re) begin
		pair_fastchain1_paralleltaplimitcsr0_max_storage_full[7:0] <= pair_csrbank1_y_limit_1_max0_r;
	end
	pair_fastchain1_paralleltaplimitcsr0_max_re <= pair_csrbank1_y_limit_1_max0_re;
	if (pair_csrbank1_x_limit_2_min3_re) begin
		pair_fastchain1_limitcsr3_min_storage_full[24] <= pair_csrbank1_x_limit_2_min3_r;
	end
	if (pair_csrbank1_x_limit_2_min2_re) begin
		pair_fastchain1_limitcsr3_min_storage_full[23:16] <= pair_csrbank1_x_limit_2_min2_r;
	end
	if (pair_csrbank1_x_limit_2_min1_re) begin
		pair_fastchain1_limitcsr3_min_storage_full[15:8] <= pair_csrbank1_x_limit_2_min1_r;
	end
	if (pair_csrbank1_x_limit_2_min0_re) begin
		pair_fastchain1_limitcsr3_min_storage_full[7:0] <= pair_csrbank1_x_limit_2_min0_r;
	end
	pair_fastchain1_limitcsr3_min_re <= pair_csrbank1_x_limit_2_min0_re;
	if (pair_csrbank1_x_limit_2_max3_re) begin
		pair_fastchain1_limitcsr3_max_storage_full[24] <= pair_csrbank1_x_limit_2_max3_r;
	end
	if (pair_csrbank1_x_limit_2_max2_re) begin
		pair_fastchain1_limitcsr3_max_storage_full[23:16] <= pair_csrbank1_x_limit_2_max2_r;
	end
	if (pair_csrbank1_x_limit_2_max1_re) begin
		pair_fastchain1_limitcsr3_max_storage_full[15:8] <= pair_csrbank1_x_limit_2_max1_r;
	end
	if (pair_csrbank1_x_limit_2_max0_re) begin
		pair_fastchain1_limitcsr3_max_storage_full[7:0] <= pair_csrbank1_x_limit_2_max0_r;
	end
	pair_fastchain1_limitcsr3_max_re <= pair_csrbank1_x_limit_2_max0_re;
	if (pair_csrbank1_iir_c_2_z03_re) begin
		pair_fastchain1_iir3_storage_full0[26:24] <= pair_csrbank1_iir_c_2_z03_r;
	end
	if (pair_csrbank1_iir_c_2_z02_re) begin
		pair_fastchain1_iir3_storage_full0[23:16] <= pair_csrbank1_iir_c_2_z02_r;
	end
	if (pair_csrbank1_iir_c_2_z01_re) begin
		pair_fastchain1_iir3_storage_full0[15:8] <= pair_csrbank1_iir_c_2_z01_r;
	end
	if (pair_csrbank1_iir_c_2_z00_re) begin
		pair_fastchain1_iir3_storage_full0[7:0] <= pair_csrbank1_iir_c_2_z00_r;
	end
	pair_fastchain1_iir3_re0 <= pair_csrbank1_iir_c_2_z00_re;
	if (pair_csrbank1_iir_c_2_a13_re) begin
		pair_fastchain1_iir3_csrstorage9_storage_full[24] <= pair_csrbank1_iir_c_2_a13_r;
	end
	if (pair_csrbank1_iir_c_2_a12_re) begin
		pair_fastchain1_iir3_csrstorage9_storage_full[23:16] <= pair_csrbank1_iir_c_2_a12_r;
	end
	if (pair_csrbank1_iir_c_2_a11_re) begin
		pair_fastchain1_iir3_csrstorage9_storage_full[15:8] <= pair_csrbank1_iir_c_2_a11_r;
	end
	if (pair_csrbank1_iir_c_2_a10_re) begin
		pair_fastchain1_iir3_csrstorage9_storage_full[7:0] <= pair_csrbank1_iir_c_2_a10_r;
	end
	pair_fastchain1_iir3_csrstorage9_re <= pair_csrbank1_iir_c_2_a10_re;
	if (pair_csrbank1_iir_c_2_b03_re) begin
		pair_fastchain1_iir3_csrstorage10_storage_full[24] <= pair_csrbank1_iir_c_2_b03_r;
	end
	if (pair_csrbank1_iir_c_2_b02_re) begin
		pair_fastchain1_iir3_csrstorage10_storage_full[23:16] <= pair_csrbank1_iir_c_2_b02_r;
	end
	if (pair_csrbank1_iir_c_2_b01_re) begin
		pair_fastchain1_iir3_csrstorage10_storage_full[15:8] <= pair_csrbank1_iir_c_2_b01_r;
	end
	if (pair_csrbank1_iir_c_2_b00_re) begin
		pair_fastchain1_iir3_csrstorage10_storage_full[7:0] <= pair_csrbank1_iir_c_2_b00_r;
	end
	pair_fastchain1_iir3_csrstorage10_re <= pair_csrbank1_iir_c_2_b00_re;
	if (pair_csrbank1_iir_c_2_b13_re) begin
		pair_fastchain1_iir3_csrstorage11_storage_full[24] <= pair_csrbank1_iir_c_2_b13_r;
	end
	if (pair_csrbank1_iir_c_2_b12_re) begin
		pair_fastchain1_iir3_csrstorage11_storage_full[23:16] <= pair_csrbank1_iir_c_2_b12_r;
	end
	if (pair_csrbank1_iir_c_2_b11_re) begin
		pair_fastchain1_iir3_csrstorage11_storage_full[15:8] <= pair_csrbank1_iir_c_2_b11_r;
	end
	if (pair_csrbank1_iir_c_2_b10_re) begin
		pair_fastchain1_iir3_csrstorage11_storage_full[7:0] <= pair_csrbank1_iir_c_2_b10_r;
	end
	pair_fastchain1_iir3_csrstorage11_re <= pair_csrbank1_iir_c_2_b10_re;
	if (pair_csrbank1_iir_d_2_z03_re) begin
		pair_fastchain1_iir3_storage_full1[26:24] <= pair_csrbank1_iir_d_2_z03_r;
	end
	if (pair_csrbank1_iir_d_2_z02_re) begin
		pair_fastchain1_iir3_storage_full1[23:16] <= pair_csrbank1_iir_d_2_z02_r;
	end
	if (pair_csrbank1_iir_d_2_z01_re) begin
		pair_fastchain1_iir3_storage_full1[15:8] <= pair_csrbank1_iir_d_2_z01_r;
	end
	if (pair_csrbank1_iir_d_2_z00_re) begin
		pair_fastchain1_iir3_storage_full1[7:0] <= pair_csrbank1_iir_d_2_z00_r;
	end
	pair_fastchain1_iir3_re1 <= pair_csrbank1_iir_d_2_z00_re;
	if (pair_csrbank1_iir_d_2_a13_re) begin
		pair_fastchain1_iir3_csrstorage15_storage_full[24] <= pair_csrbank1_iir_d_2_a13_r;
	end
	if (pair_csrbank1_iir_d_2_a12_re) begin
		pair_fastchain1_iir3_csrstorage15_storage_full[23:16] <= pair_csrbank1_iir_d_2_a12_r;
	end
	if (pair_csrbank1_iir_d_2_a11_re) begin
		pair_fastchain1_iir3_csrstorage15_storage_full[15:8] <= pair_csrbank1_iir_d_2_a11_r;
	end
	if (pair_csrbank1_iir_d_2_a10_re) begin
		pair_fastchain1_iir3_csrstorage15_storage_full[7:0] <= pair_csrbank1_iir_d_2_a10_r;
	end
	pair_fastchain1_iir3_csrstorage15_re <= pair_csrbank1_iir_d_2_a10_re;
	if (pair_csrbank1_iir_d_2_a23_re) begin
		pair_fastchain1_iir3_csrstorage16_storage_full[24] <= pair_csrbank1_iir_d_2_a23_r;
	end
	if (pair_csrbank1_iir_d_2_a22_re) begin
		pair_fastchain1_iir3_csrstorage16_storage_full[23:16] <= pair_csrbank1_iir_d_2_a22_r;
	end
	if (pair_csrbank1_iir_d_2_a21_re) begin
		pair_fastchain1_iir3_csrstorage16_storage_full[15:8] <= pair_csrbank1_iir_d_2_a21_r;
	end
	if (pair_csrbank1_iir_d_2_a20_re) begin
		pair_fastchain1_iir3_csrstorage16_storage_full[7:0] <= pair_csrbank1_iir_d_2_a20_r;
	end
	pair_fastchain1_iir3_csrstorage16_re <= pair_csrbank1_iir_d_2_a20_re;
	if (pair_csrbank1_iir_d_2_b03_re) begin
		pair_fastchain1_iir3_csrstorage17_storage_full[24] <= pair_csrbank1_iir_d_2_b03_r;
	end
	if (pair_csrbank1_iir_d_2_b02_re) begin
		pair_fastchain1_iir3_csrstorage17_storage_full[23:16] <= pair_csrbank1_iir_d_2_b02_r;
	end
	if (pair_csrbank1_iir_d_2_b01_re) begin
		pair_fastchain1_iir3_csrstorage17_storage_full[15:8] <= pair_csrbank1_iir_d_2_b01_r;
	end
	if (pair_csrbank1_iir_d_2_b00_re) begin
		pair_fastchain1_iir3_csrstorage17_storage_full[7:0] <= pair_csrbank1_iir_d_2_b00_r;
	end
	pair_fastchain1_iir3_csrstorage17_re <= pair_csrbank1_iir_d_2_b00_re;
	if (pair_csrbank1_iir_d_2_b13_re) begin
		pair_fastchain1_iir3_csrstorage18_storage_full[24] <= pair_csrbank1_iir_d_2_b13_r;
	end
	if (pair_csrbank1_iir_d_2_b12_re) begin
		pair_fastchain1_iir3_csrstorage18_storage_full[23:16] <= pair_csrbank1_iir_d_2_b12_r;
	end
	if (pair_csrbank1_iir_d_2_b11_re) begin
		pair_fastchain1_iir3_csrstorage18_storage_full[15:8] <= pair_csrbank1_iir_d_2_b11_r;
	end
	if (pair_csrbank1_iir_d_2_b10_re) begin
		pair_fastchain1_iir3_csrstorage18_storage_full[7:0] <= pair_csrbank1_iir_d_2_b10_r;
	end
	pair_fastchain1_iir3_csrstorage18_re <= pair_csrbank1_iir_d_2_b10_re;
	if (pair_csrbank1_iir_d_2_b23_re) begin
		pair_fastchain1_iir3_csrstorage19_storage_full[24] <= pair_csrbank1_iir_d_2_b23_r;
	end
	if (pair_csrbank1_iir_d_2_b22_re) begin
		pair_fastchain1_iir3_csrstorage19_storage_full[23:16] <= pair_csrbank1_iir_d_2_b22_r;
	end
	if (pair_csrbank1_iir_d_2_b21_re) begin
		pair_fastchain1_iir3_csrstorage19_storage_full[15:8] <= pair_csrbank1_iir_d_2_b21_r;
	end
	if (pair_csrbank1_iir_d_2_b20_re) begin
		pair_fastchain1_iir3_csrstorage19_storage_full[7:0] <= pair_csrbank1_iir_d_2_b20_r;
	end
	pair_fastchain1_iir3_csrstorage19_re <= pair_csrbank1_iir_d_2_b20_re;
	if (pair_csrbank1_y_limit_2_min3_re) begin
		pair_fastchain1_paralleltaplimitcsr1_min_storage_full[24] <= pair_csrbank1_y_limit_2_min3_r;
	end
	if (pair_csrbank1_y_limit_2_min2_re) begin
		pair_fastchain1_paralleltaplimitcsr1_min_storage_full[23:16] <= pair_csrbank1_y_limit_2_min2_r;
	end
	if (pair_csrbank1_y_limit_2_min1_re) begin
		pair_fastchain1_paralleltaplimitcsr1_min_storage_full[15:8] <= pair_csrbank1_y_limit_2_min1_r;
	end
	if (pair_csrbank1_y_limit_2_min0_re) begin
		pair_fastchain1_paralleltaplimitcsr1_min_storage_full[7:0] <= pair_csrbank1_y_limit_2_min0_r;
	end
	pair_fastchain1_paralleltaplimitcsr1_min_re <= pair_csrbank1_y_limit_2_min0_re;
	if (pair_csrbank1_y_limit_2_max3_re) begin
		pair_fastchain1_paralleltaplimitcsr1_max_storage_full[24] <= pair_csrbank1_y_limit_2_max3_r;
	end
	if (pair_csrbank1_y_limit_2_max2_re) begin
		pair_fastchain1_paralleltaplimitcsr1_max_storage_full[23:16] <= pair_csrbank1_y_limit_2_max2_r;
	end
	if (pair_csrbank1_y_limit_2_max1_re) begin
		pair_fastchain1_paralleltaplimitcsr1_max_storage_full[15:8] <= pair_csrbank1_y_limit_2_max1_r;
	end
	if (pair_csrbank1_y_limit_2_max0_re) begin
		pair_fastchain1_paralleltaplimitcsr1_max_storage_full[7:0] <= pair_csrbank1_y_limit_2_max0_r;
	end
	pair_fastchain1_paralleltaplimitcsr1_max_re <= pair_csrbank1_y_limit_2_max0_re;
	if (sys_rst) begin
		pair_fastchain0_y_tap_storage_full <= 2'd0;
		pair_fastchain0_y_tap_re <= 1'd0;
		pair_fastchain0_invert_storage_full <= 1'd0;
		pair_fastchain0_invert_re <= 1'd0;
		pair_fastchain0_delay_storage_full <= 32'd0;
		pair_fastchain0_delay_re <= 1'd0;
		pair_fastchain0_multiplier_storage_full <= 4'd1;
		pair_fastchain0_multiplier_re <= 1'd0;
		pair_fastchain0_cordic01 <= 17'sd0;
		pair_fastchain0_cordic02 <= 17'sd0;
		pair_fastchain0_cordic03 <= 17'sd0;
		pair_fastchain0_cordic04 <= 17'sd0;
		pair_fastchain0_cordic05 <= 17'sd0;
		pair_fastchain0_cordic06 <= 17'sd0;
		pair_fastchain0_cordic07 <= 17'sd0;
		pair_fastchain0_cordic08 <= 17'sd0;
		pair_fastchain0_cordic09 <= 17'sd0;
		pair_fastchain0_cordic010 <= 17'sd0;
		pair_fastchain0_cordic011 <= 17'sd0;
		pair_fastchain0_cordic012 <= 17'sd0;
		pair_fastchain0_cordic013 <= 17'sd0;
		pair_fastchain0_cordic014 <= 17'sd0;
		pair_fastchain0_cordic015 <= 17'sd0;
		pair_fastchain0_cordic017 <= 17'sd0;
		pair_fastchain0_cordic018 <= 17'sd0;
		pair_fastchain0_cordic019 <= 17'sd0;
		pair_fastchain0_cordic020 <= 17'sd0;
		pair_fastchain0_cordic021 <= 17'sd0;
		pair_fastchain0_cordic022 <= 17'sd0;
		pair_fastchain0_cordic023 <= 17'sd0;
		pair_fastchain0_cordic024 <= 17'sd0;
		pair_fastchain0_cordic025 <= 17'sd0;
		pair_fastchain0_cordic026 <= 17'sd0;
		pair_fastchain0_cordic027 <= 17'sd0;
		pair_fastchain0_cordic028 <= 17'sd0;
		pair_fastchain0_cordic029 <= 17'sd0;
		pair_fastchain0_cordic030 <= 17'sd0;
		pair_fastchain0_cordic031 <= 17'sd0;
		pair_fastchain0_cordic033 <= 17'sd0;
		pair_fastchain0_cordic034 <= 17'sd0;
		pair_fastchain0_cordic035 <= 17'sd0;
		pair_fastchain0_cordic036 <= 17'sd0;
		pair_fastchain0_cordic037 <= 17'sd0;
		pair_fastchain0_cordic038 <= 17'sd0;
		pair_fastchain0_cordic039 <= 17'sd0;
		pair_fastchain0_cordic040 <= 17'sd0;
		pair_fastchain0_cordic041 <= 17'sd0;
		pair_fastchain0_cordic042 <= 17'sd0;
		pair_fastchain0_cordic043 <= 17'sd0;
		pair_fastchain0_cordic044 <= 17'sd0;
		pair_fastchain0_cordic045 <= 17'sd0;
		pair_fastchain0_cordic046 <= 17'sd0;
		pair_fastchain0_cordic047 <= 17'sd0;
		pair_fastchain0_ya <= 17'sd0;
		pair_fastchain0_limitcsr0_limitcsr0_y0 <= 25'sd0;
		pair_fastchain0_limitcsr0_limitcsr0_error0 <= 1'd0;
		pair_fastchain0_limitcsr0_min_storage_full0 <= 25'd16777216;
		pair_fastchain0_limitcsr0_min_re0 <= 1'd0;
		pair_fastchain0_limitcsr0_max_storage_full0 <= 25'd16777215;
		pair_fastchain0_limitcsr0_max_re0 <= 1'd0;
		pair_fastchain0_limitcsr0_limit_max0 <= 26'sd0;
		pair_fastchain0_limitcsr0_limit_min0 <= 26'sd0;
		pair_fastchain0_iir0_y0 <= 25'sd0;
		pair_fastchain0_iir0_error0 <= 1'd0;
		pair_fastchain0_iir0_storage_full0 <= 27'd0;
		pair_fastchain0_iir0_re0 <= 1'd0;
		pair_fastchain0_iir0_a10 <= 25'sd0;
		pair_fastchain0_iir0_csrstorage0_storage_full0 <= 25'd0;
		pair_fastchain0_iir0_csrstorage0_re0 <= 1'd0;
		pair_fastchain0_iir0_b00 <= 25'sd0;
		pair_fastchain0_iir0_csrstorage1_storage_full0 <= 25'd0;
		pair_fastchain0_iir0_csrstorage1_re0 <= 1'd0;
		pair_fastchain0_iir0_b10 <= 25'sd0;
		pair_fastchain0_iir0_csrstorage2_storage_full0 <= 25'd0;
		pair_fastchain0_iir0_csrstorage2_re0 <= 1'd0;
		pair_fastchain0_iir0_z0r0 <= 50'sd0;
		pair_fastchain0_iir0_y1 <= 25'sd0;
		pair_fastchain0_iir0_zr0 <= 50'sd0;
		pair_fastchain0_iir0_zr1 <= 50'sd0;
		pair_fastchain0_iir0_zr2 <= 50'sd0;
		pair_fastchain0_iir0_y2 <= 25'sd0;
		pair_fastchain0_iir0_error1 <= 1'd0;
		pair_fastchain0_iir0_storage_full1 <= 27'd0;
		pair_fastchain0_iir0_re1 <= 1'd0;
		pair_fastchain0_iir0_a11 <= 25'sd0;
		pair_fastchain0_iir0_csrstorage0_storage_full1 <= 25'd0;
		pair_fastchain0_iir0_csrstorage0_re1 <= 1'd0;
		pair_fastchain0_iir0_a2 <= 25'sd0;
		pair_fastchain0_iir0_csrstorage1_storage_full1 <= 25'd0;
		pair_fastchain0_iir0_csrstorage1_re1 <= 1'd0;
		pair_fastchain0_iir0_b01 <= 25'sd0;
		pair_fastchain0_iir0_csrstorage2_storage_full1 <= 25'd0;
		pair_fastchain0_iir0_csrstorage2_re1 <= 1'd0;
		pair_fastchain0_iir0_b11 <= 25'sd0;
		pair_fastchain0_iir0_csrstorage3_storage_full <= 25'd0;
		pair_fastchain0_iir0_csrstorage3_re <= 1'd0;
		pair_fastchain0_iir0_b2 <= 25'sd0;
		pair_fastchain0_iir0_csrstorage4_storage_full <= 25'd0;
		pair_fastchain0_iir0_csrstorage4_re <= 1'd0;
		pair_fastchain0_iir0_z0r1 <= 50'sd0;
		pair_fastchain0_iir0_y3 <= 25'sd0;
		pair_fastchain0_iir0_zr3 <= 50'sd0;
		pair_fastchain0_iir0_zr4 <= 50'sd0;
		pair_fastchain0_iir0_zr5 <= 50'sd0;
		pair_fastchain0_iir0_zr6 <= 50'sd0;
		pair_fastchain0_iir0_zr7 <= 50'sd0;
		pair_fastchain0_limitcsr0_limitcsr0_y1 <= 25'sd0;
		pair_fastchain0_limitcsr0_limitcsr0_error1 <= 1'd0;
		pair_fastchain0_limitcsr0_min_storage_full1 <= 25'd16777216;
		pair_fastchain0_limitcsr0_min_re1 <= 1'd0;
		pair_fastchain0_limitcsr0_max_storage_full1 <= 25'd16777215;
		pair_fastchain0_limitcsr0_max_re1 <= 1'd0;
		pair_fastchain0_limitcsr0_limit_max1 <= 28'sd0;
		pair_fastchain0_limitcsr0_limit_min1 <= 28'sd0;
		pair_fastchain0_limitcsr1_limitcsr1_y0 <= 25'sd0;
		pair_fastchain0_limitcsr1_limitcsr1_error0 <= 1'd0;
		pair_fastchain0_limitcsr1_min_storage_full0 <= 25'd16777216;
		pair_fastchain0_limitcsr1_min_re0 <= 1'd0;
		pair_fastchain0_limitcsr1_max_storage_full0 <= 25'd16777215;
		pair_fastchain0_limitcsr1_max_re0 <= 1'd0;
		pair_fastchain0_limitcsr1_limit_max0 <= 26'sd0;
		pair_fastchain0_limitcsr1_limit_min0 <= 26'sd0;
		pair_fastchain0_iir1_y0 <= 25'sd0;
		pair_fastchain0_iir1_error0 <= 1'd0;
		pair_fastchain0_iir1_storage_full0 <= 27'd0;
		pair_fastchain0_iir1_re0 <= 1'd0;
		pair_fastchain0_iir1_a10 <= 25'sd0;
		pair_fastchain0_iir1_csrstorage3_storage_full <= 25'd0;
		pair_fastchain0_iir1_csrstorage3_re <= 1'd0;
		pair_fastchain0_iir1_b00 <= 25'sd0;
		pair_fastchain0_iir1_csrstorage4_storage_full <= 25'd0;
		pair_fastchain0_iir1_csrstorage4_re <= 1'd0;
		pair_fastchain0_iir1_b10 <= 25'sd0;
		pair_fastchain0_iir1_csrstorage5_storage_full0 <= 25'd0;
		pair_fastchain0_iir1_csrstorage5_re0 <= 1'd0;
		pair_fastchain0_iir1_z0r0 <= 50'sd0;
		pair_fastchain0_iir1_y1 <= 25'sd0;
		pair_fastchain0_iir1_zr0 <= 50'sd0;
		pair_fastchain0_iir1_zr1 <= 50'sd0;
		pair_fastchain0_iir1_zr2 <= 50'sd0;
		pair_fastchain0_iir1_y2 <= 25'sd0;
		pair_fastchain0_iir1_error1 <= 1'd0;
		pair_fastchain0_iir1_storage_full1 <= 27'd0;
		pair_fastchain0_iir1_re1 <= 1'd0;
		pair_fastchain0_iir1_a11 <= 25'sd0;
		pair_fastchain0_iir1_csrstorage5_storage_full1 <= 25'd0;
		pair_fastchain0_iir1_csrstorage5_re1 <= 1'd0;
		pair_fastchain0_iir1_a2 <= 25'sd0;
		pair_fastchain0_iir1_csrstorage6_storage_full <= 25'd0;
		pair_fastchain0_iir1_csrstorage6_re <= 1'd0;
		pair_fastchain0_iir1_b01 <= 25'sd0;
		pair_fastchain0_iir1_csrstorage7_storage_full <= 25'd0;
		pair_fastchain0_iir1_csrstorage7_re <= 1'd0;
		pair_fastchain0_iir1_b11 <= 25'sd0;
		pair_fastchain0_iir1_csrstorage8_storage_full <= 25'd0;
		pair_fastchain0_iir1_csrstorage8_re <= 1'd0;
		pair_fastchain0_iir1_b2 <= 25'sd0;
		pair_fastchain0_iir1_csrstorage9_storage_full <= 25'd0;
		pair_fastchain0_iir1_csrstorage9_re <= 1'd0;
		pair_fastchain0_iir1_z0r1 <= 50'sd0;
		pair_fastchain0_iir1_y3 <= 25'sd0;
		pair_fastchain0_iir1_zr3 <= 50'sd0;
		pair_fastchain0_iir1_zr4 <= 50'sd0;
		pair_fastchain0_iir1_zr5 <= 50'sd0;
		pair_fastchain0_iir1_zr6 <= 50'sd0;
		pair_fastchain0_iir1_zr7 <= 50'sd0;
		pair_fastchain0_limitcsr1_limitcsr1_y1 <= 25'sd0;
		pair_fastchain0_limitcsr1_limitcsr1_error1 <= 1'd0;
		pair_fastchain0_limitcsr1_min_storage_full1 <= 25'd16777216;
		pair_fastchain0_limitcsr1_min_re1 <= 1'd0;
		pair_fastchain0_limitcsr1_max_storage_full1 <= 25'd16777215;
		pair_fastchain0_limitcsr1_max_re1 <= 1'd0;
		pair_fastchain0_limitcsr1_limit_max1 <= 28'sd0;
		pair_fastchain0_limitcsr1_limit_min1 <= 28'sd0;
		pair_csrbank0_bus_dat_r <= 8'd0;
		pair_fastchain1_y_tap_storage_full <= 2'd0;
		pair_fastchain1_y_tap_re <= 1'd0;
		pair_fastchain1_invert_storage_full <= 1'd0;
		pair_fastchain1_invert_re <= 1'd0;
		pair_fastchain1_delay_storage_full <= 32'd0;
		pair_fastchain1_delay_re <= 1'd0;
		pair_fastchain1_multiplier_storage_full <= 4'd1;
		pair_fastchain1_multiplier_re <= 1'd0;
		pair_fastchain1_cordic11 <= 17'sd0;
		pair_fastchain1_cordic12 <= 17'sd0;
		pair_fastchain1_cordic13 <= 17'sd0;
		pair_fastchain1_cordic14 <= 17'sd0;
		pair_fastchain1_cordic15 <= 17'sd0;
		pair_fastchain1_cordic16 <= 17'sd0;
		pair_fastchain1_cordic17 <= 17'sd0;
		pair_fastchain1_cordic18 <= 17'sd0;
		pair_fastchain1_cordic19 <= 17'sd0;
		pair_fastchain1_cordic110 <= 17'sd0;
		pair_fastchain1_cordic111 <= 17'sd0;
		pair_fastchain1_cordic112 <= 17'sd0;
		pair_fastchain1_cordic113 <= 17'sd0;
		pair_fastchain1_cordic114 <= 17'sd0;
		pair_fastchain1_cordic115 <= 17'sd0;
		pair_fastchain1_cordic117 <= 17'sd0;
		pair_fastchain1_cordic118 <= 17'sd0;
		pair_fastchain1_cordic119 <= 17'sd0;
		pair_fastchain1_cordic120 <= 17'sd0;
		pair_fastchain1_cordic121 <= 17'sd0;
		pair_fastchain1_cordic122 <= 17'sd0;
		pair_fastchain1_cordic123 <= 17'sd0;
		pair_fastchain1_cordic124 <= 17'sd0;
		pair_fastchain1_cordic125 <= 17'sd0;
		pair_fastchain1_cordic126 <= 17'sd0;
		pair_fastchain1_cordic127 <= 17'sd0;
		pair_fastchain1_cordic128 <= 17'sd0;
		pair_fastchain1_cordic129 <= 17'sd0;
		pair_fastchain1_cordic130 <= 17'sd0;
		pair_fastchain1_cordic131 <= 17'sd0;
		pair_fastchain1_cordic133 <= 17'sd0;
		pair_fastchain1_cordic134 <= 17'sd0;
		pair_fastchain1_cordic135 <= 17'sd0;
		pair_fastchain1_cordic136 <= 17'sd0;
		pair_fastchain1_cordic137 <= 17'sd0;
		pair_fastchain1_cordic138 <= 17'sd0;
		pair_fastchain1_cordic139 <= 17'sd0;
		pair_fastchain1_cordic140 <= 17'sd0;
		pair_fastchain1_cordic141 <= 17'sd0;
		pair_fastchain1_cordic142 <= 17'sd0;
		pair_fastchain1_cordic143 <= 17'sd0;
		pair_fastchain1_cordic144 <= 17'sd0;
		pair_fastchain1_cordic145 <= 17'sd0;
		pair_fastchain1_cordic146 <= 17'sd0;
		pair_fastchain1_cordic147 <= 17'sd0;
		pair_fastchain1_ya <= 17'sd0;
		pair_fastchain1_limitcsr2_limitcsr2_y <= 25'sd0;
		pair_fastchain1_limitcsr2_limitcsr2_error <= 1'd0;
		pair_fastchain1_limitcsr2_min_storage_full <= 25'd16777216;
		pair_fastchain1_limitcsr2_min_re <= 1'd0;
		pair_fastchain1_limitcsr2_max_storage_full <= 25'd16777215;
		pair_fastchain1_limitcsr2_max_re <= 1'd0;
		pair_fastchain1_limitcsr2_limit_max <= 26'sd0;
		pair_fastchain1_limitcsr2_limit_min <= 26'sd0;
		pair_fastchain1_iir2_y0 <= 25'sd0;
		pair_fastchain1_iir2_error0 <= 1'd0;
		pair_fastchain1_iir2_storage_full0 <= 27'd0;
		pair_fastchain1_iir2_re0 <= 1'd0;
		pair_fastchain1_iir2_a10 <= 25'sd0;
		pair_fastchain1_iir2_csrstorage6_storage_full <= 25'd0;
		pair_fastchain1_iir2_csrstorage6_re <= 1'd0;
		pair_fastchain1_iir2_b00 <= 25'sd0;
		pair_fastchain1_iir2_csrstorage7_storage_full <= 25'd0;
		pair_fastchain1_iir2_csrstorage7_re <= 1'd0;
		pair_fastchain1_iir2_b10 <= 25'sd0;
		pair_fastchain1_iir2_csrstorage8_storage_full <= 25'd0;
		pair_fastchain1_iir2_csrstorage8_re <= 1'd0;
		pair_fastchain1_iir2_z0r0 <= 50'sd0;
		pair_fastchain1_iir2_y1 <= 25'sd0;
		pair_fastchain1_iir2_zr0 <= 50'sd0;
		pair_fastchain1_iir2_zr1 <= 50'sd0;
		pair_fastchain1_iir2_zr2 <= 50'sd0;
		pair_fastchain1_iir2_y2 <= 25'sd0;
		pair_fastchain1_iir2_error1 <= 1'd0;
		pair_fastchain1_iir2_storage_full1 <= 27'd0;
		pair_fastchain1_iir2_re1 <= 1'd0;
		pair_fastchain1_iir2_a11 <= 25'sd0;
		pair_fastchain1_iir2_csrstorage10_storage_full <= 25'd0;
		pair_fastchain1_iir2_csrstorage10_re <= 1'd0;
		pair_fastchain1_iir2_a2 <= 25'sd0;
		pair_fastchain1_iir2_csrstorage11_storage_full <= 25'd0;
		pair_fastchain1_iir2_csrstorage11_re <= 1'd0;
		pair_fastchain1_iir2_b01 <= 25'sd0;
		pair_fastchain1_iir2_csrstorage12_storage_full <= 25'd0;
		pair_fastchain1_iir2_csrstorage12_re <= 1'd0;
		pair_fastchain1_iir2_b11 <= 25'sd0;
		pair_fastchain1_iir2_csrstorage13_storage_full <= 25'd0;
		pair_fastchain1_iir2_csrstorage13_re <= 1'd0;
		pair_fastchain1_iir2_b2 <= 25'sd0;
		pair_fastchain1_iir2_csrstorage14_storage_full <= 25'd0;
		pair_fastchain1_iir2_csrstorage14_re <= 1'd0;
		pair_fastchain1_iir2_z0r1 <= 50'sd0;
		pair_fastchain1_iir2_y3 <= 25'sd0;
		pair_fastchain1_iir2_zr3 <= 50'sd0;
		pair_fastchain1_iir2_zr4 <= 50'sd0;
		pair_fastchain1_iir2_zr5 <= 50'sd0;
		pair_fastchain1_iir2_zr6 <= 50'sd0;
		pair_fastchain1_iir2_zr7 <= 50'sd0;
		pair_fastchain1_paralleltaplimitcsr0_y <= 25'sd0;
		pair_fastchain1_paralleltaplimitcsr0_error <= 1'd0;
		pair_fastchain1_paralleltaplimitcsr0_min_storage_full <= 25'd16777216;
		pair_fastchain1_paralleltaplimitcsr0_min_re <= 1'd0;
		pair_fastchain1_paralleltaplimitcsr0_max_storage_full <= 25'd16777215;
		pair_fastchain1_paralleltaplimitcsr0_max_re <= 1'd0;
		pair_fastchain1_paralleltaplimitcsr0_bound_min <= 28'sd0;
		pair_fastchain1_paralleltaplimitcsr0_bound_max <= 28'sd0;
		pair_fastchain1_limitcsr3_limitcsr3_y <= 25'sd0;
		pair_fastchain1_limitcsr3_limitcsr3_error <= 1'd0;
		pair_fastchain1_limitcsr3_min_storage_full <= 25'd16777216;
		pair_fastchain1_limitcsr3_min_re <= 1'd0;
		pair_fastchain1_limitcsr3_max_storage_full <= 25'd16777215;
		pair_fastchain1_limitcsr3_max_re <= 1'd0;
		pair_fastchain1_limitcsr3_limit_max <= 26'sd0;
		pair_fastchain1_limitcsr3_limit_min <= 26'sd0;
		pair_fastchain1_iir3_y0 <= 25'sd0;
		pair_fastchain1_iir3_error0 <= 1'd0;
		pair_fastchain1_iir3_storage_full0 <= 27'd0;
		pair_fastchain1_iir3_re0 <= 1'd0;
		pair_fastchain1_iir3_a10 <= 25'sd0;
		pair_fastchain1_iir3_csrstorage9_storage_full <= 25'd0;
		pair_fastchain1_iir3_csrstorage9_re <= 1'd0;
		pair_fastchain1_iir3_b00 <= 25'sd0;
		pair_fastchain1_iir3_csrstorage10_storage_full <= 25'd0;
		pair_fastchain1_iir3_csrstorage10_re <= 1'd0;
		pair_fastchain1_iir3_b10 <= 25'sd0;
		pair_fastchain1_iir3_csrstorage11_storage_full <= 25'd0;
		pair_fastchain1_iir3_csrstorage11_re <= 1'd0;
		pair_fastchain1_iir3_z0r0 <= 50'sd0;
		pair_fastchain1_iir3_y1 <= 25'sd0;
		pair_fastchain1_iir3_zr0 <= 50'sd0;
		pair_fastchain1_iir3_zr1 <= 50'sd0;
		pair_fastchain1_iir3_zr2 <= 50'sd0;
		pair_fastchain1_iir3_y2 <= 25'sd0;
		pair_fastchain1_iir3_error1 <= 1'd0;
		pair_fastchain1_iir3_storage_full1 <= 27'd0;
		pair_fastchain1_iir3_re1 <= 1'd0;
		pair_fastchain1_iir3_a11 <= 25'sd0;
		pair_fastchain1_iir3_csrstorage15_storage_full <= 25'd0;
		pair_fastchain1_iir3_csrstorage15_re <= 1'd0;
		pair_fastchain1_iir3_a2 <= 25'sd0;
		pair_fastchain1_iir3_csrstorage16_storage_full <= 25'd0;
		pair_fastchain1_iir3_csrstorage16_re <= 1'd0;
		pair_fastchain1_iir3_b01 <= 25'sd0;
		pair_fastchain1_iir3_csrstorage17_storage_full <= 25'd0;
		pair_fastchain1_iir3_csrstorage17_re <= 1'd0;
		pair_fastchain1_iir3_b11 <= 25'sd0;
		pair_fastchain1_iir3_csrstorage18_storage_full <= 25'd0;
		pair_fastchain1_iir3_csrstorage18_re <= 1'd0;
		pair_fastchain1_iir3_b2 <= 25'sd0;
		pair_fastchain1_iir3_csrstorage19_storage_full <= 25'd0;
		pair_fastchain1_iir3_csrstorage19_re <= 1'd0;
		pair_fastchain1_iir3_z0r1 <= 50'sd0;
		pair_fastchain1_iir3_y3 <= 25'sd0;
		pair_fastchain1_iir3_zr3 <= 50'sd0;
		pair_fastchain1_iir3_zr4 <= 50'sd0;
		pair_fastchain1_iir3_zr5 <= 50'sd0;
		pair_fastchain1_iir3_zr6 <= 50'sd0;
		pair_fastchain1_iir3_zr7 <= 50'sd0;
		pair_fastchain1_paralleltaplimitcsr1_y <= 25'sd0;
		pair_fastchain1_paralleltaplimitcsr1_error <= 1'd0;
		pair_fastchain1_paralleltaplimitcsr1_min_storage_full <= 25'd16777216;
		pair_fastchain1_paralleltaplimitcsr1_min_re <= 1'd0;
		pair_fastchain1_paralleltaplimitcsr1_max_storage_full <= 25'd16777215;
		pair_fastchain1_paralleltaplimitcsr1_max_re <= 1'd0;
		pair_fastchain1_paralleltaplimitcsr1_bound_min <= 28'sd0;
		pair_fastchain1_paralleltaplimitcsr1_bound_max <= 28'sd0;
		pair_csrbank1_bus_dat_r <= 8'd0;
	end
end

endmodule
