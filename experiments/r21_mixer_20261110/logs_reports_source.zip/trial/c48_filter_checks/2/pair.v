/* Machine-generated using Migen */
module iir_frame_pair(
	input sys_clk,
	input sys_rst,
	input signed [24:0] x,
	input hold,
	input clear,
	input [13:0] csr_adr,
	input csr_we,
	input [7:0] csr_dat_w,
	output [24:0] ref_y,
	output [24:0] cand_y,
	output ref_error,
	output cand_error,
	output [7:0] read_value,
	output [124:0] ref_coeff,
	output [124:0] cand_coeff,
	output [151:0] cfg
);

wire signed [24:0] pair_iir_x;
reg signed [24:0] pair_iir_y0 = 25'sd0;
wire pair_iir_hold;
wire pair_iir_clear;
reg pair_iir_error = 1'd0;
reg [26:0] pair_iir_storage_full = 27'd0;
wire [26:0] pair_iir_storage;
reg pair_iir_re = 1'd0;
reg signed [24:0] pair_iir_a1 = 25'sd0;
reg [24:0] pair_iir_csrstorage0_storage_full = 25'd0;
wire [24:0] pair_iir_csrstorage0_storage;
reg pair_iir_csrstorage0_re = 1'd0;
reg signed [24:0] pair_iir_a2 = 25'sd0;
reg [24:0] pair_iir_csrstorage1_storage_full = 25'd0;
wire [24:0] pair_iir_csrstorage1_storage;
reg pair_iir_csrstorage1_re = 1'd0;
reg signed [24:0] pair_iir_b0 = 25'sd0;
reg [24:0] pair_iir_csrstorage2_storage_full = 25'd0;
wire [24:0] pair_iir_csrstorage2_storage;
reg pair_iir_csrstorage2_re = 1'd0;
reg signed [24:0] pair_iir_b1 = 25'sd0;
reg [24:0] pair_iir_csrstorage3_storage_full = 25'd0;
wire [24:0] pair_iir_csrstorage3_storage;
reg pair_iir_csrstorage3_re = 1'd0;
reg signed [24:0] pair_iir_b2 = 25'sd0;
reg [24:0] pair_iir_csrstorage4_storage_full = 25'd0;
wire [24:0] pair_iir_csrstorage4_storage;
reg pair_iir_csrstorage4_re = 1'd0;
reg signed [49:0] pair_iir_z0r = 50'sd0;
reg signed [24:0] pair_iir_y_lim;
wire signed [49:0] pair_iir_y_next;
reg [2:0] pair_iir_y_pat = 3'd7;
reg signed [24:0] pair_iir_y1 = 25'sd0;
wire pair_iir_railed;
reg signed [49:0] pair_iir_zr0 = 50'sd0;
wire signed [49:0] pair_iir_z0;
wire signed [17:0] pair_iir_xlo0;
wire signed [7:0] pair_iir_xhi0;
wire signed [47:0] pair_iir_zlo0;
wire signed [1:0] pair_iir_ztop0;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_low0;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_high0;
wire pair_iir0;
wire pair_iir1;
wire signed [3:0] pair_iir_correction0;
wire [1:0] pair_iir_top0;
wire signed [49:0] pair_iir_result0;
reg signed [49:0] pair_iir_zr1 = 50'sd0;
wire signed [49:0] pair_iir_z1;
wire signed [17:0] pair_iir_xlo1;
wire signed [7:0] pair_iir_xhi1;
wire signed [47:0] pair_iir_zlo1;
wire signed [1:0] pair_iir_ztop1;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_low1;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_high1;
wire pair_iir2;
wire pair_iir3;
wire signed [3:0] pair_iir_correction1;
wire [1:0] pair_iir_top1;
wire signed [49:0] pair_iir_result1;
reg signed [49:0] pair_iir_zr2 = 50'sd0;
wire signed [49:0] pair_iir_z2;
wire signed [17:0] pair_iir_xlo2;
wire signed [7:0] pair_iir_xhi2;
wire signed [47:0] pair_iir_zlo2;
wire signed [1:0] pair_iir_ztop2;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_low2;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_high2;
wire pair_iir4;
wire pair_iir5;
wire signed [3:0] pair_iir_correction2;
wire [1:0] pair_iir_top2;
wire signed [49:0] pair_iir_result2;
reg signed [49:0] pair_iir_zr3 = 50'sd0;
wire signed [49:0] pair_iir_z3;
wire signed [17:0] pair_iir_xlo3;
wire signed [7:0] pair_iir_xhi3;
wire signed [47:0] pair_iir_zlo3;
wire signed [1:0] pair_iir_ztop3;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_low3;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_high3;
wire pair_iir6;
wire pair_iir7;
wire signed [3:0] pair_iir_correction3;
wire [1:0] pair_iir_top3;
wire signed [49:0] pair_iir_result3;
reg signed [49:0] pair_iir_zr4 = 50'sd0;
wire signed [49:0] pair_iir_z4;
wire signed [17:0] pair_iir_xlo4;
wire signed [7:0] pair_iir_xhi4;
wire signed [47:0] pair_iir_zlo4;
wire signed [1:0] pair_iir_ztop4;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_low4;
(* use_dsp = "yes" *) wire signed [47:0] pair_iir_high4;
wire pair_iir8;
wire pair_iir9;
wire signed [3:0] pair_iir_correction4;
wire [1:0] pair_iir_top4;
wire signed [49:0] pair_iir_result4;
wire signed [24:0] pair_x;
reg signed [24:0] pair_y0 = 25'sd0;
wire pair_hold;
wire pair_clear;
reg pair_error = 1'd0;
wire [26:0] pair_z0_storage;
reg signed [24:0] pair_a1 = 25'sd0;
wire [24:0] pair_rci_storage0;
reg signed [24:0] pair_a2 = 25'sd0;
wire [24:0] pair_rci_storage1;
reg signed [24:0] pair_b0 = 25'sd0;
wire [24:0] pair_rci_storage2;
reg signed [24:0] pair_b1 = 25'sd0;
wire [24:0] pair_rci_storage3;
reg signed [24:0] pair_b2 = 25'sd0;
wire [24:0] pair_rci_storage4;
reg signed [49:0] pair_z0r = 50'sd0;
reg signed [24:0] pair_y_lim;
wire signed [49:0] pair_y_next;
reg [2:0] pair_y_pat = 3'd7;
reg signed [24:0] pair_y1 = 25'sd0;
wire pair_railed;
reg signed [49:0] pair_zr0 = 50'sd0;
wire signed [49:0] pair_z0;
reg signed [49:0] pair_zr1 = 50'sd0;
wire signed [49:0] pair_z1;
reg signed [49:0] pair_zr2 = 50'sd0;
wire signed [49:0] pair_z2;
reg signed [49:0] pair_zr3 = 50'sd0;
wire signed [49:0] pair_z3;
reg signed [49:0] pair_zr4 = 50'sd0;
wire signed [49:0] pair_z4;
wire [13:0] pair_bus_adr;
wire pair_bus_we;
wire [7:0] pair_bus_dat_w;
reg [7:0] pair_bus_dat_r = 8'd0;
wire pair_z03_re;
wire [2:0] pair_z03_r;
wire [2:0] pair_z03_w;
wire pair_z02_re;
wire [7:0] pair_z02_r;
wire [7:0] pair_z02_w;
wire pair_z01_re;
wire [7:0] pair_z01_r;
wire [7:0] pair_z01_w;
wire pair_z00_re;
wire [7:0] pair_z00_r;
wire [7:0] pair_z00_w;
wire pair_a13_re;
wire pair_a13_r;
wire pair_a13_w;
wire pair_a12_re;
wire [7:0] pair_a12_r;
wire [7:0] pair_a12_w;
wire pair_a11_re;
wire [7:0] pair_a11_r;
wire [7:0] pair_a11_w;
wire pair_a10_re;
wire [7:0] pair_a10_r;
wire [7:0] pair_a10_w;
wire pair_a23_re;
wire pair_a23_r;
wire pair_a23_w;
wire pair_a22_re;
wire [7:0] pair_a22_r;
wire [7:0] pair_a22_w;
wire pair_a21_re;
wire [7:0] pair_a21_r;
wire [7:0] pair_a21_w;
wire pair_a20_re;
wire [7:0] pair_a20_r;
wire [7:0] pair_a20_w;
wire pair_b03_re;
wire pair_b03_r;
wire pair_b03_w;
wire pair_b02_re;
wire [7:0] pair_b02_r;
wire [7:0] pair_b02_w;
wire pair_b01_re;
wire [7:0] pair_b01_r;
wire [7:0] pair_b01_w;
wire pair_b00_re;
wire [7:0] pair_b00_r;
wire [7:0] pair_b00_w;
wire pair_b13_re;
wire pair_b13_r;
wire pair_b13_w;
wire pair_b12_re;
wire [7:0] pair_b12_r;
wire [7:0] pair_b12_w;
wire pair_b11_re;
wire [7:0] pair_b11_r;
wire [7:0] pair_b11_w;
wire pair_b10_re;
wire [7:0] pair_b10_r;
wire [7:0] pair_b10_w;
wire pair_b23_re;
wire pair_b23_r;
wire pair_b23_w;
wire pair_b22_re;
wire [7:0] pair_b22_r;
wire [7:0] pair_b22_w;
wire pair_b21_re;
wire [7:0] pair_b21_r;
wire [7:0] pair_b21_w;
wire pair_b20_re;
wire [7:0] pair_b20_r;
wire [7:0] pair_b20_w;
wire pair_sel;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign pair_iir_x = x;
assign pair_x = x;
assign pair_iir_hold = hold;
assign pair_hold = hold;
assign pair_iir_clear = clear;
assign pair_clear = clear;
assign pair_z0_storage = pair_iir_storage;
assign pair_rci_storage0 = pair_iir_csrstorage0_storage;
assign pair_rci_storage1 = pair_iir_csrstorage1_storage;
assign pair_rci_storage2 = pair_iir_csrstorage2_storage;
assign pair_rci_storage3 = pair_iir_csrstorage3_storage;
assign pair_rci_storage4 = pair_iir_csrstorage4_storage;
assign pair_bus_adr = csr_adr;
assign pair_bus_we = csr_we;
assign pair_bus_dat_w = csr_dat_w;
assign ref_y = pair_y0;
assign cand_y = pair_iir_y0;
assign ref_error = pair_error;
assign cand_error = pair_iir_error;
assign read_value = pair_bus_dat_r;
assign ref_coeff = {pair_b2, pair_b1, pair_b0, pair_a2, pair_a1};
assign cand_coeff = {pair_iir_b2, pair_iir_b1, pair_iir_b0, pair_iir_a2, pair_iir_a1};
assign cfg = {pair_iir_csrstorage4_storage, pair_iir_csrstorage3_storage, pair_iir_csrstorage2_storage, pair_iir_csrstorage1_storage, pair_iir_csrstorage0_storage, pair_iir_storage};
assign pair_iir_railed = (~((pair_iir_y_next[49:47] == $signed({1'd0, pair_iir_y_pat})) | (pair_iir_y_next[49:47] == $signed({1'd0, (~pair_iir_y_pat)}))));

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	pair_iir_y_lim <= 25'sd0;
	if (pair_iir_railed) begin
		pair_iir_y_lim <= pair_iir_y0;
	end else begin
		pair_iir_y_lim <= pair_iir_y_next[49:23];
	end
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end
assign pair_iir_xlo0 = {1'd0, pair_iir_x[16:0]};
assign pair_iir_xhi0 = pair_iir_x[24:17];
assign pair_iir_zlo0 = pair_iir_zr0[47:0];
assign pair_iir_ztop0 = pair_iir_zr0[49:48];
assign pair_iir_low0 = ((pair_iir_b2 * pair_iir_xlo0) + pair_iir_zlo0);
assign pair_iir_high0 = ((pair_iir_b2 * pair_iir_xhi0) + (pair_iir_low0 >>> 5'd17));
assign pair_iir0 = (((~pair_iir_zlo0[47]) & (~pair_iir_b2[24])) & pair_iir_low0[47]);
assign pair_iir1 = ((pair_iir_zlo0[47] & pair_iir_b2[24]) & (~pair_iir_low0[47]));
assign pair_iir_correction0 = (((pair_iir_ztop0 + pair_iir_zlo0[47]) + $signed({1'd0, pair_iir0})) - $signed({1'd0, pair_iir1}));
assign pair_iir_top0 = (pair_iir_high0[32:31] + pair_iir_correction0);
assign pair_iir_result0 = {pair_iir_top0, pair_iir_high0[30:0], pair_iir_low0[16:0]};
assign pair_iir_z0 = pair_iir_result0;
assign pair_iir_xlo1 = {1'd0, pair_iir_x[16:0]};
assign pair_iir_xhi1 = pair_iir_x[24:17];
assign pair_iir_zlo1 = pair_iir_zr1[47:0];
assign pair_iir_ztop1 = pair_iir_zr1[49:48];
assign pair_iir_low1 = ((pair_iir_b1 * pair_iir_xlo1) + pair_iir_zlo1);
assign pair_iir_high1 = ((pair_iir_b1 * pair_iir_xhi1) + (pair_iir_low1 >>> 5'd17));
assign pair_iir2 = (((~pair_iir_zlo1[47]) & (~pair_iir_b1[24])) & pair_iir_low1[47]);
assign pair_iir3 = ((pair_iir_zlo1[47] & pair_iir_b1[24]) & (~pair_iir_low1[47]));
assign pair_iir_correction1 = (((pair_iir_ztop1 + pair_iir_zlo1[47]) + $signed({1'd0, pair_iir2})) - $signed({1'd0, pair_iir3}));
assign pair_iir_top1 = (pair_iir_high1[32:31] + pair_iir_correction1);
assign pair_iir_result1 = {pair_iir_top1, pair_iir_high1[30:0], pair_iir_low1[16:0]};
assign pair_iir_z1 = pair_iir_result1;
assign pair_iir_xlo2 = {1'd0, pair_iir_x[16:0]};
assign pair_iir_xhi2 = pair_iir_x[24:17];
assign pair_iir_zlo2 = pair_iir_zr2[47:0];
assign pair_iir_ztop2 = pair_iir_zr2[49:48];
assign pair_iir_low2 = ((pair_iir_b0 * pair_iir_xlo2) + pair_iir_zlo2);
assign pair_iir_high2 = ((pair_iir_b0 * pair_iir_xhi2) + (pair_iir_low2 >>> 5'd17));
assign pair_iir4 = (((~pair_iir_zlo2[47]) & (~pair_iir_b0[24])) & pair_iir_low2[47]);
assign pair_iir5 = ((pair_iir_zlo2[47] & pair_iir_b0[24]) & (~pair_iir_low2[47]));
assign pair_iir_correction2 = (((pair_iir_ztop2 + pair_iir_zlo2[47]) + $signed({1'd0, pair_iir4})) - $signed({1'd0, pair_iir5}));
assign pair_iir_top2 = (pair_iir_high2[32:31] + pair_iir_correction2);
assign pair_iir_result2 = {pair_iir_top2, pair_iir_high2[30:0], pair_iir_low2[16:0]};
assign pair_iir_z2 = pair_iir_result2;
assign pair_iir_xlo3 = {1'd0, pair_iir_y1[16:0]};
assign pair_iir_xhi3 = pair_iir_y1[24:17];
assign pair_iir_zlo3 = pair_iir_zr3[47:0];
assign pair_iir_ztop3 = pair_iir_zr3[49:48];
assign pair_iir_low3 = ((pair_iir_a2 * pair_iir_xlo3) + pair_iir_zlo3);
assign pair_iir_high3 = ((pair_iir_a2 * pair_iir_xhi3) + (pair_iir_low3 >>> 5'd17));
assign pair_iir6 = (((~pair_iir_zlo3[47]) & (~pair_iir_a2[24])) & pair_iir_low3[47]);
assign pair_iir7 = ((pair_iir_zlo3[47] & pair_iir_a2[24]) & (~pair_iir_low3[47]));
assign pair_iir_correction3 = (((pair_iir_ztop3 + pair_iir_zlo3[47]) + $signed({1'd0, pair_iir6})) - $signed({1'd0, pair_iir7}));
assign pair_iir_top3 = (pair_iir_high3[32:31] + pair_iir_correction3);
assign pair_iir_result3 = {pair_iir_top3, pair_iir_high3[30:0], pair_iir_low3[16:0]};
assign pair_iir_z3 = pair_iir_result3;
assign pair_iir_xlo4 = {1'd0, pair_iir_y1[16:0]};
assign pair_iir_xhi4 = pair_iir_y1[24:17];
assign pair_iir_zlo4 = pair_iir_zr4[47:0];
assign pair_iir_ztop4 = pair_iir_zr4[49:48];
assign pair_iir_low4 = ((pair_iir_a1 * pair_iir_xlo4) + pair_iir_zlo4);
assign pair_iir_high4 = ((pair_iir_a1 * pair_iir_xhi4) + (pair_iir_low4 >>> 5'd17));
assign pair_iir8 = (((~pair_iir_zlo4[47]) & (~pair_iir_a1[24])) & pair_iir_low4[47]);
assign pair_iir9 = ((pair_iir_zlo4[47] & pair_iir_a1[24]) & (~pair_iir_low4[47]));
assign pair_iir_correction4 = (((pair_iir_ztop4 + pair_iir_zlo4[47]) + $signed({1'd0, pair_iir8})) - $signed({1'd0, pair_iir9}));
assign pair_iir_top4 = (pair_iir_high4[32:31] + pair_iir_correction4);
assign pair_iir_result4 = {pair_iir_top4, pair_iir_high4[30:0], pair_iir_low4[16:0]};
assign pair_iir_z4 = pair_iir_result4;
assign pair_iir_y_next = pair_iir_z4;
assign pair_railed = (~((pair_y_next[49:47] == $signed({1'd0, pair_y_pat})) | (pair_y_next[49:47] == $signed({1'd0, (~pair_y_pat)}))));

// synthesis translate_off
reg dummy_d_1;
// synthesis translate_on
always @(*) begin
	pair_y_lim <= 25'sd0;
	if (pair_railed) begin
		pair_y_lim <= pair_y0;
	end else begin
		pair_y_lim <= pair_y_next[49:23];
	end
// synthesis translate_off
	dummy_d_1 <= dummy_s;
// synthesis translate_on
end
assign pair_z0 = (pair_zr0 + (pair_x * pair_b2));
assign pair_z1 = (pair_zr1 + (pair_x * pair_b1));
assign pair_z2 = (pair_zr2 + (pair_x * pair_b0));
assign pair_z3 = (pair_zr3 + (pair_y1 * pair_a2));
assign pair_z4 = (pair_zr4 + (pair_y1 * pair_a1));
assign pair_y_next = pair_z4;
assign pair_sel = (pair_bus_adr[13:9] == 1'd0);
assign pair_z03_r = pair_bus_dat_w[2:0];
assign pair_z03_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 1'd0));
assign pair_z02_r = pair_bus_dat_w[7:0];
assign pair_z02_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 1'd1));
assign pair_z01_r = pair_bus_dat_w[7:0];
assign pair_z01_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 2'd2));
assign pair_z00_r = pair_bus_dat_w[7:0];
assign pair_z00_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 2'd3));
assign pair_a13_r = pair_bus_dat_w[0];
assign pair_a13_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 3'd4));
assign pair_a12_r = pair_bus_dat_w[7:0];
assign pair_a12_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 3'd5));
assign pair_a11_r = pair_bus_dat_w[7:0];
assign pair_a11_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 3'd6));
assign pair_a10_r = pair_bus_dat_w[7:0];
assign pair_a10_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 3'd7));
assign pair_a23_r = pair_bus_dat_w[0];
assign pair_a23_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 4'd8));
assign pair_a22_r = pair_bus_dat_w[7:0];
assign pair_a22_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 4'd9));
assign pair_a21_r = pair_bus_dat_w[7:0];
assign pair_a21_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 4'd10));
assign pair_a20_r = pair_bus_dat_w[7:0];
assign pair_a20_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 4'd11));
assign pair_b03_r = pair_bus_dat_w[0];
assign pair_b03_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 4'd12));
assign pair_b02_r = pair_bus_dat_w[7:0];
assign pair_b02_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 4'd13));
assign pair_b01_r = pair_bus_dat_w[7:0];
assign pair_b01_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 4'd14));
assign pair_b00_r = pair_bus_dat_w[7:0];
assign pair_b00_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 4'd15));
assign pair_b13_r = pair_bus_dat_w[0];
assign pair_b13_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 5'd16));
assign pair_b12_r = pair_bus_dat_w[7:0];
assign pair_b12_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 5'd17));
assign pair_b11_r = pair_bus_dat_w[7:0];
assign pair_b11_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 5'd18));
assign pair_b10_r = pair_bus_dat_w[7:0];
assign pair_b10_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 5'd19));
assign pair_b23_r = pair_bus_dat_w[0];
assign pair_b23_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 5'd20));
assign pair_b22_r = pair_bus_dat_w[7:0];
assign pair_b22_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 5'd21));
assign pair_b21_r = pair_bus_dat_w[7:0];
assign pair_b21_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 5'd22));
assign pair_b20_r = pair_bus_dat_w[7:0];
assign pair_b20_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[4:0] == 5'd23));
assign pair_iir_storage = pair_iir_storage_full[26:0];
assign pair_z03_w = pair_iir_storage_full[26:24];
assign pair_z02_w = pair_iir_storage_full[23:16];
assign pair_z01_w = pair_iir_storage_full[15:8];
assign pair_z00_w = pair_iir_storage_full[7:0];
assign pair_iir_csrstorage0_storage = pair_iir_csrstorage0_storage_full[24:0];
assign pair_a13_w = pair_iir_csrstorage0_storage_full[24];
assign pair_a12_w = pair_iir_csrstorage0_storage_full[23:16];
assign pair_a11_w = pair_iir_csrstorage0_storage_full[15:8];
assign pair_a10_w = pair_iir_csrstorage0_storage_full[7:0];
assign pair_iir_csrstorage1_storage = pair_iir_csrstorage1_storage_full[24:0];
assign pair_a23_w = pair_iir_csrstorage1_storage_full[24];
assign pair_a22_w = pair_iir_csrstorage1_storage_full[23:16];
assign pair_a21_w = pair_iir_csrstorage1_storage_full[15:8];
assign pair_a20_w = pair_iir_csrstorage1_storage_full[7:0];
assign pair_iir_csrstorage2_storage = pair_iir_csrstorage2_storage_full[24:0];
assign pair_b03_w = pair_iir_csrstorage2_storage_full[24];
assign pair_b02_w = pair_iir_csrstorage2_storage_full[23:16];
assign pair_b01_w = pair_iir_csrstorage2_storage_full[15:8];
assign pair_b00_w = pair_iir_csrstorage2_storage_full[7:0];
assign pair_iir_csrstorage3_storage = pair_iir_csrstorage3_storage_full[24:0];
assign pair_b13_w = pair_iir_csrstorage3_storage_full[24];
assign pair_b12_w = pair_iir_csrstorage3_storage_full[23:16];
assign pair_b11_w = pair_iir_csrstorage3_storage_full[15:8];
assign pair_b10_w = pair_iir_csrstorage3_storage_full[7:0];
assign pair_iir_csrstorage4_storage = pair_iir_csrstorage4_storage_full[24:0];
assign pair_b23_w = pair_iir_csrstorage4_storage_full[24];
assign pair_b22_w = pair_iir_csrstorage4_storage_full[23:16];
assign pair_b21_w = pair_iir_csrstorage4_storage_full[15:8];
assign pair_b20_w = pair_iir_csrstorage4_storage_full[7:0];

always @(posedge sys_clk) begin
	pair_iir_a1 <= pair_iir_csrstorage0_storage;
	pair_iir_a2 <= pair_iir_csrstorage1_storage;
	pair_iir_b0 <= pair_iir_csrstorage2_storage;
	pair_iir_b1 <= pair_iir_csrstorage3_storage;
	pair_iir_b2 <= pair_iir_csrstorage4_storage;
	pair_iir_z0r <= (pair_iir_storage <<< 5'd23);
	pair_iir_error <= pair_iir_railed;
	pair_iir_y0 <= pair_iir_y_lim;
	if (pair_iir_clear) begin
		pair_iir_y1 <= 1'd0;
	end else begin
		if ((~pair_iir_hold)) begin
			pair_iir_y1 <= pair_iir_y_lim;
		end
	end
	pair_iir_zr0 <= pair_iir_z0r;
	pair_iir_zr1 <= pair_iir_z0;
	pair_iir_zr2 <= pair_iir_z1;
	pair_iir_zr3 <= pair_iir_z2;
	pair_iir_zr4 <= pair_iir_z3;
	pair_a1 <= pair_rci_storage0;
	pair_a2 <= pair_rci_storage1;
	pair_b0 <= pair_rci_storage2;
	pair_b1 <= pair_rci_storage3;
	pair_b2 <= pair_rci_storage4;
	pair_z0r <= (pair_z0_storage <<< 5'd23);
	pair_error <= pair_railed;
	pair_y0 <= pair_y_lim;
	if (pair_clear) begin
		pair_y1 <= 1'd0;
	end else begin
		if ((~pair_hold)) begin
			pair_y1 <= pair_y_lim;
		end
	end
	pair_zr0 <= pair_z0r;
	pair_zr1 <= pair_z0;
	pair_zr2 <= pair_z1;
	pair_zr3 <= pair_z2;
	pair_zr4 <= pair_z3;
	pair_bus_dat_r <= 1'd0;
	if (pair_sel) begin
		case (pair_bus_adr[4:0])
			1'd0: begin
				pair_bus_dat_r <= pair_z03_w;
			end
			1'd1: begin
				pair_bus_dat_r <= pair_z02_w;
			end
			2'd2: begin
				pair_bus_dat_r <= pair_z01_w;
			end
			2'd3: begin
				pair_bus_dat_r <= pair_z00_w;
			end
			3'd4: begin
				pair_bus_dat_r <= pair_a13_w;
			end
			3'd5: begin
				pair_bus_dat_r <= pair_a12_w;
			end
			3'd6: begin
				pair_bus_dat_r <= pair_a11_w;
			end
			3'd7: begin
				pair_bus_dat_r <= pair_a10_w;
			end
			4'd8: begin
				pair_bus_dat_r <= pair_a23_w;
			end
			4'd9: begin
				pair_bus_dat_r <= pair_a22_w;
			end
			4'd10: begin
				pair_bus_dat_r <= pair_a21_w;
			end
			4'd11: begin
				pair_bus_dat_r <= pair_a20_w;
			end
			4'd12: begin
				pair_bus_dat_r <= pair_b03_w;
			end
			4'd13: begin
				pair_bus_dat_r <= pair_b02_w;
			end
			4'd14: begin
				pair_bus_dat_r <= pair_b01_w;
			end
			4'd15: begin
				pair_bus_dat_r <= pair_b00_w;
			end
			5'd16: begin
				pair_bus_dat_r <= pair_b13_w;
			end
			5'd17: begin
				pair_bus_dat_r <= pair_b12_w;
			end
			5'd18: begin
				pair_bus_dat_r <= pair_b11_w;
			end
			5'd19: begin
				pair_bus_dat_r <= pair_b10_w;
			end
			5'd20: begin
				pair_bus_dat_r <= pair_b23_w;
			end
			5'd21: begin
				pair_bus_dat_r <= pair_b22_w;
			end
			5'd22: begin
				pair_bus_dat_r <= pair_b21_w;
			end
			5'd23: begin
				pair_bus_dat_r <= pair_b20_w;
			end
		endcase
	end
	if (pair_z03_re) begin
		pair_iir_storage_full[26:24] <= pair_z03_r;
	end
	if (pair_z02_re) begin
		pair_iir_storage_full[23:16] <= pair_z02_r;
	end
	if (pair_z01_re) begin
		pair_iir_storage_full[15:8] <= pair_z01_r;
	end
	if (pair_z00_re) begin
		pair_iir_storage_full[7:0] <= pair_z00_r;
	end
	pair_iir_re <= pair_z00_re;
	if (pair_a13_re) begin
		pair_iir_csrstorage0_storage_full[24] <= pair_a13_r;
	end
	if (pair_a12_re) begin
		pair_iir_csrstorage0_storage_full[23:16] <= pair_a12_r;
	end
	if (pair_a11_re) begin
		pair_iir_csrstorage0_storage_full[15:8] <= pair_a11_r;
	end
	if (pair_a10_re) begin
		pair_iir_csrstorage0_storage_full[7:0] <= pair_a10_r;
	end
	pair_iir_csrstorage0_re <= pair_a10_re;
	if (pair_a23_re) begin
		pair_iir_csrstorage1_storage_full[24] <= pair_a23_r;
	end
	if (pair_a22_re) begin
		pair_iir_csrstorage1_storage_full[23:16] <= pair_a22_r;
	end
	if (pair_a21_re) begin
		pair_iir_csrstorage1_storage_full[15:8] <= pair_a21_r;
	end
	if (pair_a20_re) begin
		pair_iir_csrstorage1_storage_full[7:0] <= pair_a20_r;
	end
	pair_iir_csrstorage1_re <= pair_a20_re;
	if (pair_b03_re) begin
		pair_iir_csrstorage2_storage_full[24] <= pair_b03_r;
	end
	if (pair_b02_re) begin
		pair_iir_csrstorage2_storage_full[23:16] <= pair_b02_r;
	end
	if (pair_b01_re) begin
		pair_iir_csrstorage2_storage_full[15:8] <= pair_b01_r;
	end
	if (pair_b00_re) begin
		pair_iir_csrstorage2_storage_full[7:0] <= pair_b00_r;
	end
	pair_iir_csrstorage2_re <= pair_b00_re;
	if (pair_b13_re) begin
		pair_iir_csrstorage3_storage_full[24] <= pair_b13_r;
	end
	if (pair_b12_re) begin
		pair_iir_csrstorage3_storage_full[23:16] <= pair_b12_r;
	end
	if (pair_b11_re) begin
		pair_iir_csrstorage3_storage_full[15:8] <= pair_b11_r;
	end
	if (pair_b10_re) begin
		pair_iir_csrstorage3_storage_full[7:0] <= pair_b10_r;
	end
	pair_iir_csrstorage3_re <= pair_b10_re;
	if (pair_b23_re) begin
		pair_iir_csrstorage4_storage_full[24] <= pair_b23_r;
	end
	if (pair_b22_re) begin
		pair_iir_csrstorage4_storage_full[23:16] <= pair_b22_r;
	end
	if (pair_b21_re) begin
		pair_iir_csrstorage4_storage_full[15:8] <= pair_b21_r;
	end
	if (pair_b20_re) begin
		pair_iir_csrstorage4_storage_full[7:0] <= pair_b20_r;
	end
	pair_iir_csrstorage4_re <= pair_b20_re;
	if (sys_rst) begin
		pair_iir_y0 <= 25'sd0;
		pair_iir_error <= 1'd0;
		pair_iir_storage_full <= 27'd0;
		pair_iir_re <= 1'd0;
		pair_iir_a1 <= 25'sd0;
		pair_iir_csrstorage0_storage_full <= 25'd0;
		pair_iir_csrstorage0_re <= 1'd0;
		pair_iir_a2 <= 25'sd0;
		pair_iir_csrstorage1_storage_full <= 25'd0;
		pair_iir_csrstorage1_re <= 1'd0;
		pair_iir_b0 <= 25'sd0;
		pair_iir_csrstorage2_storage_full <= 25'd0;
		pair_iir_csrstorage2_re <= 1'd0;
		pair_iir_b1 <= 25'sd0;
		pair_iir_csrstorage3_storage_full <= 25'd0;
		pair_iir_csrstorage3_re <= 1'd0;
		pair_iir_b2 <= 25'sd0;
		pair_iir_csrstorage4_storage_full <= 25'd0;
		pair_iir_csrstorage4_re <= 1'd0;
		pair_iir_z0r <= 50'sd0;
		pair_iir_y1 <= 25'sd0;
		pair_iir_zr0 <= 50'sd0;
		pair_iir_zr1 <= 50'sd0;
		pair_iir_zr2 <= 50'sd0;
		pair_iir_zr3 <= 50'sd0;
		pair_iir_zr4 <= 50'sd0;
		pair_y0 <= 25'sd0;
		pair_error <= 1'd0;
		pair_a1 <= 25'sd0;
		pair_a2 <= 25'sd0;
		pair_b0 <= 25'sd0;
		pair_b1 <= 25'sd0;
		pair_b2 <= 25'sd0;
		pair_z0r <= 50'sd0;
		pair_y1 <= 25'sd0;
		pair_zr0 <= 50'sd0;
		pair_zr1 <= 50'sd0;
		pair_zr2 <= 50'sd0;
		pair_zr3 <= 50'sd0;
		pair_zr4 <= 50'sd0;
		pair_bus_dat_r <= 8'd0;
	end
end

endmodule
