from pathlib import Path
import ast,hashlib,json,re,subprocess
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261110-r31-autolock-grouped-threshold');trial=r/'gateware/build/trials/20261110_204052_r31_autolock_grouped_threshold';s=(trial/'top.v').read_text();prefix='linienmodule_autolock_pipelinedrobustautolock_'
decls=re.findall(r'\(\* dont_touch = "true" \*\) wire '+prefix+r'result(\d+);',s);assert sorted(map(int,decls))==list(range(8)),decls
assert re.search(r'\breg '+prefix+r'over_threshold;',s)
assert prefix+'fallback' in s
def syncs(text):
    return [ast.dump(n) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Attribute) and n.target.attr=='sync']
old=subprocess.check_output(['git','show','9c5c32a:gateware/logic/autolock_pipeline.py'],cwd=r).decode();now=(r/'gateware/logic/autolock_pipeline.py').read_text(encoding='utf-8');assert syncs(old)==syncs(now)
helper=(r/'gateware/logic/late_threshold_select.py').read_text(encoding='utf-8');assert not any(isinstance(x,ast.Attribute) and x.attr=='sync' for x in ast.walk(ast.parse(helper)))
for rel in ('gateware/logic/pid.py','gateware/logic/pid_pipeline.py','gateware/logic/pid_output_limit.py','gateware/logic/iir.py','gateware/linien_module.py','gateware/logic/slow_pipeline.py','gateware/logic/abs_threshold.py'):
    a=subprocess.check_output(['git','show','9c5c32a:'+rel],cwd=r).replace(b'\r\n',b'\n');b=(r/rel).read_bytes().replace(b'\r\n',b'\n');assert a==b,rel
baseline=Path('D:/RP_Dev/linien_trials/20261110-r28-pid-output-bitdecode/gateware/build/trials/20261110_193543_r28_pid_output_bitdecode');assert (trial/'top.xdc').read_bytes()==(baseline/'top.xdc').read_bytes()
ns={};exec((trial/'csrmap.py').read_text(),ns);assert ns['states'][12]=='robustover_threshold'
fixture_before=subprocess.check_output(['git','rev-parse','bde8f03:tools/check_threshold_bank.py'],cwd=r,text=True).strip();fixture_now=subprocess.check_output(['git','rev-parse','HEAD:tools/check_threshold_bank.py'],cwd=r,text=True).strip();assert fixture_before==fixture_now
data={'passed':True,'top_sha256':hashlib.sha256((trial/'top.v').read_bytes()).hexdigest(),'parallel_predicate_lanes':8,'wide_selection_per_lane':4,'selected_output_width':1,'output_declared_reg_but_combinational':True,'explanation':'Verilog reg from complete combinational Case, not a new clocked FF. Original sync AST identical and helper has no sync/clock. Native all-cycle/XZ equivalence separately PASS.','default_unknown_index':'Independent unchanged scalar predicate on threshold31, same original Migen Array fallback','same_R30_bank_fixture_blob':fixture_now,'attribute':'dont_touch=true only8 result wires','new_serial_cycles':0,'unchanged_PID_IIR_Root_scalar_sources':True,'XDC_same_bytes_R28':True,'public_state12':'robustover_threshold','scope':'Actual generated Root structure and AST/source checks, not STA/postroute/SDF proof.'}
(h/'r31_generated_structure.json').write_text(json.dumps(data,indent=2),encoding='utf-8');print('R31_GENERATED_EIGHT_LANE_COMBINATIONAL_AND_SYNC_AST_PASS')
