/* Machine-generated using Migen */
module robust_pair(
	input sys_clk,
	input sys_rst,
	input signed [13:0] data,
	input request,
	input at_start,
	input writing,
	input sweep_up,
	input [13:0] csr_adr,
	input csr_we,
	input [7:0] csr_dat_w,
	output [93:0] ref_obs,
	output [1393:0] ref_cfg,
	output [7:0] ref_read,
	output [4:0] ref_idx,
	output ref_watch,
	output ref_turn,
	output [93:0] cand_obs,
	output [1393:0] cand_cfg,
	output [7:0] cand_read,
	output [4:0] cand_idx,
	output cand_watch,
	output cand_turn
);

wire pair_reference_robust_restart0;
wire pair_reference_robust_writing_data_now0;
wire signed [13:0] pair_reference_robust_input0;
wire [13:0] pair_reference_robust_delay_value;
reg signed [27:0] pair_reference_robust_sum_value = 28'sd0;
wire signed [27:0] pair_reference_robust_delayed_sum;
wire signed [28:0] pair_reference_robust_current_sum_diff;
wire signed [28:0] pair_reference_robust_output0;
wire [12:0] pair_reference_robust_delay;
wire pair_reference_robust_restart1;
wire pair_reference_robust_writing_data_now1;
wire signed [27:0] pair_reference_robust_input1;
reg signed [27:0] pair_reference_robust_output1;
reg [12:0] pair_reference_robust_rdport_adr;
wire [27:0] pair_reference_robust_rdport_dat_r;
wire [12:0] pair_reference_robust_wrport_adr;
wire [27:0] pair_reference_robust_wrport_dat_r;
wire pair_reference_robust_wrport_we;
wire [27:0] pair_reference_robust_wrport_dat_w;
reg [12:0] pair_reference_robust_counter = 13'd0;
wire [12:0] pair_reference_robust_counter_delayed;
wire [13:0] pair_reference_robust_time_scale_storage;
wire [4:0] pair_reference_robust_N_instructions_storage;
wire [13:0] pair_reference_robust_final_wait_time_storage;
wire [27:0] pair_reference_robust_csrstorage_storage0;
wire [27:0] pair_reference_robust_csrstorage_storage1;
wire [27:0] pair_reference_robust_csrstorage_storage2;
wire [27:0] pair_reference_robust_csrstorage_storage3;
wire [27:0] pair_reference_robust_csrstorage_storage4;
wire [27:0] pair_reference_robust_csrstorage_storage5;
wire [27:0] pair_reference_robust_csrstorage_storage6;
wire [27:0] pair_reference_robust_csrstorage_storage7;
wire [27:0] pair_reference_robust_csrstorage_storage8;
wire [27:0] pair_reference_robust_csrstorage_storage9;
wire [27:0] pair_reference_robust_csrstorage_storage10;
wire [27:0] pair_reference_robust_csrstorage_storage11;
wire [27:0] pair_reference_robust_csrstorage_storage12;
wire [27:0] pair_reference_robust_csrstorage_storage13;
wire [27:0] pair_reference_robust_csrstorage_storage14;
wire [27:0] pair_reference_robust_csrstorage_storage15;
wire [27:0] pair_reference_robust_csrstorage_storage16;
wire [27:0] pair_reference_robust_csrstorage_storage17;
wire [27:0] pair_reference_robust_csrstorage_storage18;
wire [27:0] pair_reference_robust_csrstorage_storage19;
wire [27:0] pair_reference_robust_csrstorage_storage20;
wire [27:0] pair_reference_robust_csrstorage_storage21;
wire [27:0] pair_reference_robust_csrstorage_storage22;
wire [27:0] pair_reference_robust_csrstorage_storage23;
wire [27:0] pair_reference_robust_csrstorage_storage24;
wire [27:0] pair_reference_robust_csrstorage_storage25;
wire [27:0] pair_reference_robust_csrstorage_storage26;
wire [27:0] pair_reference_robust_csrstorage_storage27;
wire [27:0] pair_reference_robust_csrstorage_storage28;
wire [27:0] pair_reference_robust_csrstorage_storage29;
wire [27:0] pair_reference_robust_csrstorage_storage30;
wire [27:0] pair_reference_robust_csrstorage_storage31;
wire [13:0] pair_reference_robust_csrstorage_storage32;
wire [13:0] pair_reference_robust_csrstorage_storage33;
wire [13:0] pair_reference_robust_csrstorage_storage34;
wire [13:0] pair_reference_robust_csrstorage_storage35;
wire [13:0] pair_reference_robust_csrstorage_storage36;
wire [13:0] pair_reference_robust_csrstorage_storage37;
wire [13:0] pair_reference_robust_csrstorage_storage38;
wire [13:0] pair_reference_robust_csrstorage_storage39;
wire [13:0] pair_reference_robust_csrstorage_storage40;
wire [13:0] pair_reference_robust_csrstorage_storage41;
wire [13:0] pair_reference_robust_csrstorage_storage42;
wire [13:0] pair_reference_robust_csrstorage_storage43;
wire [13:0] pair_reference_robust_csrstorage_storage44;
wire [13:0] pair_reference_robust_csrstorage_storage45;
wire [13:0] pair_reference_robust_csrstorage_storage46;
wire [13:0] pair_reference_robust_csrstorage_storage47;
wire [13:0] pair_reference_robust_csrstorage_storage48;
wire [13:0] pair_reference_robust_csrstorage_storage49;
wire [13:0] pair_reference_robust_csrstorage_storage50;
wire [13:0] pair_reference_robust_csrstorage_storage51;
wire [13:0] pair_reference_robust_csrstorage_storage52;
wire [13:0] pair_reference_robust_csrstorage_storage53;
wire [13:0] pair_reference_robust_csrstorage_storage54;
wire [13:0] pair_reference_robust_csrstorage_storage55;
wire [13:0] pair_reference_robust_csrstorage_storage56;
wire [13:0] pair_reference_robust_csrstorage_storage57;
wire [13:0] pair_reference_robust_csrstorage_storage58;
wire [13:0] pair_reference_robust_csrstorage_storage59;
wire [13:0] pair_reference_robust_csrstorage_storage60;
wire [13:0] pair_reference_robust_csrstorage_storage61;
wire [13:0] pair_reference_robust_csrstorage_storage62;
wire [13:0] pair_reference_robust_csrstorage_storage63;
wire signed [13:0] pair_reference_robust_input2;
wire pair_reference_robust_request_lock;
wire pair_reference_robust_at_start;
wire pair_reference_robust_writing_data_now2;
wire pair_reference_robust_sweep_up;
wire pair_reference_robust_turn_on_lock;
reg pair_reference_robust_watching = 1'd0;
reg [4:0] pair_reference_robust_current_instruction_idx = 5'd0;
wire signed [27:0] pair_reference_robust_current_peak_height;
reg signed [27:0] pair_reference_robust_abs_current_peak_height;
wire [13:0] pair_reference_robust_current_wait_for;
reg [13:0] pair_reference_robust_waited_for = 14'd0;
reg [13:0] pair_reference_robust_final_waited_for = 14'd0;
wire signed [28:0] pair_reference_robust_sum_diff;
reg signed [28:0] pair_reference_robust_abs_sum_diff;
wire pair_reference_robust_sign_equal;
wire pair_reference_robust_over_threshold;
wire pair_reference_robust_waited_long_enough;
wire pair_reference_robust_all_instructions_triggered;
wire signed [13:0] pair_reference_robust_public0;
reg signed [13:0] pair_reference_robust_q0 = 14'sd0;
wire pair_reference_robust_public1;
reg pair_reference_robust_q1 = 1'd0;
wire pair_reference_robust_public2;
reg pair_reference_robust_q2 = 1'd0;
wire pair_reference_robust_public3;
reg pair_reference_robust_q3 = 1'd0;
wire pair_reference_robust_public4;
reg pair_reference_robust_q4 = 1'd0;
reg [13:0] pair_reference_robust_csrstorage0_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage0_storage;
reg pair_reference_robust_csrstorage0_re = 1'd0;
reg [13:0] pair_reference_robust_q5 = 14'd0;
reg [4:0] pair_reference_robust_csrstorage1_storage_full = 5'd0;
wire [4:0] pair_reference_robust_csrstorage1_storage;
reg pair_reference_robust_csrstorage1_re = 1'd0;
reg [4:0] pair_reference_robust_q6 = 5'd0;
reg [13:0] pair_reference_robust_csrstorage2_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage2_storage;
reg pair_reference_robust_csrstorage2_re = 1'd0;
reg [13:0] pair_reference_robust_q7 = 14'd0;
reg [27:0] pair_reference_robust_csrstorage3_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage3_storage;
reg pair_reference_robust_csrstorage3_re = 1'd0;
reg [27:0] pair_reference_robust_q8 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage4_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage4_storage;
reg pair_reference_robust_csrstorage4_re = 1'd0;
reg [27:0] pair_reference_robust_q9 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage5_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage5_storage;
reg pair_reference_robust_csrstorage5_re = 1'd0;
reg [27:0] pair_reference_robust_q10 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage6_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage6_storage;
reg pair_reference_robust_csrstorage6_re = 1'd0;
reg [27:0] pair_reference_robust_q11 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage7_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage7_storage;
reg pair_reference_robust_csrstorage7_re = 1'd0;
reg [27:0] pair_reference_robust_q12 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage8_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage8_storage;
reg pair_reference_robust_csrstorage8_re = 1'd0;
reg [27:0] pair_reference_robust_q13 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage9_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage9_storage;
reg pair_reference_robust_csrstorage9_re = 1'd0;
reg [27:0] pair_reference_robust_q14 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage10_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage10_storage;
reg pair_reference_robust_csrstorage10_re = 1'd0;
reg [27:0] pair_reference_robust_q15 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage11_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage11_storage;
reg pair_reference_robust_csrstorage11_re = 1'd0;
reg [27:0] pair_reference_robust_q16 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage12_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage12_storage;
reg pair_reference_robust_csrstorage12_re = 1'd0;
reg [27:0] pair_reference_robust_q17 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage13_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage13_storage;
reg pair_reference_robust_csrstorage13_re = 1'd0;
reg [27:0] pair_reference_robust_q18 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage14_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage14_storage;
reg pair_reference_robust_csrstorage14_re = 1'd0;
reg [27:0] pair_reference_robust_q19 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage15_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage15_storage;
reg pair_reference_robust_csrstorage15_re = 1'd0;
reg [27:0] pair_reference_robust_q20 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage16_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage16_storage;
reg pair_reference_robust_csrstorage16_re = 1'd0;
reg [27:0] pair_reference_robust_q21 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage17_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage17_storage;
reg pair_reference_robust_csrstorage17_re = 1'd0;
reg [27:0] pair_reference_robust_q22 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage18_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage18_storage;
reg pair_reference_robust_csrstorage18_re = 1'd0;
reg [27:0] pair_reference_robust_q23 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage19_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage19_storage;
reg pair_reference_robust_csrstorage19_re = 1'd0;
reg [27:0] pair_reference_robust_q24 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage20_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage20_storage;
reg pair_reference_robust_csrstorage20_re = 1'd0;
reg [27:0] pair_reference_robust_q25 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage21_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage21_storage;
reg pair_reference_robust_csrstorage21_re = 1'd0;
reg [27:0] pair_reference_robust_q26 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage22_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage22_storage;
reg pair_reference_robust_csrstorage22_re = 1'd0;
reg [27:0] pair_reference_robust_q27 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage23_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage23_storage;
reg pair_reference_robust_csrstorage23_re = 1'd0;
reg [27:0] pair_reference_robust_q28 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage24_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage24_storage;
reg pair_reference_robust_csrstorage24_re = 1'd0;
reg [27:0] pair_reference_robust_q29 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage25_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage25_storage;
reg pair_reference_robust_csrstorage25_re = 1'd0;
reg [27:0] pair_reference_robust_q30 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage26_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage26_storage;
reg pair_reference_robust_csrstorage26_re = 1'd0;
reg [27:0] pair_reference_robust_q31 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage27_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage27_storage;
reg pair_reference_robust_csrstorage27_re = 1'd0;
reg [27:0] pair_reference_robust_q32 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage28_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage28_storage;
reg pair_reference_robust_csrstorage28_re = 1'd0;
reg [27:0] pair_reference_robust_q33 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage29_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage29_storage;
reg pair_reference_robust_csrstorage29_re = 1'd0;
reg [27:0] pair_reference_robust_q34 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage30_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage30_storage;
reg pair_reference_robust_csrstorage30_re = 1'd0;
reg [27:0] pair_reference_robust_q35 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage31_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage31_storage;
reg pair_reference_robust_csrstorage31_re = 1'd0;
reg [27:0] pair_reference_robust_q36 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage32_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage32_storage;
reg pair_reference_robust_csrstorage32_re = 1'd0;
reg [27:0] pair_reference_robust_q37 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage33_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage33_storage;
reg pair_reference_robust_csrstorage33_re = 1'd0;
reg [27:0] pair_reference_robust_q38 = 28'd0;
reg [27:0] pair_reference_robust_csrstorage34_storage_full = 28'd0;
wire [27:0] pair_reference_robust_csrstorage34_storage;
reg pair_reference_robust_csrstorage34_re = 1'd0;
reg [27:0] pair_reference_robust_q39 = 28'd0;
reg [13:0] pair_reference_robust_csrstorage35_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage35_storage;
reg pair_reference_robust_csrstorage35_re = 1'd0;
reg [13:0] pair_reference_robust_q40 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage36_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage36_storage;
reg pair_reference_robust_csrstorage36_re = 1'd0;
reg [13:0] pair_reference_robust_q41 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage37_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage37_storage;
reg pair_reference_robust_csrstorage37_re = 1'd0;
reg [13:0] pair_reference_robust_q42 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage38_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage38_storage;
reg pair_reference_robust_csrstorage38_re = 1'd0;
reg [13:0] pair_reference_robust_q43 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage39_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage39_storage;
reg pair_reference_robust_csrstorage39_re = 1'd0;
reg [13:0] pair_reference_robust_q44 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage40_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage40_storage;
reg pair_reference_robust_csrstorage40_re = 1'd0;
reg [13:0] pair_reference_robust_q45 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage41_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage41_storage;
reg pair_reference_robust_csrstorage41_re = 1'd0;
reg [13:0] pair_reference_robust_q46 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage42_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage42_storage;
reg pair_reference_robust_csrstorage42_re = 1'd0;
reg [13:0] pair_reference_robust_q47 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage43_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage43_storage;
reg pair_reference_robust_csrstorage43_re = 1'd0;
reg [13:0] pair_reference_robust_q48 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage44_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage44_storage;
reg pair_reference_robust_csrstorage44_re = 1'd0;
reg [13:0] pair_reference_robust_q49 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage45_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage45_storage;
reg pair_reference_robust_csrstorage45_re = 1'd0;
reg [13:0] pair_reference_robust_q50 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage46_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage46_storage;
reg pair_reference_robust_csrstorage46_re = 1'd0;
reg [13:0] pair_reference_robust_q51 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage47_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage47_storage;
reg pair_reference_robust_csrstorage47_re = 1'd0;
reg [13:0] pair_reference_robust_q52 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage48_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage48_storage;
reg pair_reference_robust_csrstorage48_re = 1'd0;
reg [13:0] pair_reference_robust_q53 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage49_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage49_storage;
reg pair_reference_robust_csrstorage49_re = 1'd0;
reg [13:0] pair_reference_robust_q54 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage50_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage50_storage;
reg pair_reference_robust_csrstorage50_re = 1'd0;
reg [13:0] pair_reference_robust_q55 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage51_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage51_storage;
reg pair_reference_robust_csrstorage51_re = 1'd0;
reg [13:0] pair_reference_robust_q56 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage52_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage52_storage;
reg pair_reference_robust_csrstorage52_re = 1'd0;
reg [13:0] pair_reference_robust_q57 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage53_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage53_storage;
reg pair_reference_robust_csrstorage53_re = 1'd0;
reg [13:0] pair_reference_robust_q58 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage54_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage54_storage;
reg pair_reference_robust_csrstorage54_re = 1'd0;
reg [13:0] pair_reference_robust_q59 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage55_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage55_storage;
reg pair_reference_robust_csrstorage55_re = 1'd0;
reg [13:0] pair_reference_robust_q60 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage56_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage56_storage;
reg pair_reference_robust_csrstorage56_re = 1'd0;
reg [13:0] pair_reference_robust_q61 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage57_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage57_storage;
reg pair_reference_robust_csrstorage57_re = 1'd0;
reg [13:0] pair_reference_robust_q62 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage58_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage58_storage;
reg pair_reference_robust_csrstorage58_re = 1'd0;
reg [13:0] pair_reference_robust_q63 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage59_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage59_storage;
reg pair_reference_robust_csrstorage59_re = 1'd0;
reg [13:0] pair_reference_robust_q64 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage60_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage60_storage;
reg pair_reference_robust_csrstorage60_re = 1'd0;
reg [13:0] pair_reference_robust_q65 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage61_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage61_storage;
reg pair_reference_robust_csrstorage61_re = 1'd0;
reg [13:0] pair_reference_robust_q66 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage62_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage62_storage;
reg pair_reference_robust_csrstorage62_re = 1'd0;
reg [13:0] pair_reference_robust_q67 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage63_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage63_storage;
reg pair_reference_robust_csrstorage63_re = 1'd0;
reg [13:0] pair_reference_robust_q68 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage64_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage64_storage;
reg pair_reference_robust_csrstorage64_re = 1'd0;
reg [13:0] pair_reference_robust_q69 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage65_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage65_storage;
reg pair_reference_robust_csrstorage65_re = 1'd0;
reg [13:0] pair_reference_robust_q70 = 14'd0;
reg [13:0] pair_reference_robust_csrstorage66_storage_full = 14'd0;
wire [13:0] pair_reference_robust_csrstorage66_storage;
reg pair_reference_robust_csrstorage66_re = 1'd0;
reg [13:0] pair_reference_robust_q71 = 14'd0;
wire pair_reference_fast_request_lock;
reg pair_reference_fast_turn_on_lock = 1'd0;
wire signed [13:0] pair_reference_fast_sweep_value;
wire [13:0] pair_reference_fast_sweep_step;
wire pair_reference_fast_sweep_up;
reg [13:0] pair_reference_fast_storage_full = 14'd0;
wire [13:0] pair_reference_fast_storage;
reg pair_reference_fast_re = 1'd0;
wire signed [13:0] pair_reference_fast_target_position_signed;
reg pair_reference_request_lock_storage_full = 1'd0;
wire pair_reference_request_lock_storage;
reg pair_reference_request_lock_re = 1'd0;
reg [1:0] pair_reference_autolock_mode_storage_full = 2'd0;
wire [1:0] pair_reference_autolock_mode_storage;
reg pair_reference_autolock_mode_re = 1'd0;
reg pair_reference_status = 1'd0;
wire pair_candidate_pipelinedrobustautolock_restart0;
wire pair_candidate_pipelinedrobustautolock_writing_data_now0;
wire signed [13:0] pair_candidate_pipelinedrobustautolock_input0;
wire [13:0] pair_candidate_pipelinedrobustautolock_delay_value;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_sum_value = 28'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_delayed_sum;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_current_sum_diff;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_output0;
wire [12:0] pair_candidate_pipelinedrobustautolock_delay;
wire pair_candidate_pipelinedrobustautolock_restart1;
wire pair_candidate_pipelinedrobustautolock_writing_data_now1;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_input1;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_output1;
reg [12:0] pair_candidate_pipelinedrobustautolock_rdport_adr;
wire [27:0] pair_candidate_pipelinedrobustautolock_rdport_dat_r;
wire [12:0] pair_candidate_pipelinedrobustautolock_wrport_adr;
wire [27:0] pair_candidate_pipelinedrobustautolock_wrport_dat_r;
wire pair_candidate_pipelinedrobustautolock_wrport_we;
wire [27:0] pair_candidate_pipelinedrobustautolock_wrport_dat_w;
reg [12:0] pair_candidate_pipelinedrobustautolock_counter = 13'd0;
wire [12:0] pair_candidate_pipelinedrobustautolock_counter_delayed;
reg [13:0] pair_candidate_pipelinedrobustautolock_time_scale_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_time_scale_storage;
reg pair_candidate_pipelinedrobustautolock_time_scale_re = 1'd0;
reg [4:0] pair_candidate_pipelinedrobustautolock_N_instructions_storage_full = 5'd0;
wire [4:0] pair_candidate_pipelinedrobustautolock_N_instructions_storage;
reg pair_candidate_pipelinedrobustautolock_N_instructions_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_final_wait_time_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_final_wait_time_storage;
reg pair_candidate_pipelinedrobustautolock_final_wait_time_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage0_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage0_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage1_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage1_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage2_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage2_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage3_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage3_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage4_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage4_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage5_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage5_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage6_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage6_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage7_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage7_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage8_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage8_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage9_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage9_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage10_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage10_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage11_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage11_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage12_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage12_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage13_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage13_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage14_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage14_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage15_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage15_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage16_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage16_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage17_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage17_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage18_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage18_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage19_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage19_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage20_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage20_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage21_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage21_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage22_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage22_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage23_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage23_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage24_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage24_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage25_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage25_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage26_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage26_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage27_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage27_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage28_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage28_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage29_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage29_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage30_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage30_re = 1'd0;
reg [27:0] pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full = 28'd0;
wire [27:0] pair_candidate_pipelinedrobustautolock_csrstorage31_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage31_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage32_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage32_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage32_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage33_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage33_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage33_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage34_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage34_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage34_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage35_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage35_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage35_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage36_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage36_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage36_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage37_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage37_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage37_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage38_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage38_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage38_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage39_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage39_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage39_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage40_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage40_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage40_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage41_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage41_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage41_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage42_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage42_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage42_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage43_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage43_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage43_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage44_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage44_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage44_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage45_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage45_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage45_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage46_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage46_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage46_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage47_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage47_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage47_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage48_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage48_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage48_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage49_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage49_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage49_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage50_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage50_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage50_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage51_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage51_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage51_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage52_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage52_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage52_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage53_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage53_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage53_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage54_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage54_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage54_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage55_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage55_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage55_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage56_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage56_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage56_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage57_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage57_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage57_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage58_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage58_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage58_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage59_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage59_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage59_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage60_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage60_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage60_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage61_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage61_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage61_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage62_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage62_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage62_re = 1'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_csrstorage63_storage_full = 14'd0;
wire [13:0] pair_candidate_pipelinedrobustautolock_csrstorage63_storage;
reg pair_candidate_pipelinedrobustautolock_csrstorage63_re = 1'd0;
wire signed [13:0] pair_candidate_pipelinedrobustautolock_input2;
wire pair_candidate_pipelinedrobustautolock_request_lock;
wire pair_candidate_pipelinedrobustautolock_at_start;
wire pair_candidate_pipelinedrobustautolock_writing_data_now2;
wire pair_candidate_pipelinedrobustautolock_sweep_up;
wire pair_candidate_pipelinedrobustautolock_turn_on_lock;
reg pair_candidate_pipelinedrobustautolock0 = 1'd0;
reg pair_candidate_pipelinedrobustautolock1 = 1'd0;
reg pair_candidate_pipelinedrobustautolock2 = 1'd0;
reg pair_candidate_pipelinedrobustautolock3 = 1'd0;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_sum_diff_s1 = 29'sd0;
reg [4:0] pair_candidate_pipelinedrobustautolock_n_instructions_s1 = 5'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_final_wait_s1 = 14'd0;
wire pair_candidate_pipelinedrobustautolock_current_peak_positive;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude0 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive0 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next0;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended0;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative0 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height1;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude1 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive1 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next1;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended1;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative1 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height2;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude2 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive2 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next2;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended2;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative2 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height3;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude3 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive3 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next3;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended3;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative3 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height4;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude4 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive4 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next4;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended4;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative4 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height5;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude5 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive5 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next5;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended5;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative5 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height6;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude6 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive6 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next6;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended6;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative6 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height7;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude7 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive7 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next7;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended7;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative7 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height8;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude8 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive8 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next8;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended8;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative8 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height9;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude9 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive9 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next9;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended9;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative9 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height10;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude10 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive10 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next10;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended10;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative10 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height11;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude11 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive11 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next11;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended11;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative11 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height12;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude12 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive12 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next12;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended12;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative12 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height13;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude13 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive13 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next13;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended13;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative13 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height14;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude14 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive14 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next14;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended14;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative14 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height15;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude15 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive15 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next15;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended15;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative15 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height16;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude16 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive16 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next16;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended16;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative16 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height17;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude17 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive17 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next17;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended17;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative17 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height18;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude18 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive18 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next18;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended18;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative18 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height19;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude19 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive19 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next19;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended19;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative19 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height20;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude20 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive20 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next20;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended20;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative20 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height21;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude21 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive21 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next21;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended21;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative21 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height22;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude22 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive22 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next22;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended22;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative22 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height23;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude23 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive23 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next23;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended23;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative23 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height24;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude24 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive24 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next24;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended24;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative24 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height25;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude25 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive25 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next25;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended25;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative25 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height26;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude26 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive26 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next26;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended26;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative26 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height27;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude27 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive27 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next27;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended27;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative27 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height28;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude28 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive28 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next28;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended28;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative28 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height29;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude29 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive29 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next29;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended29;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative29 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height30;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude30 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive30 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next30;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended30;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative30 = 29'sd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_signed_height31;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_magnitude31 = 28'sd0;
reg pair_candidate_pipelinedrobustautolock_positive31 = 1'd0;
reg signed [27:0] pair_candidate_pipelinedrobustautolock_abs_next31;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_abs_extended31;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_negative31 = 29'sd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value0 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value1 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value2 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value3 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value4 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value5 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value6 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value7 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value8 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value9 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value10 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value11 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value12 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value13 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value14 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value15 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value16 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value17 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value18 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value19 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value20 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value21 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value22 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value23 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value24 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value25 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value26 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value27 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value28 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value29 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value30 = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_value31 = 14'd0;
reg pair_candidate_pipelinedrobustautolock_watching = 1'd0;
reg [4:0] pair_candidate_pipelinedrobustautolock_current_instruction_idx = 5'd0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_current_peak_height;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_abs_current_peak_height;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_negative_current_peak_height;
wire [13:0] pair_candidate_pipelinedrobustautolock_current_wait_for;
reg [13:0] pair_candidate_pipelinedrobustautolock_waited_for = 14'd0;
reg [13:0] pair_candidate_pipelinedrobustautolock_final_waited_for = 14'd0;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_sum_diff;
reg signed [28:0] pair_candidate_pipelinedrobustautolock_abs_sum_diff;
wire pair_candidate_pipelinedrobustautolock_sign_equal;
reg pair_candidate_pipelinedrobustautolock_over_threshold;
wire pair_candidate_pipelinedrobustautolock_waited_long_enough;
wire pair_candidate_pipelinedrobustautolock_all_instructions_triggered;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_threshold0;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_negative32;
(* keep = "true" *) wire pair_candidate_pipelinedrobustautolock_result0;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_threshold1;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_negative33;
(* keep = "true" *) wire pair_candidate_pipelinedrobustautolock_result1;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_threshold2;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_negative34;
(* keep = "true" *) wire pair_candidate_pipelinedrobustautolock_result2;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_threshold3;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_negative35;
(* keep = "true" *) wire pair_candidate_pipelinedrobustautolock_result3;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_threshold4;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_negative36;
(* keep = "true" *) wire pair_candidate_pipelinedrobustautolock_result4;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_threshold5;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_negative37;
(* keep = "true" *) wire pair_candidate_pipelinedrobustautolock_result5;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_threshold6;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_negative38;
(* keep = "true" *) wire pair_candidate_pipelinedrobustautolock_result6;
wire signed [27:0] pair_candidate_pipelinedrobustautolock_threshold7;
wire signed [28:0] pair_candidate_pipelinedrobustautolock_negative39;
(* keep = "true" *) wire pair_candidate_pipelinedrobustautolock_result7;
wire pair_candidate_pipelinedrobustautolock_fallback;
wire pair_candidate_fast_request_lock;
reg pair_candidate_fast_turn_on_lock = 1'd0;
wire signed [13:0] pair_candidate_fast_sweep_value;
wire [13:0] pair_candidate_fast_sweep_step;
wire pair_candidate_fast_sweep_up;
reg [13:0] pair_candidate_fast_storage_full = 14'd0;
wire [13:0] pair_candidate_fast_storage;
reg pair_candidate_fast_re = 1'd0;
wire signed [13:0] pair_candidate_fast_target_position_signed;
reg pair_candidate_request_lock_storage_full = 1'd0;
wire pair_candidate_request_lock_storage;
reg pair_candidate_request_lock_re = 1'd0;
reg [1:0] pair_candidate_autolock_mode_storage_full = 2'd0;
wire [1:0] pair_candidate_autolock_mode_storage;
reg pair_candidate_autolock_mode_re = 1'd0;
reg pair_candidate_status = 1'd0;
wire [13:0] pair_rb_bus_adr;
wire pair_rb_bus_we;
wire [7:0] pair_rb_bus_dat_w;
reg [7:0] pair_rb_bus_dat_r = 8'd0;
wire pair_rb_robust_time_scale1_re;
wire [5:0] pair_rb_robust_time_scale1_r;
wire [5:0] pair_rb_robust_time_scale1_w;
wire pair_rb_robust_time_scale0_re;
wire [7:0] pair_rb_robust_time_scale0_r;
wire [7:0] pair_rb_robust_time_scale0_w;
wire pair_rb_robust_N_instructions0_re;
wire [4:0] pair_rb_robust_N_instructions0_r;
wire [4:0] pair_rb_robust_N_instructions0_w;
wire pair_rb_robust_final_wait_time1_re;
wire [5:0] pair_rb_robust_final_wait_time1_r;
wire [5:0] pair_rb_robust_final_wait_time1_w;
wire pair_rb_robust_final_wait_time0_re;
wire [7:0] pair_rb_robust_final_wait_time0_r;
wire [7:0] pair_rb_robust_final_wait_time0_w;
wire pair_rb_robust_peak_height_03_re;
wire [3:0] pair_rb_robust_peak_height_03_r;
wire [3:0] pair_rb_robust_peak_height_03_w;
wire pair_rb_robust_peak_height_02_re;
wire [7:0] pair_rb_robust_peak_height_02_r;
wire [7:0] pair_rb_robust_peak_height_02_w;
wire pair_rb_robust_peak_height_01_re;
wire [7:0] pair_rb_robust_peak_height_01_r;
wire [7:0] pair_rb_robust_peak_height_01_w;
wire pair_rb_robust_peak_height_00_re;
wire [7:0] pair_rb_robust_peak_height_00_r;
wire [7:0] pair_rb_robust_peak_height_00_w;
wire pair_rb_robust_peak_height_13_re;
wire [3:0] pair_rb_robust_peak_height_13_r;
wire [3:0] pair_rb_robust_peak_height_13_w;
wire pair_rb_robust_peak_height_12_re;
wire [7:0] pair_rb_robust_peak_height_12_r;
wire [7:0] pair_rb_robust_peak_height_12_w;
wire pair_rb_robust_peak_height_11_re;
wire [7:0] pair_rb_robust_peak_height_11_r;
wire [7:0] pair_rb_robust_peak_height_11_w;
wire pair_rb_robust_peak_height_10_re;
wire [7:0] pair_rb_robust_peak_height_10_r;
wire [7:0] pair_rb_robust_peak_height_10_w;
wire pair_rb_robust_peak_height_23_re;
wire [3:0] pair_rb_robust_peak_height_23_r;
wire [3:0] pair_rb_robust_peak_height_23_w;
wire pair_rb_robust_peak_height_22_re;
wire [7:0] pair_rb_robust_peak_height_22_r;
wire [7:0] pair_rb_robust_peak_height_22_w;
wire pair_rb_robust_peak_height_21_re;
wire [7:0] pair_rb_robust_peak_height_21_r;
wire [7:0] pair_rb_robust_peak_height_21_w;
wire pair_rb_robust_peak_height_20_re;
wire [7:0] pair_rb_robust_peak_height_20_r;
wire [7:0] pair_rb_robust_peak_height_20_w;
wire pair_rb_robust_peak_height_33_re;
wire [3:0] pair_rb_robust_peak_height_33_r;
wire [3:0] pair_rb_robust_peak_height_33_w;
wire pair_rb_robust_peak_height_32_re;
wire [7:0] pair_rb_robust_peak_height_32_r;
wire [7:0] pair_rb_robust_peak_height_32_w;
wire pair_rb_robust_peak_height_31_re;
wire [7:0] pair_rb_robust_peak_height_31_r;
wire [7:0] pair_rb_robust_peak_height_31_w;
wire pair_rb_robust_peak_height_30_re;
wire [7:0] pair_rb_robust_peak_height_30_r;
wire [7:0] pair_rb_robust_peak_height_30_w;
wire pair_rb_robust_peak_height_43_re;
wire [3:0] pair_rb_robust_peak_height_43_r;
wire [3:0] pair_rb_robust_peak_height_43_w;
wire pair_rb_robust_peak_height_42_re;
wire [7:0] pair_rb_robust_peak_height_42_r;
wire [7:0] pair_rb_robust_peak_height_42_w;
wire pair_rb_robust_peak_height_41_re;
wire [7:0] pair_rb_robust_peak_height_41_r;
wire [7:0] pair_rb_robust_peak_height_41_w;
wire pair_rb_robust_peak_height_40_re;
wire [7:0] pair_rb_robust_peak_height_40_r;
wire [7:0] pair_rb_robust_peak_height_40_w;
wire pair_rb_robust_peak_height_53_re;
wire [3:0] pair_rb_robust_peak_height_53_r;
wire [3:0] pair_rb_robust_peak_height_53_w;
wire pair_rb_robust_peak_height_52_re;
wire [7:0] pair_rb_robust_peak_height_52_r;
wire [7:0] pair_rb_robust_peak_height_52_w;
wire pair_rb_robust_peak_height_51_re;
wire [7:0] pair_rb_robust_peak_height_51_r;
wire [7:0] pair_rb_robust_peak_height_51_w;
wire pair_rb_robust_peak_height_50_re;
wire [7:0] pair_rb_robust_peak_height_50_r;
wire [7:0] pair_rb_robust_peak_height_50_w;
wire pair_rb_robust_peak_height_63_re;
wire [3:0] pair_rb_robust_peak_height_63_r;
wire [3:0] pair_rb_robust_peak_height_63_w;
wire pair_rb_robust_peak_height_62_re;
wire [7:0] pair_rb_robust_peak_height_62_r;
wire [7:0] pair_rb_robust_peak_height_62_w;
wire pair_rb_robust_peak_height_61_re;
wire [7:0] pair_rb_robust_peak_height_61_r;
wire [7:0] pair_rb_robust_peak_height_61_w;
wire pair_rb_robust_peak_height_60_re;
wire [7:0] pair_rb_robust_peak_height_60_r;
wire [7:0] pair_rb_robust_peak_height_60_w;
wire pair_rb_robust_peak_height_73_re;
wire [3:0] pair_rb_robust_peak_height_73_r;
wire [3:0] pair_rb_robust_peak_height_73_w;
wire pair_rb_robust_peak_height_72_re;
wire [7:0] pair_rb_robust_peak_height_72_r;
wire [7:0] pair_rb_robust_peak_height_72_w;
wire pair_rb_robust_peak_height_71_re;
wire [7:0] pair_rb_robust_peak_height_71_r;
wire [7:0] pair_rb_robust_peak_height_71_w;
wire pair_rb_robust_peak_height_70_re;
wire [7:0] pair_rb_robust_peak_height_70_r;
wire [7:0] pair_rb_robust_peak_height_70_w;
wire pair_rb_robust_peak_height_83_re;
wire [3:0] pair_rb_robust_peak_height_83_r;
wire [3:0] pair_rb_robust_peak_height_83_w;
wire pair_rb_robust_peak_height_82_re;
wire [7:0] pair_rb_robust_peak_height_82_r;
wire [7:0] pair_rb_robust_peak_height_82_w;
wire pair_rb_robust_peak_height_81_re;
wire [7:0] pair_rb_robust_peak_height_81_r;
wire [7:0] pair_rb_robust_peak_height_81_w;
wire pair_rb_robust_peak_height_80_re;
wire [7:0] pair_rb_robust_peak_height_80_r;
wire [7:0] pair_rb_robust_peak_height_80_w;
wire pair_rb_robust_peak_height_93_re;
wire [3:0] pair_rb_robust_peak_height_93_r;
wire [3:0] pair_rb_robust_peak_height_93_w;
wire pair_rb_robust_peak_height_92_re;
wire [7:0] pair_rb_robust_peak_height_92_r;
wire [7:0] pair_rb_robust_peak_height_92_w;
wire pair_rb_robust_peak_height_91_re;
wire [7:0] pair_rb_robust_peak_height_91_r;
wire [7:0] pair_rb_robust_peak_height_91_w;
wire pair_rb_robust_peak_height_90_re;
wire [7:0] pair_rb_robust_peak_height_90_r;
wire [7:0] pair_rb_robust_peak_height_90_w;
wire pair_rb_robust_peak_height_103_re;
wire [3:0] pair_rb_robust_peak_height_103_r;
wire [3:0] pair_rb_robust_peak_height_103_w;
wire pair_rb_robust_peak_height_102_re;
wire [7:0] pair_rb_robust_peak_height_102_r;
wire [7:0] pair_rb_robust_peak_height_102_w;
wire pair_rb_robust_peak_height_101_re;
wire [7:0] pair_rb_robust_peak_height_101_r;
wire [7:0] pair_rb_robust_peak_height_101_w;
wire pair_rb_robust_peak_height_100_re;
wire [7:0] pair_rb_robust_peak_height_100_r;
wire [7:0] pair_rb_robust_peak_height_100_w;
wire pair_rb_robust_peak_height_113_re;
wire [3:0] pair_rb_robust_peak_height_113_r;
wire [3:0] pair_rb_robust_peak_height_113_w;
wire pair_rb_robust_peak_height_112_re;
wire [7:0] pair_rb_robust_peak_height_112_r;
wire [7:0] pair_rb_robust_peak_height_112_w;
wire pair_rb_robust_peak_height_111_re;
wire [7:0] pair_rb_robust_peak_height_111_r;
wire [7:0] pair_rb_robust_peak_height_111_w;
wire pair_rb_robust_peak_height_110_re;
wire [7:0] pair_rb_robust_peak_height_110_r;
wire [7:0] pair_rb_robust_peak_height_110_w;
wire pair_rb_robust_peak_height_123_re;
wire [3:0] pair_rb_robust_peak_height_123_r;
wire [3:0] pair_rb_robust_peak_height_123_w;
wire pair_rb_robust_peak_height_122_re;
wire [7:0] pair_rb_robust_peak_height_122_r;
wire [7:0] pair_rb_robust_peak_height_122_w;
wire pair_rb_robust_peak_height_121_re;
wire [7:0] pair_rb_robust_peak_height_121_r;
wire [7:0] pair_rb_robust_peak_height_121_w;
wire pair_rb_robust_peak_height_120_re;
wire [7:0] pair_rb_robust_peak_height_120_r;
wire [7:0] pair_rb_robust_peak_height_120_w;
wire pair_rb_robust_peak_height_133_re;
wire [3:0] pair_rb_robust_peak_height_133_r;
wire [3:0] pair_rb_robust_peak_height_133_w;
wire pair_rb_robust_peak_height_132_re;
wire [7:0] pair_rb_robust_peak_height_132_r;
wire [7:0] pair_rb_robust_peak_height_132_w;
wire pair_rb_robust_peak_height_131_re;
wire [7:0] pair_rb_robust_peak_height_131_r;
wire [7:0] pair_rb_robust_peak_height_131_w;
wire pair_rb_robust_peak_height_130_re;
wire [7:0] pair_rb_robust_peak_height_130_r;
wire [7:0] pair_rb_robust_peak_height_130_w;
wire pair_rb_robust_peak_height_143_re;
wire [3:0] pair_rb_robust_peak_height_143_r;
wire [3:0] pair_rb_robust_peak_height_143_w;
wire pair_rb_robust_peak_height_142_re;
wire [7:0] pair_rb_robust_peak_height_142_r;
wire [7:0] pair_rb_robust_peak_height_142_w;
wire pair_rb_robust_peak_height_141_re;
wire [7:0] pair_rb_robust_peak_height_141_r;
wire [7:0] pair_rb_robust_peak_height_141_w;
wire pair_rb_robust_peak_height_140_re;
wire [7:0] pair_rb_robust_peak_height_140_r;
wire [7:0] pair_rb_robust_peak_height_140_w;
wire pair_rb_robust_peak_height_153_re;
wire [3:0] pair_rb_robust_peak_height_153_r;
wire [3:0] pair_rb_robust_peak_height_153_w;
wire pair_rb_robust_peak_height_152_re;
wire [7:0] pair_rb_robust_peak_height_152_r;
wire [7:0] pair_rb_robust_peak_height_152_w;
wire pair_rb_robust_peak_height_151_re;
wire [7:0] pair_rb_robust_peak_height_151_r;
wire [7:0] pair_rb_robust_peak_height_151_w;
wire pair_rb_robust_peak_height_150_re;
wire [7:0] pair_rb_robust_peak_height_150_r;
wire [7:0] pair_rb_robust_peak_height_150_w;
wire pair_rb_robust_peak_height_163_re;
wire [3:0] pair_rb_robust_peak_height_163_r;
wire [3:0] pair_rb_robust_peak_height_163_w;
wire pair_rb_robust_peak_height_162_re;
wire [7:0] pair_rb_robust_peak_height_162_r;
wire [7:0] pair_rb_robust_peak_height_162_w;
wire pair_rb_robust_peak_height_161_re;
wire [7:0] pair_rb_robust_peak_height_161_r;
wire [7:0] pair_rb_robust_peak_height_161_w;
wire pair_rb_robust_peak_height_160_re;
wire [7:0] pair_rb_robust_peak_height_160_r;
wire [7:0] pair_rb_robust_peak_height_160_w;
wire pair_rb_robust_peak_height_173_re;
wire [3:0] pair_rb_robust_peak_height_173_r;
wire [3:0] pair_rb_robust_peak_height_173_w;
wire pair_rb_robust_peak_height_172_re;
wire [7:0] pair_rb_robust_peak_height_172_r;
wire [7:0] pair_rb_robust_peak_height_172_w;
wire pair_rb_robust_peak_height_171_re;
wire [7:0] pair_rb_robust_peak_height_171_r;
wire [7:0] pair_rb_robust_peak_height_171_w;
wire pair_rb_robust_peak_height_170_re;
wire [7:0] pair_rb_robust_peak_height_170_r;
wire [7:0] pair_rb_robust_peak_height_170_w;
wire pair_rb_robust_peak_height_183_re;
wire [3:0] pair_rb_robust_peak_height_183_r;
wire [3:0] pair_rb_robust_peak_height_183_w;
wire pair_rb_robust_peak_height_182_re;
wire [7:0] pair_rb_robust_peak_height_182_r;
wire [7:0] pair_rb_robust_peak_height_182_w;
wire pair_rb_robust_peak_height_181_re;
wire [7:0] pair_rb_robust_peak_height_181_r;
wire [7:0] pair_rb_robust_peak_height_181_w;
wire pair_rb_robust_peak_height_180_re;
wire [7:0] pair_rb_robust_peak_height_180_r;
wire [7:0] pair_rb_robust_peak_height_180_w;
wire pair_rb_robust_peak_height_193_re;
wire [3:0] pair_rb_robust_peak_height_193_r;
wire [3:0] pair_rb_robust_peak_height_193_w;
wire pair_rb_robust_peak_height_192_re;
wire [7:0] pair_rb_robust_peak_height_192_r;
wire [7:0] pair_rb_robust_peak_height_192_w;
wire pair_rb_robust_peak_height_191_re;
wire [7:0] pair_rb_robust_peak_height_191_r;
wire [7:0] pair_rb_robust_peak_height_191_w;
wire pair_rb_robust_peak_height_190_re;
wire [7:0] pair_rb_robust_peak_height_190_r;
wire [7:0] pair_rb_robust_peak_height_190_w;
wire pair_rb_robust_peak_height_203_re;
wire [3:0] pair_rb_robust_peak_height_203_r;
wire [3:0] pair_rb_robust_peak_height_203_w;
wire pair_rb_robust_peak_height_202_re;
wire [7:0] pair_rb_robust_peak_height_202_r;
wire [7:0] pair_rb_robust_peak_height_202_w;
wire pair_rb_robust_peak_height_201_re;
wire [7:0] pair_rb_robust_peak_height_201_r;
wire [7:0] pair_rb_robust_peak_height_201_w;
wire pair_rb_robust_peak_height_200_re;
wire [7:0] pair_rb_robust_peak_height_200_r;
wire [7:0] pair_rb_robust_peak_height_200_w;
wire pair_rb_robust_peak_height_213_re;
wire [3:0] pair_rb_robust_peak_height_213_r;
wire [3:0] pair_rb_robust_peak_height_213_w;
wire pair_rb_robust_peak_height_212_re;
wire [7:0] pair_rb_robust_peak_height_212_r;
wire [7:0] pair_rb_robust_peak_height_212_w;
wire pair_rb_robust_peak_height_211_re;
wire [7:0] pair_rb_robust_peak_height_211_r;
wire [7:0] pair_rb_robust_peak_height_211_w;
wire pair_rb_robust_peak_height_210_re;
wire [7:0] pair_rb_robust_peak_height_210_r;
wire [7:0] pair_rb_robust_peak_height_210_w;
wire pair_rb_robust_peak_height_223_re;
wire [3:0] pair_rb_robust_peak_height_223_r;
wire [3:0] pair_rb_robust_peak_height_223_w;
wire pair_rb_robust_peak_height_222_re;
wire [7:0] pair_rb_robust_peak_height_222_r;
wire [7:0] pair_rb_robust_peak_height_222_w;
wire pair_rb_robust_peak_height_221_re;
wire [7:0] pair_rb_robust_peak_height_221_r;
wire [7:0] pair_rb_robust_peak_height_221_w;
wire pair_rb_robust_peak_height_220_re;
wire [7:0] pair_rb_robust_peak_height_220_r;
wire [7:0] pair_rb_robust_peak_height_220_w;
wire pair_rb_robust_peak_height_233_re;
wire [3:0] pair_rb_robust_peak_height_233_r;
wire [3:0] pair_rb_robust_peak_height_233_w;
wire pair_rb_robust_peak_height_232_re;
wire [7:0] pair_rb_robust_peak_height_232_r;
wire [7:0] pair_rb_robust_peak_height_232_w;
wire pair_rb_robust_peak_height_231_re;
wire [7:0] pair_rb_robust_peak_height_231_r;
wire [7:0] pair_rb_robust_peak_height_231_w;
wire pair_rb_robust_peak_height_230_re;
wire [7:0] pair_rb_robust_peak_height_230_r;
wire [7:0] pair_rb_robust_peak_height_230_w;
wire pair_rb_robust_peak_height_243_re;
wire [3:0] pair_rb_robust_peak_height_243_r;
wire [3:0] pair_rb_robust_peak_height_243_w;
wire pair_rb_robust_peak_height_242_re;
wire [7:0] pair_rb_robust_peak_height_242_r;
wire [7:0] pair_rb_robust_peak_height_242_w;
wire pair_rb_robust_peak_height_241_re;
wire [7:0] pair_rb_robust_peak_height_241_r;
wire [7:0] pair_rb_robust_peak_height_241_w;
wire pair_rb_robust_peak_height_240_re;
wire [7:0] pair_rb_robust_peak_height_240_r;
wire [7:0] pair_rb_robust_peak_height_240_w;
wire pair_rb_robust_peak_height_253_re;
wire [3:0] pair_rb_robust_peak_height_253_r;
wire [3:0] pair_rb_robust_peak_height_253_w;
wire pair_rb_robust_peak_height_252_re;
wire [7:0] pair_rb_robust_peak_height_252_r;
wire [7:0] pair_rb_robust_peak_height_252_w;
wire pair_rb_robust_peak_height_251_re;
wire [7:0] pair_rb_robust_peak_height_251_r;
wire [7:0] pair_rb_robust_peak_height_251_w;
wire pair_rb_robust_peak_height_250_re;
wire [7:0] pair_rb_robust_peak_height_250_r;
wire [7:0] pair_rb_robust_peak_height_250_w;
wire pair_rb_robust_peak_height_263_re;
wire [3:0] pair_rb_robust_peak_height_263_r;
wire [3:0] pair_rb_robust_peak_height_263_w;
wire pair_rb_robust_peak_height_262_re;
wire [7:0] pair_rb_robust_peak_height_262_r;
wire [7:0] pair_rb_robust_peak_height_262_w;
wire pair_rb_robust_peak_height_261_re;
wire [7:0] pair_rb_robust_peak_height_261_r;
wire [7:0] pair_rb_robust_peak_height_261_w;
wire pair_rb_robust_peak_height_260_re;
wire [7:0] pair_rb_robust_peak_height_260_r;
wire [7:0] pair_rb_robust_peak_height_260_w;
wire pair_rb_robust_peak_height_273_re;
wire [3:0] pair_rb_robust_peak_height_273_r;
wire [3:0] pair_rb_robust_peak_height_273_w;
wire pair_rb_robust_peak_height_272_re;
wire [7:0] pair_rb_robust_peak_height_272_r;
wire [7:0] pair_rb_robust_peak_height_272_w;
wire pair_rb_robust_peak_height_271_re;
wire [7:0] pair_rb_robust_peak_height_271_r;
wire [7:0] pair_rb_robust_peak_height_271_w;
wire pair_rb_robust_peak_height_270_re;
wire [7:0] pair_rb_robust_peak_height_270_r;
wire [7:0] pair_rb_robust_peak_height_270_w;
wire pair_rb_robust_peak_height_283_re;
wire [3:0] pair_rb_robust_peak_height_283_r;
wire [3:0] pair_rb_robust_peak_height_283_w;
wire pair_rb_robust_peak_height_282_re;
wire [7:0] pair_rb_robust_peak_height_282_r;
wire [7:0] pair_rb_robust_peak_height_282_w;
wire pair_rb_robust_peak_height_281_re;
wire [7:0] pair_rb_robust_peak_height_281_r;
wire [7:0] pair_rb_robust_peak_height_281_w;
wire pair_rb_robust_peak_height_280_re;
wire [7:0] pair_rb_robust_peak_height_280_r;
wire [7:0] pair_rb_robust_peak_height_280_w;
wire pair_rb_robust_peak_height_293_re;
wire [3:0] pair_rb_robust_peak_height_293_r;
wire [3:0] pair_rb_robust_peak_height_293_w;
wire pair_rb_robust_peak_height_292_re;
wire [7:0] pair_rb_robust_peak_height_292_r;
wire [7:0] pair_rb_robust_peak_height_292_w;
wire pair_rb_robust_peak_height_291_re;
wire [7:0] pair_rb_robust_peak_height_291_r;
wire [7:0] pair_rb_robust_peak_height_291_w;
wire pair_rb_robust_peak_height_290_re;
wire [7:0] pair_rb_robust_peak_height_290_r;
wire [7:0] pair_rb_robust_peak_height_290_w;
wire pair_rb_robust_peak_height_303_re;
wire [3:0] pair_rb_robust_peak_height_303_r;
wire [3:0] pair_rb_robust_peak_height_303_w;
wire pair_rb_robust_peak_height_302_re;
wire [7:0] pair_rb_robust_peak_height_302_r;
wire [7:0] pair_rb_robust_peak_height_302_w;
wire pair_rb_robust_peak_height_301_re;
wire [7:0] pair_rb_robust_peak_height_301_r;
wire [7:0] pair_rb_robust_peak_height_301_w;
wire pair_rb_robust_peak_height_300_re;
wire [7:0] pair_rb_robust_peak_height_300_r;
wire [7:0] pair_rb_robust_peak_height_300_w;
wire pair_rb_robust_peak_height_313_re;
wire [3:0] pair_rb_robust_peak_height_313_r;
wire [3:0] pair_rb_robust_peak_height_313_w;
wire pair_rb_robust_peak_height_312_re;
wire [7:0] pair_rb_robust_peak_height_312_r;
wire [7:0] pair_rb_robust_peak_height_312_w;
wire pair_rb_robust_peak_height_311_re;
wire [7:0] pair_rb_robust_peak_height_311_r;
wire [7:0] pair_rb_robust_peak_height_311_w;
wire pair_rb_robust_peak_height_310_re;
wire [7:0] pair_rb_robust_peak_height_310_r;
wire [7:0] pair_rb_robust_peak_height_310_w;
wire pair_rb_robust_wait_for_01_re;
wire [5:0] pair_rb_robust_wait_for_01_r;
wire [5:0] pair_rb_robust_wait_for_01_w;
wire pair_rb_robust_wait_for_00_re;
wire [7:0] pair_rb_robust_wait_for_00_r;
wire [7:0] pair_rb_robust_wait_for_00_w;
wire pair_rb_robust_wait_for_11_re;
wire [5:0] pair_rb_robust_wait_for_11_r;
wire [5:0] pair_rb_robust_wait_for_11_w;
wire pair_rb_robust_wait_for_10_re;
wire [7:0] pair_rb_robust_wait_for_10_r;
wire [7:0] pair_rb_robust_wait_for_10_w;
wire pair_rb_robust_wait_for_21_re;
wire [5:0] pair_rb_robust_wait_for_21_r;
wire [5:0] pair_rb_robust_wait_for_21_w;
wire pair_rb_robust_wait_for_20_re;
wire [7:0] pair_rb_robust_wait_for_20_r;
wire [7:0] pair_rb_robust_wait_for_20_w;
wire pair_rb_robust_wait_for_31_re;
wire [5:0] pair_rb_robust_wait_for_31_r;
wire [5:0] pair_rb_robust_wait_for_31_w;
wire pair_rb_robust_wait_for_30_re;
wire [7:0] pair_rb_robust_wait_for_30_r;
wire [7:0] pair_rb_robust_wait_for_30_w;
wire pair_rb_robust_wait_for_41_re;
wire [5:0] pair_rb_robust_wait_for_41_r;
wire [5:0] pair_rb_robust_wait_for_41_w;
wire pair_rb_robust_wait_for_40_re;
wire [7:0] pair_rb_robust_wait_for_40_r;
wire [7:0] pair_rb_robust_wait_for_40_w;
wire pair_rb_robust_wait_for_51_re;
wire [5:0] pair_rb_robust_wait_for_51_r;
wire [5:0] pair_rb_robust_wait_for_51_w;
wire pair_rb_robust_wait_for_50_re;
wire [7:0] pair_rb_robust_wait_for_50_r;
wire [7:0] pair_rb_robust_wait_for_50_w;
wire pair_rb_robust_wait_for_61_re;
wire [5:0] pair_rb_robust_wait_for_61_r;
wire [5:0] pair_rb_robust_wait_for_61_w;
wire pair_rb_robust_wait_for_60_re;
wire [7:0] pair_rb_robust_wait_for_60_r;
wire [7:0] pair_rb_robust_wait_for_60_w;
wire pair_rb_robust_wait_for_71_re;
wire [5:0] pair_rb_robust_wait_for_71_r;
wire [5:0] pair_rb_robust_wait_for_71_w;
wire pair_rb_robust_wait_for_70_re;
wire [7:0] pair_rb_robust_wait_for_70_r;
wire [7:0] pair_rb_robust_wait_for_70_w;
wire pair_rb_robust_wait_for_81_re;
wire [5:0] pair_rb_robust_wait_for_81_r;
wire [5:0] pair_rb_robust_wait_for_81_w;
wire pair_rb_robust_wait_for_80_re;
wire [7:0] pair_rb_robust_wait_for_80_r;
wire [7:0] pair_rb_robust_wait_for_80_w;
wire pair_rb_robust_wait_for_91_re;
wire [5:0] pair_rb_robust_wait_for_91_r;
wire [5:0] pair_rb_robust_wait_for_91_w;
wire pair_rb_robust_wait_for_90_re;
wire [7:0] pair_rb_robust_wait_for_90_r;
wire [7:0] pair_rb_robust_wait_for_90_w;
wire pair_rb_robust_wait_for_101_re;
wire [5:0] pair_rb_robust_wait_for_101_r;
wire [5:0] pair_rb_robust_wait_for_101_w;
wire pair_rb_robust_wait_for_100_re;
wire [7:0] pair_rb_robust_wait_for_100_r;
wire [7:0] pair_rb_robust_wait_for_100_w;
wire pair_rb_robust_wait_for_111_re;
wire [5:0] pair_rb_robust_wait_for_111_r;
wire [5:0] pair_rb_robust_wait_for_111_w;
wire pair_rb_robust_wait_for_110_re;
wire [7:0] pair_rb_robust_wait_for_110_r;
wire [7:0] pair_rb_robust_wait_for_110_w;
wire pair_rb_robust_wait_for_121_re;
wire [5:0] pair_rb_robust_wait_for_121_r;
wire [5:0] pair_rb_robust_wait_for_121_w;
wire pair_rb_robust_wait_for_120_re;
wire [7:0] pair_rb_robust_wait_for_120_r;
wire [7:0] pair_rb_robust_wait_for_120_w;
wire pair_rb_robust_wait_for_131_re;
wire [5:0] pair_rb_robust_wait_for_131_r;
wire [5:0] pair_rb_robust_wait_for_131_w;
wire pair_rb_robust_wait_for_130_re;
wire [7:0] pair_rb_robust_wait_for_130_r;
wire [7:0] pair_rb_robust_wait_for_130_w;
wire pair_rb_robust_wait_for_141_re;
wire [5:0] pair_rb_robust_wait_for_141_r;
wire [5:0] pair_rb_robust_wait_for_141_w;
wire pair_rb_robust_wait_for_140_re;
wire [7:0] pair_rb_robust_wait_for_140_r;
wire [7:0] pair_rb_robust_wait_for_140_w;
wire pair_rb_robust_wait_for_151_re;
wire [5:0] pair_rb_robust_wait_for_151_r;
wire [5:0] pair_rb_robust_wait_for_151_w;
wire pair_rb_robust_wait_for_150_re;
wire [7:0] pair_rb_robust_wait_for_150_r;
wire [7:0] pair_rb_robust_wait_for_150_w;
wire pair_rb_robust_wait_for_161_re;
wire [5:0] pair_rb_robust_wait_for_161_r;
wire [5:0] pair_rb_robust_wait_for_161_w;
wire pair_rb_robust_wait_for_160_re;
wire [7:0] pair_rb_robust_wait_for_160_r;
wire [7:0] pair_rb_robust_wait_for_160_w;
wire pair_rb_robust_wait_for_171_re;
wire [5:0] pair_rb_robust_wait_for_171_r;
wire [5:0] pair_rb_robust_wait_for_171_w;
wire pair_rb_robust_wait_for_170_re;
wire [7:0] pair_rb_robust_wait_for_170_r;
wire [7:0] pair_rb_robust_wait_for_170_w;
wire pair_rb_robust_wait_for_181_re;
wire [5:0] pair_rb_robust_wait_for_181_r;
wire [5:0] pair_rb_robust_wait_for_181_w;
wire pair_rb_robust_wait_for_180_re;
wire [7:0] pair_rb_robust_wait_for_180_r;
wire [7:0] pair_rb_robust_wait_for_180_w;
wire pair_rb_robust_wait_for_191_re;
wire [5:0] pair_rb_robust_wait_for_191_r;
wire [5:0] pair_rb_robust_wait_for_191_w;
wire pair_rb_robust_wait_for_190_re;
wire [7:0] pair_rb_robust_wait_for_190_r;
wire [7:0] pair_rb_robust_wait_for_190_w;
wire pair_rb_robust_wait_for_201_re;
wire [5:0] pair_rb_robust_wait_for_201_r;
wire [5:0] pair_rb_robust_wait_for_201_w;
wire pair_rb_robust_wait_for_200_re;
wire [7:0] pair_rb_robust_wait_for_200_r;
wire [7:0] pair_rb_robust_wait_for_200_w;
wire pair_rb_robust_wait_for_211_re;
wire [5:0] pair_rb_robust_wait_for_211_r;
wire [5:0] pair_rb_robust_wait_for_211_w;
wire pair_rb_robust_wait_for_210_re;
wire [7:0] pair_rb_robust_wait_for_210_r;
wire [7:0] pair_rb_robust_wait_for_210_w;
wire pair_rb_robust_wait_for_221_re;
wire [5:0] pair_rb_robust_wait_for_221_r;
wire [5:0] pair_rb_robust_wait_for_221_w;
wire pair_rb_robust_wait_for_220_re;
wire [7:0] pair_rb_robust_wait_for_220_r;
wire [7:0] pair_rb_robust_wait_for_220_w;
wire pair_rb_robust_wait_for_231_re;
wire [5:0] pair_rb_robust_wait_for_231_r;
wire [5:0] pair_rb_robust_wait_for_231_w;
wire pair_rb_robust_wait_for_230_re;
wire [7:0] pair_rb_robust_wait_for_230_r;
wire [7:0] pair_rb_robust_wait_for_230_w;
wire pair_rb_robust_wait_for_241_re;
wire [5:0] pair_rb_robust_wait_for_241_r;
wire [5:0] pair_rb_robust_wait_for_241_w;
wire pair_rb_robust_wait_for_240_re;
wire [7:0] pair_rb_robust_wait_for_240_r;
wire [7:0] pair_rb_robust_wait_for_240_w;
wire pair_rb_robust_wait_for_251_re;
wire [5:0] pair_rb_robust_wait_for_251_r;
wire [5:0] pair_rb_robust_wait_for_251_w;
wire pair_rb_robust_wait_for_250_re;
wire [7:0] pair_rb_robust_wait_for_250_r;
wire [7:0] pair_rb_robust_wait_for_250_w;
wire pair_rb_robust_wait_for_261_re;
wire [5:0] pair_rb_robust_wait_for_261_r;
wire [5:0] pair_rb_robust_wait_for_261_w;
wire pair_rb_robust_wait_for_260_re;
wire [7:0] pair_rb_robust_wait_for_260_r;
wire [7:0] pair_rb_robust_wait_for_260_w;
wire pair_rb_robust_wait_for_271_re;
wire [5:0] pair_rb_robust_wait_for_271_r;
wire [5:0] pair_rb_robust_wait_for_271_w;
wire pair_rb_robust_wait_for_270_re;
wire [7:0] pair_rb_robust_wait_for_270_r;
wire [7:0] pair_rb_robust_wait_for_270_w;
wire pair_rb_robust_wait_for_281_re;
wire [5:0] pair_rb_robust_wait_for_281_r;
wire [5:0] pair_rb_robust_wait_for_281_w;
wire pair_rb_robust_wait_for_280_re;
wire [7:0] pair_rb_robust_wait_for_280_r;
wire [7:0] pair_rb_robust_wait_for_280_w;
wire pair_rb_robust_wait_for_291_re;
wire [5:0] pair_rb_robust_wait_for_291_r;
wire [5:0] pair_rb_robust_wait_for_291_w;
wire pair_rb_robust_wait_for_290_re;
wire [7:0] pair_rb_robust_wait_for_290_r;
wire [7:0] pair_rb_robust_wait_for_290_w;
wire pair_rb_robust_wait_for_301_re;
wire [5:0] pair_rb_robust_wait_for_301_r;
wire [5:0] pair_rb_robust_wait_for_301_w;
wire pair_rb_robust_wait_for_300_re;
wire [7:0] pair_rb_robust_wait_for_300_r;
wire [7:0] pair_rb_robust_wait_for_300_w;
wire pair_rb_robust_wait_for_311_re;
wire [5:0] pair_rb_robust_wait_for_311_r;
wire [5:0] pair_rb_robust_wait_for_311_w;
wire pair_rb_robust_wait_for_310_re;
wire [7:0] pair_rb_robust_wait_for_310_r;
wire [7:0] pair_rb_robust_wait_for_310_w;
wire pair_rb_fast_target_position1_re;
wire [5:0] pair_rb_fast_target_position1_r;
wire [5:0] pair_rb_fast_target_position1_w;
wire pair_rb_fast_target_position0_re;
wire [7:0] pair_rb_fast_target_position0_r;
wire [7:0] pair_rb_fast_target_position0_w;
wire pair_rb_request_lock0_re;
wire pair_rb_request_lock0_r;
wire pair_rb_request_lock0_w;
wire pair_rb_autolock_mode0_re;
wire [1:0] pair_rb_autolock_mode0_r;
wire [1:0] pair_rb_autolock_mode0_w;
wire pair_rb_lock_running_re;
wire pair_rb_lock_running_r;
wire pair_rb_lock_running_w;
wire pair_rb_sel;
wire [13:0] pair_cb_bus_adr;
wire pair_cb_bus_we;
wire [7:0] pair_cb_bus_dat_w;
reg [7:0] pair_cb_bus_dat_r = 8'd0;
wire pair_cb_robust_time_scale1_re;
wire [5:0] pair_cb_robust_time_scale1_r;
wire [5:0] pair_cb_robust_time_scale1_w;
wire pair_cb_robust_time_scale0_re;
wire [7:0] pair_cb_robust_time_scale0_r;
wire [7:0] pair_cb_robust_time_scale0_w;
wire pair_cb_robust_N_instructions0_re;
wire [4:0] pair_cb_robust_N_instructions0_r;
wire [4:0] pair_cb_robust_N_instructions0_w;
wire pair_cb_robust_final_wait_time1_re;
wire [5:0] pair_cb_robust_final_wait_time1_r;
wire [5:0] pair_cb_robust_final_wait_time1_w;
wire pair_cb_robust_final_wait_time0_re;
wire [7:0] pair_cb_robust_final_wait_time0_r;
wire [7:0] pair_cb_robust_final_wait_time0_w;
wire pair_cb_robust_peak_height_03_re;
wire [3:0] pair_cb_robust_peak_height_03_r;
wire [3:0] pair_cb_robust_peak_height_03_w;
wire pair_cb_robust_peak_height_02_re;
wire [7:0] pair_cb_robust_peak_height_02_r;
wire [7:0] pair_cb_robust_peak_height_02_w;
wire pair_cb_robust_peak_height_01_re;
wire [7:0] pair_cb_robust_peak_height_01_r;
wire [7:0] pair_cb_robust_peak_height_01_w;
wire pair_cb_robust_peak_height_00_re;
wire [7:0] pair_cb_robust_peak_height_00_r;
wire [7:0] pair_cb_robust_peak_height_00_w;
wire pair_cb_robust_peak_height_13_re;
wire [3:0] pair_cb_robust_peak_height_13_r;
wire [3:0] pair_cb_robust_peak_height_13_w;
wire pair_cb_robust_peak_height_12_re;
wire [7:0] pair_cb_robust_peak_height_12_r;
wire [7:0] pair_cb_robust_peak_height_12_w;
wire pair_cb_robust_peak_height_11_re;
wire [7:0] pair_cb_robust_peak_height_11_r;
wire [7:0] pair_cb_robust_peak_height_11_w;
wire pair_cb_robust_peak_height_10_re;
wire [7:0] pair_cb_robust_peak_height_10_r;
wire [7:0] pair_cb_robust_peak_height_10_w;
wire pair_cb_robust_peak_height_23_re;
wire [3:0] pair_cb_robust_peak_height_23_r;
wire [3:0] pair_cb_robust_peak_height_23_w;
wire pair_cb_robust_peak_height_22_re;
wire [7:0] pair_cb_robust_peak_height_22_r;
wire [7:0] pair_cb_robust_peak_height_22_w;
wire pair_cb_robust_peak_height_21_re;
wire [7:0] pair_cb_robust_peak_height_21_r;
wire [7:0] pair_cb_robust_peak_height_21_w;
wire pair_cb_robust_peak_height_20_re;
wire [7:0] pair_cb_robust_peak_height_20_r;
wire [7:0] pair_cb_robust_peak_height_20_w;
wire pair_cb_robust_peak_height_33_re;
wire [3:0] pair_cb_robust_peak_height_33_r;
wire [3:0] pair_cb_robust_peak_height_33_w;
wire pair_cb_robust_peak_height_32_re;
wire [7:0] pair_cb_robust_peak_height_32_r;
wire [7:0] pair_cb_robust_peak_height_32_w;
wire pair_cb_robust_peak_height_31_re;
wire [7:0] pair_cb_robust_peak_height_31_r;
wire [7:0] pair_cb_robust_peak_height_31_w;
wire pair_cb_robust_peak_height_30_re;
wire [7:0] pair_cb_robust_peak_height_30_r;
wire [7:0] pair_cb_robust_peak_height_30_w;
wire pair_cb_robust_peak_height_43_re;
wire [3:0] pair_cb_robust_peak_height_43_r;
wire [3:0] pair_cb_robust_peak_height_43_w;
wire pair_cb_robust_peak_height_42_re;
wire [7:0] pair_cb_robust_peak_height_42_r;
wire [7:0] pair_cb_robust_peak_height_42_w;
wire pair_cb_robust_peak_height_41_re;
wire [7:0] pair_cb_robust_peak_height_41_r;
wire [7:0] pair_cb_robust_peak_height_41_w;
wire pair_cb_robust_peak_height_40_re;
wire [7:0] pair_cb_robust_peak_height_40_r;
wire [7:0] pair_cb_robust_peak_height_40_w;
wire pair_cb_robust_peak_height_53_re;
wire [3:0] pair_cb_robust_peak_height_53_r;
wire [3:0] pair_cb_robust_peak_height_53_w;
wire pair_cb_robust_peak_height_52_re;
wire [7:0] pair_cb_robust_peak_height_52_r;
wire [7:0] pair_cb_robust_peak_height_52_w;
wire pair_cb_robust_peak_height_51_re;
wire [7:0] pair_cb_robust_peak_height_51_r;
wire [7:0] pair_cb_robust_peak_height_51_w;
wire pair_cb_robust_peak_height_50_re;
wire [7:0] pair_cb_robust_peak_height_50_r;
wire [7:0] pair_cb_robust_peak_height_50_w;
wire pair_cb_robust_peak_height_63_re;
wire [3:0] pair_cb_robust_peak_height_63_r;
wire [3:0] pair_cb_robust_peak_height_63_w;
wire pair_cb_robust_peak_height_62_re;
wire [7:0] pair_cb_robust_peak_height_62_r;
wire [7:0] pair_cb_robust_peak_height_62_w;
wire pair_cb_robust_peak_height_61_re;
wire [7:0] pair_cb_robust_peak_height_61_r;
wire [7:0] pair_cb_robust_peak_height_61_w;
wire pair_cb_robust_peak_height_60_re;
wire [7:0] pair_cb_robust_peak_height_60_r;
wire [7:0] pair_cb_robust_peak_height_60_w;
wire pair_cb_robust_peak_height_73_re;
wire [3:0] pair_cb_robust_peak_height_73_r;
wire [3:0] pair_cb_robust_peak_height_73_w;
wire pair_cb_robust_peak_height_72_re;
wire [7:0] pair_cb_robust_peak_height_72_r;
wire [7:0] pair_cb_robust_peak_height_72_w;
wire pair_cb_robust_peak_height_71_re;
wire [7:0] pair_cb_robust_peak_height_71_r;
wire [7:0] pair_cb_robust_peak_height_71_w;
wire pair_cb_robust_peak_height_70_re;
wire [7:0] pair_cb_robust_peak_height_70_r;
wire [7:0] pair_cb_robust_peak_height_70_w;
wire pair_cb_robust_peak_height_83_re;
wire [3:0] pair_cb_robust_peak_height_83_r;
wire [3:0] pair_cb_robust_peak_height_83_w;
wire pair_cb_robust_peak_height_82_re;
wire [7:0] pair_cb_robust_peak_height_82_r;
wire [7:0] pair_cb_robust_peak_height_82_w;
wire pair_cb_robust_peak_height_81_re;
wire [7:0] pair_cb_robust_peak_height_81_r;
wire [7:0] pair_cb_robust_peak_height_81_w;
wire pair_cb_robust_peak_height_80_re;
wire [7:0] pair_cb_robust_peak_height_80_r;
wire [7:0] pair_cb_robust_peak_height_80_w;
wire pair_cb_robust_peak_height_93_re;
wire [3:0] pair_cb_robust_peak_height_93_r;
wire [3:0] pair_cb_robust_peak_height_93_w;
wire pair_cb_robust_peak_height_92_re;
wire [7:0] pair_cb_robust_peak_height_92_r;
wire [7:0] pair_cb_robust_peak_height_92_w;
wire pair_cb_robust_peak_height_91_re;
wire [7:0] pair_cb_robust_peak_height_91_r;
wire [7:0] pair_cb_robust_peak_height_91_w;
wire pair_cb_robust_peak_height_90_re;
wire [7:0] pair_cb_robust_peak_height_90_r;
wire [7:0] pair_cb_robust_peak_height_90_w;
wire pair_cb_robust_peak_height_103_re;
wire [3:0] pair_cb_robust_peak_height_103_r;
wire [3:0] pair_cb_robust_peak_height_103_w;
wire pair_cb_robust_peak_height_102_re;
wire [7:0] pair_cb_robust_peak_height_102_r;
wire [7:0] pair_cb_robust_peak_height_102_w;
wire pair_cb_robust_peak_height_101_re;
wire [7:0] pair_cb_robust_peak_height_101_r;
wire [7:0] pair_cb_robust_peak_height_101_w;
wire pair_cb_robust_peak_height_100_re;
wire [7:0] pair_cb_robust_peak_height_100_r;
wire [7:0] pair_cb_robust_peak_height_100_w;
wire pair_cb_robust_peak_height_113_re;
wire [3:0] pair_cb_robust_peak_height_113_r;
wire [3:0] pair_cb_robust_peak_height_113_w;
wire pair_cb_robust_peak_height_112_re;
wire [7:0] pair_cb_robust_peak_height_112_r;
wire [7:0] pair_cb_robust_peak_height_112_w;
wire pair_cb_robust_peak_height_111_re;
wire [7:0] pair_cb_robust_peak_height_111_r;
wire [7:0] pair_cb_robust_peak_height_111_w;
wire pair_cb_robust_peak_height_110_re;
wire [7:0] pair_cb_robust_peak_height_110_r;
wire [7:0] pair_cb_robust_peak_height_110_w;
wire pair_cb_robust_peak_height_123_re;
wire [3:0] pair_cb_robust_peak_height_123_r;
wire [3:0] pair_cb_robust_peak_height_123_w;
wire pair_cb_robust_peak_height_122_re;
wire [7:0] pair_cb_robust_peak_height_122_r;
wire [7:0] pair_cb_robust_peak_height_122_w;
wire pair_cb_robust_peak_height_121_re;
wire [7:0] pair_cb_robust_peak_height_121_r;
wire [7:0] pair_cb_robust_peak_height_121_w;
wire pair_cb_robust_peak_height_120_re;
wire [7:0] pair_cb_robust_peak_height_120_r;
wire [7:0] pair_cb_robust_peak_height_120_w;
wire pair_cb_robust_peak_height_133_re;
wire [3:0] pair_cb_robust_peak_height_133_r;
wire [3:0] pair_cb_robust_peak_height_133_w;
wire pair_cb_robust_peak_height_132_re;
wire [7:0] pair_cb_robust_peak_height_132_r;
wire [7:0] pair_cb_robust_peak_height_132_w;
wire pair_cb_robust_peak_height_131_re;
wire [7:0] pair_cb_robust_peak_height_131_r;
wire [7:0] pair_cb_robust_peak_height_131_w;
wire pair_cb_robust_peak_height_130_re;
wire [7:0] pair_cb_robust_peak_height_130_r;
wire [7:0] pair_cb_robust_peak_height_130_w;
wire pair_cb_robust_peak_height_143_re;
wire [3:0] pair_cb_robust_peak_height_143_r;
wire [3:0] pair_cb_robust_peak_height_143_w;
wire pair_cb_robust_peak_height_142_re;
wire [7:0] pair_cb_robust_peak_height_142_r;
wire [7:0] pair_cb_robust_peak_height_142_w;
wire pair_cb_robust_peak_height_141_re;
wire [7:0] pair_cb_robust_peak_height_141_r;
wire [7:0] pair_cb_robust_peak_height_141_w;
wire pair_cb_robust_peak_height_140_re;
wire [7:0] pair_cb_robust_peak_height_140_r;
wire [7:0] pair_cb_robust_peak_height_140_w;
wire pair_cb_robust_peak_height_153_re;
wire [3:0] pair_cb_robust_peak_height_153_r;
wire [3:0] pair_cb_robust_peak_height_153_w;
wire pair_cb_robust_peak_height_152_re;
wire [7:0] pair_cb_robust_peak_height_152_r;
wire [7:0] pair_cb_robust_peak_height_152_w;
wire pair_cb_robust_peak_height_151_re;
wire [7:0] pair_cb_robust_peak_height_151_r;
wire [7:0] pair_cb_robust_peak_height_151_w;
wire pair_cb_robust_peak_height_150_re;
wire [7:0] pair_cb_robust_peak_height_150_r;
wire [7:0] pair_cb_robust_peak_height_150_w;
wire pair_cb_robust_peak_height_163_re;
wire [3:0] pair_cb_robust_peak_height_163_r;
wire [3:0] pair_cb_robust_peak_height_163_w;
wire pair_cb_robust_peak_height_162_re;
wire [7:0] pair_cb_robust_peak_height_162_r;
wire [7:0] pair_cb_robust_peak_height_162_w;
wire pair_cb_robust_peak_height_161_re;
wire [7:0] pair_cb_robust_peak_height_161_r;
wire [7:0] pair_cb_robust_peak_height_161_w;
wire pair_cb_robust_peak_height_160_re;
wire [7:0] pair_cb_robust_peak_height_160_r;
wire [7:0] pair_cb_robust_peak_height_160_w;
wire pair_cb_robust_peak_height_173_re;
wire [3:0] pair_cb_robust_peak_height_173_r;
wire [3:0] pair_cb_robust_peak_height_173_w;
wire pair_cb_robust_peak_height_172_re;
wire [7:0] pair_cb_robust_peak_height_172_r;
wire [7:0] pair_cb_robust_peak_height_172_w;
wire pair_cb_robust_peak_height_171_re;
wire [7:0] pair_cb_robust_peak_height_171_r;
wire [7:0] pair_cb_robust_peak_height_171_w;
wire pair_cb_robust_peak_height_170_re;
wire [7:0] pair_cb_robust_peak_height_170_r;
wire [7:0] pair_cb_robust_peak_height_170_w;
wire pair_cb_robust_peak_height_183_re;
wire [3:0] pair_cb_robust_peak_height_183_r;
wire [3:0] pair_cb_robust_peak_height_183_w;
wire pair_cb_robust_peak_height_182_re;
wire [7:0] pair_cb_robust_peak_height_182_r;
wire [7:0] pair_cb_robust_peak_height_182_w;
wire pair_cb_robust_peak_height_181_re;
wire [7:0] pair_cb_robust_peak_height_181_r;
wire [7:0] pair_cb_robust_peak_height_181_w;
wire pair_cb_robust_peak_height_180_re;
wire [7:0] pair_cb_robust_peak_height_180_r;
wire [7:0] pair_cb_robust_peak_height_180_w;
wire pair_cb_robust_peak_height_193_re;
wire [3:0] pair_cb_robust_peak_height_193_r;
wire [3:0] pair_cb_robust_peak_height_193_w;
wire pair_cb_robust_peak_height_192_re;
wire [7:0] pair_cb_robust_peak_height_192_r;
wire [7:0] pair_cb_robust_peak_height_192_w;
wire pair_cb_robust_peak_height_191_re;
wire [7:0] pair_cb_robust_peak_height_191_r;
wire [7:0] pair_cb_robust_peak_height_191_w;
wire pair_cb_robust_peak_height_190_re;
wire [7:0] pair_cb_robust_peak_height_190_r;
wire [7:0] pair_cb_robust_peak_height_190_w;
wire pair_cb_robust_peak_height_203_re;
wire [3:0] pair_cb_robust_peak_height_203_r;
wire [3:0] pair_cb_robust_peak_height_203_w;
wire pair_cb_robust_peak_height_202_re;
wire [7:0] pair_cb_robust_peak_height_202_r;
wire [7:0] pair_cb_robust_peak_height_202_w;
wire pair_cb_robust_peak_height_201_re;
wire [7:0] pair_cb_robust_peak_height_201_r;
wire [7:0] pair_cb_robust_peak_height_201_w;
wire pair_cb_robust_peak_height_200_re;
wire [7:0] pair_cb_robust_peak_height_200_r;
wire [7:0] pair_cb_robust_peak_height_200_w;
wire pair_cb_robust_peak_height_213_re;
wire [3:0] pair_cb_robust_peak_height_213_r;
wire [3:0] pair_cb_robust_peak_height_213_w;
wire pair_cb_robust_peak_height_212_re;
wire [7:0] pair_cb_robust_peak_height_212_r;
wire [7:0] pair_cb_robust_peak_height_212_w;
wire pair_cb_robust_peak_height_211_re;
wire [7:0] pair_cb_robust_peak_height_211_r;
wire [7:0] pair_cb_robust_peak_height_211_w;
wire pair_cb_robust_peak_height_210_re;
wire [7:0] pair_cb_robust_peak_height_210_r;
wire [7:0] pair_cb_robust_peak_height_210_w;
wire pair_cb_robust_peak_height_223_re;
wire [3:0] pair_cb_robust_peak_height_223_r;
wire [3:0] pair_cb_robust_peak_height_223_w;
wire pair_cb_robust_peak_height_222_re;
wire [7:0] pair_cb_robust_peak_height_222_r;
wire [7:0] pair_cb_robust_peak_height_222_w;
wire pair_cb_robust_peak_height_221_re;
wire [7:0] pair_cb_robust_peak_height_221_r;
wire [7:0] pair_cb_robust_peak_height_221_w;
wire pair_cb_robust_peak_height_220_re;
wire [7:0] pair_cb_robust_peak_height_220_r;
wire [7:0] pair_cb_robust_peak_height_220_w;
wire pair_cb_robust_peak_height_233_re;
wire [3:0] pair_cb_robust_peak_height_233_r;
wire [3:0] pair_cb_robust_peak_height_233_w;
wire pair_cb_robust_peak_height_232_re;
wire [7:0] pair_cb_robust_peak_height_232_r;
wire [7:0] pair_cb_robust_peak_height_232_w;
wire pair_cb_robust_peak_height_231_re;
wire [7:0] pair_cb_robust_peak_height_231_r;
wire [7:0] pair_cb_robust_peak_height_231_w;
wire pair_cb_robust_peak_height_230_re;
wire [7:0] pair_cb_robust_peak_height_230_r;
wire [7:0] pair_cb_robust_peak_height_230_w;
wire pair_cb_robust_peak_height_243_re;
wire [3:0] pair_cb_robust_peak_height_243_r;
wire [3:0] pair_cb_robust_peak_height_243_w;
wire pair_cb_robust_peak_height_242_re;
wire [7:0] pair_cb_robust_peak_height_242_r;
wire [7:0] pair_cb_robust_peak_height_242_w;
wire pair_cb_robust_peak_height_241_re;
wire [7:0] pair_cb_robust_peak_height_241_r;
wire [7:0] pair_cb_robust_peak_height_241_w;
wire pair_cb_robust_peak_height_240_re;
wire [7:0] pair_cb_robust_peak_height_240_r;
wire [7:0] pair_cb_robust_peak_height_240_w;
wire pair_cb_robust_peak_height_253_re;
wire [3:0] pair_cb_robust_peak_height_253_r;
wire [3:0] pair_cb_robust_peak_height_253_w;
wire pair_cb_robust_peak_height_252_re;
wire [7:0] pair_cb_robust_peak_height_252_r;
wire [7:0] pair_cb_robust_peak_height_252_w;
wire pair_cb_robust_peak_height_251_re;
wire [7:0] pair_cb_robust_peak_height_251_r;
wire [7:0] pair_cb_robust_peak_height_251_w;
wire pair_cb_robust_peak_height_250_re;
wire [7:0] pair_cb_robust_peak_height_250_r;
wire [7:0] pair_cb_robust_peak_height_250_w;
wire pair_cb_robust_peak_height_263_re;
wire [3:0] pair_cb_robust_peak_height_263_r;
wire [3:0] pair_cb_robust_peak_height_263_w;
wire pair_cb_robust_peak_height_262_re;
wire [7:0] pair_cb_robust_peak_height_262_r;
wire [7:0] pair_cb_robust_peak_height_262_w;
wire pair_cb_robust_peak_height_261_re;
wire [7:0] pair_cb_robust_peak_height_261_r;
wire [7:0] pair_cb_robust_peak_height_261_w;
wire pair_cb_robust_peak_height_260_re;
wire [7:0] pair_cb_robust_peak_height_260_r;
wire [7:0] pair_cb_robust_peak_height_260_w;
wire pair_cb_robust_peak_height_273_re;
wire [3:0] pair_cb_robust_peak_height_273_r;
wire [3:0] pair_cb_robust_peak_height_273_w;
wire pair_cb_robust_peak_height_272_re;
wire [7:0] pair_cb_robust_peak_height_272_r;
wire [7:0] pair_cb_robust_peak_height_272_w;
wire pair_cb_robust_peak_height_271_re;
wire [7:0] pair_cb_robust_peak_height_271_r;
wire [7:0] pair_cb_robust_peak_height_271_w;
wire pair_cb_robust_peak_height_270_re;
wire [7:0] pair_cb_robust_peak_height_270_r;
wire [7:0] pair_cb_robust_peak_height_270_w;
wire pair_cb_robust_peak_height_283_re;
wire [3:0] pair_cb_robust_peak_height_283_r;
wire [3:0] pair_cb_robust_peak_height_283_w;
wire pair_cb_robust_peak_height_282_re;
wire [7:0] pair_cb_robust_peak_height_282_r;
wire [7:0] pair_cb_robust_peak_height_282_w;
wire pair_cb_robust_peak_height_281_re;
wire [7:0] pair_cb_robust_peak_height_281_r;
wire [7:0] pair_cb_robust_peak_height_281_w;
wire pair_cb_robust_peak_height_280_re;
wire [7:0] pair_cb_robust_peak_height_280_r;
wire [7:0] pair_cb_robust_peak_height_280_w;
wire pair_cb_robust_peak_height_293_re;
wire [3:0] pair_cb_robust_peak_height_293_r;
wire [3:0] pair_cb_robust_peak_height_293_w;
wire pair_cb_robust_peak_height_292_re;
wire [7:0] pair_cb_robust_peak_height_292_r;
wire [7:0] pair_cb_robust_peak_height_292_w;
wire pair_cb_robust_peak_height_291_re;
wire [7:0] pair_cb_robust_peak_height_291_r;
wire [7:0] pair_cb_robust_peak_height_291_w;
wire pair_cb_robust_peak_height_290_re;
wire [7:0] pair_cb_robust_peak_height_290_r;
wire [7:0] pair_cb_robust_peak_height_290_w;
wire pair_cb_robust_peak_height_303_re;
wire [3:0] pair_cb_robust_peak_height_303_r;
wire [3:0] pair_cb_robust_peak_height_303_w;
wire pair_cb_robust_peak_height_302_re;
wire [7:0] pair_cb_robust_peak_height_302_r;
wire [7:0] pair_cb_robust_peak_height_302_w;
wire pair_cb_robust_peak_height_301_re;
wire [7:0] pair_cb_robust_peak_height_301_r;
wire [7:0] pair_cb_robust_peak_height_301_w;
wire pair_cb_robust_peak_height_300_re;
wire [7:0] pair_cb_robust_peak_height_300_r;
wire [7:0] pair_cb_robust_peak_height_300_w;
wire pair_cb_robust_peak_height_313_re;
wire [3:0] pair_cb_robust_peak_height_313_r;
wire [3:0] pair_cb_robust_peak_height_313_w;
wire pair_cb_robust_peak_height_312_re;
wire [7:0] pair_cb_robust_peak_height_312_r;
wire [7:0] pair_cb_robust_peak_height_312_w;
wire pair_cb_robust_peak_height_311_re;
wire [7:0] pair_cb_robust_peak_height_311_r;
wire [7:0] pair_cb_robust_peak_height_311_w;
wire pair_cb_robust_peak_height_310_re;
wire [7:0] pair_cb_robust_peak_height_310_r;
wire [7:0] pair_cb_robust_peak_height_310_w;
wire pair_cb_robust_wait_for_01_re;
wire [5:0] pair_cb_robust_wait_for_01_r;
wire [5:0] pair_cb_robust_wait_for_01_w;
wire pair_cb_robust_wait_for_00_re;
wire [7:0] pair_cb_robust_wait_for_00_r;
wire [7:0] pair_cb_robust_wait_for_00_w;
wire pair_cb_robust_wait_for_11_re;
wire [5:0] pair_cb_robust_wait_for_11_r;
wire [5:0] pair_cb_robust_wait_for_11_w;
wire pair_cb_robust_wait_for_10_re;
wire [7:0] pair_cb_robust_wait_for_10_r;
wire [7:0] pair_cb_robust_wait_for_10_w;
wire pair_cb_robust_wait_for_21_re;
wire [5:0] pair_cb_robust_wait_for_21_r;
wire [5:0] pair_cb_robust_wait_for_21_w;
wire pair_cb_robust_wait_for_20_re;
wire [7:0] pair_cb_robust_wait_for_20_r;
wire [7:0] pair_cb_robust_wait_for_20_w;
wire pair_cb_robust_wait_for_31_re;
wire [5:0] pair_cb_robust_wait_for_31_r;
wire [5:0] pair_cb_robust_wait_for_31_w;
wire pair_cb_robust_wait_for_30_re;
wire [7:0] pair_cb_robust_wait_for_30_r;
wire [7:0] pair_cb_robust_wait_for_30_w;
wire pair_cb_robust_wait_for_41_re;
wire [5:0] pair_cb_robust_wait_for_41_r;
wire [5:0] pair_cb_robust_wait_for_41_w;
wire pair_cb_robust_wait_for_40_re;
wire [7:0] pair_cb_robust_wait_for_40_r;
wire [7:0] pair_cb_robust_wait_for_40_w;
wire pair_cb_robust_wait_for_51_re;
wire [5:0] pair_cb_robust_wait_for_51_r;
wire [5:0] pair_cb_robust_wait_for_51_w;
wire pair_cb_robust_wait_for_50_re;
wire [7:0] pair_cb_robust_wait_for_50_r;
wire [7:0] pair_cb_robust_wait_for_50_w;
wire pair_cb_robust_wait_for_61_re;
wire [5:0] pair_cb_robust_wait_for_61_r;
wire [5:0] pair_cb_robust_wait_for_61_w;
wire pair_cb_robust_wait_for_60_re;
wire [7:0] pair_cb_robust_wait_for_60_r;
wire [7:0] pair_cb_robust_wait_for_60_w;
wire pair_cb_robust_wait_for_71_re;
wire [5:0] pair_cb_robust_wait_for_71_r;
wire [5:0] pair_cb_robust_wait_for_71_w;
wire pair_cb_robust_wait_for_70_re;
wire [7:0] pair_cb_robust_wait_for_70_r;
wire [7:0] pair_cb_robust_wait_for_70_w;
wire pair_cb_robust_wait_for_81_re;
wire [5:0] pair_cb_robust_wait_for_81_r;
wire [5:0] pair_cb_robust_wait_for_81_w;
wire pair_cb_robust_wait_for_80_re;
wire [7:0] pair_cb_robust_wait_for_80_r;
wire [7:0] pair_cb_robust_wait_for_80_w;
wire pair_cb_robust_wait_for_91_re;
wire [5:0] pair_cb_robust_wait_for_91_r;
wire [5:0] pair_cb_robust_wait_for_91_w;
wire pair_cb_robust_wait_for_90_re;
wire [7:0] pair_cb_robust_wait_for_90_r;
wire [7:0] pair_cb_robust_wait_for_90_w;
wire pair_cb_robust_wait_for_101_re;
wire [5:0] pair_cb_robust_wait_for_101_r;
wire [5:0] pair_cb_robust_wait_for_101_w;
wire pair_cb_robust_wait_for_100_re;
wire [7:0] pair_cb_robust_wait_for_100_r;
wire [7:0] pair_cb_robust_wait_for_100_w;
wire pair_cb_robust_wait_for_111_re;
wire [5:0] pair_cb_robust_wait_for_111_r;
wire [5:0] pair_cb_robust_wait_for_111_w;
wire pair_cb_robust_wait_for_110_re;
wire [7:0] pair_cb_robust_wait_for_110_r;
wire [7:0] pair_cb_robust_wait_for_110_w;
wire pair_cb_robust_wait_for_121_re;
wire [5:0] pair_cb_robust_wait_for_121_r;
wire [5:0] pair_cb_robust_wait_for_121_w;
wire pair_cb_robust_wait_for_120_re;
wire [7:0] pair_cb_robust_wait_for_120_r;
wire [7:0] pair_cb_robust_wait_for_120_w;
wire pair_cb_robust_wait_for_131_re;
wire [5:0] pair_cb_robust_wait_for_131_r;
wire [5:0] pair_cb_robust_wait_for_131_w;
wire pair_cb_robust_wait_for_130_re;
wire [7:0] pair_cb_robust_wait_for_130_r;
wire [7:0] pair_cb_robust_wait_for_130_w;
wire pair_cb_robust_wait_for_141_re;
wire [5:0] pair_cb_robust_wait_for_141_r;
wire [5:0] pair_cb_robust_wait_for_141_w;
wire pair_cb_robust_wait_for_140_re;
wire [7:0] pair_cb_robust_wait_for_140_r;
wire [7:0] pair_cb_robust_wait_for_140_w;
wire pair_cb_robust_wait_for_151_re;
wire [5:0] pair_cb_robust_wait_for_151_r;
wire [5:0] pair_cb_robust_wait_for_151_w;
wire pair_cb_robust_wait_for_150_re;
wire [7:0] pair_cb_robust_wait_for_150_r;
wire [7:0] pair_cb_robust_wait_for_150_w;
wire pair_cb_robust_wait_for_161_re;
wire [5:0] pair_cb_robust_wait_for_161_r;
wire [5:0] pair_cb_robust_wait_for_161_w;
wire pair_cb_robust_wait_for_160_re;
wire [7:0] pair_cb_robust_wait_for_160_r;
wire [7:0] pair_cb_robust_wait_for_160_w;
wire pair_cb_robust_wait_for_171_re;
wire [5:0] pair_cb_robust_wait_for_171_r;
wire [5:0] pair_cb_robust_wait_for_171_w;
wire pair_cb_robust_wait_for_170_re;
wire [7:0] pair_cb_robust_wait_for_170_r;
wire [7:0] pair_cb_robust_wait_for_170_w;
wire pair_cb_robust_wait_for_181_re;
wire [5:0] pair_cb_robust_wait_for_181_r;
wire [5:0] pair_cb_robust_wait_for_181_w;
wire pair_cb_robust_wait_for_180_re;
wire [7:0] pair_cb_robust_wait_for_180_r;
wire [7:0] pair_cb_robust_wait_for_180_w;
wire pair_cb_robust_wait_for_191_re;
wire [5:0] pair_cb_robust_wait_for_191_r;
wire [5:0] pair_cb_robust_wait_for_191_w;
wire pair_cb_robust_wait_for_190_re;
wire [7:0] pair_cb_robust_wait_for_190_r;
wire [7:0] pair_cb_robust_wait_for_190_w;
wire pair_cb_robust_wait_for_201_re;
wire [5:0] pair_cb_robust_wait_for_201_r;
wire [5:0] pair_cb_robust_wait_for_201_w;
wire pair_cb_robust_wait_for_200_re;
wire [7:0] pair_cb_robust_wait_for_200_r;
wire [7:0] pair_cb_robust_wait_for_200_w;
wire pair_cb_robust_wait_for_211_re;
wire [5:0] pair_cb_robust_wait_for_211_r;
wire [5:0] pair_cb_robust_wait_for_211_w;
wire pair_cb_robust_wait_for_210_re;
wire [7:0] pair_cb_robust_wait_for_210_r;
wire [7:0] pair_cb_robust_wait_for_210_w;
wire pair_cb_robust_wait_for_221_re;
wire [5:0] pair_cb_robust_wait_for_221_r;
wire [5:0] pair_cb_robust_wait_for_221_w;
wire pair_cb_robust_wait_for_220_re;
wire [7:0] pair_cb_robust_wait_for_220_r;
wire [7:0] pair_cb_robust_wait_for_220_w;
wire pair_cb_robust_wait_for_231_re;
wire [5:0] pair_cb_robust_wait_for_231_r;
wire [5:0] pair_cb_robust_wait_for_231_w;
wire pair_cb_robust_wait_for_230_re;
wire [7:0] pair_cb_robust_wait_for_230_r;
wire [7:0] pair_cb_robust_wait_for_230_w;
wire pair_cb_robust_wait_for_241_re;
wire [5:0] pair_cb_robust_wait_for_241_r;
wire [5:0] pair_cb_robust_wait_for_241_w;
wire pair_cb_robust_wait_for_240_re;
wire [7:0] pair_cb_robust_wait_for_240_r;
wire [7:0] pair_cb_robust_wait_for_240_w;
wire pair_cb_robust_wait_for_251_re;
wire [5:0] pair_cb_robust_wait_for_251_r;
wire [5:0] pair_cb_robust_wait_for_251_w;
wire pair_cb_robust_wait_for_250_re;
wire [7:0] pair_cb_robust_wait_for_250_r;
wire [7:0] pair_cb_robust_wait_for_250_w;
wire pair_cb_robust_wait_for_261_re;
wire [5:0] pair_cb_robust_wait_for_261_r;
wire [5:0] pair_cb_robust_wait_for_261_w;
wire pair_cb_robust_wait_for_260_re;
wire [7:0] pair_cb_robust_wait_for_260_r;
wire [7:0] pair_cb_robust_wait_for_260_w;
wire pair_cb_robust_wait_for_271_re;
wire [5:0] pair_cb_robust_wait_for_271_r;
wire [5:0] pair_cb_robust_wait_for_271_w;
wire pair_cb_robust_wait_for_270_re;
wire [7:0] pair_cb_robust_wait_for_270_r;
wire [7:0] pair_cb_robust_wait_for_270_w;
wire pair_cb_robust_wait_for_281_re;
wire [5:0] pair_cb_robust_wait_for_281_r;
wire [5:0] pair_cb_robust_wait_for_281_w;
wire pair_cb_robust_wait_for_280_re;
wire [7:0] pair_cb_robust_wait_for_280_r;
wire [7:0] pair_cb_robust_wait_for_280_w;
wire pair_cb_robust_wait_for_291_re;
wire [5:0] pair_cb_robust_wait_for_291_r;
wire [5:0] pair_cb_robust_wait_for_291_w;
wire pair_cb_robust_wait_for_290_re;
wire [7:0] pair_cb_robust_wait_for_290_r;
wire [7:0] pair_cb_robust_wait_for_290_w;
wire pair_cb_robust_wait_for_301_re;
wire [5:0] pair_cb_robust_wait_for_301_r;
wire [5:0] pair_cb_robust_wait_for_301_w;
wire pair_cb_robust_wait_for_300_re;
wire [7:0] pair_cb_robust_wait_for_300_r;
wire [7:0] pair_cb_robust_wait_for_300_w;
wire pair_cb_robust_wait_for_311_re;
wire [5:0] pair_cb_robust_wait_for_311_r;
wire [5:0] pair_cb_robust_wait_for_311_w;
wire pair_cb_robust_wait_for_310_re;
wire [7:0] pair_cb_robust_wait_for_310_r;
wire [7:0] pair_cb_robust_wait_for_310_w;
wire pair_cb_fast_target_position1_re;
wire [5:0] pair_cb_fast_target_position1_r;
wire [5:0] pair_cb_fast_target_position1_w;
wire pair_cb_fast_target_position0_re;
wire [7:0] pair_cb_fast_target_position0_r;
wire [7:0] pair_cb_fast_target_position0_w;
wire pair_cb_request_lock0_re;
wire pair_cb_request_lock0_r;
wire pair_cb_request_lock0_w;
wire pair_cb_autolock_mode0_re;
wire [1:0] pair_cb_autolock_mode0_r;
wire [1:0] pair_cb_autolock_mode0_w;
wire pair_cb_lock_running_re;
wire pair_cb_lock_running_r;
wire pair_cb_lock_running_w;
wire pair_cb_sel;
reg signed [27:0] pair_pair0 = 28'sd0;
reg [12:0] pair_pair1 = 13'd0;
reg [12:0] pair_pair_q = 13'd1;
reg signed [28:0] pair_pair2 = 29'sd0;
reg [27:0] array_muxed0;
reg [13:0] array_muxed1;
reg [27:0] array_muxed2;
reg [13:0] array_muxed3;
reg signed [27:0] array_muxed4;
reg array_muxed5;
reg signed [28:0] array_muxed6;
reg signed [27:0] array_muxed7;
reg signed [28:0] array_muxed8;
reg signed [27:0] array_muxed9;
reg signed [28:0] array_muxed10;
reg signed [27:0] array_muxed11;
reg signed [28:0] array_muxed12;
reg signed [27:0] array_muxed13;
reg signed [28:0] array_muxed14;
reg signed [27:0] array_muxed15;
reg signed [28:0] array_muxed16;
reg signed [27:0] array_muxed17;
reg signed [28:0] array_muxed18;
reg signed [27:0] array_muxed19;
reg signed [28:0] array_muxed20;
reg signed [27:0] array_muxed21;
reg signed [28:0] array_muxed22;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign pair_reference_robust_public0 = data;
assign pair_reference_robust_public2 = at_start;
assign pair_reference_robust_public3 = writing;
assign pair_reference_robust_public4 = sweep_up;
assign pair_reference_fast_sweep_value = data;
assign pair_reference_fast_sweep_up = sweep_up;
assign pair_reference_fast_sweep_step = 4'd8;
assign pair_rb_bus_adr = csr_adr;
assign pair_rb_bus_we = csr_we;
assign pair_rb_bus_dat_w = csr_dat_w;
assign ref_obs = {pair_reference_status, pair_reference_robust_output0, pair_reference_robust_counter_delayed, pair_reference_robust_counter, pair_reference_robust_sum_value, pair_reference_robust_waited_long_enough, pair_reference_robust_over_threshold, pair_reference_robust_sign_equal, pair_reference_robust_turn_on_lock, pair_reference_robust_watching, pair_reference_robust_current_instruction_idx};
assign ref_cfg = {pair_reference_fast_storage, pair_reference_autolock_mode_storage, pair_reference_request_lock_storage, pair_reference_robust_csrstorage66_storage, pair_reference_robust_csrstorage65_storage, pair_reference_robust_csrstorage64_storage, pair_reference_robust_csrstorage63_storage, pair_reference_robust_csrstorage62_storage, pair_reference_robust_csrstorage61_storage, pair_reference_robust_csrstorage60_storage, pair_reference_robust_csrstorage59_storage, pair_reference_robust_csrstorage58_storage, pair_reference_robust_csrstorage57_storage, pair_reference_robust_csrstorage56_storage, pair_reference_robust_csrstorage55_storage, pair_reference_robust_csrstorage54_storage, pair_reference_robust_csrstorage53_storage, pair_reference_robust_csrstorage52_storage, pair_reference_robust_csrstorage51_storage, pair_reference_robust_csrstorage50_storage, pair_reference_robust_csrstorage49_storage, pair_reference_robust_csrstorage48_storage, pair_reference_robust_csrstorage47_storage, pair_reference_robust_csrstorage46_storage, pair_reference_robust_csrstorage45_storage, pair_reference_robust_csrstorage44_storage, pair_reference_robust_csrstorage43_storage, pair_reference_robust_csrstorage42_storage, pair_reference_robust_csrstorage41_storage, pair_reference_robust_csrstorage40_storage, pair_reference_robust_csrstorage39_storage, pair_reference_robust_csrstorage38_storage, pair_reference_robust_csrstorage37_storage, pair_reference_robust_csrstorage36_storage, pair_reference_robust_csrstorage35_storage, pair_reference_robust_csrstorage34_storage, pair_reference_robust_csrstorage33_storage, pair_reference_robust_csrstorage32_storage, pair_reference_robust_csrstorage31_storage, pair_reference_robust_csrstorage30_storage, pair_reference_robust_csrstorage29_storage, pair_reference_robust_csrstorage28_storage, pair_reference_robust_csrstorage27_storage, pair_reference_robust_csrstorage26_storage, pair_reference_robust_csrstorage25_storage, pair_reference_robust_csrstorage24_storage, pair_reference_robust_csrstorage23_storage, pair_reference_robust_csrstorage22_storage, pair_reference_robust_csrstorage21_storage, pair_reference_robust_csrstorage20_storage, pair_reference_robust_csrstorage19_storage, pair_reference_robust_csrstorage18_storage, pair_reference_robust_csrstorage17_storage, pair_reference_robust_csrstorage16_storage, pair_reference_robust_csrstorage15_storage, pair_reference_robust_csrstorage14_storage, pair_reference_robust_csrstorage13_storage, pair_reference_robust_csrstorage12_storage, pair_reference_robust_csrstorage11_storage, pair_reference_robust_csrstorage10_storage, pair_reference_robust_csrstorage9_storage, pair_reference_robust_csrstorage8_storage, pair_reference_robust_csrstorage7_storage, pair_reference_robust_csrstorage6_storage, pair_reference_robust_csrstorage5_storage, pair_reference_robust_csrstorage4_storage, pair_reference_robust_csrstorage3_storage, pair_reference_robust_csrstorage2_storage, pair_reference_robust_csrstorage1_storage, pair_reference_robust_csrstorage0_storage};
assign ref_read = pair_rb_bus_dat_r;
assign ref_idx = pair_reference_robust_current_instruction_idx;
assign ref_watch = pair_reference_robust_watching;
assign ref_turn = pair_reference_status;
assign pair_candidate_pipelinedrobustautolock_input2 = data;
assign pair_candidate_pipelinedrobustautolock_at_start = at_start;
assign pair_candidate_pipelinedrobustautolock_writing_data_now2 = writing;
assign pair_candidate_pipelinedrobustautolock_sweep_up = sweep_up;
assign pair_candidate_fast_sweep_value = data;
assign pair_candidate_fast_sweep_up = sweep_up;
assign pair_candidate_fast_sweep_step = 4'd8;
assign pair_cb_bus_adr = csr_adr;
assign pair_cb_bus_we = csr_we;
assign pair_cb_bus_dat_w = csr_dat_w;
assign cand_obs = {pair_candidate_status, pair_pair2, pair_pair_q, pair_pair1, pair_pair0, pair_candidate_pipelinedrobustautolock_waited_long_enough, pair_candidate_pipelinedrobustautolock_over_threshold, pair_candidate_pipelinedrobustautolock_sign_equal, pair_candidate_pipelinedrobustautolock_turn_on_lock, pair_candidate_pipelinedrobustautolock_watching, pair_candidate_pipelinedrobustautolock_current_instruction_idx};
assign cand_cfg = {pair_candidate_fast_storage, pair_candidate_autolock_mode_storage, pair_candidate_request_lock_storage, pair_candidate_pipelinedrobustautolock_csrstorage63_storage, pair_candidate_pipelinedrobustautolock_csrstorage62_storage, pair_candidate_pipelinedrobustautolock_csrstorage61_storage, pair_candidate_pipelinedrobustautolock_csrstorage60_storage, pair_candidate_pipelinedrobustautolock_csrstorage59_storage, pair_candidate_pipelinedrobustautolock_csrstorage58_storage, pair_candidate_pipelinedrobustautolock_csrstorage57_storage, pair_candidate_pipelinedrobustautolock_csrstorage56_storage, pair_candidate_pipelinedrobustautolock_csrstorage55_storage, pair_candidate_pipelinedrobustautolock_csrstorage54_storage, pair_candidate_pipelinedrobustautolock_csrstorage53_storage, pair_candidate_pipelinedrobustautolock_csrstorage52_storage, pair_candidate_pipelinedrobustautolock_csrstorage51_storage, pair_candidate_pipelinedrobustautolock_csrstorage50_storage, pair_candidate_pipelinedrobustautolock_csrstorage49_storage, pair_candidate_pipelinedrobustautolock_csrstorage48_storage, pair_candidate_pipelinedrobustautolock_csrstorage47_storage, pair_candidate_pipelinedrobustautolock_csrstorage46_storage, pair_candidate_pipelinedrobustautolock_csrstorage45_storage, pair_candidate_pipelinedrobustautolock_csrstorage44_storage, pair_candidate_pipelinedrobustautolock_csrstorage43_storage, pair_candidate_pipelinedrobustautolock_csrstorage42_storage, pair_candidate_pipelinedrobustautolock_csrstorage41_storage, pair_candidate_pipelinedrobustautolock_csrstorage40_storage, pair_candidate_pipelinedrobustautolock_csrstorage39_storage, pair_candidate_pipelinedrobustautolock_csrstorage38_storage, pair_candidate_pipelinedrobustautolock_csrstorage37_storage, pair_candidate_pipelinedrobustautolock_csrstorage36_storage, pair_candidate_pipelinedrobustautolock_csrstorage35_storage, pair_candidate_pipelinedrobustautolock_csrstorage34_storage, pair_candidate_pipelinedrobustautolock_csrstorage33_storage, pair_candidate_pipelinedrobustautolock_csrstorage32_storage, pair_candidate_pipelinedrobustautolock_csrstorage31_storage, pair_candidate_pipelinedrobustautolock_csrstorage30_storage, pair_candidate_pipelinedrobustautolock_csrstorage29_storage, pair_candidate_pipelinedrobustautolock_csrstorage28_storage, pair_candidate_pipelinedrobustautolock_csrstorage27_storage, pair_candidate_pipelinedrobustautolock_csrstorage26_storage, pair_candidate_pipelinedrobustautolock_csrstorage25_storage, pair_candidate_pipelinedrobustautolock_csrstorage24_storage, pair_candidate_pipelinedrobustautolock_csrstorage23_storage, pair_candidate_pipelinedrobustautolock_csrstorage22_storage, pair_candidate_pipelinedrobustautolock_csrstorage21_storage, pair_candidate_pipelinedrobustautolock_csrstorage20_storage, pair_candidate_pipelinedrobustautolock_csrstorage19_storage, pair_candidate_pipelinedrobustautolock_csrstorage18_storage, pair_candidate_pipelinedrobustautolock_csrstorage17_storage, pair_candidate_pipelinedrobustautolock_csrstorage16_storage, pair_candidate_pipelinedrobustautolock_csrstorage15_storage, pair_candidate_pipelinedrobustautolock_csrstorage14_storage, pair_candidate_pipelinedrobustautolock_csrstorage13_storage, pair_candidate_pipelinedrobustautolock_csrstorage12_storage, pair_candidate_pipelinedrobustautolock_csrstorage11_storage, pair_candidate_pipelinedrobustautolock_csrstorage10_storage, pair_candidate_pipelinedrobustautolock_csrstorage9_storage, pair_candidate_pipelinedrobustautolock_csrstorage8_storage, pair_candidate_pipelinedrobustautolock_csrstorage7_storage, pair_candidate_pipelinedrobustautolock_csrstorage6_storage, pair_candidate_pipelinedrobustautolock_csrstorage5_storage, pair_candidate_pipelinedrobustautolock_csrstorage4_storage, pair_candidate_pipelinedrobustautolock_csrstorage3_storage, pair_candidate_pipelinedrobustautolock_csrstorage2_storage, pair_candidate_pipelinedrobustautolock_csrstorage1_storage, pair_candidate_pipelinedrobustautolock_csrstorage0_storage, pair_candidate_pipelinedrobustautolock_final_wait_time_storage, pair_candidate_pipelinedrobustautolock_N_instructions_storage, pair_candidate_pipelinedrobustautolock_time_scale_storage};
assign cand_read = pair_cb_bus_dat_r;
assign cand_idx = pair_candidate_pipelinedrobustautolock_current_instruction_idx;
assign cand_watch = pair_candidate_pipelinedrobustautolock_watching;
assign cand_turn = pair_candidate_status;
assign pair_reference_fast_request_lock = pair_reference_request_lock_storage;
assign pair_reference_robust_public1 = pair_reference_request_lock_storage;
assign pair_reference_robust_current_peak_height = array_muxed0;
assign pair_reference_robust_current_wait_for = array_muxed1;
assign pair_reference_robust_writing_data_now0 = pair_reference_robust_writing_data_now2;
assign pair_reference_robust_restart0 = pair_reference_robust_at_start;
assign pair_reference_robust_input0 = pair_reference_robust_input2;
assign pair_reference_robust_delay_value = pair_reference_robust_time_scale_storage;
assign pair_reference_robust_sum_diff = pair_reference_robust_output0;
assign pair_reference_robust_sign_equal = ((pair_reference_robust_sum_diff > $signed({1'd0, 1'd0})) == (pair_reference_robust_current_peak_height > $signed({1'd0, 1'd0})));

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	pair_reference_robust_abs_sum_diff <= 29'sd0;
	if ((pair_reference_robust_sum_diff >= $signed({1'd0, 1'd0}))) begin
		pair_reference_robust_abs_sum_diff <= pair_reference_robust_sum_diff;
	end else begin
		pair_reference_robust_abs_sum_diff <= (1'sd1 * pair_reference_robust_sum_diff);
	end
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_1;
// synthesis translate_on
always @(*) begin
	pair_reference_robust_abs_current_peak_height <= 28'sd0;
	if ((pair_reference_robust_current_peak_height >= $signed({1'd0, 1'd0}))) begin
		pair_reference_robust_abs_current_peak_height <= pair_reference_robust_current_peak_height;
	end else begin
		pair_reference_robust_abs_current_peak_height <= (1'sd1 * pair_reference_robust_current_peak_height);
	end
// synthesis translate_off
	dummy_d_1 <= dummy_s;
// synthesis translate_on
end
assign pair_reference_robust_over_threshold = (pair_reference_robust_abs_sum_diff >= pair_reference_robust_abs_current_peak_height);
assign pair_reference_robust_waited_long_enough = (pair_reference_robust_waited_for > pair_reference_robust_current_wait_for);
assign pair_reference_robust_all_instructions_triggered = (pair_reference_robust_current_instruction_idx >= pair_reference_robust_N_instructions_storage);
assign pair_reference_robust_turn_on_lock = (pair_reference_robust_all_instructions_triggered & (pair_reference_robust_final_waited_for >= pair_reference_robust_final_wait_time_storage));
assign pair_reference_robust_input2 = pair_reference_robust_q0;
assign pair_reference_robust_request_lock = pair_reference_robust_q1;
assign pair_reference_robust_at_start = pair_reference_robust_q2;
assign pair_reference_robust_writing_data_now2 = pair_reference_robust_q3;
assign pair_reference_robust_sweep_up = pair_reference_robust_q4;
assign pair_reference_robust_time_scale_storage = pair_reference_robust_q5;
assign pair_reference_robust_N_instructions_storage = pair_reference_robust_q6;
assign pair_reference_robust_final_wait_time_storage = pair_reference_robust_q7;
assign pair_reference_robust_csrstorage_storage0 = pair_reference_robust_q8;
assign pair_reference_robust_csrstorage_storage1 = pair_reference_robust_q9;
assign pair_reference_robust_csrstorage_storage2 = pair_reference_robust_q10;
assign pair_reference_robust_csrstorage_storage3 = pair_reference_robust_q11;
assign pair_reference_robust_csrstorage_storage4 = pair_reference_robust_q12;
assign pair_reference_robust_csrstorage_storage5 = pair_reference_robust_q13;
assign pair_reference_robust_csrstorage_storage6 = pair_reference_robust_q14;
assign pair_reference_robust_csrstorage_storage7 = pair_reference_robust_q15;
assign pair_reference_robust_csrstorage_storage8 = pair_reference_robust_q16;
assign pair_reference_robust_csrstorage_storage9 = pair_reference_robust_q17;
assign pair_reference_robust_csrstorage_storage10 = pair_reference_robust_q18;
assign pair_reference_robust_csrstorage_storage11 = pair_reference_robust_q19;
assign pair_reference_robust_csrstorage_storage12 = pair_reference_robust_q20;
assign pair_reference_robust_csrstorage_storage13 = pair_reference_robust_q21;
assign pair_reference_robust_csrstorage_storage14 = pair_reference_robust_q22;
assign pair_reference_robust_csrstorage_storage15 = pair_reference_robust_q23;
assign pair_reference_robust_csrstorage_storage16 = pair_reference_robust_q24;
assign pair_reference_robust_csrstorage_storage17 = pair_reference_robust_q25;
assign pair_reference_robust_csrstorage_storage18 = pair_reference_robust_q26;
assign pair_reference_robust_csrstorage_storage19 = pair_reference_robust_q27;
assign pair_reference_robust_csrstorage_storage20 = pair_reference_robust_q28;
assign pair_reference_robust_csrstorage_storage21 = pair_reference_robust_q29;
assign pair_reference_robust_csrstorage_storage22 = pair_reference_robust_q30;
assign pair_reference_robust_csrstorage_storage23 = pair_reference_robust_q31;
assign pair_reference_robust_csrstorage_storage24 = pair_reference_robust_q32;
assign pair_reference_robust_csrstorage_storage25 = pair_reference_robust_q33;
assign pair_reference_robust_csrstorage_storage26 = pair_reference_robust_q34;
assign pair_reference_robust_csrstorage_storage27 = pair_reference_robust_q35;
assign pair_reference_robust_csrstorage_storage28 = pair_reference_robust_q36;
assign pair_reference_robust_csrstorage_storage29 = pair_reference_robust_q37;
assign pair_reference_robust_csrstorage_storage30 = pair_reference_robust_q38;
assign pair_reference_robust_csrstorage_storage31 = pair_reference_robust_q39;
assign pair_reference_robust_csrstorage_storage32 = pair_reference_robust_q40;
assign pair_reference_robust_csrstorage_storage33 = pair_reference_robust_q41;
assign pair_reference_robust_csrstorage_storage34 = pair_reference_robust_q42;
assign pair_reference_robust_csrstorage_storage35 = pair_reference_robust_q43;
assign pair_reference_robust_csrstorage_storage36 = pair_reference_robust_q44;
assign pair_reference_robust_csrstorage_storage37 = pair_reference_robust_q45;
assign pair_reference_robust_csrstorage_storage38 = pair_reference_robust_q46;
assign pair_reference_robust_csrstorage_storage39 = pair_reference_robust_q47;
assign pair_reference_robust_csrstorage_storage40 = pair_reference_robust_q48;
assign pair_reference_robust_csrstorage_storage41 = pair_reference_robust_q49;
assign pair_reference_robust_csrstorage_storage42 = pair_reference_robust_q50;
assign pair_reference_robust_csrstorage_storage43 = pair_reference_robust_q51;
assign pair_reference_robust_csrstorage_storage44 = pair_reference_robust_q52;
assign pair_reference_robust_csrstorage_storage45 = pair_reference_robust_q53;
assign pair_reference_robust_csrstorage_storage46 = pair_reference_robust_q54;
assign pair_reference_robust_csrstorage_storage47 = pair_reference_robust_q55;
assign pair_reference_robust_csrstorage_storage48 = pair_reference_robust_q56;
assign pair_reference_robust_csrstorage_storage49 = pair_reference_robust_q57;
assign pair_reference_robust_csrstorage_storage50 = pair_reference_robust_q58;
assign pair_reference_robust_csrstorage_storage51 = pair_reference_robust_q59;
assign pair_reference_robust_csrstorage_storage52 = pair_reference_robust_q60;
assign pair_reference_robust_csrstorage_storage53 = pair_reference_robust_q61;
assign pair_reference_robust_csrstorage_storage54 = pair_reference_robust_q62;
assign pair_reference_robust_csrstorage_storage55 = pair_reference_robust_q63;
assign pair_reference_robust_csrstorage_storage56 = pair_reference_robust_q64;
assign pair_reference_robust_csrstorage_storage57 = pair_reference_robust_q65;
assign pair_reference_robust_csrstorage_storage58 = pair_reference_robust_q66;
assign pair_reference_robust_csrstorage_storage59 = pair_reference_robust_q67;
assign pair_reference_robust_csrstorage_storage60 = pair_reference_robust_q68;
assign pair_reference_robust_csrstorage_storage61 = pair_reference_robust_q69;
assign pair_reference_robust_csrstorage_storage62 = pair_reference_robust_q70;
assign pair_reference_robust_csrstorage_storage63 = pair_reference_robust_q71;
assign pair_reference_robust_writing_data_now1 = pair_reference_robust_writing_data_now0;
assign pair_reference_robust_restart1 = pair_reference_robust_restart0;
assign pair_reference_robust_delay = pair_reference_robust_delay_value;
assign pair_reference_robust_input1 = pair_reference_robust_sum_value;
assign pair_reference_robust_delayed_sum = pair_reference_robust_output1;
assign pair_reference_robust_current_sum_diff = (pair_reference_robust_sum_value - pair_reference_robust_delayed_sum);
assign pair_reference_robust_output0 = pair_reference_robust_current_sum_diff;
assign pair_reference_robust_wrport_we = pair_reference_robust_writing_data_now1;
assign pair_reference_robust_wrport_adr = pair_reference_robust_counter;
assign pair_reference_robust_wrport_dat_w = pair_reference_robust_input1;
assign pair_reference_robust_counter_delayed = ((pair_reference_robust_counter - pair_reference_robust_delay) + 1'd1);

// synthesis translate_off
reg dummy_d_2;
// synthesis translate_on
always @(*) begin
	pair_reference_robust_rdport_adr <= 13'd0;
	pair_reference_robust_rdport_adr <= pair_reference_robust_counter_delayed;
	pair_reference_robust_rdport_adr <= pair_reference_robust_counter_delayed;
// synthesis translate_off
	dummy_d_2 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_3;
// synthesis translate_on
always @(*) begin
	pair_reference_robust_output1 <= 28'sd0;
	if ((pair_reference_robust_counter < (pair_reference_robust_delay - 1'd1))) begin
		pair_reference_robust_output1 <= 1'd0;
	end else begin
		pair_reference_robust_output1 <= pair_reference_robust_rdport_dat_r;
	end
// synthesis translate_off
	dummy_d_3 <= dummy_s;
// synthesis translate_on
end
assign pair_reference_fast_target_position_signed = pair_reference_fast_storage;
assign pair_candidate_fast_request_lock = pair_candidate_request_lock_storage;
assign pair_candidate_pipelinedrobustautolock_request_lock = pair_candidate_request_lock_storage;
assign pair_candidate_pipelinedrobustautolock_signed_height0 = pair_candidate_pipelinedrobustautolock_csrstorage0_storage;

// synthesis translate_off
reg dummy_d_4;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next0 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height0 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next0 <= pair_candidate_pipelinedrobustautolock_signed_height0;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next0 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height0);
	end
// synthesis translate_off
	dummy_d_4 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended0 = pair_candidate_pipelinedrobustautolock_abs_next0;
assign pair_candidate_pipelinedrobustautolock_signed_height1 = pair_candidate_pipelinedrobustautolock_csrstorage1_storage;

// synthesis translate_off
reg dummy_d_5;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next1 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height1 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next1 <= pair_candidate_pipelinedrobustautolock_signed_height1;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next1 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height1);
	end
// synthesis translate_off
	dummy_d_5 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended1 = pair_candidate_pipelinedrobustautolock_abs_next1;
assign pair_candidate_pipelinedrobustautolock_signed_height2 = pair_candidate_pipelinedrobustautolock_csrstorage2_storage;

// synthesis translate_off
reg dummy_d_6;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next2 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height2 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next2 <= pair_candidate_pipelinedrobustautolock_signed_height2;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next2 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height2);
	end
// synthesis translate_off
	dummy_d_6 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended2 = pair_candidate_pipelinedrobustautolock_abs_next2;
assign pair_candidate_pipelinedrobustautolock_signed_height3 = pair_candidate_pipelinedrobustautolock_csrstorage3_storage;

// synthesis translate_off
reg dummy_d_7;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next3 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height3 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next3 <= pair_candidate_pipelinedrobustautolock_signed_height3;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next3 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height3);
	end
// synthesis translate_off
	dummy_d_7 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended3 = pair_candidate_pipelinedrobustautolock_abs_next3;
assign pair_candidate_pipelinedrobustautolock_signed_height4 = pair_candidate_pipelinedrobustautolock_csrstorage4_storage;

// synthesis translate_off
reg dummy_d_8;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next4 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height4 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next4 <= pair_candidate_pipelinedrobustautolock_signed_height4;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next4 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height4);
	end
// synthesis translate_off
	dummy_d_8 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended4 = pair_candidate_pipelinedrobustautolock_abs_next4;
assign pair_candidate_pipelinedrobustautolock_signed_height5 = pair_candidate_pipelinedrobustautolock_csrstorage5_storage;

// synthesis translate_off
reg dummy_d_9;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next5 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height5 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next5 <= pair_candidate_pipelinedrobustautolock_signed_height5;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next5 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height5);
	end
// synthesis translate_off
	dummy_d_9 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended5 = pair_candidate_pipelinedrobustautolock_abs_next5;
assign pair_candidate_pipelinedrobustautolock_signed_height6 = pair_candidate_pipelinedrobustautolock_csrstorage6_storage;

// synthesis translate_off
reg dummy_d_10;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next6 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height6 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next6 <= pair_candidate_pipelinedrobustautolock_signed_height6;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next6 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height6);
	end
// synthesis translate_off
	dummy_d_10 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended6 = pair_candidate_pipelinedrobustautolock_abs_next6;
assign pair_candidate_pipelinedrobustautolock_signed_height7 = pair_candidate_pipelinedrobustautolock_csrstorage7_storage;

// synthesis translate_off
reg dummy_d_11;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next7 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height7 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next7 <= pair_candidate_pipelinedrobustautolock_signed_height7;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next7 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height7);
	end
// synthesis translate_off
	dummy_d_11 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended7 = pair_candidate_pipelinedrobustautolock_abs_next7;
assign pair_candidate_pipelinedrobustautolock_signed_height8 = pair_candidate_pipelinedrobustautolock_csrstorage8_storage;

// synthesis translate_off
reg dummy_d_12;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next8 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height8 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next8 <= pair_candidate_pipelinedrobustautolock_signed_height8;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next8 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height8);
	end
// synthesis translate_off
	dummy_d_12 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended8 = pair_candidate_pipelinedrobustautolock_abs_next8;
assign pair_candidate_pipelinedrobustautolock_signed_height9 = pair_candidate_pipelinedrobustautolock_csrstorage9_storage;

// synthesis translate_off
reg dummy_d_13;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next9 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height9 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next9 <= pair_candidate_pipelinedrobustautolock_signed_height9;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next9 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height9);
	end
// synthesis translate_off
	dummy_d_13 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended9 = pair_candidate_pipelinedrobustautolock_abs_next9;
assign pair_candidate_pipelinedrobustautolock_signed_height10 = pair_candidate_pipelinedrobustautolock_csrstorage10_storage;

// synthesis translate_off
reg dummy_d_14;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next10 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height10 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next10 <= pair_candidate_pipelinedrobustautolock_signed_height10;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next10 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height10);
	end
// synthesis translate_off
	dummy_d_14 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended10 = pair_candidate_pipelinedrobustautolock_abs_next10;
assign pair_candidate_pipelinedrobustautolock_signed_height11 = pair_candidate_pipelinedrobustautolock_csrstorage11_storage;

// synthesis translate_off
reg dummy_d_15;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next11 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height11 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next11 <= pair_candidate_pipelinedrobustautolock_signed_height11;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next11 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height11);
	end
// synthesis translate_off
	dummy_d_15 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended11 = pair_candidate_pipelinedrobustautolock_abs_next11;
assign pair_candidate_pipelinedrobustautolock_signed_height12 = pair_candidate_pipelinedrobustautolock_csrstorage12_storage;

// synthesis translate_off
reg dummy_d_16;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next12 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height12 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next12 <= pair_candidate_pipelinedrobustautolock_signed_height12;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next12 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height12);
	end
// synthesis translate_off
	dummy_d_16 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended12 = pair_candidate_pipelinedrobustautolock_abs_next12;
assign pair_candidate_pipelinedrobustautolock_signed_height13 = pair_candidate_pipelinedrobustautolock_csrstorage13_storage;

// synthesis translate_off
reg dummy_d_17;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next13 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height13 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next13 <= pair_candidate_pipelinedrobustautolock_signed_height13;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next13 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height13);
	end
// synthesis translate_off
	dummy_d_17 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended13 = pair_candidate_pipelinedrobustautolock_abs_next13;
assign pair_candidate_pipelinedrobustautolock_signed_height14 = pair_candidate_pipelinedrobustautolock_csrstorage14_storage;

// synthesis translate_off
reg dummy_d_18;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next14 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height14 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next14 <= pair_candidate_pipelinedrobustautolock_signed_height14;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next14 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height14);
	end
// synthesis translate_off
	dummy_d_18 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended14 = pair_candidate_pipelinedrobustautolock_abs_next14;
assign pair_candidate_pipelinedrobustautolock_signed_height15 = pair_candidate_pipelinedrobustautolock_csrstorage15_storage;

// synthesis translate_off
reg dummy_d_19;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next15 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height15 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next15 <= pair_candidate_pipelinedrobustautolock_signed_height15;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next15 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height15);
	end
// synthesis translate_off
	dummy_d_19 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended15 = pair_candidate_pipelinedrobustautolock_abs_next15;
assign pair_candidate_pipelinedrobustautolock_signed_height16 = pair_candidate_pipelinedrobustautolock_csrstorage16_storage;

// synthesis translate_off
reg dummy_d_20;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next16 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height16 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next16 <= pair_candidate_pipelinedrobustautolock_signed_height16;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next16 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height16);
	end
// synthesis translate_off
	dummy_d_20 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended16 = pair_candidate_pipelinedrobustautolock_abs_next16;
assign pair_candidate_pipelinedrobustautolock_signed_height17 = pair_candidate_pipelinedrobustautolock_csrstorage17_storage;

// synthesis translate_off
reg dummy_d_21;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next17 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height17 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next17 <= pair_candidate_pipelinedrobustautolock_signed_height17;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next17 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height17);
	end
// synthesis translate_off
	dummy_d_21 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended17 = pair_candidate_pipelinedrobustautolock_abs_next17;
assign pair_candidate_pipelinedrobustautolock_signed_height18 = pair_candidate_pipelinedrobustautolock_csrstorage18_storage;

// synthesis translate_off
reg dummy_d_22;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next18 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height18 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next18 <= pair_candidate_pipelinedrobustautolock_signed_height18;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next18 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height18);
	end
// synthesis translate_off
	dummy_d_22 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended18 = pair_candidate_pipelinedrobustautolock_abs_next18;
assign pair_candidate_pipelinedrobustautolock_signed_height19 = pair_candidate_pipelinedrobustautolock_csrstorage19_storage;

// synthesis translate_off
reg dummy_d_23;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next19 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height19 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next19 <= pair_candidate_pipelinedrobustautolock_signed_height19;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next19 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height19);
	end
// synthesis translate_off
	dummy_d_23 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended19 = pair_candidate_pipelinedrobustautolock_abs_next19;
assign pair_candidate_pipelinedrobustautolock_signed_height20 = pair_candidate_pipelinedrobustautolock_csrstorage20_storage;

// synthesis translate_off
reg dummy_d_24;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next20 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height20 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next20 <= pair_candidate_pipelinedrobustautolock_signed_height20;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next20 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height20);
	end
// synthesis translate_off
	dummy_d_24 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended20 = pair_candidate_pipelinedrobustautolock_abs_next20;
assign pair_candidate_pipelinedrobustautolock_signed_height21 = pair_candidate_pipelinedrobustautolock_csrstorage21_storage;

// synthesis translate_off
reg dummy_d_25;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next21 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height21 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next21 <= pair_candidate_pipelinedrobustautolock_signed_height21;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next21 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height21);
	end
// synthesis translate_off
	dummy_d_25 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended21 = pair_candidate_pipelinedrobustautolock_abs_next21;
assign pair_candidate_pipelinedrobustautolock_signed_height22 = pair_candidate_pipelinedrobustautolock_csrstorage22_storage;

// synthesis translate_off
reg dummy_d_26;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next22 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height22 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next22 <= pair_candidate_pipelinedrobustautolock_signed_height22;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next22 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height22);
	end
// synthesis translate_off
	dummy_d_26 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended22 = pair_candidate_pipelinedrobustautolock_abs_next22;
assign pair_candidate_pipelinedrobustautolock_signed_height23 = pair_candidate_pipelinedrobustautolock_csrstorage23_storage;

// synthesis translate_off
reg dummy_d_27;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next23 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height23 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next23 <= pair_candidate_pipelinedrobustautolock_signed_height23;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next23 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height23);
	end
// synthesis translate_off
	dummy_d_27 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended23 = pair_candidate_pipelinedrobustautolock_abs_next23;
assign pair_candidate_pipelinedrobustautolock_signed_height24 = pair_candidate_pipelinedrobustautolock_csrstorage24_storage;

// synthesis translate_off
reg dummy_d_28;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next24 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height24 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next24 <= pair_candidate_pipelinedrobustautolock_signed_height24;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next24 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height24);
	end
// synthesis translate_off
	dummy_d_28 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended24 = pair_candidate_pipelinedrobustautolock_abs_next24;
assign pair_candidate_pipelinedrobustautolock_signed_height25 = pair_candidate_pipelinedrobustautolock_csrstorage25_storage;

// synthesis translate_off
reg dummy_d_29;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next25 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height25 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next25 <= pair_candidate_pipelinedrobustautolock_signed_height25;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next25 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height25);
	end
// synthesis translate_off
	dummy_d_29 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended25 = pair_candidate_pipelinedrobustautolock_abs_next25;
assign pair_candidate_pipelinedrobustautolock_signed_height26 = pair_candidate_pipelinedrobustautolock_csrstorage26_storage;

// synthesis translate_off
reg dummy_d_30;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next26 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height26 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next26 <= pair_candidate_pipelinedrobustautolock_signed_height26;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next26 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height26);
	end
// synthesis translate_off
	dummy_d_30 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended26 = pair_candidate_pipelinedrobustautolock_abs_next26;
assign pair_candidate_pipelinedrobustautolock_signed_height27 = pair_candidate_pipelinedrobustautolock_csrstorage27_storage;

// synthesis translate_off
reg dummy_d_31;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next27 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height27 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next27 <= pair_candidate_pipelinedrobustautolock_signed_height27;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next27 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height27);
	end
// synthesis translate_off
	dummy_d_31 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended27 = pair_candidate_pipelinedrobustautolock_abs_next27;
assign pair_candidate_pipelinedrobustautolock_signed_height28 = pair_candidate_pipelinedrobustautolock_csrstorage28_storage;

// synthesis translate_off
reg dummy_d_32;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next28 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height28 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next28 <= pair_candidate_pipelinedrobustautolock_signed_height28;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next28 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height28);
	end
// synthesis translate_off
	dummy_d_32 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended28 = pair_candidate_pipelinedrobustautolock_abs_next28;
assign pair_candidate_pipelinedrobustautolock_signed_height29 = pair_candidate_pipelinedrobustautolock_csrstorage29_storage;

// synthesis translate_off
reg dummy_d_33;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next29 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height29 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next29 <= pair_candidate_pipelinedrobustautolock_signed_height29;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next29 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height29);
	end
// synthesis translate_off
	dummy_d_33 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended29 = pair_candidate_pipelinedrobustautolock_abs_next29;
assign pair_candidate_pipelinedrobustautolock_signed_height30 = pair_candidate_pipelinedrobustautolock_csrstorage30_storage;

// synthesis translate_off
reg dummy_d_34;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next30 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height30 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next30 <= pair_candidate_pipelinedrobustautolock_signed_height30;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next30 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height30);
	end
// synthesis translate_off
	dummy_d_34 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended30 = pair_candidate_pipelinedrobustautolock_abs_next30;
assign pair_candidate_pipelinedrobustautolock_signed_height31 = pair_candidate_pipelinedrobustautolock_csrstorage31_storage;

// synthesis translate_off
reg dummy_d_35;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_next31 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_signed_height31 >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_next31 <= pair_candidate_pipelinedrobustautolock_signed_height31;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_next31 <= (1'sd1 * pair_candidate_pipelinedrobustautolock_signed_height31);
	end
// synthesis translate_off
	dummy_d_35 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_extended31 = pair_candidate_pipelinedrobustautolock_abs_next31;
assign pair_candidate_pipelinedrobustautolock_current_peak_height = array_muxed2;
assign pair_candidate_pipelinedrobustautolock_current_wait_for = array_muxed3;
assign pair_candidate_pipelinedrobustautolock_writing_data_now0 = pair_candidate_pipelinedrobustautolock_writing_data_now2;
assign pair_candidate_pipelinedrobustautolock_restart0 = pair_candidate_pipelinedrobustautolock_at_start;
assign pair_candidate_pipelinedrobustautolock_input0 = pair_candidate_pipelinedrobustautolock_input2;
assign pair_candidate_pipelinedrobustautolock_delay_value = pair_candidate_pipelinedrobustautolock_time_scale_storage;
assign pair_candidate_pipelinedrobustautolock_sum_diff = pair_candidate_pipelinedrobustautolock_sum_diff_s1;
assign pair_candidate_pipelinedrobustautolock_sign_equal = ((pair_candidate_pipelinedrobustautolock_sum_diff > $signed({1'd0, 1'd0})) == $signed({1'd0, pair_candidate_pipelinedrobustautolock_current_peak_positive}));

// synthesis translate_off
reg dummy_d_36;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_abs_sum_diff <= 29'sd0;
	if ((pair_candidate_pipelinedrobustautolock_sum_diff >= $signed({1'd0, 1'd0}))) begin
		pair_candidate_pipelinedrobustautolock_abs_sum_diff <= pair_candidate_pipelinedrobustautolock_sum_diff;
	end else begin
		pair_candidate_pipelinedrobustautolock_abs_sum_diff <= (1'sd1 * pair_candidate_pipelinedrobustautolock_sum_diff);
	end
// synthesis translate_off
	dummy_d_36 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_abs_current_peak_height = array_muxed4;
assign pair_candidate_pipelinedrobustautolock_current_peak_positive = array_muxed5;
assign pair_candidate_pipelinedrobustautolock_negative_current_peak_height = array_muxed6;
assign pair_candidate_pipelinedrobustautolock_waited_long_enough = (pair_candidate_pipelinedrobustautolock_waited_for > pair_candidate_pipelinedrobustautolock_current_wait_for);
assign pair_candidate_pipelinedrobustautolock_all_instructions_triggered = (pair_candidate_pipelinedrobustautolock_current_instruction_idx >= pair_candidate_pipelinedrobustautolock_n_instructions_s1);
assign pair_candidate_pipelinedrobustautolock_turn_on_lock = (pair_candidate_pipelinedrobustautolock_all_instructions_triggered & (pair_candidate_pipelinedrobustautolock_final_waited_for >= pair_candidate_pipelinedrobustautolock_final_wait_s1));
assign pair_candidate_pipelinedrobustautolock_threshold0 = array_muxed7;
assign pair_candidate_pipelinedrobustautolock_negative32 = array_muxed8;
assign pair_candidate_pipelinedrobustautolock_result0 = ((pair_candidate_pipelinedrobustautolock_sum_diff[28] & (pair_candidate_pipelinedrobustautolock_sum_diff != 29'sd268435456)) ? (pair_candidate_pipelinedrobustautolock_sum_diff <= pair_candidate_pipelinedrobustautolock_negative32) : (pair_candidate_pipelinedrobustautolock_sum_diff >= pair_candidate_pipelinedrobustautolock_threshold0));
assign pair_candidate_pipelinedrobustautolock_threshold1 = array_muxed9;
assign pair_candidate_pipelinedrobustautolock_negative33 = array_muxed10;
assign pair_candidate_pipelinedrobustautolock_result1 = ((pair_candidate_pipelinedrobustautolock_sum_diff[28] & (pair_candidate_pipelinedrobustautolock_sum_diff != 29'sd268435456)) ? (pair_candidate_pipelinedrobustautolock_sum_diff <= pair_candidate_pipelinedrobustautolock_negative33) : (pair_candidate_pipelinedrobustautolock_sum_diff >= pair_candidate_pipelinedrobustautolock_threshold1));
assign pair_candidate_pipelinedrobustautolock_threshold2 = array_muxed11;
assign pair_candidate_pipelinedrobustautolock_negative34 = array_muxed12;
assign pair_candidate_pipelinedrobustautolock_result2 = ((pair_candidate_pipelinedrobustautolock_sum_diff[28] & (pair_candidate_pipelinedrobustautolock_sum_diff != 29'sd268435456)) ? (pair_candidate_pipelinedrobustautolock_sum_diff <= pair_candidate_pipelinedrobustautolock_negative34) : (pair_candidate_pipelinedrobustautolock_sum_diff >= pair_candidate_pipelinedrobustautolock_threshold2));
assign pair_candidate_pipelinedrobustautolock_threshold3 = array_muxed13;
assign pair_candidate_pipelinedrobustautolock_negative35 = array_muxed14;
assign pair_candidate_pipelinedrobustautolock_result3 = ((pair_candidate_pipelinedrobustautolock_sum_diff[28] & (pair_candidate_pipelinedrobustautolock_sum_diff != 29'sd268435456)) ? (pair_candidate_pipelinedrobustautolock_sum_diff <= pair_candidate_pipelinedrobustautolock_negative35) : (pair_candidate_pipelinedrobustautolock_sum_diff >= pair_candidate_pipelinedrobustautolock_threshold3));
assign pair_candidate_pipelinedrobustautolock_threshold4 = array_muxed15;
assign pair_candidate_pipelinedrobustautolock_negative36 = array_muxed16;
assign pair_candidate_pipelinedrobustautolock_result4 = ((pair_candidate_pipelinedrobustautolock_sum_diff[28] & (pair_candidate_pipelinedrobustautolock_sum_diff != 29'sd268435456)) ? (pair_candidate_pipelinedrobustautolock_sum_diff <= pair_candidate_pipelinedrobustautolock_negative36) : (pair_candidate_pipelinedrobustautolock_sum_diff >= pair_candidate_pipelinedrobustautolock_threshold4));
assign pair_candidate_pipelinedrobustautolock_threshold5 = array_muxed17;
assign pair_candidate_pipelinedrobustautolock_negative37 = array_muxed18;
assign pair_candidate_pipelinedrobustautolock_result5 = ((pair_candidate_pipelinedrobustautolock_sum_diff[28] & (pair_candidate_pipelinedrobustautolock_sum_diff != 29'sd268435456)) ? (pair_candidate_pipelinedrobustautolock_sum_diff <= pair_candidate_pipelinedrobustautolock_negative37) : (pair_candidate_pipelinedrobustautolock_sum_diff >= pair_candidate_pipelinedrobustautolock_threshold5));
assign pair_candidate_pipelinedrobustautolock_threshold6 = array_muxed19;
assign pair_candidate_pipelinedrobustautolock_negative38 = array_muxed20;
assign pair_candidate_pipelinedrobustautolock_result6 = ((pair_candidate_pipelinedrobustautolock_sum_diff[28] & (pair_candidate_pipelinedrobustautolock_sum_diff != 29'sd268435456)) ? (pair_candidate_pipelinedrobustautolock_sum_diff <= pair_candidate_pipelinedrobustautolock_negative38) : (pair_candidate_pipelinedrobustautolock_sum_diff >= pair_candidate_pipelinedrobustautolock_threshold6));
assign pair_candidate_pipelinedrobustautolock_threshold7 = array_muxed21;
assign pair_candidate_pipelinedrobustautolock_negative39 = array_muxed22;
assign pair_candidate_pipelinedrobustautolock_result7 = ((pair_candidate_pipelinedrobustautolock_sum_diff[28] & (pair_candidate_pipelinedrobustautolock_sum_diff != 29'sd268435456)) ? (pair_candidate_pipelinedrobustautolock_sum_diff <= pair_candidate_pipelinedrobustautolock_negative39) : (pair_candidate_pipelinedrobustautolock_sum_diff >= pair_candidate_pipelinedrobustautolock_threshold7));
assign pair_candidate_pipelinedrobustautolock_fallback = ((pair_candidate_pipelinedrobustautolock_sum_diff[28] & (pair_candidate_pipelinedrobustautolock_sum_diff != 29'sd268435456)) ? (pair_candidate_pipelinedrobustautolock_sum_diff <= pair_candidate_pipelinedrobustautolock_negative31) : (pair_candidate_pipelinedrobustautolock_sum_diff >= pair_candidate_pipelinedrobustautolock_magnitude31));

// synthesis translate_off
reg dummy_d_37;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_over_threshold <= 1'd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx)
		1'd0: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result0;
		end
		1'd1: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result1;
		end
		2'd2: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result2;
		end
		2'd3: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result3;
		end
		3'd4: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result4;
		end
		3'd5: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result5;
		end
		3'd6: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result6;
		end
		3'd7: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result7;
		end
		4'd8: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result0;
		end
		4'd9: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result1;
		end
		4'd10: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result2;
		end
		4'd11: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result3;
		end
		4'd12: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result4;
		end
		4'd13: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result5;
		end
		4'd14: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result6;
		end
		4'd15: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result7;
		end
		5'd16: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result0;
		end
		5'd17: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result1;
		end
		5'd18: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result2;
		end
		5'd19: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result3;
		end
		5'd20: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result4;
		end
		5'd21: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result5;
		end
		5'd22: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result6;
		end
		5'd23: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result7;
		end
		5'd24: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result0;
		end
		5'd25: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result1;
		end
		5'd26: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result2;
		end
		5'd27: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result3;
		end
		5'd28: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result4;
		end
		5'd29: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result5;
		end
		5'd30: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result6;
		end
		5'd31: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_result7;
		end
		default: begin
			pair_candidate_pipelinedrobustautolock_over_threshold <= pair_candidate_pipelinedrobustautolock_fallback;
		end
	endcase
// synthesis translate_off
	dummy_d_37 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_pipelinedrobustautolock_writing_data_now1 = pair_candidate_pipelinedrobustautolock_writing_data_now0;
assign pair_candidate_pipelinedrobustautolock_restart1 = pair_candidate_pipelinedrobustautolock_restart0;
assign pair_candidate_pipelinedrobustautolock_delay = pair_candidate_pipelinedrobustautolock_delay_value;
assign pair_candidate_pipelinedrobustautolock_input1 = pair_candidate_pipelinedrobustautolock_sum_value;
assign pair_candidate_pipelinedrobustautolock_delayed_sum = pair_candidate_pipelinedrobustautolock_output1;
assign pair_candidate_pipelinedrobustautolock_current_sum_diff = (pair_candidate_pipelinedrobustautolock_sum_value - pair_candidate_pipelinedrobustautolock_delayed_sum);
assign pair_candidate_pipelinedrobustautolock_output0 = pair_candidate_pipelinedrobustautolock_current_sum_diff;
assign pair_candidate_pipelinedrobustautolock_wrport_we = pair_candidate_pipelinedrobustautolock_writing_data_now1;
assign pair_candidate_pipelinedrobustautolock_wrport_adr = pair_candidate_pipelinedrobustautolock_counter;
assign pair_candidate_pipelinedrobustautolock_wrport_dat_w = pair_candidate_pipelinedrobustautolock_input1;
assign pair_candidate_pipelinedrobustautolock_counter_delayed = ((pair_candidate_pipelinedrobustautolock_counter - pair_candidate_pipelinedrobustautolock_delay) + 1'd1);

// synthesis translate_off
reg dummy_d_38;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_rdport_adr <= 13'd0;
	pair_candidate_pipelinedrobustautolock_rdport_adr <= pair_candidate_pipelinedrobustautolock_counter_delayed;
	pair_candidate_pipelinedrobustautolock_rdport_adr <= pair_candidate_pipelinedrobustautolock_counter_delayed;
// synthesis translate_off
	dummy_d_38 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_39;
// synthesis translate_on
always @(*) begin
	pair_candidate_pipelinedrobustautolock_output1 <= 28'sd0;
	if ((pair_candidate_pipelinedrobustautolock_counter < (pair_candidate_pipelinedrobustautolock_delay - 1'd1))) begin
		pair_candidate_pipelinedrobustautolock_output1 <= 1'd0;
	end else begin
		pair_candidate_pipelinedrobustautolock_output1 <= pair_candidate_pipelinedrobustautolock_rdport_dat_r;
	end
// synthesis translate_off
	dummy_d_39 <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_fast_target_position_signed = pair_candidate_fast_storage;
assign pair_rb_sel = (pair_rb_bus_adr[13:9] == 1'd0);
assign pair_rb_robust_time_scale1_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_time_scale1_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 1'd0));
assign pair_rb_robust_time_scale0_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_time_scale0_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 1'd1));
assign pair_rb_robust_N_instructions0_r = pair_rb_bus_dat_w[4:0];
assign pair_rb_robust_N_instructions0_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 2'd2));
assign pair_rb_robust_final_wait_time1_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_final_wait_time1_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 2'd3));
assign pair_rb_robust_final_wait_time0_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_final_wait_time0_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 3'd4));
assign pair_rb_robust_peak_height_03_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_03_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 3'd5));
assign pair_rb_robust_peak_height_02_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_02_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 3'd6));
assign pair_rb_robust_peak_height_01_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_01_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 3'd7));
assign pair_rb_robust_peak_height_00_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_00_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 4'd8));
assign pair_rb_robust_peak_height_13_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_13_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 4'd9));
assign pair_rb_robust_peak_height_12_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_12_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 4'd10));
assign pair_rb_robust_peak_height_11_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_11_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 4'd11));
assign pair_rb_robust_peak_height_10_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_10_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 4'd12));
assign pair_rb_robust_peak_height_23_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_23_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 4'd13));
assign pair_rb_robust_peak_height_22_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_22_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 4'd14));
assign pair_rb_robust_peak_height_21_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_21_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 4'd15));
assign pair_rb_robust_peak_height_20_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_20_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd16));
assign pair_rb_robust_peak_height_33_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_33_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd17));
assign pair_rb_robust_peak_height_32_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_32_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd18));
assign pair_rb_robust_peak_height_31_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_31_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd19));
assign pair_rb_robust_peak_height_30_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_30_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd20));
assign pair_rb_robust_peak_height_43_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_43_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd21));
assign pair_rb_robust_peak_height_42_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_42_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd22));
assign pair_rb_robust_peak_height_41_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_41_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd23));
assign pair_rb_robust_peak_height_40_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_40_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd24));
assign pair_rb_robust_peak_height_53_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_53_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd25));
assign pair_rb_robust_peak_height_52_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_52_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd26));
assign pair_rb_robust_peak_height_51_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_51_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd27));
assign pair_rb_robust_peak_height_50_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_50_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd28));
assign pair_rb_robust_peak_height_63_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_63_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd29));
assign pair_rb_robust_peak_height_62_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_62_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd30));
assign pair_rb_robust_peak_height_61_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_61_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 5'd31));
assign pair_rb_robust_peak_height_60_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_60_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd32));
assign pair_rb_robust_peak_height_73_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_73_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd33));
assign pair_rb_robust_peak_height_72_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_72_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd34));
assign pair_rb_robust_peak_height_71_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_71_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd35));
assign pair_rb_robust_peak_height_70_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_70_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd36));
assign pair_rb_robust_peak_height_83_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_83_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd37));
assign pair_rb_robust_peak_height_82_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_82_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd38));
assign pair_rb_robust_peak_height_81_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_81_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd39));
assign pair_rb_robust_peak_height_80_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_80_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd40));
assign pair_rb_robust_peak_height_93_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_93_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd41));
assign pair_rb_robust_peak_height_92_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_92_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd42));
assign pair_rb_robust_peak_height_91_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_91_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd43));
assign pair_rb_robust_peak_height_90_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_90_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd44));
assign pair_rb_robust_peak_height_103_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_103_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd45));
assign pair_rb_robust_peak_height_102_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_102_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd46));
assign pair_rb_robust_peak_height_101_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_101_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd47));
assign pair_rb_robust_peak_height_100_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_100_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd48));
assign pair_rb_robust_peak_height_113_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_113_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd49));
assign pair_rb_robust_peak_height_112_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_112_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd50));
assign pair_rb_robust_peak_height_111_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_111_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd51));
assign pair_rb_robust_peak_height_110_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_110_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd52));
assign pair_rb_robust_peak_height_123_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_123_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd53));
assign pair_rb_robust_peak_height_122_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_122_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd54));
assign pair_rb_robust_peak_height_121_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_121_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd55));
assign pair_rb_robust_peak_height_120_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_120_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd56));
assign pair_rb_robust_peak_height_133_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_133_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd57));
assign pair_rb_robust_peak_height_132_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_132_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd58));
assign pair_rb_robust_peak_height_131_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_131_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd59));
assign pair_rb_robust_peak_height_130_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_130_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd60));
assign pair_rb_robust_peak_height_143_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_143_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd61));
assign pair_rb_robust_peak_height_142_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_142_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd62));
assign pair_rb_robust_peak_height_141_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_141_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 6'd63));
assign pair_rb_robust_peak_height_140_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_140_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd64));
assign pair_rb_robust_peak_height_153_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_153_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd65));
assign pair_rb_robust_peak_height_152_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_152_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd66));
assign pair_rb_robust_peak_height_151_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_151_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd67));
assign pair_rb_robust_peak_height_150_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_150_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd68));
assign pair_rb_robust_peak_height_163_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_163_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd69));
assign pair_rb_robust_peak_height_162_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_162_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd70));
assign pair_rb_robust_peak_height_161_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_161_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd71));
assign pair_rb_robust_peak_height_160_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_160_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd72));
assign pair_rb_robust_peak_height_173_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_173_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd73));
assign pair_rb_robust_peak_height_172_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_172_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd74));
assign pair_rb_robust_peak_height_171_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_171_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd75));
assign pair_rb_robust_peak_height_170_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_170_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd76));
assign pair_rb_robust_peak_height_183_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_183_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd77));
assign pair_rb_robust_peak_height_182_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_182_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd78));
assign pair_rb_robust_peak_height_181_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_181_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd79));
assign pair_rb_robust_peak_height_180_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_180_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd80));
assign pair_rb_robust_peak_height_193_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_193_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd81));
assign pair_rb_robust_peak_height_192_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_192_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd82));
assign pair_rb_robust_peak_height_191_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_191_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd83));
assign pair_rb_robust_peak_height_190_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_190_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd84));
assign pair_rb_robust_peak_height_203_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_203_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd85));
assign pair_rb_robust_peak_height_202_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_202_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd86));
assign pair_rb_robust_peak_height_201_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_201_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd87));
assign pair_rb_robust_peak_height_200_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_200_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd88));
assign pair_rb_robust_peak_height_213_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_213_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd89));
assign pair_rb_robust_peak_height_212_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_212_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd90));
assign pair_rb_robust_peak_height_211_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_211_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd91));
assign pair_rb_robust_peak_height_210_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_210_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd92));
assign pair_rb_robust_peak_height_223_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_223_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd93));
assign pair_rb_robust_peak_height_222_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_222_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd94));
assign pair_rb_robust_peak_height_221_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_221_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd95));
assign pair_rb_robust_peak_height_220_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_220_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd96));
assign pair_rb_robust_peak_height_233_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_233_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd97));
assign pair_rb_robust_peak_height_232_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_232_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd98));
assign pair_rb_robust_peak_height_231_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_231_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd99));
assign pair_rb_robust_peak_height_230_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_230_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd100));
assign pair_rb_robust_peak_height_243_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_243_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd101));
assign pair_rb_robust_peak_height_242_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_242_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd102));
assign pair_rb_robust_peak_height_241_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_241_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd103));
assign pair_rb_robust_peak_height_240_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_240_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd104));
assign pair_rb_robust_peak_height_253_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_253_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd105));
assign pair_rb_robust_peak_height_252_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_252_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd106));
assign pair_rb_robust_peak_height_251_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_251_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd107));
assign pair_rb_robust_peak_height_250_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_250_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd108));
assign pair_rb_robust_peak_height_263_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_263_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd109));
assign pair_rb_robust_peak_height_262_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_262_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd110));
assign pair_rb_robust_peak_height_261_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_261_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd111));
assign pair_rb_robust_peak_height_260_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_260_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd112));
assign pair_rb_robust_peak_height_273_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_273_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd113));
assign pair_rb_robust_peak_height_272_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_272_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd114));
assign pair_rb_robust_peak_height_271_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_271_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd115));
assign pair_rb_robust_peak_height_270_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_270_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd116));
assign pair_rb_robust_peak_height_283_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_283_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd117));
assign pair_rb_robust_peak_height_282_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_282_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd118));
assign pair_rb_robust_peak_height_281_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_281_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd119));
assign pair_rb_robust_peak_height_280_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_280_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd120));
assign pair_rb_robust_peak_height_293_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_293_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd121));
assign pair_rb_robust_peak_height_292_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_292_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd122));
assign pair_rb_robust_peak_height_291_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_291_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd123));
assign pair_rb_robust_peak_height_290_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_290_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd124));
assign pair_rb_robust_peak_height_303_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_303_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd125));
assign pair_rb_robust_peak_height_302_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_302_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd126));
assign pair_rb_robust_peak_height_301_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_301_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 7'd127));
assign pair_rb_robust_peak_height_300_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_300_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd128));
assign pair_rb_robust_peak_height_313_r = pair_rb_bus_dat_w[3:0];
assign pair_rb_robust_peak_height_313_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd129));
assign pair_rb_robust_peak_height_312_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_312_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd130));
assign pair_rb_robust_peak_height_311_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_311_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd131));
assign pair_rb_robust_peak_height_310_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_peak_height_310_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd132));
assign pair_rb_robust_wait_for_01_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_01_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd133));
assign pair_rb_robust_wait_for_00_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_00_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd134));
assign pair_rb_robust_wait_for_11_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_11_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd135));
assign pair_rb_robust_wait_for_10_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_10_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd136));
assign pair_rb_robust_wait_for_21_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_21_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd137));
assign pair_rb_robust_wait_for_20_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_20_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd138));
assign pair_rb_robust_wait_for_31_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_31_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd139));
assign pair_rb_robust_wait_for_30_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_30_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd140));
assign pair_rb_robust_wait_for_41_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_41_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd141));
assign pair_rb_robust_wait_for_40_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_40_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd142));
assign pair_rb_robust_wait_for_51_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_51_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd143));
assign pair_rb_robust_wait_for_50_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_50_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd144));
assign pair_rb_robust_wait_for_61_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_61_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd145));
assign pair_rb_robust_wait_for_60_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_60_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd146));
assign pair_rb_robust_wait_for_71_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_71_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd147));
assign pair_rb_robust_wait_for_70_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_70_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd148));
assign pair_rb_robust_wait_for_81_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_81_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd149));
assign pair_rb_robust_wait_for_80_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_80_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd150));
assign pair_rb_robust_wait_for_91_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_91_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd151));
assign pair_rb_robust_wait_for_90_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_90_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd152));
assign pair_rb_robust_wait_for_101_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_101_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd153));
assign pair_rb_robust_wait_for_100_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_100_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd154));
assign pair_rb_robust_wait_for_111_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_111_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd155));
assign pair_rb_robust_wait_for_110_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_110_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd156));
assign pair_rb_robust_wait_for_121_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_121_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd157));
assign pair_rb_robust_wait_for_120_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_120_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd158));
assign pair_rb_robust_wait_for_131_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_131_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd159));
assign pair_rb_robust_wait_for_130_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_130_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd160));
assign pair_rb_robust_wait_for_141_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_141_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd161));
assign pair_rb_robust_wait_for_140_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_140_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd162));
assign pair_rb_robust_wait_for_151_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_151_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd163));
assign pair_rb_robust_wait_for_150_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_150_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd164));
assign pair_rb_robust_wait_for_161_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_161_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd165));
assign pair_rb_robust_wait_for_160_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_160_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd166));
assign pair_rb_robust_wait_for_171_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_171_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd167));
assign pair_rb_robust_wait_for_170_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_170_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd168));
assign pair_rb_robust_wait_for_181_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_181_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd169));
assign pair_rb_robust_wait_for_180_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_180_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd170));
assign pair_rb_robust_wait_for_191_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_191_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd171));
assign pair_rb_robust_wait_for_190_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_190_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd172));
assign pair_rb_robust_wait_for_201_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_201_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd173));
assign pair_rb_robust_wait_for_200_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_200_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd174));
assign pair_rb_robust_wait_for_211_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_211_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd175));
assign pair_rb_robust_wait_for_210_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_210_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd176));
assign pair_rb_robust_wait_for_221_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_221_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd177));
assign pair_rb_robust_wait_for_220_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_220_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd178));
assign pair_rb_robust_wait_for_231_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_231_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd179));
assign pair_rb_robust_wait_for_230_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_230_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd180));
assign pair_rb_robust_wait_for_241_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_241_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd181));
assign pair_rb_robust_wait_for_240_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_240_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd182));
assign pair_rb_robust_wait_for_251_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_251_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd183));
assign pair_rb_robust_wait_for_250_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_250_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd184));
assign pair_rb_robust_wait_for_261_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_261_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd185));
assign pair_rb_robust_wait_for_260_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_260_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd186));
assign pair_rb_robust_wait_for_271_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_271_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd187));
assign pair_rb_robust_wait_for_270_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_270_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd188));
assign pair_rb_robust_wait_for_281_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_281_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd189));
assign pair_rb_robust_wait_for_280_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_280_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd190));
assign pair_rb_robust_wait_for_291_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_291_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd191));
assign pair_rb_robust_wait_for_290_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_290_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd192));
assign pair_rb_robust_wait_for_301_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_301_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd193));
assign pair_rb_robust_wait_for_300_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_300_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd194));
assign pair_rb_robust_wait_for_311_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_robust_wait_for_311_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd195));
assign pair_rb_robust_wait_for_310_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_robust_wait_for_310_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd196));
assign pair_rb_fast_target_position1_r = pair_rb_bus_dat_w[5:0];
assign pair_rb_fast_target_position1_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd197));
assign pair_rb_fast_target_position0_r = pair_rb_bus_dat_w[7:0];
assign pair_rb_fast_target_position0_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd198));
assign pair_rb_request_lock0_r = pair_rb_bus_dat_w[0];
assign pair_rb_request_lock0_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd199));
assign pair_rb_autolock_mode0_r = pair_rb_bus_dat_w[1:0];
assign pair_rb_autolock_mode0_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd200));
assign pair_rb_lock_running_r = pair_rb_bus_dat_w[0];
assign pair_rb_lock_running_re = ((pair_rb_sel & pair_rb_bus_we) & (pair_rb_bus_adr[7:0] == 8'd201));
assign pair_reference_robust_csrstorage0_storage = pair_reference_robust_csrstorage0_storage_full[13:0];
assign pair_rb_robust_time_scale1_w = pair_reference_robust_csrstorage0_storage_full[13:8];
assign pair_rb_robust_time_scale0_w = pair_reference_robust_csrstorage0_storage_full[7:0];
assign pair_reference_robust_csrstorage1_storage = pair_reference_robust_csrstorage1_storage_full[4:0];
assign pair_rb_robust_N_instructions0_w = pair_reference_robust_csrstorage1_storage_full[4:0];
assign pair_reference_robust_csrstorage2_storage = pair_reference_robust_csrstorage2_storage_full[13:0];
assign pair_rb_robust_final_wait_time1_w = pair_reference_robust_csrstorage2_storage_full[13:8];
assign pair_rb_robust_final_wait_time0_w = pair_reference_robust_csrstorage2_storage_full[7:0];
assign pair_reference_robust_csrstorage3_storage = pair_reference_robust_csrstorage3_storage_full[27:0];
assign pair_rb_robust_peak_height_03_w = pair_reference_robust_csrstorage3_storage_full[27:24];
assign pair_rb_robust_peak_height_02_w = pair_reference_robust_csrstorage3_storage_full[23:16];
assign pair_rb_robust_peak_height_01_w = pair_reference_robust_csrstorage3_storage_full[15:8];
assign pair_rb_robust_peak_height_00_w = pair_reference_robust_csrstorage3_storage_full[7:0];
assign pair_reference_robust_csrstorage4_storage = pair_reference_robust_csrstorage4_storage_full[27:0];
assign pair_rb_robust_peak_height_13_w = pair_reference_robust_csrstorage4_storage_full[27:24];
assign pair_rb_robust_peak_height_12_w = pair_reference_robust_csrstorage4_storage_full[23:16];
assign pair_rb_robust_peak_height_11_w = pair_reference_robust_csrstorage4_storage_full[15:8];
assign pair_rb_robust_peak_height_10_w = pair_reference_robust_csrstorage4_storage_full[7:0];
assign pair_reference_robust_csrstorage5_storage = pair_reference_robust_csrstorage5_storage_full[27:0];
assign pair_rb_robust_peak_height_23_w = pair_reference_robust_csrstorage5_storage_full[27:24];
assign pair_rb_robust_peak_height_22_w = pair_reference_robust_csrstorage5_storage_full[23:16];
assign pair_rb_robust_peak_height_21_w = pair_reference_robust_csrstorage5_storage_full[15:8];
assign pair_rb_robust_peak_height_20_w = pair_reference_robust_csrstorage5_storage_full[7:0];
assign pair_reference_robust_csrstorage6_storage = pair_reference_robust_csrstorage6_storage_full[27:0];
assign pair_rb_robust_peak_height_33_w = pair_reference_robust_csrstorage6_storage_full[27:24];
assign pair_rb_robust_peak_height_32_w = pair_reference_robust_csrstorage6_storage_full[23:16];
assign pair_rb_robust_peak_height_31_w = pair_reference_robust_csrstorage6_storage_full[15:8];
assign pair_rb_robust_peak_height_30_w = pair_reference_robust_csrstorage6_storage_full[7:0];
assign pair_reference_robust_csrstorage7_storage = pair_reference_robust_csrstorage7_storage_full[27:0];
assign pair_rb_robust_peak_height_43_w = pair_reference_robust_csrstorage7_storage_full[27:24];
assign pair_rb_robust_peak_height_42_w = pair_reference_robust_csrstorage7_storage_full[23:16];
assign pair_rb_robust_peak_height_41_w = pair_reference_robust_csrstorage7_storage_full[15:8];
assign pair_rb_robust_peak_height_40_w = pair_reference_robust_csrstorage7_storage_full[7:0];
assign pair_reference_robust_csrstorage8_storage = pair_reference_robust_csrstorage8_storage_full[27:0];
assign pair_rb_robust_peak_height_53_w = pair_reference_robust_csrstorage8_storage_full[27:24];
assign pair_rb_robust_peak_height_52_w = pair_reference_robust_csrstorage8_storage_full[23:16];
assign pair_rb_robust_peak_height_51_w = pair_reference_robust_csrstorage8_storage_full[15:8];
assign pair_rb_robust_peak_height_50_w = pair_reference_robust_csrstorage8_storage_full[7:0];
assign pair_reference_robust_csrstorage9_storage = pair_reference_robust_csrstorage9_storage_full[27:0];
assign pair_rb_robust_peak_height_63_w = pair_reference_robust_csrstorage9_storage_full[27:24];
assign pair_rb_robust_peak_height_62_w = pair_reference_robust_csrstorage9_storage_full[23:16];
assign pair_rb_robust_peak_height_61_w = pair_reference_robust_csrstorage9_storage_full[15:8];
assign pair_rb_robust_peak_height_60_w = pair_reference_robust_csrstorage9_storage_full[7:0];
assign pair_reference_robust_csrstorage10_storage = pair_reference_robust_csrstorage10_storage_full[27:0];
assign pair_rb_robust_peak_height_73_w = pair_reference_robust_csrstorage10_storage_full[27:24];
assign pair_rb_robust_peak_height_72_w = pair_reference_robust_csrstorage10_storage_full[23:16];
assign pair_rb_robust_peak_height_71_w = pair_reference_robust_csrstorage10_storage_full[15:8];
assign pair_rb_robust_peak_height_70_w = pair_reference_robust_csrstorage10_storage_full[7:0];
assign pair_reference_robust_csrstorage11_storage = pair_reference_robust_csrstorage11_storage_full[27:0];
assign pair_rb_robust_peak_height_83_w = pair_reference_robust_csrstorage11_storage_full[27:24];
assign pair_rb_robust_peak_height_82_w = pair_reference_robust_csrstorage11_storage_full[23:16];
assign pair_rb_robust_peak_height_81_w = pair_reference_robust_csrstorage11_storage_full[15:8];
assign pair_rb_robust_peak_height_80_w = pair_reference_robust_csrstorage11_storage_full[7:0];
assign pair_reference_robust_csrstorage12_storage = pair_reference_robust_csrstorage12_storage_full[27:0];
assign pair_rb_robust_peak_height_93_w = pair_reference_robust_csrstorage12_storage_full[27:24];
assign pair_rb_robust_peak_height_92_w = pair_reference_robust_csrstorage12_storage_full[23:16];
assign pair_rb_robust_peak_height_91_w = pair_reference_robust_csrstorage12_storage_full[15:8];
assign pair_rb_robust_peak_height_90_w = pair_reference_robust_csrstorage12_storage_full[7:0];
assign pair_reference_robust_csrstorage13_storage = pair_reference_robust_csrstorage13_storage_full[27:0];
assign pair_rb_robust_peak_height_103_w = pair_reference_robust_csrstorage13_storage_full[27:24];
assign pair_rb_robust_peak_height_102_w = pair_reference_robust_csrstorage13_storage_full[23:16];
assign pair_rb_robust_peak_height_101_w = pair_reference_robust_csrstorage13_storage_full[15:8];
assign pair_rb_robust_peak_height_100_w = pair_reference_robust_csrstorage13_storage_full[7:0];
assign pair_reference_robust_csrstorage14_storage = pair_reference_robust_csrstorage14_storage_full[27:0];
assign pair_rb_robust_peak_height_113_w = pair_reference_robust_csrstorage14_storage_full[27:24];
assign pair_rb_robust_peak_height_112_w = pair_reference_robust_csrstorage14_storage_full[23:16];
assign pair_rb_robust_peak_height_111_w = pair_reference_robust_csrstorage14_storage_full[15:8];
assign pair_rb_robust_peak_height_110_w = pair_reference_robust_csrstorage14_storage_full[7:0];
assign pair_reference_robust_csrstorage15_storage = pair_reference_robust_csrstorage15_storage_full[27:0];
assign pair_rb_robust_peak_height_123_w = pair_reference_robust_csrstorage15_storage_full[27:24];
assign pair_rb_robust_peak_height_122_w = pair_reference_robust_csrstorage15_storage_full[23:16];
assign pair_rb_robust_peak_height_121_w = pair_reference_robust_csrstorage15_storage_full[15:8];
assign pair_rb_robust_peak_height_120_w = pair_reference_robust_csrstorage15_storage_full[7:0];
assign pair_reference_robust_csrstorage16_storage = pair_reference_robust_csrstorage16_storage_full[27:0];
assign pair_rb_robust_peak_height_133_w = pair_reference_robust_csrstorage16_storage_full[27:24];
assign pair_rb_robust_peak_height_132_w = pair_reference_robust_csrstorage16_storage_full[23:16];
assign pair_rb_robust_peak_height_131_w = pair_reference_robust_csrstorage16_storage_full[15:8];
assign pair_rb_robust_peak_height_130_w = pair_reference_robust_csrstorage16_storage_full[7:0];
assign pair_reference_robust_csrstorage17_storage = pair_reference_robust_csrstorage17_storage_full[27:0];
assign pair_rb_robust_peak_height_143_w = pair_reference_robust_csrstorage17_storage_full[27:24];
assign pair_rb_robust_peak_height_142_w = pair_reference_robust_csrstorage17_storage_full[23:16];
assign pair_rb_robust_peak_height_141_w = pair_reference_robust_csrstorage17_storage_full[15:8];
assign pair_rb_robust_peak_height_140_w = pair_reference_robust_csrstorage17_storage_full[7:0];
assign pair_reference_robust_csrstorage18_storage = pair_reference_robust_csrstorage18_storage_full[27:0];
assign pair_rb_robust_peak_height_153_w = pair_reference_robust_csrstorage18_storage_full[27:24];
assign pair_rb_robust_peak_height_152_w = pair_reference_robust_csrstorage18_storage_full[23:16];
assign pair_rb_robust_peak_height_151_w = pair_reference_robust_csrstorage18_storage_full[15:8];
assign pair_rb_robust_peak_height_150_w = pair_reference_robust_csrstorage18_storage_full[7:0];
assign pair_reference_robust_csrstorage19_storage = pair_reference_robust_csrstorage19_storage_full[27:0];
assign pair_rb_robust_peak_height_163_w = pair_reference_robust_csrstorage19_storage_full[27:24];
assign pair_rb_robust_peak_height_162_w = pair_reference_robust_csrstorage19_storage_full[23:16];
assign pair_rb_robust_peak_height_161_w = pair_reference_robust_csrstorage19_storage_full[15:8];
assign pair_rb_robust_peak_height_160_w = pair_reference_robust_csrstorage19_storage_full[7:0];
assign pair_reference_robust_csrstorage20_storage = pair_reference_robust_csrstorage20_storage_full[27:0];
assign pair_rb_robust_peak_height_173_w = pair_reference_robust_csrstorage20_storage_full[27:24];
assign pair_rb_robust_peak_height_172_w = pair_reference_robust_csrstorage20_storage_full[23:16];
assign pair_rb_robust_peak_height_171_w = pair_reference_robust_csrstorage20_storage_full[15:8];
assign pair_rb_robust_peak_height_170_w = pair_reference_robust_csrstorage20_storage_full[7:0];
assign pair_reference_robust_csrstorage21_storage = pair_reference_robust_csrstorage21_storage_full[27:0];
assign pair_rb_robust_peak_height_183_w = pair_reference_robust_csrstorage21_storage_full[27:24];
assign pair_rb_robust_peak_height_182_w = pair_reference_robust_csrstorage21_storage_full[23:16];
assign pair_rb_robust_peak_height_181_w = pair_reference_robust_csrstorage21_storage_full[15:8];
assign pair_rb_robust_peak_height_180_w = pair_reference_robust_csrstorage21_storage_full[7:0];
assign pair_reference_robust_csrstorage22_storage = pair_reference_robust_csrstorage22_storage_full[27:0];
assign pair_rb_robust_peak_height_193_w = pair_reference_robust_csrstorage22_storage_full[27:24];
assign pair_rb_robust_peak_height_192_w = pair_reference_robust_csrstorage22_storage_full[23:16];
assign pair_rb_robust_peak_height_191_w = pair_reference_robust_csrstorage22_storage_full[15:8];
assign pair_rb_robust_peak_height_190_w = pair_reference_robust_csrstorage22_storage_full[7:0];
assign pair_reference_robust_csrstorage23_storage = pair_reference_robust_csrstorage23_storage_full[27:0];
assign pair_rb_robust_peak_height_203_w = pair_reference_robust_csrstorage23_storage_full[27:24];
assign pair_rb_robust_peak_height_202_w = pair_reference_robust_csrstorage23_storage_full[23:16];
assign pair_rb_robust_peak_height_201_w = pair_reference_robust_csrstorage23_storage_full[15:8];
assign pair_rb_robust_peak_height_200_w = pair_reference_robust_csrstorage23_storage_full[7:0];
assign pair_reference_robust_csrstorage24_storage = pair_reference_robust_csrstorage24_storage_full[27:0];
assign pair_rb_robust_peak_height_213_w = pair_reference_robust_csrstorage24_storage_full[27:24];
assign pair_rb_robust_peak_height_212_w = pair_reference_robust_csrstorage24_storage_full[23:16];
assign pair_rb_robust_peak_height_211_w = pair_reference_robust_csrstorage24_storage_full[15:8];
assign pair_rb_robust_peak_height_210_w = pair_reference_robust_csrstorage24_storage_full[7:0];
assign pair_reference_robust_csrstorage25_storage = pair_reference_robust_csrstorage25_storage_full[27:0];
assign pair_rb_robust_peak_height_223_w = pair_reference_robust_csrstorage25_storage_full[27:24];
assign pair_rb_robust_peak_height_222_w = pair_reference_robust_csrstorage25_storage_full[23:16];
assign pair_rb_robust_peak_height_221_w = pair_reference_robust_csrstorage25_storage_full[15:8];
assign pair_rb_robust_peak_height_220_w = pair_reference_robust_csrstorage25_storage_full[7:0];
assign pair_reference_robust_csrstorage26_storage = pair_reference_robust_csrstorage26_storage_full[27:0];
assign pair_rb_robust_peak_height_233_w = pair_reference_robust_csrstorage26_storage_full[27:24];
assign pair_rb_robust_peak_height_232_w = pair_reference_robust_csrstorage26_storage_full[23:16];
assign pair_rb_robust_peak_height_231_w = pair_reference_robust_csrstorage26_storage_full[15:8];
assign pair_rb_robust_peak_height_230_w = pair_reference_robust_csrstorage26_storage_full[7:0];
assign pair_reference_robust_csrstorage27_storage = pair_reference_robust_csrstorage27_storage_full[27:0];
assign pair_rb_robust_peak_height_243_w = pair_reference_robust_csrstorage27_storage_full[27:24];
assign pair_rb_robust_peak_height_242_w = pair_reference_robust_csrstorage27_storage_full[23:16];
assign pair_rb_robust_peak_height_241_w = pair_reference_robust_csrstorage27_storage_full[15:8];
assign pair_rb_robust_peak_height_240_w = pair_reference_robust_csrstorage27_storage_full[7:0];
assign pair_reference_robust_csrstorage28_storage = pair_reference_robust_csrstorage28_storage_full[27:0];
assign pair_rb_robust_peak_height_253_w = pair_reference_robust_csrstorage28_storage_full[27:24];
assign pair_rb_robust_peak_height_252_w = pair_reference_robust_csrstorage28_storage_full[23:16];
assign pair_rb_robust_peak_height_251_w = pair_reference_robust_csrstorage28_storage_full[15:8];
assign pair_rb_robust_peak_height_250_w = pair_reference_robust_csrstorage28_storage_full[7:0];
assign pair_reference_robust_csrstorage29_storage = pair_reference_robust_csrstorage29_storage_full[27:0];
assign pair_rb_robust_peak_height_263_w = pair_reference_robust_csrstorage29_storage_full[27:24];
assign pair_rb_robust_peak_height_262_w = pair_reference_robust_csrstorage29_storage_full[23:16];
assign pair_rb_robust_peak_height_261_w = pair_reference_robust_csrstorage29_storage_full[15:8];
assign pair_rb_robust_peak_height_260_w = pair_reference_robust_csrstorage29_storage_full[7:0];
assign pair_reference_robust_csrstorage30_storage = pair_reference_robust_csrstorage30_storage_full[27:0];
assign pair_rb_robust_peak_height_273_w = pair_reference_robust_csrstorage30_storage_full[27:24];
assign pair_rb_robust_peak_height_272_w = pair_reference_robust_csrstorage30_storage_full[23:16];
assign pair_rb_robust_peak_height_271_w = pair_reference_robust_csrstorage30_storage_full[15:8];
assign pair_rb_robust_peak_height_270_w = pair_reference_robust_csrstorage30_storage_full[7:0];
assign pair_reference_robust_csrstorage31_storage = pair_reference_robust_csrstorage31_storage_full[27:0];
assign pair_rb_robust_peak_height_283_w = pair_reference_robust_csrstorage31_storage_full[27:24];
assign pair_rb_robust_peak_height_282_w = pair_reference_robust_csrstorage31_storage_full[23:16];
assign pair_rb_robust_peak_height_281_w = pair_reference_robust_csrstorage31_storage_full[15:8];
assign pair_rb_robust_peak_height_280_w = pair_reference_robust_csrstorage31_storage_full[7:0];
assign pair_reference_robust_csrstorage32_storage = pair_reference_robust_csrstorage32_storage_full[27:0];
assign pair_rb_robust_peak_height_293_w = pair_reference_robust_csrstorage32_storage_full[27:24];
assign pair_rb_robust_peak_height_292_w = pair_reference_robust_csrstorage32_storage_full[23:16];
assign pair_rb_robust_peak_height_291_w = pair_reference_robust_csrstorage32_storage_full[15:8];
assign pair_rb_robust_peak_height_290_w = pair_reference_robust_csrstorage32_storage_full[7:0];
assign pair_reference_robust_csrstorage33_storage = pair_reference_robust_csrstorage33_storage_full[27:0];
assign pair_rb_robust_peak_height_303_w = pair_reference_robust_csrstorage33_storage_full[27:24];
assign pair_rb_robust_peak_height_302_w = pair_reference_robust_csrstorage33_storage_full[23:16];
assign pair_rb_robust_peak_height_301_w = pair_reference_robust_csrstorage33_storage_full[15:8];
assign pair_rb_robust_peak_height_300_w = pair_reference_robust_csrstorage33_storage_full[7:0];
assign pair_reference_robust_csrstorage34_storage = pair_reference_robust_csrstorage34_storage_full[27:0];
assign pair_rb_robust_peak_height_313_w = pair_reference_robust_csrstorage34_storage_full[27:24];
assign pair_rb_robust_peak_height_312_w = pair_reference_robust_csrstorage34_storage_full[23:16];
assign pair_rb_robust_peak_height_311_w = pair_reference_robust_csrstorage34_storage_full[15:8];
assign pair_rb_robust_peak_height_310_w = pair_reference_robust_csrstorage34_storage_full[7:0];
assign pair_reference_robust_csrstorage35_storage = pair_reference_robust_csrstorage35_storage_full[13:0];
assign pair_rb_robust_wait_for_01_w = pair_reference_robust_csrstorage35_storage_full[13:8];
assign pair_rb_robust_wait_for_00_w = pair_reference_robust_csrstorage35_storage_full[7:0];
assign pair_reference_robust_csrstorage36_storage = pair_reference_robust_csrstorage36_storage_full[13:0];
assign pair_rb_robust_wait_for_11_w = pair_reference_robust_csrstorage36_storage_full[13:8];
assign pair_rb_robust_wait_for_10_w = pair_reference_robust_csrstorage36_storage_full[7:0];
assign pair_reference_robust_csrstorage37_storage = pair_reference_robust_csrstorage37_storage_full[13:0];
assign pair_rb_robust_wait_for_21_w = pair_reference_robust_csrstorage37_storage_full[13:8];
assign pair_rb_robust_wait_for_20_w = pair_reference_robust_csrstorage37_storage_full[7:0];
assign pair_reference_robust_csrstorage38_storage = pair_reference_robust_csrstorage38_storage_full[13:0];
assign pair_rb_robust_wait_for_31_w = pair_reference_robust_csrstorage38_storage_full[13:8];
assign pair_rb_robust_wait_for_30_w = pair_reference_robust_csrstorage38_storage_full[7:0];
assign pair_reference_robust_csrstorage39_storage = pair_reference_robust_csrstorage39_storage_full[13:0];
assign pair_rb_robust_wait_for_41_w = pair_reference_robust_csrstorage39_storage_full[13:8];
assign pair_rb_robust_wait_for_40_w = pair_reference_robust_csrstorage39_storage_full[7:0];
assign pair_reference_robust_csrstorage40_storage = pair_reference_robust_csrstorage40_storage_full[13:0];
assign pair_rb_robust_wait_for_51_w = pair_reference_robust_csrstorage40_storage_full[13:8];
assign pair_rb_robust_wait_for_50_w = pair_reference_robust_csrstorage40_storage_full[7:0];
assign pair_reference_robust_csrstorage41_storage = pair_reference_robust_csrstorage41_storage_full[13:0];
assign pair_rb_robust_wait_for_61_w = pair_reference_robust_csrstorage41_storage_full[13:8];
assign pair_rb_robust_wait_for_60_w = pair_reference_robust_csrstorage41_storage_full[7:0];
assign pair_reference_robust_csrstorage42_storage = pair_reference_robust_csrstorage42_storage_full[13:0];
assign pair_rb_robust_wait_for_71_w = pair_reference_robust_csrstorage42_storage_full[13:8];
assign pair_rb_robust_wait_for_70_w = pair_reference_robust_csrstorage42_storage_full[7:0];
assign pair_reference_robust_csrstorage43_storage = pair_reference_robust_csrstorage43_storage_full[13:0];
assign pair_rb_robust_wait_for_81_w = pair_reference_robust_csrstorage43_storage_full[13:8];
assign pair_rb_robust_wait_for_80_w = pair_reference_robust_csrstorage43_storage_full[7:0];
assign pair_reference_robust_csrstorage44_storage = pair_reference_robust_csrstorage44_storage_full[13:0];
assign pair_rb_robust_wait_for_91_w = pair_reference_robust_csrstorage44_storage_full[13:8];
assign pair_rb_robust_wait_for_90_w = pair_reference_robust_csrstorage44_storage_full[7:0];
assign pair_reference_robust_csrstorage45_storage = pair_reference_robust_csrstorage45_storage_full[13:0];
assign pair_rb_robust_wait_for_101_w = pair_reference_robust_csrstorage45_storage_full[13:8];
assign pair_rb_robust_wait_for_100_w = pair_reference_robust_csrstorage45_storage_full[7:0];
assign pair_reference_robust_csrstorage46_storage = pair_reference_robust_csrstorage46_storage_full[13:0];
assign pair_rb_robust_wait_for_111_w = pair_reference_robust_csrstorage46_storage_full[13:8];
assign pair_rb_robust_wait_for_110_w = pair_reference_robust_csrstorage46_storage_full[7:0];
assign pair_reference_robust_csrstorage47_storage = pair_reference_robust_csrstorage47_storage_full[13:0];
assign pair_rb_robust_wait_for_121_w = pair_reference_robust_csrstorage47_storage_full[13:8];
assign pair_rb_robust_wait_for_120_w = pair_reference_robust_csrstorage47_storage_full[7:0];
assign pair_reference_robust_csrstorage48_storage = pair_reference_robust_csrstorage48_storage_full[13:0];
assign pair_rb_robust_wait_for_131_w = pair_reference_robust_csrstorage48_storage_full[13:8];
assign pair_rb_robust_wait_for_130_w = pair_reference_robust_csrstorage48_storage_full[7:0];
assign pair_reference_robust_csrstorage49_storage = pair_reference_robust_csrstorage49_storage_full[13:0];
assign pair_rb_robust_wait_for_141_w = pair_reference_robust_csrstorage49_storage_full[13:8];
assign pair_rb_robust_wait_for_140_w = pair_reference_robust_csrstorage49_storage_full[7:0];
assign pair_reference_robust_csrstorage50_storage = pair_reference_robust_csrstorage50_storage_full[13:0];
assign pair_rb_robust_wait_for_151_w = pair_reference_robust_csrstorage50_storage_full[13:8];
assign pair_rb_robust_wait_for_150_w = pair_reference_robust_csrstorage50_storage_full[7:0];
assign pair_reference_robust_csrstorage51_storage = pair_reference_robust_csrstorage51_storage_full[13:0];
assign pair_rb_robust_wait_for_161_w = pair_reference_robust_csrstorage51_storage_full[13:8];
assign pair_rb_robust_wait_for_160_w = pair_reference_robust_csrstorage51_storage_full[7:0];
assign pair_reference_robust_csrstorage52_storage = pair_reference_robust_csrstorage52_storage_full[13:0];
assign pair_rb_robust_wait_for_171_w = pair_reference_robust_csrstorage52_storage_full[13:8];
assign pair_rb_robust_wait_for_170_w = pair_reference_robust_csrstorage52_storage_full[7:0];
assign pair_reference_robust_csrstorage53_storage = pair_reference_robust_csrstorage53_storage_full[13:0];
assign pair_rb_robust_wait_for_181_w = pair_reference_robust_csrstorage53_storage_full[13:8];
assign pair_rb_robust_wait_for_180_w = pair_reference_robust_csrstorage53_storage_full[7:0];
assign pair_reference_robust_csrstorage54_storage = pair_reference_robust_csrstorage54_storage_full[13:0];
assign pair_rb_robust_wait_for_191_w = pair_reference_robust_csrstorage54_storage_full[13:8];
assign pair_rb_robust_wait_for_190_w = pair_reference_robust_csrstorage54_storage_full[7:0];
assign pair_reference_robust_csrstorage55_storage = pair_reference_robust_csrstorage55_storage_full[13:0];
assign pair_rb_robust_wait_for_201_w = pair_reference_robust_csrstorage55_storage_full[13:8];
assign pair_rb_robust_wait_for_200_w = pair_reference_robust_csrstorage55_storage_full[7:0];
assign pair_reference_robust_csrstorage56_storage = pair_reference_robust_csrstorage56_storage_full[13:0];
assign pair_rb_robust_wait_for_211_w = pair_reference_robust_csrstorage56_storage_full[13:8];
assign pair_rb_robust_wait_for_210_w = pair_reference_robust_csrstorage56_storage_full[7:0];
assign pair_reference_robust_csrstorage57_storage = pair_reference_robust_csrstorage57_storage_full[13:0];
assign pair_rb_robust_wait_for_221_w = pair_reference_robust_csrstorage57_storage_full[13:8];
assign pair_rb_robust_wait_for_220_w = pair_reference_robust_csrstorage57_storage_full[7:0];
assign pair_reference_robust_csrstorage58_storage = pair_reference_robust_csrstorage58_storage_full[13:0];
assign pair_rb_robust_wait_for_231_w = pair_reference_robust_csrstorage58_storage_full[13:8];
assign pair_rb_robust_wait_for_230_w = pair_reference_robust_csrstorage58_storage_full[7:0];
assign pair_reference_robust_csrstorage59_storage = pair_reference_robust_csrstorage59_storage_full[13:0];
assign pair_rb_robust_wait_for_241_w = pair_reference_robust_csrstorage59_storage_full[13:8];
assign pair_rb_robust_wait_for_240_w = pair_reference_robust_csrstorage59_storage_full[7:0];
assign pair_reference_robust_csrstorage60_storage = pair_reference_robust_csrstorage60_storage_full[13:0];
assign pair_rb_robust_wait_for_251_w = pair_reference_robust_csrstorage60_storage_full[13:8];
assign pair_rb_robust_wait_for_250_w = pair_reference_robust_csrstorage60_storage_full[7:0];
assign pair_reference_robust_csrstorage61_storage = pair_reference_robust_csrstorage61_storage_full[13:0];
assign pair_rb_robust_wait_for_261_w = pair_reference_robust_csrstorage61_storage_full[13:8];
assign pair_rb_robust_wait_for_260_w = pair_reference_robust_csrstorage61_storage_full[7:0];
assign pair_reference_robust_csrstorage62_storage = pair_reference_robust_csrstorage62_storage_full[13:0];
assign pair_rb_robust_wait_for_271_w = pair_reference_robust_csrstorage62_storage_full[13:8];
assign pair_rb_robust_wait_for_270_w = pair_reference_robust_csrstorage62_storage_full[7:0];
assign pair_reference_robust_csrstorage63_storage = pair_reference_robust_csrstorage63_storage_full[13:0];
assign pair_rb_robust_wait_for_281_w = pair_reference_robust_csrstorage63_storage_full[13:8];
assign pair_rb_robust_wait_for_280_w = pair_reference_robust_csrstorage63_storage_full[7:0];
assign pair_reference_robust_csrstorage64_storage = pair_reference_robust_csrstorage64_storage_full[13:0];
assign pair_rb_robust_wait_for_291_w = pair_reference_robust_csrstorage64_storage_full[13:8];
assign pair_rb_robust_wait_for_290_w = pair_reference_robust_csrstorage64_storage_full[7:0];
assign pair_reference_robust_csrstorage65_storage = pair_reference_robust_csrstorage65_storage_full[13:0];
assign pair_rb_robust_wait_for_301_w = pair_reference_robust_csrstorage65_storage_full[13:8];
assign pair_rb_robust_wait_for_300_w = pair_reference_robust_csrstorage65_storage_full[7:0];
assign pair_reference_robust_csrstorage66_storage = pair_reference_robust_csrstorage66_storage_full[13:0];
assign pair_rb_robust_wait_for_311_w = pair_reference_robust_csrstorage66_storage_full[13:8];
assign pair_rb_robust_wait_for_310_w = pair_reference_robust_csrstorage66_storage_full[7:0];
assign pair_reference_fast_storage = pair_reference_fast_storage_full[13:0];
assign pair_rb_fast_target_position1_w = pair_reference_fast_storage_full[13:8];
assign pair_rb_fast_target_position0_w = pair_reference_fast_storage_full[7:0];
assign pair_reference_request_lock_storage = pair_reference_request_lock_storage_full;
assign pair_rb_request_lock0_w = pair_reference_request_lock_storage_full;
assign pair_reference_autolock_mode_storage = pair_reference_autolock_mode_storage_full[1:0];
assign pair_rb_autolock_mode0_w = pair_reference_autolock_mode_storage_full[1:0];
assign pair_rb_lock_running_w = pair_reference_status;
assign pair_cb_sel = (pair_cb_bus_adr[13:9] == 1'd0);
assign pair_cb_robust_time_scale1_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_time_scale1_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 1'd0));
assign pair_cb_robust_time_scale0_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_time_scale0_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 1'd1));
assign pair_cb_robust_N_instructions0_r = pair_cb_bus_dat_w[4:0];
assign pair_cb_robust_N_instructions0_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 2'd2));
assign pair_cb_robust_final_wait_time1_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_final_wait_time1_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 2'd3));
assign pair_cb_robust_final_wait_time0_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_final_wait_time0_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 3'd4));
assign pair_cb_robust_peak_height_03_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_03_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 3'd5));
assign pair_cb_robust_peak_height_02_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_02_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 3'd6));
assign pair_cb_robust_peak_height_01_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_01_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 3'd7));
assign pair_cb_robust_peak_height_00_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_00_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 4'd8));
assign pair_cb_robust_peak_height_13_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_13_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 4'd9));
assign pair_cb_robust_peak_height_12_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_12_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 4'd10));
assign pair_cb_robust_peak_height_11_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_11_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 4'd11));
assign pair_cb_robust_peak_height_10_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_10_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 4'd12));
assign pair_cb_robust_peak_height_23_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_23_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 4'd13));
assign pair_cb_robust_peak_height_22_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_22_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 4'd14));
assign pair_cb_robust_peak_height_21_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_21_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 4'd15));
assign pair_cb_robust_peak_height_20_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_20_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd16));
assign pair_cb_robust_peak_height_33_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_33_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd17));
assign pair_cb_robust_peak_height_32_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_32_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd18));
assign pair_cb_robust_peak_height_31_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_31_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd19));
assign pair_cb_robust_peak_height_30_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_30_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd20));
assign pair_cb_robust_peak_height_43_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_43_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd21));
assign pair_cb_robust_peak_height_42_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_42_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd22));
assign pair_cb_robust_peak_height_41_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_41_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd23));
assign pair_cb_robust_peak_height_40_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_40_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd24));
assign pair_cb_robust_peak_height_53_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_53_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd25));
assign pair_cb_robust_peak_height_52_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_52_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd26));
assign pair_cb_robust_peak_height_51_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_51_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd27));
assign pair_cb_robust_peak_height_50_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_50_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd28));
assign pair_cb_robust_peak_height_63_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_63_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd29));
assign pair_cb_robust_peak_height_62_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_62_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd30));
assign pair_cb_robust_peak_height_61_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_61_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 5'd31));
assign pair_cb_robust_peak_height_60_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_60_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd32));
assign pair_cb_robust_peak_height_73_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_73_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd33));
assign pair_cb_robust_peak_height_72_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_72_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd34));
assign pair_cb_robust_peak_height_71_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_71_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd35));
assign pair_cb_robust_peak_height_70_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_70_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd36));
assign pair_cb_robust_peak_height_83_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_83_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd37));
assign pair_cb_robust_peak_height_82_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_82_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd38));
assign pair_cb_robust_peak_height_81_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_81_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd39));
assign pair_cb_robust_peak_height_80_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_80_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd40));
assign pair_cb_robust_peak_height_93_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_93_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd41));
assign pair_cb_robust_peak_height_92_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_92_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd42));
assign pair_cb_robust_peak_height_91_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_91_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd43));
assign pair_cb_robust_peak_height_90_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_90_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd44));
assign pair_cb_robust_peak_height_103_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_103_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd45));
assign pair_cb_robust_peak_height_102_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_102_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd46));
assign pair_cb_robust_peak_height_101_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_101_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd47));
assign pair_cb_robust_peak_height_100_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_100_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd48));
assign pair_cb_robust_peak_height_113_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_113_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd49));
assign pair_cb_robust_peak_height_112_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_112_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd50));
assign pair_cb_robust_peak_height_111_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_111_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd51));
assign pair_cb_robust_peak_height_110_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_110_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd52));
assign pair_cb_robust_peak_height_123_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_123_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd53));
assign pair_cb_robust_peak_height_122_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_122_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd54));
assign pair_cb_robust_peak_height_121_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_121_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd55));
assign pair_cb_robust_peak_height_120_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_120_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd56));
assign pair_cb_robust_peak_height_133_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_133_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd57));
assign pair_cb_robust_peak_height_132_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_132_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd58));
assign pair_cb_robust_peak_height_131_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_131_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd59));
assign pair_cb_robust_peak_height_130_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_130_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd60));
assign pair_cb_robust_peak_height_143_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_143_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd61));
assign pair_cb_robust_peak_height_142_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_142_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd62));
assign pair_cb_robust_peak_height_141_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_141_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 6'd63));
assign pair_cb_robust_peak_height_140_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_140_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd64));
assign pair_cb_robust_peak_height_153_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_153_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd65));
assign pair_cb_robust_peak_height_152_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_152_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd66));
assign pair_cb_robust_peak_height_151_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_151_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd67));
assign pair_cb_robust_peak_height_150_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_150_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd68));
assign pair_cb_robust_peak_height_163_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_163_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd69));
assign pair_cb_robust_peak_height_162_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_162_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd70));
assign pair_cb_robust_peak_height_161_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_161_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd71));
assign pair_cb_robust_peak_height_160_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_160_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd72));
assign pair_cb_robust_peak_height_173_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_173_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd73));
assign pair_cb_robust_peak_height_172_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_172_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd74));
assign pair_cb_robust_peak_height_171_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_171_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd75));
assign pair_cb_robust_peak_height_170_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_170_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd76));
assign pair_cb_robust_peak_height_183_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_183_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd77));
assign pair_cb_robust_peak_height_182_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_182_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd78));
assign pair_cb_robust_peak_height_181_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_181_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd79));
assign pair_cb_robust_peak_height_180_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_180_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd80));
assign pair_cb_robust_peak_height_193_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_193_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd81));
assign pair_cb_robust_peak_height_192_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_192_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd82));
assign pair_cb_robust_peak_height_191_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_191_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd83));
assign pair_cb_robust_peak_height_190_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_190_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd84));
assign pair_cb_robust_peak_height_203_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_203_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd85));
assign pair_cb_robust_peak_height_202_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_202_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd86));
assign pair_cb_robust_peak_height_201_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_201_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd87));
assign pair_cb_robust_peak_height_200_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_200_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd88));
assign pair_cb_robust_peak_height_213_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_213_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd89));
assign pair_cb_robust_peak_height_212_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_212_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd90));
assign pair_cb_robust_peak_height_211_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_211_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd91));
assign pair_cb_robust_peak_height_210_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_210_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd92));
assign pair_cb_robust_peak_height_223_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_223_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd93));
assign pair_cb_robust_peak_height_222_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_222_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd94));
assign pair_cb_robust_peak_height_221_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_221_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd95));
assign pair_cb_robust_peak_height_220_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_220_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd96));
assign pair_cb_robust_peak_height_233_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_233_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd97));
assign pair_cb_robust_peak_height_232_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_232_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd98));
assign pair_cb_robust_peak_height_231_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_231_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd99));
assign pair_cb_robust_peak_height_230_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_230_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd100));
assign pair_cb_robust_peak_height_243_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_243_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd101));
assign pair_cb_robust_peak_height_242_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_242_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd102));
assign pair_cb_robust_peak_height_241_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_241_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd103));
assign pair_cb_robust_peak_height_240_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_240_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd104));
assign pair_cb_robust_peak_height_253_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_253_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd105));
assign pair_cb_robust_peak_height_252_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_252_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd106));
assign pair_cb_robust_peak_height_251_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_251_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd107));
assign pair_cb_robust_peak_height_250_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_250_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd108));
assign pair_cb_robust_peak_height_263_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_263_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd109));
assign pair_cb_robust_peak_height_262_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_262_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd110));
assign pair_cb_robust_peak_height_261_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_261_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd111));
assign pair_cb_robust_peak_height_260_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_260_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd112));
assign pair_cb_robust_peak_height_273_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_273_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd113));
assign pair_cb_robust_peak_height_272_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_272_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd114));
assign pair_cb_robust_peak_height_271_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_271_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd115));
assign pair_cb_robust_peak_height_270_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_270_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd116));
assign pair_cb_robust_peak_height_283_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_283_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd117));
assign pair_cb_robust_peak_height_282_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_282_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd118));
assign pair_cb_robust_peak_height_281_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_281_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd119));
assign pair_cb_robust_peak_height_280_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_280_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd120));
assign pair_cb_robust_peak_height_293_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_293_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd121));
assign pair_cb_robust_peak_height_292_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_292_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd122));
assign pair_cb_robust_peak_height_291_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_291_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd123));
assign pair_cb_robust_peak_height_290_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_290_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd124));
assign pair_cb_robust_peak_height_303_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_303_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd125));
assign pair_cb_robust_peak_height_302_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_302_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd126));
assign pair_cb_robust_peak_height_301_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_301_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 7'd127));
assign pair_cb_robust_peak_height_300_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_300_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd128));
assign pair_cb_robust_peak_height_313_r = pair_cb_bus_dat_w[3:0];
assign pair_cb_robust_peak_height_313_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd129));
assign pair_cb_robust_peak_height_312_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_312_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd130));
assign pair_cb_robust_peak_height_311_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_311_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd131));
assign pair_cb_robust_peak_height_310_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_peak_height_310_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd132));
assign pair_cb_robust_wait_for_01_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_01_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd133));
assign pair_cb_robust_wait_for_00_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_00_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd134));
assign pair_cb_robust_wait_for_11_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_11_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd135));
assign pair_cb_robust_wait_for_10_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_10_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd136));
assign pair_cb_robust_wait_for_21_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_21_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd137));
assign pair_cb_robust_wait_for_20_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_20_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd138));
assign pair_cb_robust_wait_for_31_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_31_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd139));
assign pair_cb_robust_wait_for_30_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_30_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd140));
assign pair_cb_robust_wait_for_41_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_41_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd141));
assign pair_cb_robust_wait_for_40_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_40_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd142));
assign pair_cb_robust_wait_for_51_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_51_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd143));
assign pair_cb_robust_wait_for_50_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_50_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd144));
assign pair_cb_robust_wait_for_61_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_61_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd145));
assign pair_cb_robust_wait_for_60_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_60_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd146));
assign pair_cb_robust_wait_for_71_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_71_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd147));
assign pair_cb_robust_wait_for_70_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_70_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd148));
assign pair_cb_robust_wait_for_81_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_81_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd149));
assign pair_cb_robust_wait_for_80_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_80_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd150));
assign pair_cb_robust_wait_for_91_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_91_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd151));
assign pair_cb_robust_wait_for_90_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_90_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd152));
assign pair_cb_robust_wait_for_101_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_101_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd153));
assign pair_cb_robust_wait_for_100_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_100_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd154));
assign pair_cb_robust_wait_for_111_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_111_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd155));
assign pair_cb_robust_wait_for_110_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_110_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd156));
assign pair_cb_robust_wait_for_121_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_121_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd157));
assign pair_cb_robust_wait_for_120_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_120_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd158));
assign pair_cb_robust_wait_for_131_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_131_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd159));
assign pair_cb_robust_wait_for_130_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_130_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd160));
assign pair_cb_robust_wait_for_141_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_141_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd161));
assign pair_cb_robust_wait_for_140_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_140_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd162));
assign pair_cb_robust_wait_for_151_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_151_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd163));
assign pair_cb_robust_wait_for_150_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_150_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd164));
assign pair_cb_robust_wait_for_161_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_161_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd165));
assign pair_cb_robust_wait_for_160_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_160_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd166));
assign pair_cb_robust_wait_for_171_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_171_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd167));
assign pair_cb_robust_wait_for_170_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_170_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd168));
assign pair_cb_robust_wait_for_181_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_181_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd169));
assign pair_cb_robust_wait_for_180_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_180_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd170));
assign pair_cb_robust_wait_for_191_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_191_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd171));
assign pair_cb_robust_wait_for_190_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_190_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd172));
assign pair_cb_robust_wait_for_201_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_201_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd173));
assign pair_cb_robust_wait_for_200_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_200_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd174));
assign pair_cb_robust_wait_for_211_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_211_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd175));
assign pair_cb_robust_wait_for_210_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_210_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd176));
assign pair_cb_robust_wait_for_221_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_221_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd177));
assign pair_cb_robust_wait_for_220_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_220_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd178));
assign pair_cb_robust_wait_for_231_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_231_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd179));
assign pair_cb_robust_wait_for_230_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_230_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd180));
assign pair_cb_robust_wait_for_241_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_241_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd181));
assign pair_cb_robust_wait_for_240_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_240_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd182));
assign pair_cb_robust_wait_for_251_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_251_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd183));
assign pair_cb_robust_wait_for_250_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_250_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd184));
assign pair_cb_robust_wait_for_261_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_261_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd185));
assign pair_cb_robust_wait_for_260_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_260_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd186));
assign pair_cb_robust_wait_for_271_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_271_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd187));
assign pair_cb_robust_wait_for_270_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_270_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd188));
assign pair_cb_robust_wait_for_281_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_281_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd189));
assign pair_cb_robust_wait_for_280_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_280_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd190));
assign pair_cb_robust_wait_for_291_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_291_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd191));
assign pair_cb_robust_wait_for_290_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_290_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd192));
assign pair_cb_robust_wait_for_301_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_301_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd193));
assign pair_cb_robust_wait_for_300_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_300_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd194));
assign pair_cb_robust_wait_for_311_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_robust_wait_for_311_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd195));
assign pair_cb_robust_wait_for_310_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_robust_wait_for_310_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd196));
assign pair_cb_fast_target_position1_r = pair_cb_bus_dat_w[5:0];
assign pair_cb_fast_target_position1_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd197));
assign pair_cb_fast_target_position0_r = pair_cb_bus_dat_w[7:0];
assign pair_cb_fast_target_position0_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd198));
assign pair_cb_request_lock0_r = pair_cb_bus_dat_w[0];
assign pair_cb_request_lock0_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd199));
assign pair_cb_autolock_mode0_r = pair_cb_bus_dat_w[1:0];
assign pair_cb_autolock_mode0_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd200));
assign pair_cb_lock_running_r = pair_cb_bus_dat_w[0];
assign pair_cb_lock_running_re = ((pair_cb_sel & pair_cb_bus_we) & (pair_cb_bus_adr[7:0] == 8'd201));
assign pair_candidate_pipelinedrobustautolock_time_scale_storage = pair_candidate_pipelinedrobustautolock_time_scale_storage_full[13:0];
assign pair_cb_robust_time_scale1_w = pair_candidate_pipelinedrobustautolock_time_scale_storage_full[13:8];
assign pair_cb_robust_time_scale0_w = pair_candidate_pipelinedrobustautolock_time_scale_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_N_instructions_storage = pair_candidate_pipelinedrobustautolock_N_instructions_storage_full[4:0];
assign pair_cb_robust_N_instructions0_w = pair_candidate_pipelinedrobustautolock_N_instructions_storage_full[4:0];
assign pair_candidate_pipelinedrobustautolock_final_wait_time_storage = pair_candidate_pipelinedrobustautolock_final_wait_time_storage_full[13:0];
assign pair_cb_robust_final_wait_time1_w = pair_candidate_pipelinedrobustautolock_final_wait_time_storage_full[13:8];
assign pair_cb_robust_final_wait_time0_w = pair_candidate_pipelinedrobustautolock_final_wait_time_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage0_storage = pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full[27:0];
assign pair_cb_robust_peak_height_03_w = pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full[27:24];
assign pair_cb_robust_peak_height_02_w = pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full[23:16];
assign pair_cb_robust_peak_height_01_w = pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full[15:8];
assign pair_cb_robust_peak_height_00_w = pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage1_storage = pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full[27:0];
assign pair_cb_robust_peak_height_13_w = pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full[27:24];
assign pair_cb_robust_peak_height_12_w = pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full[23:16];
assign pair_cb_robust_peak_height_11_w = pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full[15:8];
assign pair_cb_robust_peak_height_10_w = pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage2_storage = pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full[27:0];
assign pair_cb_robust_peak_height_23_w = pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full[27:24];
assign pair_cb_robust_peak_height_22_w = pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full[23:16];
assign pair_cb_robust_peak_height_21_w = pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full[15:8];
assign pair_cb_robust_peak_height_20_w = pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage3_storage = pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full[27:0];
assign pair_cb_robust_peak_height_33_w = pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full[27:24];
assign pair_cb_robust_peak_height_32_w = pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full[23:16];
assign pair_cb_robust_peak_height_31_w = pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full[15:8];
assign pair_cb_robust_peak_height_30_w = pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage4_storage = pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full[27:0];
assign pair_cb_robust_peak_height_43_w = pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full[27:24];
assign pair_cb_robust_peak_height_42_w = pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full[23:16];
assign pair_cb_robust_peak_height_41_w = pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full[15:8];
assign pair_cb_robust_peak_height_40_w = pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage5_storage = pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full[27:0];
assign pair_cb_robust_peak_height_53_w = pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full[27:24];
assign pair_cb_robust_peak_height_52_w = pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full[23:16];
assign pair_cb_robust_peak_height_51_w = pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full[15:8];
assign pair_cb_robust_peak_height_50_w = pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage6_storage = pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full[27:0];
assign pair_cb_robust_peak_height_63_w = pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full[27:24];
assign pair_cb_robust_peak_height_62_w = pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full[23:16];
assign pair_cb_robust_peak_height_61_w = pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full[15:8];
assign pair_cb_robust_peak_height_60_w = pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage7_storage = pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full[27:0];
assign pair_cb_robust_peak_height_73_w = pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full[27:24];
assign pair_cb_robust_peak_height_72_w = pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full[23:16];
assign pair_cb_robust_peak_height_71_w = pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full[15:8];
assign pair_cb_robust_peak_height_70_w = pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage8_storage = pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full[27:0];
assign pair_cb_robust_peak_height_83_w = pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full[27:24];
assign pair_cb_robust_peak_height_82_w = pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full[23:16];
assign pair_cb_robust_peak_height_81_w = pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full[15:8];
assign pair_cb_robust_peak_height_80_w = pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage9_storage = pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full[27:0];
assign pair_cb_robust_peak_height_93_w = pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full[27:24];
assign pair_cb_robust_peak_height_92_w = pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full[23:16];
assign pair_cb_robust_peak_height_91_w = pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full[15:8];
assign pair_cb_robust_peak_height_90_w = pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage10_storage = pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full[27:0];
assign pair_cb_robust_peak_height_103_w = pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full[27:24];
assign pair_cb_robust_peak_height_102_w = pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full[23:16];
assign pair_cb_robust_peak_height_101_w = pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full[15:8];
assign pair_cb_robust_peak_height_100_w = pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage11_storage = pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full[27:0];
assign pair_cb_robust_peak_height_113_w = pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full[27:24];
assign pair_cb_robust_peak_height_112_w = pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full[23:16];
assign pair_cb_robust_peak_height_111_w = pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full[15:8];
assign pair_cb_robust_peak_height_110_w = pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage12_storage = pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full[27:0];
assign pair_cb_robust_peak_height_123_w = pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full[27:24];
assign pair_cb_robust_peak_height_122_w = pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full[23:16];
assign pair_cb_robust_peak_height_121_w = pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full[15:8];
assign pair_cb_robust_peak_height_120_w = pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage13_storage = pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full[27:0];
assign pair_cb_robust_peak_height_133_w = pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full[27:24];
assign pair_cb_robust_peak_height_132_w = pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full[23:16];
assign pair_cb_robust_peak_height_131_w = pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full[15:8];
assign pair_cb_robust_peak_height_130_w = pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage14_storage = pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full[27:0];
assign pair_cb_robust_peak_height_143_w = pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full[27:24];
assign pair_cb_robust_peak_height_142_w = pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full[23:16];
assign pair_cb_robust_peak_height_141_w = pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full[15:8];
assign pair_cb_robust_peak_height_140_w = pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage15_storage = pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full[27:0];
assign pair_cb_robust_peak_height_153_w = pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full[27:24];
assign pair_cb_robust_peak_height_152_w = pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full[23:16];
assign pair_cb_robust_peak_height_151_w = pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full[15:8];
assign pair_cb_robust_peak_height_150_w = pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage16_storage = pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full[27:0];
assign pair_cb_robust_peak_height_163_w = pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full[27:24];
assign pair_cb_robust_peak_height_162_w = pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full[23:16];
assign pair_cb_robust_peak_height_161_w = pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full[15:8];
assign pair_cb_robust_peak_height_160_w = pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage17_storage = pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full[27:0];
assign pair_cb_robust_peak_height_173_w = pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full[27:24];
assign pair_cb_robust_peak_height_172_w = pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full[23:16];
assign pair_cb_robust_peak_height_171_w = pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full[15:8];
assign pair_cb_robust_peak_height_170_w = pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage18_storage = pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full[27:0];
assign pair_cb_robust_peak_height_183_w = pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full[27:24];
assign pair_cb_robust_peak_height_182_w = pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full[23:16];
assign pair_cb_robust_peak_height_181_w = pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full[15:8];
assign pair_cb_robust_peak_height_180_w = pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage19_storage = pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full[27:0];
assign pair_cb_robust_peak_height_193_w = pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full[27:24];
assign pair_cb_robust_peak_height_192_w = pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full[23:16];
assign pair_cb_robust_peak_height_191_w = pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full[15:8];
assign pair_cb_robust_peak_height_190_w = pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage20_storage = pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full[27:0];
assign pair_cb_robust_peak_height_203_w = pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full[27:24];
assign pair_cb_robust_peak_height_202_w = pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full[23:16];
assign pair_cb_robust_peak_height_201_w = pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full[15:8];
assign pair_cb_robust_peak_height_200_w = pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage21_storage = pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full[27:0];
assign pair_cb_robust_peak_height_213_w = pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full[27:24];
assign pair_cb_robust_peak_height_212_w = pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full[23:16];
assign pair_cb_robust_peak_height_211_w = pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full[15:8];
assign pair_cb_robust_peak_height_210_w = pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage22_storage = pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full[27:0];
assign pair_cb_robust_peak_height_223_w = pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full[27:24];
assign pair_cb_robust_peak_height_222_w = pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full[23:16];
assign pair_cb_robust_peak_height_221_w = pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full[15:8];
assign pair_cb_robust_peak_height_220_w = pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage23_storage = pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full[27:0];
assign pair_cb_robust_peak_height_233_w = pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full[27:24];
assign pair_cb_robust_peak_height_232_w = pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full[23:16];
assign pair_cb_robust_peak_height_231_w = pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full[15:8];
assign pair_cb_robust_peak_height_230_w = pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage24_storage = pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full[27:0];
assign pair_cb_robust_peak_height_243_w = pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full[27:24];
assign pair_cb_robust_peak_height_242_w = pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full[23:16];
assign pair_cb_robust_peak_height_241_w = pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full[15:8];
assign pair_cb_robust_peak_height_240_w = pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage25_storage = pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full[27:0];
assign pair_cb_robust_peak_height_253_w = pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full[27:24];
assign pair_cb_robust_peak_height_252_w = pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full[23:16];
assign pair_cb_robust_peak_height_251_w = pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full[15:8];
assign pair_cb_robust_peak_height_250_w = pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage26_storage = pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full[27:0];
assign pair_cb_robust_peak_height_263_w = pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full[27:24];
assign pair_cb_robust_peak_height_262_w = pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full[23:16];
assign pair_cb_robust_peak_height_261_w = pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full[15:8];
assign pair_cb_robust_peak_height_260_w = pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage27_storage = pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full[27:0];
assign pair_cb_robust_peak_height_273_w = pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full[27:24];
assign pair_cb_robust_peak_height_272_w = pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full[23:16];
assign pair_cb_robust_peak_height_271_w = pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full[15:8];
assign pair_cb_robust_peak_height_270_w = pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage28_storage = pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full[27:0];
assign pair_cb_robust_peak_height_283_w = pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full[27:24];
assign pair_cb_robust_peak_height_282_w = pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full[23:16];
assign pair_cb_robust_peak_height_281_w = pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full[15:8];
assign pair_cb_robust_peak_height_280_w = pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage29_storage = pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full[27:0];
assign pair_cb_robust_peak_height_293_w = pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full[27:24];
assign pair_cb_robust_peak_height_292_w = pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full[23:16];
assign pair_cb_robust_peak_height_291_w = pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full[15:8];
assign pair_cb_robust_peak_height_290_w = pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage30_storage = pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full[27:0];
assign pair_cb_robust_peak_height_303_w = pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full[27:24];
assign pair_cb_robust_peak_height_302_w = pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full[23:16];
assign pair_cb_robust_peak_height_301_w = pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full[15:8];
assign pair_cb_robust_peak_height_300_w = pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage31_storage = pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full[27:0];
assign pair_cb_robust_peak_height_313_w = pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full[27:24];
assign pair_cb_robust_peak_height_312_w = pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full[23:16];
assign pair_cb_robust_peak_height_311_w = pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full[15:8];
assign pair_cb_robust_peak_height_310_w = pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage32_storage = pair_candidate_pipelinedrobustautolock_csrstorage32_storage_full[13:0];
assign pair_cb_robust_wait_for_01_w = pair_candidate_pipelinedrobustautolock_csrstorage32_storage_full[13:8];
assign pair_cb_robust_wait_for_00_w = pair_candidate_pipelinedrobustautolock_csrstorage32_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage33_storage = pair_candidate_pipelinedrobustautolock_csrstorage33_storage_full[13:0];
assign pair_cb_robust_wait_for_11_w = pair_candidate_pipelinedrobustautolock_csrstorage33_storage_full[13:8];
assign pair_cb_robust_wait_for_10_w = pair_candidate_pipelinedrobustautolock_csrstorage33_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage34_storage = pair_candidate_pipelinedrobustautolock_csrstorage34_storage_full[13:0];
assign pair_cb_robust_wait_for_21_w = pair_candidate_pipelinedrobustautolock_csrstorage34_storage_full[13:8];
assign pair_cb_robust_wait_for_20_w = pair_candidate_pipelinedrobustautolock_csrstorage34_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage35_storage = pair_candidate_pipelinedrobustautolock_csrstorage35_storage_full[13:0];
assign pair_cb_robust_wait_for_31_w = pair_candidate_pipelinedrobustautolock_csrstorage35_storage_full[13:8];
assign pair_cb_robust_wait_for_30_w = pair_candidate_pipelinedrobustautolock_csrstorage35_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage36_storage = pair_candidate_pipelinedrobustautolock_csrstorage36_storage_full[13:0];
assign pair_cb_robust_wait_for_41_w = pair_candidate_pipelinedrobustautolock_csrstorage36_storage_full[13:8];
assign pair_cb_robust_wait_for_40_w = pair_candidate_pipelinedrobustautolock_csrstorage36_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage37_storage = pair_candidate_pipelinedrobustautolock_csrstorage37_storage_full[13:0];
assign pair_cb_robust_wait_for_51_w = pair_candidate_pipelinedrobustautolock_csrstorage37_storage_full[13:8];
assign pair_cb_robust_wait_for_50_w = pair_candidate_pipelinedrobustautolock_csrstorage37_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage38_storage = pair_candidate_pipelinedrobustautolock_csrstorage38_storage_full[13:0];
assign pair_cb_robust_wait_for_61_w = pair_candidate_pipelinedrobustautolock_csrstorage38_storage_full[13:8];
assign pair_cb_robust_wait_for_60_w = pair_candidate_pipelinedrobustautolock_csrstorage38_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage39_storage = pair_candidate_pipelinedrobustautolock_csrstorage39_storage_full[13:0];
assign pair_cb_robust_wait_for_71_w = pair_candidate_pipelinedrobustautolock_csrstorage39_storage_full[13:8];
assign pair_cb_robust_wait_for_70_w = pair_candidate_pipelinedrobustautolock_csrstorage39_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage40_storage = pair_candidate_pipelinedrobustautolock_csrstorage40_storage_full[13:0];
assign pair_cb_robust_wait_for_81_w = pair_candidate_pipelinedrobustautolock_csrstorage40_storage_full[13:8];
assign pair_cb_robust_wait_for_80_w = pair_candidate_pipelinedrobustautolock_csrstorage40_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage41_storage = pair_candidate_pipelinedrobustautolock_csrstorage41_storage_full[13:0];
assign pair_cb_robust_wait_for_91_w = pair_candidate_pipelinedrobustautolock_csrstorage41_storage_full[13:8];
assign pair_cb_robust_wait_for_90_w = pair_candidate_pipelinedrobustautolock_csrstorage41_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage42_storage = pair_candidate_pipelinedrobustautolock_csrstorage42_storage_full[13:0];
assign pair_cb_robust_wait_for_101_w = pair_candidate_pipelinedrobustautolock_csrstorage42_storage_full[13:8];
assign pair_cb_robust_wait_for_100_w = pair_candidate_pipelinedrobustautolock_csrstorage42_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage43_storage = pair_candidate_pipelinedrobustautolock_csrstorage43_storage_full[13:0];
assign pair_cb_robust_wait_for_111_w = pair_candidate_pipelinedrobustautolock_csrstorage43_storage_full[13:8];
assign pair_cb_robust_wait_for_110_w = pair_candidate_pipelinedrobustautolock_csrstorage43_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage44_storage = pair_candidate_pipelinedrobustautolock_csrstorage44_storage_full[13:0];
assign pair_cb_robust_wait_for_121_w = pair_candidate_pipelinedrobustautolock_csrstorage44_storage_full[13:8];
assign pair_cb_robust_wait_for_120_w = pair_candidate_pipelinedrobustautolock_csrstorage44_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage45_storage = pair_candidate_pipelinedrobustautolock_csrstorage45_storage_full[13:0];
assign pair_cb_robust_wait_for_131_w = pair_candidate_pipelinedrobustautolock_csrstorage45_storage_full[13:8];
assign pair_cb_robust_wait_for_130_w = pair_candidate_pipelinedrobustautolock_csrstorage45_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage46_storage = pair_candidate_pipelinedrobustautolock_csrstorage46_storage_full[13:0];
assign pair_cb_robust_wait_for_141_w = pair_candidate_pipelinedrobustautolock_csrstorage46_storage_full[13:8];
assign pair_cb_robust_wait_for_140_w = pair_candidate_pipelinedrobustautolock_csrstorage46_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage47_storage = pair_candidate_pipelinedrobustautolock_csrstorage47_storage_full[13:0];
assign pair_cb_robust_wait_for_151_w = pair_candidate_pipelinedrobustautolock_csrstorage47_storage_full[13:8];
assign pair_cb_robust_wait_for_150_w = pair_candidate_pipelinedrobustautolock_csrstorage47_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage48_storage = pair_candidate_pipelinedrobustautolock_csrstorage48_storage_full[13:0];
assign pair_cb_robust_wait_for_161_w = pair_candidate_pipelinedrobustautolock_csrstorage48_storage_full[13:8];
assign pair_cb_robust_wait_for_160_w = pair_candidate_pipelinedrobustautolock_csrstorage48_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage49_storage = pair_candidate_pipelinedrobustautolock_csrstorage49_storage_full[13:0];
assign pair_cb_robust_wait_for_171_w = pair_candidate_pipelinedrobustautolock_csrstorage49_storage_full[13:8];
assign pair_cb_robust_wait_for_170_w = pair_candidate_pipelinedrobustautolock_csrstorage49_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage50_storage = pair_candidate_pipelinedrobustautolock_csrstorage50_storage_full[13:0];
assign pair_cb_robust_wait_for_181_w = pair_candidate_pipelinedrobustautolock_csrstorage50_storage_full[13:8];
assign pair_cb_robust_wait_for_180_w = pair_candidate_pipelinedrobustautolock_csrstorage50_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage51_storage = pair_candidate_pipelinedrobustautolock_csrstorage51_storage_full[13:0];
assign pair_cb_robust_wait_for_191_w = pair_candidate_pipelinedrobustautolock_csrstorage51_storage_full[13:8];
assign pair_cb_robust_wait_for_190_w = pair_candidate_pipelinedrobustautolock_csrstorage51_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage52_storage = pair_candidate_pipelinedrobustautolock_csrstorage52_storage_full[13:0];
assign pair_cb_robust_wait_for_201_w = pair_candidate_pipelinedrobustautolock_csrstorage52_storage_full[13:8];
assign pair_cb_robust_wait_for_200_w = pair_candidate_pipelinedrobustautolock_csrstorage52_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage53_storage = pair_candidate_pipelinedrobustautolock_csrstorage53_storage_full[13:0];
assign pair_cb_robust_wait_for_211_w = pair_candidate_pipelinedrobustautolock_csrstorage53_storage_full[13:8];
assign pair_cb_robust_wait_for_210_w = pair_candidate_pipelinedrobustautolock_csrstorage53_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage54_storage = pair_candidate_pipelinedrobustautolock_csrstorage54_storage_full[13:0];
assign pair_cb_robust_wait_for_221_w = pair_candidate_pipelinedrobustautolock_csrstorage54_storage_full[13:8];
assign pair_cb_robust_wait_for_220_w = pair_candidate_pipelinedrobustautolock_csrstorage54_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage55_storage = pair_candidate_pipelinedrobustautolock_csrstorage55_storage_full[13:0];
assign pair_cb_robust_wait_for_231_w = pair_candidate_pipelinedrobustautolock_csrstorage55_storage_full[13:8];
assign pair_cb_robust_wait_for_230_w = pair_candidate_pipelinedrobustautolock_csrstorage55_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage56_storage = pair_candidate_pipelinedrobustautolock_csrstorage56_storage_full[13:0];
assign pair_cb_robust_wait_for_241_w = pair_candidate_pipelinedrobustautolock_csrstorage56_storage_full[13:8];
assign pair_cb_robust_wait_for_240_w = pair_candidate_pipelinedrobustautolock_csrstorage56_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage57_storage = pair_candidate_pipelinedrobustautolock_csrstorage57_storage_full[13:0];
assign pair_cb_robust_wait_for_251_w = pair_candidate_pipelinedrobustautolock_csrstorage57_storage_full[13:8];
assign pair_cb_robust_wait_for_250_w = pair_candidate_pipelinedrobustautolock_csrstorage57_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage58_storage = pair_candidate_pipelinedrobustautolock_csrstorage58_storage_full[13:0];
assign pair_cb_robust_wait_for_261_w = pair_candidate_pipelinedrobustautolock_csrstorage58_storage_full[13:8];
assign pair_cb_robust_wait_for_260_w = pair_candidate_pipelinedrobustautolock_csrstorage58_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage59_storage = pair_candidate_pipelinedrobustautolock_csrstorage59_storage_full[13:0];
assign pair_cb_robust_wait_for_271_w = pair_candidate_pipelinedrobustautolock_csrstorage59_storage_full[13:8];
assign pair_cb_robust_wait_for_270_w = pair_candidate_pipelinedrobustautolock_csrstorage59_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage60_storage = pair_candidate_pipelinedrobustautolock_csrstorage60_storage_full[13:0];
assign pair_cb_robust_wait_for_281_w = pair_candidate_pipelinedrobustautolock_csrstorage60_storage_full[13:8];
assign pair_cb_robust_wait_for_280_w = pair_candidate_pipelinedrobustautolock_csrstorage60_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage61_storage = pair_candidate_pipelinedrobustautolock_csrstorage61_storage_full[13:0];
assign pair_cb_robust_wait_for_291_w = pair_candidate_pipelinedrobustautolock_csrstorage61_storage_full[13:8];
assign pair_cb_robust_wait_for_290_w = pair_candidate_pipelinedrobustautolock_csrstorage61_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage62_storage = pair_candidate_pipelinedrobustautolock_csrstorage62_storage_full[13:0];
assign pair_cb_robust_wait_for_301_w = pair_candidate_pipelinedrobustautolock_csrstorage62_storage_full[13:8];
assign pair_cb_robust_wait_for_300_w = pair_candidate_pipelinedrobustautolock_csrstorage62_storage_full[7:0];
assign pair_candidate_pipelinedrobustautolock_csrstorage63_storage = pair_candidate_pipelinedrobustautolock_csrstorage63_storage_full[13:0];
assign pair_cb_robust_wait_for_311_w = pair_candidate_pipelinedrobustautolock_csrstorage63_storage_full[13:8];
assign pair_cb_robust_wait_for_310_w = pair_candidate_pipelinedrobustautolock_csrstorage63_storage_full[7:0];
assign pair_candidate_fast_storage = pair_candidate_fast_storage_full[13:0];
assign pair_cb_fast_target_position1_w = pair_candidate_fast_storage_full[13:8];
assign pair_cb_fast_target_position0_w = pair_candidate_fast_storage_full[7:0];
assign pair_candidate_request_lock_storage = pair_candidate_request_lock_storage_full;
assign pair_cb_request_lock0_w = pair_candidate_request_lock_storage_full;
assign pair_candidate_autolock_mode_storage = pair_candidate_autolock_mode_storage_full[1:0];
assign pair_cb_autolock_mode0_w = pair_candidate_autolock_mode_storage_full[1:0];
assign pair_cb_lock_running_w = pair_candidate_status;

// synthesis translate_off
reg dummy_d_40;
// synthesis translate_on
always @(*) begin
	array_muxed0 <= 28'd0;
	case (pair_reference_robust_current_instruction_idx)
		1'd0: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage0;
		end
		1'd1: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage1;
		end
		2'd2: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage2;
		end
		2'd3: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage3;
		end
		3'd4: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage4;
		end
		3'd5: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage5;
		end
		3'd6: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage6;
		end
		3'd7: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage7;
		end
		4'd8: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage8;
		end
		4'd9: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage9;
		end
		4'd10: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage10;
		end
		4'd11: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage11;
		end
		4'd12: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage12;
		end
		4'd13: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage13;
		end
		4'd14: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage14;
		end
		4'd15: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage15;
		end
		5'd16: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage16;
		end
		5'd17: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage17;
		end
		5'd18: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage18;
		end
		5'd19: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage19;
		end
		5'd20: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage20;
		end
		5'd21: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage21;
		end
		5'd22: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage22;
		end
		5'd23: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage23;
		end
		5'd24: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage24;
		end
		5'd25: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage25;
		end
		5'd26: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage26;
		end
		5'd27: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage27;
		end
		5'd28: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage28;
		end
		5'd29: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage29;
		end
		5'd30: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage30;
		end
		default: begin
			array_muxed0 <= pair_reference_robust_csrstorage_storage31;
		end
	endcase
// synthesis translate_off
	dummy_d_40 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_41;
// synthesis translate_on
always @(*) begin
	array_muxed1 <= 14'd0;
	case (pair_reference_robust_current_instruction_idx)
		1'd0: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage32;
		end
		1'd1: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage33;
		end
		2'd2: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage34;
		end
		2'd3: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage35;
		end
		3'd4: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage36;
		end
		3'd5: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage37;
		end
		3'd6: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage38;
		end
		3'd7: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage39;
		end
		4'd8: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage40;
		end
		4'd9: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage41;
		end
		4'd10: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage42;
		end
		4'd11: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage43;
		end
		4'd12: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage44;
		end
		4'd13: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage45;
		end
		4'd14: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage46;
		end
		4'd15: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage47;
		end
		5'd16: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage48;
		end
		5'd17: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage49;
		end
		5'd18: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage50;
		end
		5'd19: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage51;
		end
		5'd20: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage52;
		end
		5'd21: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage53;
		end
		5'd22: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage54;
		end
		5'd23: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage55;
		end
		5'd24: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage56;
		end
		5'd25: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage57;
		end
		5'd26: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage58;
		end
		5'd27: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage59;
		end
		5'd28: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage60;
		end
		5'd29: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage61;
		end
		5'd30: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage62;
		end
		default: begin
			array_muxed1 <= pair_reference_robust_csrstorage_storage63;
		end
	endcase
// synthesis translate_off
	dummy_d_41 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_42;
// synthesis translate_on
always @(*) begin
	array_muxed2 <= 28'd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx)
		1'd0: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage0_storage;
		end
		1'd1: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage1_storage;
		end
		2'd2: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage2_storage;
		end
		2'd3: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage3_storage;
		end
		3'd4: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage4_storage;
		end
		3'd5: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage5_storage;
		end
		3'd6: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage6_storage;
		end
		3'd7: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage7_storage;
		end
		4'd8: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage8_storage;
		end
		4'd9: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage9_storage;
		end
		4'd10: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage10_storage;
		end
		4'd11: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage11_storage;
		end
		4'd12: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage12_storage;
		end
		4'd13: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage13_storage;
		end
		4'd14: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage14_storage;
		end
		4'd15: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage15_storage;
		end
		5'd16: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage16_storage;
		end
		5'd17: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage17_storage;
		end
		5'd18: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage18_storage;
		end
		5'd19: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage19_storage;
		end
		5'd20: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage20_storage;
		end
		5'd21: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage21_storage;
		end
		5'd22: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage22_storage;
		end
		5'd23: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage23_storage;
		end
		5'd24: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage24_storage;
		end
		5'd25: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage25_storage;
		end
		5'd26: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage26_storage;
		end
		5'd27: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage27_storage;
		end
		5'd28: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage28_storage;
		end
		5'd29: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage29_storage;
		end
		5'd30: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage30_storage;
		end
		default: begin
			array_muxed2 <= pair_candidate_pipelinedrobustautolock_csrstorage31_storage;
		end
	endcase
// synthesis translate_off
	dummy_d_42 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_43;
// synthesis translate_on
always @(*) begin
	array_muxed3 <= 14'd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx)
		1'd0: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value0;
		end
		1'd1: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value1;
		end
		2'd2: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value2;
		end
		2'd3: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value3;
		end
		3'd4: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value4;
		end
		3'd5: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value5;
		end
		3'd6: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value6;
		end
		3'd7: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value7;
		end
		4'd8: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value8;
		end
		4'd9: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value9;
		end
		4'd10: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value10;
		end
		4'd11: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value11;
		end
		4'd12: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value12;
		end
		4'd13: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value13;
		end
		4'd14: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value14;
		end
		4'd15: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value15;
		end
		5'd16: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value16;
		end
		5'd17: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value17;
		end
		5'd18: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value18;
		end
		5'd19: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value19;
		end
		5'd20: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value20;
		end
		5'd21: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value21;
		end
		5'd22: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value22;
		end
		5'd23: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value23;
		end
		5'd24: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value24;
		end
		5'd25: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value25;
		end
		5'd26: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value26;
		end
		5'd27: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value27;
		end
		5'd28: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value28;
		end
		5'd29: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value29;
		end
		5'd30: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value30;
		end
		default: begin
			array_muxed3 <= pair_candidate_pipelinedrobustautolock_value31;
		end
	endcase
// synthesis translate_off
	dummy_d_43 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_44;
// synthesis translate_on
always @(*) begin
	array_muxed4 <= 28'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx)
		1'd0: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude0;
		end
		1'd1: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude1;
		end
		2'd2: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude2;
		end
		2'd3: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude3;
		end
		3'd4: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude4;
		end
		3'd5: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude5;
		end
		3'd6: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude6;
		end
		3'd7: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude7;
		end
		4'd8: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude8;
		end
		4'd9: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude9;
		end
		4'd10: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude10;
		end
		4'd11: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude11;
		end
		4'd12: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude12;
		end
		4'd13: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude13;
		end
		4'd14: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude14;
		end
		4'd15: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude15;
		end
		5'd16: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude16;
		end
		5'd17: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude17;
		end
		5'd18: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude18;
		end
		5'd19: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude19;
		end
		5'd20: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude20;
		end
		5'd21: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude21;
		end
		5'd22: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude22;
		end
		5'd23: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude23;
		end
		5'd24: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude24;
		end
		5'd25: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude25;
		end
		5'd26: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude26;
		end
		5'd27: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude27;
		end
		5'd28: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude28;
		end
		5'd29: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude29;
		end
		5'd30: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude30;
		end
		default: begin
			array_muxed4 <= pair_candidate_pipelinedrobustautolock_magnitude31;
		end
	endcase
// synthesis translate_off
	dummy_d_44 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_45;
// synthesis translate_on
always @(*) begin
	array_muxed5 <= 1'd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx)
		1'd0: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive0;
		end
		1'd1: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive1;
		end
		2'd2: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive2;
		end
		2'd3: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive3;
		end
		3'd4: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive4;
		end
		3'd5: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive5;
		end
		3'd6: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive6;
		end
		3'd7: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive7;
		end
		4'd8: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive8;
		end
		4'd9: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive9;
		end
		4'd10: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive10;
		end
		4'd11: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive11;
		end
		4'd12: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive12;
		end
		4'd13: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive13;
		end
		4'd14: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive14;
		end
		4'd15: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive15;
		end
		5'd16: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive16;
		end
		5'd17: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive17;
		end
		5'd18: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive18;
		end
		5'd19: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive19;
		end
		5'd20: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive20;
		end
		5'd21: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive21;
		end
		5'd22: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive22;
		end
		5'd23: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive23;
		end
		5'd24: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive24;
		end
		5'd25: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive25;
		end
		5'd26: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive26;
		end
		5'd27: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive27;
		end
		5'd28: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive28;
		end
		5'd29: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive29;
		end
		5'd30: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive30;
		end
		default: begin
			array_muxed5 <= pair_candidate_pipelinedrobustautolock_positive31;
		end
	endcase
// synthesis translate_off
	dummy_d_45 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_46;
// synthesis translate_on
always @(*) begin
	array_muxed6 <= 29'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx)
		1'd0: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative0;
		end
		1'd1: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative1;
		end
		2'd2: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative2;
		end
		2'd3: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative3;
		end
		3'd4: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative4;
		end
		3'd5: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative5;
		end
		3'd6: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative6;
		end
		3'd7: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative7;
		end
		4'd8: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative8;
		end
		4'd9: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative9;
		end
		4'd10: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative10;
		end
		4'd11: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative11;
		end
		4'd12: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative12;
		end
		4'd13: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative13;
		end
		4'd14: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative14;
		end
		4'd15: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative15;
		end
		5'd16: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative16;
		end
		5'd17: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative17;
		end
		5'd18: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative18;
		end
		5'd19: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative19;
		end
		5'd20: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative20;
		end
		5'd21: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative21;
		end
		5'd22: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative22;
		end
		5'd23: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative23;
		end
		5'd24: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative24;
		end
		5'd25: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative25;
		end
		5'd26: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative26;
		end
		5'd27: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative27;
		end
		5'd28: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative28;
		end
		5'd29: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative29;
		end
		5'd30: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative30;
		end
		default: begin
			array_muxed6 <= pair_candidate_pipelinedrobustautolock_negative31;
		end
	endcase
// synthesis translate_off
	dummy_d_46 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_47;
// synthesis translate_on
always @(*) begin
	array_muxed7 <= 28'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed7 <= pair_candidate_pipelinedrobustautolock_magnitude0;
		end
		1'd1: begin
			array_muxed7 <= pair_candidate_pipelinedrobustautolock_magnitude8;
		end
		2'd2: begin
			array_muxed7 <= pair_candidate_pipelinedrobustautolock_magnitude16;
		end
		default: begin
			array_muxed7 <= pair_candidate_pipelinedrobustautolock_magnitude24;
		end
	endcase
// synthesis translate_off
	dummy_d_47 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_48;
// synthesis translate_on
always @(*) begin
	array_muxed8 <= 29'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed8 <= pair_candidate_pipelinedrobustautolock_negative0;
		end
		1'd1: begin
			array_muxed8 <= pair_candidate_pipelinedrobustautolock_negative8;
		end
		2'd2: begin
			array_muxed8 <= pair_candidate_pipelinedrobustautolock_negative16;
		end
		default: begin
			array_muxed8 <= pair_candidate_pipelinedrobustautolock_negative24;
		end
	endcase
// synthesis translate_off
	dummy_d_48 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_49;
// synthesis translate_on
always @(*) begin
	array_muxed9 <= 28'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed9 <= pair_candidate_pipelinedrobustautolock_magnitude1;
		end
		1'd1: begin
			array_muxed9 <= pair_candidate_pipelinedrobustautolock_magnitude9;
		end
		2'd2: begin
			array_muxed9 <= pair_candidate_pipelinedrobustautolock_magnitude17;
		end
		default: begin
			array_muxed9 <= pair_candidate_pipelinedrobustautolock_magnitude25;
		end
	endcase
// synthesis translate_off
	dummy_d_49 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_50;
// synthesis translate_on
always @(*) begin
	array_muxed10 <= 29'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed10 <= pair_candidate_pipelinedrobustautolock_negative1;
		end
		1'd1: begin
			array_muxed10 <= pair_candidate_pipelinedrobustautolock_negative9;
		end
		2'd2: begin
			array_muxed10 <= pair_candidate_pipelinedrobustautolock_negative17;
		end
		default: begin
			array_muxed10 <= pair_candidate_pipelinedrobustautolock_negative25;
		end
	endcase
// synthesis translate_off
	dummy_d_50 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_51;
// synthesis translate_on
always @(*) begin
	array_muxed11 <= 28'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed11 <= pair_candidate_pipelinedrobustautolock_magnitude2;
		end
		1'd1: begin
			array_muxed11 <= pair_candidate_pipelinedrobustautolock_magnitude10;
		end
		2'd2: begin
			array_muxed11 <= pair_candidate_pipelinedrobustautolock_magnitude18;
		end
		default: begin
			array_muxed11 <= pair_candidate_pipelinedrobustautolock_magnitude26;
		end
	endcase
// synthesis translate_off
	dummy_d_51 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_52;
// synthesis translate_on
always @(*) begin
	array_muxed12 <= 29'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed12 <= pair_candidate_pipelinedrobustautolock_negative2;
		end
		1'd1: begin
			array_muxed12 <= pair_candidate_pipelinedrobustautolock_negative10;
		end
		2'd2: begin
			array_muxed12 <= pair_candidate_pipelinedrobustautolock_negative18;
		end
		default: begin
			array_muxed12 <= pair_candidate_pipelinedrobustautolock_negative26;
		end
	endcase
// synthesis translate_off
	dummy_d_52 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_53;
// synthesis translate_on
always @(*) begin
	array_muxed13 <= 28'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed13 <= pair_candidate_pipelinedrobustautolock_magnitude3;
		end
		1'd1: begin
			array_muxed13 <= pair_candidate_pipelinedrobustautolock_magnitude11;
		end
		2'd2: begin
			array_muxed13 <= pair_candidate_pipelinedrobustautolock_magnitude19;
		end
		default: begin
			array_muxed13 <= pair_candidate_pipelinedrobustautolock_magnitude27;
		end
	endcase
// synthesis translate_off
	dummy_d_53 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_54;
// synthesis translate_on
always @(*) begin
	array_muxed14 <= 29'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed14 <= pair_candidate_pipelinedrobustautolock_negative3;
		end
		1'd1: begin
			array_muxed14 <= pair_candidate_pipelinedrobustautolock_negative11;
		end
		2'd2: begin
			array_muxed14 <= pair_candidate_pipelinedrobustautolock_negative19;
		end
		default: begin
			array_muxed14 <= pair_candidate_pipelinedrobustautolock_negative27;
		end
	endcase
// synthesis translate_off
	dummy_d_54 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_55;
// synthesis translate_on
always @(*) begin
	array_muxed15 <= 28'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed15 <= pair_candidate_pipelinedrobustautolock_magnitude4;
		end
		1'd1: begin
			array_muxed15 <= pair_candidate_pipelinedrobustautolock_magnitude12;
		end
		2'd2: begin
			array_muxed15 <= pair_candidate_pipelinedrobustautolock_magnitude20;
		end
		default: begin
			array_muxed15 <= pair_candidate_pipelinedrobustautolock_magnitude28;
		end
	endcase
// synthesis translate_off
	dummy_d_55 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_56;
// synthesis translate_on
always @(*) begin
	array_muxed16 <= 29'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed16 <= pair_candidate_pipelinedrobustautolock_negative4;
		end
		1'd1: begin
			array_muxed16 <= pair_candidate_pipelinedrobustautolock_negative12;
		end
		2'd2: begin
			array_muxed16 <= pair_candidate_pipelinedrobustautolock_negative20;
		end
		default: begin
			array_muxed16 <= pair_candidate_pipelinedrobustautolock_negative28;
		end
	endcase
// synthesis translate_off
	dummy_d_56 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_57;
// synthesis translate_on
always @(*) begin
	array_muxed17 <= 28'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed17 <= pair_candidate_pipelinedrobustautolock_magnitude5;
		end
		1'd1: begin
			array_muxed17 <= pair_candidate_pipelinedrobustautolock_magnitude13;
		end
		2'd2: begin
			array_muxed17 <= pair_candidate_pipelinedrobustautolock_magnitude21;
		end
		default: begin
			array_muxed17 <= pair_candidate_pipelinedrobustautolock_magnitude29;
		end
	endcase
// synthesis translate_off
	dummy_d_57 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_58;
// synthesis translate_on
always @(*) begin
	array_muxed18 <= 29'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed18 <= pair_candidate_pipelinedrobustautolock_negative5;
		end
		1'd1: begin
			array_muxed18 <= pair_candidate_pipelinedrobustautolock_negative13;
		end
		2'd2: begin
			array_muxed18 <= pair_candidate_pipelinedrobustautolock_negative21;
		end
		default: begin
			array_muxed18 <= pair_candidate_pipelinedrobustautolock_negative29;
		end
	endcase
// synthesis translate_off
	dummy_d_58 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_59;
// synthesis translate_on
always @(*) begin
	array_muxed19 <= 28'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed19 <= pair_candidate_pipelinedrobustautolock_magnitude6;
		end
		1'd1: begin
			array_muxed19 <= pair_candidate_pipelinedrobustautolock_magnitude14;
		end
		2'd2: begin
			array_muxed19 <= pair_candidate_pipelinedrobustautolock_magnitude22;
		end
		default: begin
			array_muxed19 <= pair_candidate_pipelinedrobustautolock_magnitude30;
		end
	endcase
// synthesis translate_off
	dummy_d_59 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_60;
// synthesis translate_on
always @(*) begin
	array_muxed20 <= 29'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed20 <= pair_candidate_pipelinedrobustautolock_negative6;
		end
		1'd1: begin
			array_muxed20 <= pair_candidate_pipelinedrobustautolock_negative14;
		end
		2'd2: begin
			array_muxed20 <= pair_candidate_pipelinedrobustautolock_negative22;
		end
		default: begin
			array_muxed20 <= pair_candidate_pipelinedrobustautolock_negative30;
		end
	endcase
// synthesis translate_off
	dummy_d_60 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_61;
// synthesis translate_on
always @(*) begin
	array_muxed21 <= 28'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed21 <= pair_candidate_pipelinedrobustautolock_magnitude7;
		end
		1'd1: begin
			array_muxed21 <= pair_candidate_pipelinedrobustautolock_magnitude15;
		end
		2'd2: begin
			array_muxed21 <= pair_candidate_pipelinedrobustautolock_magnitude23;
		end
		default: begin
			array_muxed21 <= pair_candidate_pipelinedrobustautolock_magnitude31;
		end
	endcase
// synthesis translate_off
	dummy_d_61 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_62;
// synthesis translate_on
always @(*) begin
	array_muxed22 <= 29'sd0;
	case (pair_candidate_pipelinedrobustautolock_current_instruction_idx[4:3])
		1'd0: begin
			array_muxed22 <= pair_candidate_pipelinedrobustautolock_negative7;
		end
		1'd1: begin
			array_muxed22 <= pair_candidate_pipelinedrobustautolock_negative15;
		end
		2'd2: begin
			array_muxed22 <= pair_candidate_pipelinedrobustautolock_negative23;
		end
		default: begin
			array_muxed22 <= pair_candidate_pipelinedrobustautolock_negative31;
		end
	endcase
// synthesis translate_off
	dummy_d_62 <= dummy_s;
// synthesis translate_on
end

always @(posedge sys_clk) begin
	pair_pair0 <= pair_candidate_pipelinedrobustautolock_sum_value;
	pair_pair1 <= pair_candidate_pipelinedrobustautolock_counter;
	pair_pair_q <= pair_candidate_pipelinedrobustautolock_counter_delayed;
	pair_pair2 <= pair_candidate_pipelinedrobustautolock_output0;
	if ((~pair_reference_request_lock_storage)) begin
		pair_reference_status <= 1'd0;
	end
	if (((pair_reference_request_lock_storage & pair_reference_fast_turn_on_lock) & (pair_reference_autolock_mode_storage == 2'd2))) begin
		pair_reference_status <= 1'd1;
	end
	if (((pair_reference_request_lock_storage & pair_reference_robust_turn_on_lock) & (pair_reference_autolock_mode_storage == 1'd1))) begin
		pair_reference_status <= 1'd1;
	end
	if (pair_reference_robust_at_start) begin
		pair_reference_robust_waited_for <= 1'd0;
		pair_reference_robust_final_waited_for <= 2'd3;
		pair_reference_robust_current_instruction_idx <= 1'd0;
		if (pair_reference_robust_request_lock) begin
			pair_reference_robust_watching <= 1'd1;
		end else begin
			pair_reference_robust_watching <= 1'd0;
		end
	end else begin
		if ((~pair_reference_robust_request_lock)) begin
			pair_reference_robust_watching <= 1'd0;
		end
		if (((pair_reference_robust_writing_data_now2 & (~pair_reference_robust_all_instructions_triggered)) & pair_reference_robust_sweep_up)) begin
			if ((((pair_reference_robust_watching & pair_reference_robust_sign_equal) & pair_reference_robust_over_threshold) & pair_reference_robust_waited_long_enough)) begin
				pair_reference_robust_current_instruction_idx <= (pair_reference_robust_current_instruction_idx + 1'd1);
				pair_reference_robust_waited_for <= 1'd0;
			end else begin
				pair_reference_robust_waited_for <= (pair_reference_robust_waited_for + 1'd1);
			end
		end
		if (((pair_reference_robust_writing_data_now2 & pair_reference_robust_all_instructions_triggered) & pair_reference_robust_sweep_up)) begin
			pair_reference_robust_final_waited_for <= (pair_reference_robust_final_waited_for + 1'd1);
		end
	end
	pair_reference_robust_q0 <= pair_reference_robust_public0;
	pair_reference_robust_q1 <= pair_reference_robust_public1;
	pair_reference_robust_q2 <= pair_reference_robust_public2;
	pair_reference_robust_q3 <= pair_reference_robust_public3;
	pair_reference_robust_q4 <= pair_reference_robust_public4;
	pair_reference_robust_q5 <= pair_reference_robust_csrstorage0_storage;
	pair_reference_robust_q6 <= pair_reference_robust_csrstorage1_storage;
	pair_reference_robust_q7 <= pair_reference_robust_csrstorage2_storage;
	pair_reference_robust_q8 <= pair_reference_robust_csrstorage3_storage;
	pair_reference_robust_q9 <= pair_reference_robust_csrstorage4_storage;
	pair_reference_robust_q10 <= pair_reference_robust_csrstorage5_storage;
	pair_reference_robust_q11 <= pair_reference_robust_csrstorage6_storage;
	pair_reference_robust_q12 <= pair_reference_robust_csrstorage7_storage;
	pair_reference_robust_q13 <= pair_reference_robust_csrstorage8_storage;
	pair_reference_robust_q14 <= pair_reference_robust_csrstorage9_storage;
	pair_reference_robust_q15 <= pair_reference_robust_csrstorage10_storage;
	pair_reference_robust_q16 <= pair_reference_robust_csrstorage11_storage;
	pair_reference_robust_q17 <= pair_reference_robust_csrstorage12_storage;
	pair_reference_robust_q18 <= pair_reference_robust_csrstorage13_storage;
	pair_reference_robust_q19 <= pair_reference_robust_csrstorage14_storage;
	pair_reference_robust_q20 <= pair_reference_robust_csrstorage15_storage;
	pair_reference_robust_q21 <= pair_reference_robust_csrstorage16_storage;
	pair_reference_robust_q22 <= pair_reference_robust_csrstorage17_storage;
	pair_reference_robust_q23 <= pair_reference_robust_csrstorage18_storage;
	pair_reference_robust_q24 <= pair_reference_robust_csrstorage19_storage;
	pair_reference_robust_q25 <= pair_reference_robust_csrstorage20_storage;
	pair_reference_robust_q26 <= pair_reference_robust_csrstorage21_storage;
	pair_reference_robust_q27 <= pair_reference_robust_csrstorage22_storage;
	pair_reference_robust_q28 <= pair_reference_robust_csrstorage23_storage;
	pair_reference_robust_q29 <= pair_reference_robust_csrstorage24_storage;
	pair_reference_robust_q30 <= pair_reference_robust_csrstorage25_storage;
	pair_reference_robust_q31 <= pair_reference_robust_csrstorage26_storage;
	pair_reference_robust_q32 <= pair_reference_robust_csrstorage27_storage;
	pair_reference_robust_q33 <= pair_reference_robust_csrstorage28_storage;
	pair_reference_robust_q34 <= pair_reference_robust_csrstorage29_storage;
	pair_reference_robust_q35 <= pair_reference_robust_csrstorage30_storage;
	pair_reference_robust_q36 <= pair_reference_robust_csrstorage31_storage;
	pair_reference_robust_q37 <= pair_reference_robust_csrstorage32_storage;
	pair_reference_robust_q38 <= pair_reference_robust_csrstorage33_storage;
	pair_reference_robust_q39 <= pair_reference_robust_csrstorage34_storage;
	pair_reference_robust_q40 <= pair_reference_robust_csrstorage35_storage;
	pair_reference_robust_q41 <= pair_reference_robust_csrstorage36_storage;
	pair_reference_robust_q42 <= pair_reference_robust_csrstorage37_storage;
	pair_reference_robust_q43 <= pair_reference_robust_csrstorage38_storage;
	pair_reference_robust_q44 <= pair_reference_robust_csrstorage39_storage;
	pair_reference_robust_q45 <= pair_reference_robust_csrstorage40_storage;
	pair_reference_robust_q46 <= pair_reference_robust_csrstorage41_storage;
	pair_reference_robust_q47 <= pair_reference_robust_csrstorage42_storage;
	pair_reference_robust_q48 <= pair_reference_robust_csrstorage43_storage;
	pair_reference_robust_q49 <= pair_reference_robust_csrstorage44_storage;
	pair_reference_robust_q50 <= pair_reference_robust_csrstorage45_storage;
	pair_reference_robust_q51 <= pair_reference_robust_csrstorage46_storage;
	pair_reference_robust_q52 <= pair_reference_robust_csrstorage47_storage;
	pair_reference_robust_q53 <= pair_reference_robust_csrstorage48_storage;
	pair_reference_robust_q54 <= pair_reference_robust_csrstorage49_storage;
	pair_reference_robust_q55 <= pair_reference_robust_csrstorage50_storage;
	pair_reference_robust_q56 <= pair_reference_robust_csrstorage51_storage;
	pair_reference_robust_q57 <= pair_reference_robust_csrstorage52_storage;
	pair_reference_robust_q58 <= pair_reference_robust_csrstorage53_storage;
	pair_reference_robust_q59 <= pair_reference_robust_csrstorage54_storage;
	pair_reference_robust_q60 <= pair_reference_robust_csrstorage55_storage;
	pair_reference_robust_q61 <= pair_reference_robust_csrstorage56_storage;
	pair_reference_robust_q62 <= pair_reference_robust_csrstorage57_storage;
	pair_reference_robust_q63 <= pair_reference_robust_csrstorage58_storage;
	pair_reference_robust_q64 <= pair_reference_robust_csrstorage59_storage;
	pair_reference_robust_q65 <= pair_reference_robust_csrstorage60_storage;
	pair_reference_robust_q66 <= pair_reference_robust_csrstorage61_storage;
	pair_reference_robust_q67 <= pair_reference_robust_csrstorage62_storage;
	pair_reference_robust_q68 <= pair_reference_robust_csrstorage63_storage;
	pair_reference_robust_q69 <= pair_reference_robust_csrstorage64_storage;
	pair_reference_robust_q70 <= pair_reference_robust_csrstorage65_storage;
	pair_reference_robust_q71 <= pair_reference_robust_csrstorage66_storage;
	if (pair_reference_robust_restart0) begin
		pair_reference_robust_sum_value <= 1'd0;
	end else begin
		if (pair_reference_robust_writing_data_now0) begin
			pair_reference_robust_sum_value <= (pair_reference_robust_sum_value + pair_reference_robust_input0);
		end
	end
	if (pair_reference_robust_restart1) begin
		pair_reference_robust_counter <= 1'd0;
	end else begin
		if (pair_reference_robust_writing_data_now1) begin
			pair_reference_robust_counter <= (pair_reference_robust_counter + 1'd1);
		end
	end
	if ((~pair_reference_fast_request_lock)) begin
		pair_reference_fast_turn_on_lock <= 1'd0;
	end else begin
		pair_reference_fast_turn_on_lock <= (((pair_reference_fast_sweep_value >= (pair_reference_fast_target_position_signed - $signed({1'd0, (pair_reference_fast_sweep_step >>> 1'd1)}))) & (pair_reference_fast_sweep_value <= ((pair_reference_fast_target_position_signed + $signed({1'd0, 1'd1})) + $signed({1'd0, (pair_reference_fast_sweep_step >>> 1'd1)})))) & $signed({1'd0, pair_reference_fast_sweep_up}));
	end
	if ((~pair_candidate_request_lock_storage)) begin
		pair_candidate_status <= 1'd0;
	end
	if (((pair_candidate_request_lock_storage & pair_candidate_fast_turn_on_lock) & (pair_candidate_autolock_mode_storage == 2'd2))) begin
		pair_candidate_status <= 1'd1;
	end
	if (((pair_candidate_request_lock_storage & pair_candidate_pipelinedrobustautolock_turn_on_lock) & (pair_candidate_autolock_mode_storage == 1'd1))) begin
		pair_candidate_status <= 1'd1;
	end
	pair_candidate_pipelinedrobustautolock0 <= pair_candidate_pipelinedrobustautolock_at_start;
	pair_candidate_pipelinedrobustautolock1 <= pair_candidate_pipelinedrobustautolock_request_lock;
	pair_candidate_pipelinedrobustautolock2 <= pair_candidate_pipelinedrobustautolock_writing_data_now2;
	pair_candidate_pipelinedrobustautolock3 <= pair_candidate_pipelinedrobustautolock_sweep_up;
	pair_candidate_pipelinedrobustautolock_sum_diff_s1 <= pair_candidate_pipelinedrobustautolock_output0;
	pair_candidate_pipelinedrobustautolock_n_instructions_s1 <= pair_candidate_pipelinedrobustautolock_N_instructions_storage;
	pair_candidate_pipelinedrobustautolock_final_wait_s1 <= pair_candidate_pipelinedrobustautolock_final_wait_time_storage;
	pair_candidate_pipelinedrobustautolock_magnitude0 <= pair_candidate_pipelinedrobustautolock_abs_next0;
	pair_candidate_pipelinedrobustautolock_negative0 <= (-pair_candidate_pipelinedrobustautolock_abs_extended0);
	pair_candidate_pipelinedrobustautolock_positive0 <= (pair_candidate_pipelinedrobustautolock_signed_height0 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude1 <= pair_candidate_pipelinedrobustautolock_abs_next1;
	pair_candidate_pipelinedrobustautolock_negative1 <= (-pair_candidate_pipelinedrobustautolock_abs_extended1);
	pair_candidate_pipelinedrobustautolock_positive1 <= (pair_candidate_pipelinedrobustautolock_signed_height1 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude2 <= pair_candidate_pipelinedrobustautolock_abs_next2;
	pair_candidate_pipelinedrobustautolock_negative2 <= (-pair_candidate_pipelinedrobustautolock_abs_extended2);
	pair_candidate_pipelinedrobustautolock_positive2 <= (pair_candidate_pipelinedrobustautolock_signed_height2 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude3 <= pair_candidate_pipelinedrobustautolock_abs_next3;
	pair_candidate_pipelinedrobustautolock_negative3 <= (-pair_candidate_pipelinedrobustautolock_abs_extended3);
	pair_candidate_pipelinedrobustautolock_positive3 <= (pair_candidate_pipelinedrobustautolock_signed_height3 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude4 <= pair_candidate_pipelinedrobustautolock_abs_next4;
	pair_candidate_pipelinedrobustautolock_negative4 <= (-pair_candidate_pipelinedrobustautolock_abs_extended4);
	pair_candidate_pipelinedrobustautolock_positive4 <= (pair_candidate_pipelinedrobustautolock_signed_height4 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude5 <= pair_candidate_pipelinedrobustautolock_abs_next5;
	pair_candidate_pipelinedrobustautolock_negative5 <= (-pair_candidate_pipelinedrobustautolock_abs_extended5);
	pair_candidate_pipelinedrobustautolock_positive5 <= (pair_candidate_pipelinedrobustautolock_signed_height5 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude6 <= pair_candidate_pipelinedrobustautolock_abs_next6;
	pair_candidate_pipelinedrobustautolock_negative6 <= (-pair_candidate_pipelinedrobustautolock_abs_extended6);
	pair_candidate_pipelinedrobustautolock_positive6 <= (pair_candidate_pipelinedrobustautolock_signed_height6 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude7 <= pair_candidate_pipelinedrobustautolock_abs_next7;
	pair_candidate_pipelinedrobustautolock_negative7 <= (-pair_candidate_pipelinedrobustautolock_abs_extended7);
	pair_candidate_pipelinedrobustautolock_positive7 <= (pair_candidate_pipelinedrobustautolock_signed_height7 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude8 <= pair_candidate_pipelinedrobustautolock_abs_next8;
	pair_candidate_pipelinedrobustautolock_negative8 <= (-pair_candidate_pipelinedrobustautolock_abs_extended8);
	pair_candidate_pipelinedrobustautolock_positive8 <= (pair_candidate_pipelinedrobustautolock_signed_height8 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude9 <= pair_candidate_pipelinedrobustautolock_abs_next9;
	pair_candidate_pipelinedrobustautolock_negative9 <= (-pair_candidate_pipelinedrobustautolock_abs_extended9);
	pair_candidate_pipelinedrobustautolock_positive9 <= (pair_candidate_pipelinedrobustautolock_signed_height9 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude10 <= pair_candidate_pipelinedrobustautolock_abs_next10;
	pair_candidate_pipelinedrobustautolock_negative10 <= (-pair_candidate_pipelinedrobustautolock_abs_extended10);
	pair_candidate_pipelinedrobustautolock_positive10 <= (pair_candidate_pipelinedrobustautolock_signed_height10 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude11 <= pair_candidate_pipelinedrobustautolock_abs_next11;
	pair_candidate_pipelinedrobustautolock_negative11 <= (-pair_candidate_pipelinedrobustautolock_abs_extended11);
	pair_candidate_pipelinedrobustautolock_positive11 <= (pair_candidate_pipelinedrobustautolock_signed_height11 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude12 <= pair_candidate_pipelinedrobustautolock_abs_next12;
	pair_candidate_pipelinedrobustautolock_negative12 <= (-pair_candidate_pipelinedrobustautolock_abs_extended12);
	pair_candidate_pipelinedrobustautolock_positive12 <= (pair_candidate_pipelinedrobustautolock_signed_height12 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude13 <= pair_candidate_pipelinedrobustautolock_abs_next13;
	pair_candidate_pipelinedrobustautolock_negative13 <= (-pair_candidate_pipelinedrobustautolock_abs_extended13);
	pair_candidate_pipelinedrobustautolock_positive13 <= (pair_candidate_pipelinedrobustautolock_signed_height13 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude14 <= pair_candidate_pipelinedrobustautolock_abs_next14;
	pair_candidate_pipelinedrobustautolock_negative14 <= (-pair_candidate_pipelinedrobustautolock_abs_extended14);
	pair_candidate_pipelinedrobustautolock_positive14 <= (pair_candidate_pipelinedrobustautolock_signed_height14 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude15 <= pair_candidate_pipelinedrobustautolock_abs_next15;
	pair_candidate_pipelinedrobustautolock_negative15 <= (-pair_candidate_pipelinedrobustautolock_abs_extended15);
	pair_candidate_pipelinedrobustautolock_positive15 <= (pair_candidate_pipelinedrobustautolock_signed_height15 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude16 <= pair_candidate_pipelinedrobustautolock_abs_next16;
	pair_candidate_pipelinedrobustautolock_negative16 <= (-pair_candidate_pipelinedrobustautolock_abs_extended16);
	pair_candidate_pipelinedrobustautolock_positive16 <= (pair_candidate_pipelinedrobustautolock_signed_height16 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude17 <= pair_candidate_pipelinedrobustautolock_abs_next17;
	pair_candidate_pipelinedrobustautolock_negative17 <= (-pair_candidate_pipelinedrobustautolock_abs_extended17);
	pair_candidate_pipelinedrobustautolock_positive17 <= (pair_candidate_pipelinedrobustautolock_signed_height17 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude18 <= pair_candidate_pipelinedrobustautolock_abs_next18;
	pair_candidate_pipelinedrobustautolock_negative18 <= (-pair_candidate_pipelinedrobustautolock_abs_extended18);
	pair_candidate_pipelinedrobustautolock_positive18 <= (pair_candidate_pipelinedrobustautolock_signed_height18 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude19 <= pair_candidate_pipelinedrobustautolock_abs_next19;
	pair_candidate_pipelinedrobustautolock_negative19 <= (-pair_candidate_pipelinedrobustautolock_abs_extended19);
	pair_candidate_pipelinedrobustautolock_positive19 <= (pair_candidate_pipelinedrobustautolock_signed_height19 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude20 <= pair_candidate_pipelinedrobustautolock_abs_next20;
	pair_candidate_pipelinedrobustautolock_negative20 <= (-pair_candidate_pipelinedrobustautolock_abs_extended20);
	pair_candidate_pipelinedrobustautolock_positive20 <= (pair_candidate_pipelinedrobustautolock_signed_height20 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude21 <= pair_candidate_pipelinedrobustautolock_abs_next21;
	pair_candidate_pipelinedrobustautolock_negative21 <= (-pair_candidate_pipelinedrobustautolock_abs_extended21);
	pair_candidate_pipelinedrobustautolock_positive21 <= (pair_candidate_pipelinedrobustautolock_signed_height21 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude22 <= pair_candidate_pipelinedrobustautolock_abs_next22;
	pair_candidate_pipelinedrobustautolock_negative22 <= (-pair_candidate_pipelinedrobustautolock_abs_extended22);
	pair_candidate_pipelinedrobustautolock_positive22 <= (pair_candidate_pipelinedrobustautolock_signed_height22 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude23 <= pair_candidate_pipelinedrobustautolock_abs_next23;
	pair_candidate_pipelinedrobustautolock_negative23 <= (-pair_candidate_pipelinedrobustautolock_abs_extended23);
	pair_candidate_pipelinedrobustautolock_positive23 <= (pair_candidate_pipelinedrobustautolock_signed_height23 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude24 <= pair_candidate_pipelinedrobustautolock_abs_next24;
	pair_candidate_pipelinedrobustautolock_negative24 <= (-pair_candidate_pipelinedrobustautolock_abs_extended24);
	pair_candidate_pipelinedrobustautolock_positive24 <= (pair_candidate_pipelinedrobustautolock_signed_height24 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude25 <= pair_candidate_pipelinedrobustautolock_abs_next25;
	pair_candidate_pipelinedrobustautolock_negative25 <= (-pair_candidate_pipelinedrobustautolock_abs_extended25);
	pair_candidate_pipelinedrobustautolock_positive25 <= (pair_candidate_pipelinedrobustautolock_signed_height25 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude26 <= pair_candidate_pipelinedrobustautolock_abs_next26;
	pair_candidate_pipelinedrobustautolock_negative26 <= (-pair_candidate_pipelinedrobustautolock_abs_extended26);
	pair_candidate_pipelinedrobustautolock_positive26 <= (pair_candidate_pipelinedrobustautolock_signed_height26 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude27 <= pair_candidate_pipelinedrobustautolock_abs_next27;
	pair_candidate_pipelinedrobustautolock_negative27 <= (-pair_candidate_pipelinedrobustautolock_abs_extended27);
	pair_candidate_pipelinedrobustautolock_positive27 <= (pair_candidate_pipelinedrobustautolock_signed_height27 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude28 <= pair_candidate_pipelinedrobustautolock_abs_next28;
	pair_candidate_pipelinedrobustautolock_negative28 <= (-pair_candidate_pipelinedrobustautolock_abs_extended28);
	pair_candidate_pipelinedrobustautolock_positive28 <= (pair_candidate_pipelinedrobustautolock_signed_height28 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude29 <= pair_candidate_pipelinedrobustautolock_abs_next29;
	pair_candidate_pipelinedrobustautolock_negative29 <= (-pair_candidate_pipelinedrobustautolock_abs_extended29);
	pair_candidate_pipelinedrobustautolock_positive29 <= (pair_candidate_pipelinedrobustautolock_signed_height29 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude30 <= pair_candidate_pipelinedrobustautolock_abs_next30;
	pair_candidate_pipelinedrobustautolock_negative30 <= (-pair_candidate_pipelinedrobustautolock_abs_extended30);
	pair_candidate_pipelinedrobustautolock_positive30 <= (pair_candidate_pipelinedrobustautolock_signed_height30 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_magnitude31 <= pair_candidate_pipelinedrobustautolock_abs_next31;
	pair_candidate_pipelinedrobustautolock_negative31 <= (-pair_candidate_pipelinedrobustautolock_abs_extended31);
	pair_candidate_pipelinedrobustautolock_positive31 <= (pair_candidate_pipelinedrobustautolock_signed_height31 > $signed({1'd0, 1'd0}));
	pair_candidate_pipelinedrobustautolock_value0 <= pair_candidate_pipelinedrobustautolock_csrstorage32_storage;
	pair_candidate_pipelinedrobustautolock_value1 <= pair_candidate_pipelinedrobustautolock_csrstorage33_storage;
	pair_candidate_pipelinedrobustautolock_value2 <= pair_candidate_pipelinedrobustautolock_csrstorage34_storage;
	pair_candidate_pipelinedrobustautolock_value3 <= pair_candidate_pipelinedrobustautolock_csrstorage35_storage;
	pair_candidate_pipelinedrobustautolock_value4 <= pair_candidate_pipelinedrobustautolock_csrstorage36_storage;
	pair_candidate_pipelinedrobustautolock_value5 <= pair_candidate_pipelinedrobustautolock_csrstorage37_storage;
	pair_candidate_pipelinedrobustautolock_value6 <= pair_candidate_pipelinedrobustautolock_csrstorage38_storage;
	pair_candidate_pipelinedrobustautolock_value7 <= pair_candidate_pipelinedrobustautolock_csrstorage39_storage;
	pair_candidate_pipelinedrobustautolock_value8 <= pair_candidate_pipelinedrobustautolock_csrstorage40_storage;
	pair_candidate_pipelinedrobustautolock_value9 <= pair_candidate_pipelinedrobustautolock_csrstorage41_storage;
	pair_candidate_pipelinedrobustautolock_value10 <= pair_candidate_pipelinedrobustautolock_csrstorage42_storage;
	pair_candidate_pipelinedrobustautolock_value11 <= pair_candidate_pipelinedrobustautolock_csrstorage43_storage;
	pair_candidate_pipelinedrobustautolock_value12 <= pair_candidate_pipelinedrobustautolock_csrstorage44_storage;
	pair_candidate_pipelinedrobustautolock_value13 <= pair_candidate_pipelinedrobustautolock_csrstorage45_storage;
	pair_candidate_pipelinedrobustautolock_value14 <= pair_candidate_pipelinedrobustautolock_csrstorage46_storage;
	pair_candidate_pipelinedrobustautolock_value15 <= pair_candidate_pipelinedrobustautolock_csrstorage47_storage;
	pair_candidate_pipelinedrobustautolock_value16 <= pair_candidate_pipelinedrobustautolock_csrstorage48_storage;
	pair_candidate_pipelinedrobustautolock_value17 <= pair_candidate_pipelinedrobustautolock_csrstorage49_storage;
	pair_candidate_pipelinedrobustautolock_value18 <= pair_candidate_pipelinedrobustautolock_csrstorage50_storage;
	pair_candidate_pipelinedrobustautolock_value19 <= pair_candidate_pipelinedrobustautolock_csrstorage51_storage;
	pair_candidate_pipelinedrobustautolock_value20 <= pair_candidate_pipelinedrobustautolock_csrstorage52_storage;
	pair_candidate_pipelinedrobustautolock_value21 <= pair_candidate_pipelinedrobustautolock_csrstorage53_storage;
	pair_candidate_pipelinedrobustautolock_value22 <= pair_candidate_pipelinedrobustautolock_csrstorage54_storage;
	pair_candidate_pipelinedrobustautolock_value23 <= pair_candidate_pipelinedrobustautolock_csrstorage55_storage;
	pair_candidate_pipelinedrobustautolock_value24 <= pair_candidate_pipelinedrobustautolock_csrstorage56_storage;
	pair_candidate_pipelinedrobustautolock_value25 <= pair_candidate_pipelinedrobustautolock_csrstorage57_storage;
	pair_candidate_pipelinedrobustautolock_value26 <= pair_candidate_pipelinedrobustautolock_csrstorage58_storage;
	pair_candidate_pipelinedrobustautolock_value27 <= pair_candidate_pipelinedrobustautolock_csrstorage59_storage;
	pair_candidate_pipelinedrobustautolock_value28 <= pair_candidate_pipelinedrobustautolock_csrstorage60_storage;
	pair_candidate_pipelinedrobustautolock_value29 <= pair_candidate_pipelinedrobustautolock_csrstorage61_storage;
	pair_candidate_pipelinedrobustautolock_value30 <= pair_candidate_pipelinedrobustautolock_csrstorage62_storage;
	pair_candidate_pipelinedrobustautolock_value31 <= pair_candidate_pipelinedrobustautolock_csrstorage63_storage;
	if (pair_candidate_pipelinedrobustautolock0) begin
		pair_candidate_pipelinedrobustautolock_waited_for <= 1'd0;
		pair_candidate_pipelinedrobustautolock_final_waited_for <= 2'd3;
		pair_candidate_pipelinedrobustautolock_current_instruction_idx <= 1'd0;
		if (pair_candidate_pipelinedrobustautolock1) begin
			pair_candidate_pipelinedrobustautolock_watching <= 1'd1;
		end else begin
			pair_candidate_pipelinedrobustautolock_watching <= 1'd0;
		end
	end else begin
		if ((~pair_candidate_pipelinedrobustautolock1)) begin
			pair_candidate_pipelinedrobustautolock_watching <= 1'd0;
		end
		if (((pair_candidate_pipelinedrobustautolock2 & (~pair_candidate_pipelinedrobustautolock_all_instructions_triggered)) & pair_candidate_pipelinedrobustautolock3)) begin
			if ((((pair_candidate_pipelinedrobustautolock_watching & pair_candidate_pipelinedrobustautolock_sign_equal) & pair_candidate_pipelinedrobustautolock_over_threshold) & pair_candidate_pipelinedrobustautolock_waited_long_enough)) begin
				pair_candidate_pipelinedrobustautolock_current_instruction_idx <= (pair_candidate_pipelinedrobustautolock_current_instruction_idx + 1'd1);
				pair_candidate_pipelinedrobustautolock_waited_for <= 1'd0;
			end else begin
				pair_candidate_pipelinedrobustautolock_waited_for <= (pair_candidate_pipelinedrobustautolock_waited_for + 1'd1);
			end
		end
		if (((pair_candidate_pipelinedrobustautolock2 & pair_candidate_pipelinedrobustautolock_all_instructions_triggered) & pair_candidate_pipelinedrobustautolock3)) begin
			pair_candidate_pipelinedrobustautolock_final_waited_for <= (pair_candidate_pipelinedrobustautolock_final_waited_for + 1'd1);
		end
	end
	if (pair_candidate_pipelinedrobustautolock_restart0) begin
		pair_candidate_pipelinedrobustautolock_sum_value <= 1'd0;
	end else begin
		if (pair_candidate_pipelinedrobustautolock_writing_data_now0) begin
			pair_candidate_pipelinedrobustautolock_sum_value <= (pair_candidate_pipelinedrobustautolock_sum_value + pair_candidate_pipelinedrobustautolock_input0);
		end
	end
	if (pair_candidate_pipelinedrobustautolock_restart1) begin
		pair_candidate_pipelinedrobustautolock_counter <= 1'd0;
	end else begin
		if (pair_candidate_pipelinedrobustautolock_writing_data_now1) begin
			pair_candidate_pipelinedrobustautolock_counter <= (pair_candidate_pipelinedrobustautolock_counter + 1'd1);
		end
	end
	if ((~pair_candidate_fast_request_lock)) begin
		pair_candidate_fast_turn_on_lock <= 1'd0;
	end else begin
		pair_candidate_fast_turn_on_lock <= (((pair_candidate_fast_sweep_value >= (pair_candidate_fast_target_position_signed - $signed({1'd0, (pair_candidate_fast_sweep_step >>> 1'd1)}))) & (pair_candidate_fast_sweep_value <= ((pair_candidate_fast_target_position_signed + $signed({1'd0, 1'd1})) + $signed({1'd0, (pair_candidate_fast_sweep_step >>> 1'd1)})))) & $signed({1'd0, pair_candidate_fast_sweep_up}));
	end
	pair_rb_bus_dat_r <= 1'd0;
	if (pair_rb_sel) begin
		case (pair_rb_bus_adr[7:0])
			1'd0: begin
				pair_rb_bus_dat_r <= pair_rb_robust_time_scale1_w;
			end
			1'd1: begin
				pair_rb_bus_dat_r <= pair_rb_robust_time_scale0_w;
			end
			2'd2: begin
				pair_rb_bus_dat_r <= pair_rb_robust_N_instructions0_w;
			end
			2'd3: begin
				pair_rb_bus_dat_r <= pair_rb_robust_final_wait_time1_w;
			end
			3'd4: begin
				pair_rb_bus_dat_r <= pair_rb_robust_final_wait_time0_w;
			end
			3'd5: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_03_w;
			end
			3'd6: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_02_w;
			end
			3'd7: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_01_w;
			end
			4'd8: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_00_w;
			end
			4'd9: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_13_w;
			end
			4'd10: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_12_w;
			end
			4'd11: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_11_w;
			end
			4'd12: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_10_w;
			end
			4'd13: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_23_w;
			end
			4'd14: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_22_w;
			end
			4'd15: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_21_w;
			end
			5'd16: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_20_w;
			end
			5'd17: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_33_w;
			end
			5'd18: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_32_w;
			end
			5'd19: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_31_w;
			end
			5'd20: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_30_w;
			end
			5'd21: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_43_w;
			end
			5'd22: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_42_w;
			end
			5'd23: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_41_w;
			end
			5'd24: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_40_w;
			end
			5'd25: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_53_w;
			end
			5'd26: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_52_w;
			end
			5'd27: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_51_w;
			end
			5'd28: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_50_w;
			end
			5'd29: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_63_w;
			end
			5'd30: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_62_w;
			end
			5'd31: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_61_w;
			end
			6'd32: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_60_w;
			end
			6'd33: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_73_w;
			end
			6'd34: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_72_w;
			end
			6'd35: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_71_w;
			end
			6'd36: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_70_w;
			end
			6'd37: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_83_w;
			end
			6'd38: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_82_w;
			end
			6'd39: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_81_w;
			end
			6'd40: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_80_w;
			end
			6'd41: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_93_w;
			end
			6'd42: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_92_w;
			end
			6'd43: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_91_w;
			end
			6'd44: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_90_w;
			end
			6'd45: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_103_w;
			end
			6'd46: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_102_w;
			end
			6'd47: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_101_w;
			end
			6'd48: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_100_w;
			end
			6'd49: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_113_w;
			end
			6'd50: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_112_w;
			end
			6'd51: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_111_w;
			end
			6'd52: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_110_w;
			end
			6'd53: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_123_w;
			end
			6'd54: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_122_w;
			end
			6'd55: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_121_w;
			end
			6'd56: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_120_w;
			end
			6'd57: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_133_w;
			end
			6'd58: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_132_w;
			end
			6'd59: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_131_w;
			end
			6'd60: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_130_w;
			end
			6'd61: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_143_w;
			end
			6'd62: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_142_w;
			end
			6'd63: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_141_w;
			end
			7'd64: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_140_w;
			end
			7'd65: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_153_w;
			end
			7'd66: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_152_w;
			end
			7'd67: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_151_w;
			end
			7'd68: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_150_w;
			end
			7'd69: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_163_w;
			end
			7'd70: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_162_w;
			end
			7'd71: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_161_w;
			end
			7'd72: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_160_w;
			end
			7'd73: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_173_w;
			end
			7'd74: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_172_w;
			end
			7'd75: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_171_w;
			end
			7'd76: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_170_w;
			end
			7'd77: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_183_w;
			end
			7'd78: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_182_w;
			end
			7'd79: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_181_w;
			end
			7'd80: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_180_w;
			end
			7'd81: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_193_w;
			end
			7'd82: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_192_w;
			end
			7'd83: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_191_w;
			end
			7'd84: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_190_w;
			end
			7'd85: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_203_w;
			end
			7'd86: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_202_w;
			end
			7'd87: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_201_w;
			end
			7'd88: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_200_w;
			end
			7'd89: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_213_w;
			end
			7'd90: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_212_w;
			end
			7'd91: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_211_w;
			end
			7'd92: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_210_w;
			end
			7'd93: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_223_w;
			end
			7'd94: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_222_w;
			end
			7'd95: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_221_w;
			end
			7'd96: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_220_w;
			end
			7'd97: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_233_w;
			end
			7'd98: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_232_w;
			end
			7'd99: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_231_w;
			end
			7'd100: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_230_w;
			end
			7'd101: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_243_w;
			end
			7'd102: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_242_w;
			end
			7'd103: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_241_w;
			end
			7'd104: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_240_w;
			end
			7'd105: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_253_w;
			end
			7'd106: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_252_w;
			end
			7'd107: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_251_w;
			end
			7'd108: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_250_w;
			end
			7'd109: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_263_w;
			end
			7'd110: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_262_w;
			end
			7'd111: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_261_w;
			end
			7'd112: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_260_w;
			end
			7'd113: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_273_w;
			end
			7'd114: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_272_w;
			end
			7'd115: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_271_w;
			end
			7'd116: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_270_w;
			end
			7'd117: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_283_w;
			end
			7'd118: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_282_w;
			end
			7'd119: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_281_w;
			end
			7'd120: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_280_w;
			end
			7'd121: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_293_w;
			end
			7'd122: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_292_w;
			end
			7'd123: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_291_w;
			end
			7'd124: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_290_w;
			end
			7'd125: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_303_w;
			end
			7'd126: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_302_w;
			end
			7'd127: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_301_w;
			end
			8'd128: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_300_w;
			end
			8'd129: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_313_w;
			end
			8'd130: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_312_w;
			end
			8'd131: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_311_w;
			end
			8'd132: begin
				pair_rb_bus_dat_r <= pair_rb_robust_peak_height_310_w;
			end
			8'd133: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_01_w;
			end
			8'd134: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_00_w;
			end
			8'd135: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_11_w;
			end
			8'd136: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_10_w;
			end
			8'd137: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_21_w;
			end
			8'd138: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_20_w;
			end
			8'd139: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_31_w;
			end
			8'd140: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_30_w;
			end
			8'd141: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_41_w;
			end
			8'd142: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_40_w;
			end
			8'd143: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_51_w;
			end
			8'd144: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_50_w;
			end
			8'd145: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_61_w;
			end
			8'd146: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_60_w;
			end
			8'd147: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_71_w;
			end
			8'd148: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_70_w;
			end
			8'd149: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_81_w;
			end
			8'd150: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_80_w;
			end
			8'd151: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_91_w;
			end
			8'd152: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_90_w;
			end
			8'd153: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_101_w;
			end
			8'd154: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_100_w;
			end
			8'd155: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_111_w;
			end
			8'd156: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_110_w;
			end
			8'd157: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_121_w;
			end
			8'd158: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_120_w;
			end
			8'd159: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_131_w;
			end
			8'd160: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_130_w;
			end
			8'd161: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_141_w;
			end
			8'd162: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_140_w;
			end
			8'd163: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_151_w;
			end
			8'd164: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_150_w;
			end
			8'd165: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_161_w;
			end
			8'd166: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_160_w;
			end
			8'd167: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_171_w;
			end
			8'd168: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_170_w;
			end
			8'd169: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_181_w;
			end
			8'd170: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_180_w;
			end
			8'd171: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_191_w;
			end
			8'd172: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_190_w;
			end
			8'd173: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_201_w;
			end
			8'd174: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_200_w;
			end
			8'd175: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_211_w;
			end
			8'd176: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_210_w;
			end
			8'd177: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_221_w;
			end
			8'd178: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_220_w;
			end
			8'd179: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_231_w;
			end
			8'd180: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_230_w;
			end
			8'd181: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_241_w;
			end
			8'd182: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_240_w;
			end
			8'd183: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_251_w;
			end
			8'd184: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_250_w;
			end
			8'd185: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_261_w;
			end
			8'd186: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_260_w;
			end
			8'd187: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_271_w;
			end
			8'd188: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_270_w;
			end
			8'd189: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_281_w;
			end
			8'd190: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_280_w;
			end
			8'd191: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_291_w;
			end
			8'd192: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_290_w;
			end
			8'd193: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_301_w;
			end
			8'd194: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_300_w;
			end
			8'd195: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_311_w;
			end
			8'd196: begin
				pair_rb_bus_dat_r <= pair_rb_robust_wait_for_310_w;
			end
			8'd197: begin
				pair_rb_bus_dat_r <= pair_rb_fast_target_position1_w;
			end
			8'd198: begin
				pair_rb_bus_dat_r <= pair_rb_fast_target_position0_w;
			end
			8'd199: begin
				pair_rb_bus_dat_r <= pair_rb_request_lock0_w;
			end
			8'd200: begin
				pair_rb_bus_dat_r <= pair_rb_autolock_mode0_w;
			end
			8'd201: begin
				pair_rb_bus_dat_r <= pair_rb_lock_running_w;
			end
		endcase
	end
	if (pair_rb_robust_time_scale1_re) begin
		pair_reference_robust_csrstorage0_storage_full[13:8] <= pair_rb_robust_time_scale1_r;
	end
	if (pair_rb_robust_time_scale0_re) begin
		pair_reference_robust_csrstorage0_storage_full[7:0] <= pair_rb_robust_time_scale0_r;
	end
	pair_reference_robust_csrstorage0_re <= pair_rb_robust_time_scale0_re;
	if (pair_rb_robust_N_instructions0_re) begin
		pair_reference_robust_csrstorage1_storage_full[4:0] <= pair_rb_robust_N_instructions0_r;
	end
	pair_reference_robust_csrstorage1_re <= pair_rb_robust_N_instructions0_re;
	if (pair_rb_robust_final_wait_time1_re) begin
		pair_reference_robust_csrstorage2_storage_full[13:8] <= pair_rb_robust_final_wait_time1_r;
	end
	if (pair_rb_robust_final_wait_time0_re) begin
		pair_reference_robust_csrstorage2_storage_full[7:0] <= pair_rb_robust_final_wait_time0_r;
	end
	pair_reference_robust_csrstorage2_re <= pair_rb_robust_final_wait_time0_re;
	if (pair_rb_robust_peak_height_03_re) begin
		pair_reference_robust_csrstorage3_storage_full[27:24] <= pair_rb_robust_peak_height_03_r;
	end
	if (pair_rb_robust_peak_height_02_re) begin
		pair_reference_robust_csrstorage3_storage_full[23:16] <= pair_rb_robust_peak_height_02_r;
	end
	if (pair_rb_robust_peak_height_01_re) begin
		pair_reference_robust_csrstorage3_storage_full[15:8] <= pair_rb_robust_peak_height_01_r;
	end
	if (pair_rb_robust_peak_height_00_re) begin
		pair_reference_robust_csrstorage3_storage_full[7:0] <= pair_rb_robust_peak_height_00_r;
	end
	pair_reference_robust_csrstorage3_re <= pair_rb_robust_peak_height_00_re;
	if (pair_rb_robust_peak_height_13_re) begin
		pair_reference_robust_csrstorage4_storage_full[27:24] <= pair_rb_robust_peak_height_13_r;
	end
	if (pair_rb_robust_peak_height_12_re) begin
		pair_reference_robust_csrstorage4_storage_full[23:16] <= pair_rb_robust_peak_height_12_r;
	end
	if (pair_rb_robust_peak_height_11_re) begin
		pair_reference_robust_csrstorage4_storage_full[15:8] <= pair_rb_robust_peak_height_11_r;
	end
	if (pair_rb_robust_peak_height_10_re) begin
		pair_reference_robust_csrstorage4_storage_full[7:0] <= pair_rb_robust_peak_height_10_r;
	end
	pair_reference_robust_csrstorage4_re <= pair_rb_robust_peak_height_10_re;
	if (pair_rb_robust_peak_height_23_re) begin
		pair_reference_robust_csrstorage5_storage_full[27:24] <= pair_rb_robust_peak_height_23_r;
	end
	if (pair_rb_robust_peak_height_22_re) begin
		pair_reference_robust_csrstorage5_storage_full[23:16] <= pair_rb_robust_peak_height_22_r;
	end
	if (pair_rb_robust_peak_height_21_re) begin
		pair_reference_robust_csrstorage5_storage_full[15:8] <= pair_rb_robust_peak_height_21_r;
	end
	if (pair_rb_robust_peak_height_20_re) begin
		pair_reference_robust_csrstorage5_storage_full[7:0] <= pair_rb_robust_peak_height_20_r;
	end
	pair_reference_robust_csrstorage5_re <= pair_rb_robust_peak_height_20_re;
	if (pair_rb_robust_peak_height_33_re) begin
		pair_reference_robust_csrstorage6_storage_full[27:24] <= pair_rb_robust_peak_height_33_r;
	end
	if (pair_rb_robust_peak_height_32_re) begin
		pair_reference_robust_csrstorage6_storage_full[23:16] <= pair_rb_robust_peak_height_32_r;
	end
	if (pair_rb_robust_peak_height_31_re) begin
		pair_reference_robust_csrstorage6_storage_full[15:8] <= pair_rb_robust_peak_height_31_r;
	end
	if (pair_rb_robust_peak_height_30_re) begin
		pair_reference_robust_csrstorage6_storage_full[7:0] <= pair_rb_robust_peak_height_30_r;
	end
	pair_reference_robust_csrstorage6_re <= pair_rb_robust_peak_height_30_re;
	if (pair_rb_robust_peak_height_43_re) begin
		pair_reference_robust_csrstorage7_storage_full[27:24] <= pair_rb_robust_peak_height_43_r;
	end
	if (pair_rb_robust_peak_height_42_re) begin
		pair_reference_robust_csrstorage7_storage_full[23:16] <= pair_rb_robust_peak_height_42_r;
	end
	if (pair_rb_robust_peak_height_41_re) begin
		pair_reference_robust_csrstorage7_storage_full[15:8] <= pair_rb_robust_peak_height_41_r;
	end
	if (pair_rb_robust_peak_height_40_re) begin
		pair_reference_robust_csrstorage7_storage_full[7:0] <= pair_rb_robust_peak_height_40_r;
	end
	pair_reference_robust_csrstorage7_re <= pair_rb_robust_peak_height_40_re;
	if (pair_rb_robust_peak_height_53_re) begin
		pair_reference_robust_csrstorage8_storage_full[27:24] <= pair_rb_robust_peak_height_53_r;
	end
	if (pair_rb_robust_peak_height_52_re) begin
		pair_reference_robust_csrstorage8_storage_full[23:16] <= pair_rb_robust_peak_height_52_r;
	end
	if (pair_rb_robust_peak_height_51_re) begin
		pair_reference_robust_csrstorage8_storage_full[15:8] <= pair_rb_robust_peak_height_51_r;
	end
	if (pair_rb_robust_peak_height_50_re) begin
		pair_reference_robust_csrstorage8_storage_full[7:0] <= pair_rb_robust_peak_height_50_r;
	end
	pair_reference_robust_csrstorage8_re <= pair_rb_robust_peak_height_50_re;
	if (pair_rb_robust_peak_height_63_re) begin
		pair_reference_robust_csrstorage9_storage_full[27:24] <= pair_rb_robust_peak_height_63_r;
	end
	if (pair_rb_robust_peak_height_62_re) begin
		pair_reference_robust_csrstorage9_storage_full[23:16] <= pair_rb_robust_peak_height_62_r;
	end
	if (pair_rb_robust_peak_height_61_re) begin
		pair_reference_robust_csrstorage9_storage_full[15:8] <= pair_rb_robust_peak_height_61_r;
	end
	if (pair_rb_robust_peak_height_60_re) begin
		pair_reference_robust_csrstorage9_storage_full[7:0] <= pair_rb_robust_peak_height_60_r;
	end
	pair_reference_robust_csrstorage9_re <= pair_rb_robust_peak_height_60_re;
	if (pair_rb_robust_peak_height_73_re) begin
		pair_reference_robust_csrstorage10_storage_full[27:24] <= pair_rb_robust_peak_height_73_r;
	end
	if (pair_rb_robust_peak_height_72_re) begin
		pair_reference_robust_csrstorage10_storage_full[23:16] <= pair_rb_robust_peak_height_72_r;
	end
	if (pair_rb_robust_peak_height_71_re) begin
		pair_reference_robust_csrstorage10_storage_full[15:8] <= pair_rb_robust_peak_height_71_r;
	end
	if (pair_rb_robust_peak_height_70_re) begin
		pair_reference_robust_csrstorage10_storage_full[7:0] <= pair_rb_robust_peak_height_70_r;
	end
	pair_reference_robust_csrstorage10_re <= pair_rb_robust_peak_height_70_re;
	if (pair_rb_robust_peak_height_83_re) begin
		pair_reference_robust_csrstorage11_storage_full[27:24] <= pair_rb_robust_peak_height_83_r;
	end
	if (pair_rb_robust_peak_height_82_re) begin
		pair_reference_robust_csrstorage11_storage_full[23:16] <= pair_rb_robust_peak_height_82_r;
	end
	if (pair_rb_robust_peak_height_81_re) begin
		pair_reference_robust_csrstorage11_storage_full[15:8] <= pair_rb_robust_peak_height_81_r;
	end
	if (pair_rb_robust_peak_height_80_re) begin
		pair_reference_robust_csrstorage11_storage_full[7:0] <= pair_rb_robust_peak_height_80_r;
	end
	pair_reference_robust_csrstorage11_re <= pair_rb_robust_peak_height_80_re;
	if (pair_rb_robust_peak_height_93_re) begin
		pair_reference_robust_csrstorage12_storage_full[27:24] <= pair_rb_robust_peak_height_93_r;
	end
	if (pair_rb_robust_peak_height_92_re) begin
		pair_reference_robust_csrstorage12_storage_full[23:16] <= pair_rb_robust_peak_height_92_r;
	end
	if (pair_rb_robust_peak_height_91_re) begin
		pair_reference_robust_csrstorage12_storage_full[15:8] <= pair_rb_robust_peak_height_91_r;
	end
	if (pair_rb_robust_peak_height_90_re) begin
		pair_reference_robust_csrstorage12_storage_full[7:0] <= pair_rb_robust_peak_height_90_r;
	end
	pair_reference_robust_csrstorage12_re <= pair_rb_robust_peak_height_90_re;
	if (pair_rb_robust_peak_height_103_re) begin
		pair_reference_robust_csrstorage13_storage_full[27:24] <= pair_rb_robust_peak_height_103_r;
	end
	if (pair_rb_robust_peak_height_102_re) begin
		pair_reference_robust_csrstorage13_storage_full[23:16] <= pair_rb_robust_peak_height_102_r;
	end
	if (pair_rb_robust_peak_height_101_re) begin
		pair_reference_robust_csrstorage13_storage_full[15:8] <= pair_rb_robust_peak_height_101_r;
	end
	if (pair_rb_robust_peak_height_100_re) begin
		pair_reference_robust_csrstorage13_storage_full[7:0] <= pair_rb_robust_peak_height_100_r;
	end
	pair_reference_robust_csrstorage13_re <= pair_rb_robust_peak_height_100_re;
	if (pair_rb_robust_peak_height_113_re) begin
		pair_reference_robust_csrstorage14_storage_full[27:24] <= pair_rb_robust_peak_height_113_r;
	end
	if (pair_rb_robust_peak_height_112_re) begin
		pair_reference_robust_csrstorage14_storage_full[23:16] <= pair_rb_robust_peak_height_112_r;
	end
	if (pair_rb_robust_peak_height_111_re) begin
		pair_reference_robust_csrstorage14_storage_full[15:8] <= pair_rb_robust_peak_height_111_r;
	end
	if (pair_rb_robust_peak_height_110_re) begin
		pair_reference_robust_csrstorage14_storage_full[7:0] <= pair_rb_robust_peak_height_110_r;
	end
	pair_reference_robust_csrstorage14_re <= pair_rb_robust_peak_height_110_re;
	if (pair_rb_robust_peak_height_123_re) begin
		pair_reference_robust_csrstorage15_storage_full[27:24] <= pair_rb_robust_peak_height_123_r;
	end
	if (pair_rb_robust_peak_height_122_re) begin
		pair_reference_robust_csrstorage15_storage_full[23:16] <= pair_rb_robust_peak_height_122_r;
	end
	if (pair_rb_robust_peak_height_121_re) begin
		pair_reference_robust_csrstorage15_storage_full[15:8] <= pair_rb_robust_peak_height_121_r;
	end
	if (pair_rb_robust_peak_height_120_re) begin
		pair_reference_robust_csrstorage15_storage_full[7:0] <= pair_rb_robust_peak_height_120_r;
	end
	pair_reference_robust_csrstorage15_re <= pair_rb_robust_peak_height_120_re;
	if (pair_rb_robust_peak_height_133_re) begin
		pair_reference_robust_csrstorage16_storage_full[27:24] <= pair_rb_robust_peak_height_133_r;
	end
	if (pair_rb_robust_peak_height_132_re) begin
		pair_reference_robust_csrstorage16_storage_full[23:16] <= pair_rb_robust_peak_height_132_r;
	end
	if (pair_rb_robust_peak_height_131_re) begin
		pair_reference_robust_csrstorage16_storage_full[15:8] <= pair_rb_robust_peak_height_131_r;
	end
	if (pair_rb_robust_peak_height_130_re) begin
		pair_reference_robust_csrstorage16_storage_full[7:0] <= pair_rb_robust_peak_height_130_r;
	end
	pair_reference_robust_csrstorage16_re <= pair_rb_robust_peak_height_130_re;
	if (pair_rb_robust_peak_height_143_re) begin
		pair_reference_robust_csrstorage17_storage_full[27:24] <= pair_rb_robust_peak_height_143_r;
	end
	if (pair_rb_robust_peak_height_142_re) begin
		pair_reference_robust_csrstorage17_storage_full[23:16] <= pair_rb_robust_peak_height_142_r;
	end
	if (pair_rb_robust_peak_height_141_re) begin
		pair_reference_robust_csrstorage17_storage_full[15:8] <= pair_rb_robust_peak_height_141_r;
	end
	if (pair_rb_robust_peak_height_140_re) begin
		pair_reference_robust_csrstorage17_storage_full[7:0] <= pair_rb_robust_peak_height_140_r;
	end
	pair_reference_robust_csrstorage17_re <= pair_rb_robust_peak_height_140_re;
	if (pair_rb_robust_peak_height_153_re) begin
		pair_reference_robust_csrstorage18_storage_full[27:24] <= pair_rb_robust_peak_height_153_r;
	end
	if (pair_rb_robust_peak_height_152_re) begin
		pair_reference_robust_csrstorage18_storage_full[23:16] <= pair_rb_robust_peak_height_152_r;
	end
	if (pair_rb_robust_peak_height_151_re) begin
		pair_reference_robust_csrstorage18_storage_full[15:8] <= pair_rb_robust_peak_height_151_r;
	end
	if (pair_rb_robust_peak_height_150_re) begin
		pair_reference_robust_csrstorage18_storage_full[7:0] <= pair_rb_robust_peak_height_150_r;
	end
	pair_reference_robust_csrstorage18_re <= pair_rb_robust_peak_height_150_re;
	if (pair_rb_robust_peak_height_163_re) begin
		pair_reference_robust_csrstorage19_storage_full[27:24] <= pair_rb_robust_peak_height_163_r;
	end
	if (pair_rb_robust_peak_height_162_re) begin
		pair_reference_robust_csrstorage19_storage_full[23:16] <= pair_rb_robust_peak_height_162_r;
	end
	if (pair_rb_robust_peak_height_161_re) begin
		pair_reference_robust_csrstorage19_storage_full[15:8] <= pair_rb_robust_peak_height_161_r;
	end
	if (pair_rb_robust_peak_height_160_re) begin
		pair_reference_robust_csrstorage19_storage_full[7:0] <= pair_rb_robust_peak_height_160_r;
	end
	pair_reference_robust_csrstorage19_re <= pair_rb_robust_peak_height_160_re;
	if (pair_rb_robust_peak_height_173_re) begin
		pair_reference_robust_csrstorage20_storage_full[27:24] <= pair_rb_robust_peak_height_173_r;
	end
	if (pair_rb_robust_peak_height_172_re) begin
		pair_reference_robust_csrstorage20_storage_full[23:16] <= pair_rb_robust_peak_height_172_r;
	end
	if (pair_rb_robust_peak_height_171_re) begin
		pair_reference_robust_csrstorage20_storage_full[15:8] <= pair_rb_robust_peak_height_171_r;
	end
	if (pair_rb_robust_peak_height_170_re) begin
		pair_reference_robust_csrstorage20_storage_full[7:0] <= pair_rb_robust_peak_height_170_r;
	end
	pair_reference_robust_csrstorage20_re <= pair_rb_robust_peak_height_170_re;
	if (pair_rb_robust_peak_height_183_re) begin
		pair_reference_robust_csrstorage21_storage_full[27:24] <= pair_rb_robust_peak_height_183_r;
	end
	if (pair_rb_robust_peak_height_182_re) begin
		pair_reference_robust_csrstorage21_storage_full[23:16] <= pair_rb_robust_peak_height_182_r;
	end
	if (pair_rb_robust_peak_height_181_re) begin
		pair_reference_robust_csrstorage21_storage_full[15:8] <= pair_rb_robust_peak_height_181_r;
	end
	if (pair_rb_robust_peak_height_180_re) begin
		pair_reference_robust_csrstorage21_storage_full[7:0] <= pair_rb_robust_peak_height_180_r;
	end
	pair_reference_robust_csrstorage21_re <= pair_rb_robust_peak_height_180_re;
	if (pair_rb_robust_peak_height_193_re) begin
		pair_reference_robust_csrstorage22_storage_full[27:24] <= pair_rb_robust_peak_height_193_r;
	end
	if (pair_rb_robust_peak_height_192_re) begin
		pair_reference_robust_csrstorage22_storage_full[23:16] <= pair_rb_robust_peak_height_192_r;
	end
	if (pair_rb_robust_peak_height_191_re) begin
		pair_reference_robust_csrstorage22_storage_full[15:8] <= pair_rb_robust_peak_height_191_r;
	end
	if (pair_rb_robust_peak_height_190_re) begin
		pair_reference_robust_csrstorage22_storage_full[7:0] <= pair_rb_robust_peak_height_190_r;
	end
	pair_reference_robust_csrstorage22_re <= pair_rb_robust_peak_height_190_re;
	if (pair_rb_robust_peak_height_203_re) begin
		pair_reference_robust_csrstorage23_storage_full[27:24] <= pair_rb_robust_peak_height_203_r;
	end
	if (pair_rb_robust_peak_height_202_re) begin
		pair_reference_robust_csrstorage23_storage_full[23:16] <= pair_rb_robust_peak_height_202_r;
	end
	if (pair_rb_robust_peak_height_201_re) begin
		pair_reference_robust_csrstorage23_storage_full[15:8] <= pair_rb_robust_peak_height_201_r;
	end
	if (pair_rb_robust_peak_height_200_re) begin
		pair_reference_robust_csrstorage23_storage_full[7:0] <= pair_rb_robust_peak_height_200_r;
	end
	pair_reference_robust_csrstorage23_re <= pair_rb_robust_peak_height_200_re;
	if (pair_rb_robust_peak_height_213_re) begin
		pair_reference_robust_csrstorage24_storage_full[27:24] <= pair_rb_robust_peak_height_213_r;
	end
	if (pair_rb_robust_peak_height_212_re) begin
		pair_reference_robust_csrstorage24_storage_full[23:16] <= pair_rb_robust_peak_height_212_r;
	end
	if (pair_rb_robust_peak_height_211_re) begin
		pair_reference_robust_csrstorage24_storage_full[15:8] <= pair_rb_robust_peak_height_211_r;
	end
	if (pair_rb_robust_peak_height_210_re) begin
		pair_reference_robust_csrstorage24_storage_full[7:0] <= pair_rb_robust_peak_height_210_r;
	end
	pair_reference_robust_csrstorage24_re <= pair_rb_robust_peak_height_210_re;
	if (pair_rb_robust_peak_height_223_re) begin
		pair_reference_robust_csrstorage25_storage_full[27:24] <= pair_rb_robust_peak_height_223_r;
	end
	if (pair_rb_robust_peak_height_222_re) begin
		pair_reference_robust_csrstorage25_storage_full[23:16] <= pair_rb_robust_peak_height_222_r;
	end
	if (pair_rb_robust_peak_height_221_re) begin
		pair_reference_robust_csrstorage25_storage_full[15:8] <= pair_rb_robust_peak_height_221_r;
	end
	if (pair_rb_robust_peak_height_220_re) begin
		pair_reference_robust_csrstorage25_storage_full[7:0] <= pair_rb_robust_peak_height_220_r;
	end
	pair_reference_robust_csrstorage25_re <= pair_rb_robust_peak_height_220_re;
	if (pair_rb_robust_peak_height_233_re) begin
		pair_reference_robust_csrstorage26_storage_full[27:24] <= pair_rb_robust_peak_height_233_r;
	end
	if (pair_rb_robust_peak_height_232_re) begin
		pair_reference_robust_csrstorage26_storage_full[23:16] <= pair_rb_robust_peak_height_232_r;
	end
	if (pair_rb_robust_peak_height_231_re) begin
		pair_reference_robust_csrstorage26_storage_full[15:8] <= pair_rb_robust_peak_height_231_r;
	end
	if (pair_rb_robust_peak_height_230_re) begin
		pair_reference_robust_csrstorage26_storage_full[7:0] <= pair_rb_robust_peak_height_230_r;
	end
	pair_reference_robust_csrstorage26_re <= pair_rb_robust_peak_height_230_re;
	if (pair_rb_robust_peak_height_243_re) begin
		pair_reference_robust_csrstorage27_storage_full[27:24] <= pair_rb_robust_peak_height_243_r;
	end
	if (pair_rb_robust_peak_height_242_re) begin
		pair_reference_robust_csrstorage27_storage_full[23:16] <= pair_rb_robust_peak_height_242_r;
	end
	if (pair_rb_robust_peak_height_241_re) begin
		pair_reference_robust_csrstorage27_storage_full[15:8] <= pair_rb_robust_peak_height_241_r;
	end
	if (pair_rb_robust_peak_height_240_re) begin
		pair_reference_robust_csrstorage27_storage_full[7:0] <= pair_rb_robust_peak_height_240_r;
	end
	pair_reference_robust_csrstorage27_re <= pair_rb_robust_peak_height_240_re;
	if (pair_rb_robust_peak_height_253_re) begin
		pair_reference_robust_csrstorage28_storage_full[27:24] <= pair_rb_robust_peak_height_253_r;
	end
	if (pair_rb_robust_peak_height_252_re) begin
		pair_reference_robust_csrstorage28_storage_full[23:16] <= pair_rb_robust_peak_height_252_r;
	end
	if (pair_rb_robust_peak_height_251_re) begin
		pair_reference_robust_csrstorage28_storage_full[15:8] <= pair_rb_robust_peak_height_251_r;
	end
	if (pair_rb_robust_peak_height_250_re) begin
		pair_reference_robust_csrstorage28_storage_full[7:0] <= pair_rb_robust_peak_height_250_r;
	end
	pair_reference_robust_csrstorage28_re <= pair_rb_robust_peak_height_250_re;
	if (pair_rb_robust_peak_height_263_re) begin
		pair_reference_robust_csrstorage29_storage_full[27:24] <= pair_rb_robust_peak_height_263_r;
	end
	if (pair_rb_robust_peak_height_262_re) begin
		pair_reference_robust_csrstorage29_storage_full[23:16] <= pair_rb_robust_peak_height_262_r;
	end
	if (pair_rb_robust_peak_height_261_re) begin
		pair_reference_robust_csrstorage29_storage_full[15:8] <= pair_rb_robust_peak_height_261_r;
	end
	if (pair_rb_robust_peak_height_260_re) begin
		pair_reference_robust_csrstorage29_storage_full[7:0] <= pair_rb_robust_peak_height_260_r;
	end
	pair_reference_robust_csrstorage29_re <= pair_rb_robust_peak_height_260_re;
	if (pair_rb_robust_peak_height_273_re) begin
		pair_reference_robust_csrstorage30_storage_full[27:24] <= pair_rb_robust_peak_height_273_r;
	end
	if (pair_rb_robust_peak_height_272_re) begin
		pair_reference_robust_csrstorage30_storage_full[23:16] <= pair_rb_robust_peak_height_272_r;
	end
	if (pair_rb_robust_peak_height_271_re) begin
		pair_reference_robust_csrstorage30_storage_full[15:8] <= pair_rb_robust_peak_height_271_r;
	end
	if (pair_rb_robust_peak_height_270_re) begin
		pair_reference_robust_csrstorage30_storage_full[7:0] <= pair_rb_robust_peak_height_270_r;
	end
	pair_reference_robust_csrstorage30_re <= pair_rb_robust_peak_height_270_re;
	if (pair_rb_robust_peak_height_283_re) begin
		pair_reference_robust_csrstorage31_storage_full[27:24] <= pair_rb_robust_peak_height_283_r;
	end
	if (pair_rb_robust_peak_height_282_re) begin
		pair_reference_robust_csrstorage31_storage_full[23:16] <= pair_rb_robust_peak_height_282_r;
	end
	if (pair_rb_robust_peak_height_281_re) begin
		pair_reference_robust_csrstorage31_storage_full[15:8] <= pair_rb_robust_peak_height_281_r;
	end
	if (pair_rb_robust_peak_height_280_re) begin
		pair_reference_robust_csrstorage31_storage_full[7:0] <= pair_rb_robust_peak_height_280_r;
	end
	pair_reference_robust_csrstorage31_re <= pair_rb_robust_peak_height_280_re;
	if (pair_rb_robust_peak_height_293_re) begin
		pair_reference_robust_csrstorage32_storage_full[27:24] <= pair_rb_robust_peak_height_293_r;
	end
	if (pair_rb_robust_peak_height_292_re) begin
		pair_reference_robust_csrstorage32_storage_full[23:16] <= pair_rb_robust_peak_height_292_r;
	end
	if (pair_rb_robust_peak_height_291_re) begin
		pair_reference_robust_csrstorage32_storage_full[15:8] <= pair_rb_robust_peak_height_291_r;
	end
	if (pair_rb_robust_peak_height_290_re) begin
		pair_reference_robust_csrstorage32_storage_full[7:0] <= pair_rb_robust_peak_height_290_r;
	end
	pair_reference_robust_csrstorage32_re <= pair_rb_robust_peak_height_290_re;
	if (pair_rb_robust_peak_height_303_re) begin
		pair_reference_robust_csrstorage33_storage_full[27:24] <= pair_rb_robust_peak_height_303_r;
	end
	if (pair_rb_robust_peak_height_302_re) begin
		pair_reference_robust_csrstorage33_storage_full[23:16] <= pair_rb_robust_peak_height_302_r;
	end
	if (pair_rb_robust_peak_height_301_re) begin
		pair_reference_robust_csrstorage33_storage_full[15:8] <= pair_rb_robust_peak_height_301_r;
	end
	if (pair_rb_robust_peak_height_300_re) begin
		pair_reference_robust_csrstorage33_storage_full[7:0] <= pair_rb_robust_peak_height_300_r;
	end
	pair_reference_robust_csrstorage33_re <= pair_rb_robust_peak_height_300_re;
	if (pair_rb_robust_peak_height_313_re) begin
		pair_reference_robust_csrstorage34_storage_full[27:24] <= pair_rb_robust_peak_height_313_r;
	end
	if (pair_rb_robust_peak_height_312_re) begin
		pair_reference_robust_csrstorage34_storage_full[23:16] <= pair_rb_robust_peak_height_312_r;
	end
	if (pair_rb_robust_peak_height_311_re) begin
		pair_reference_robust_csrstorage34_storage_full[15:8] <= pair_rb_robust_peak_height_311_r;
	end
	if (pair_rb_robust_peak_height_310_re) begin
		pair_reference_robust_csrstorage34_storage_full[7:0] <= pair_rb_robust_peak_height_310_r;
	end
	pair_reference_robust_csrstorage34_re <= pair_rb_robust_peak_height_310_re;
	if (pair_rb_robust_wait_for_01_re) begin
		pair_reference_robust_csrstorage35_storage_full[13:8] <= pair_rb_robust_wait_for_01_r;
	end
	if (pair_rb_robust_wait_for_00_re) begin
		pair_reference_robust_csrstorage35_storage_full[7:0] <= pair_rb_robust_wait_for_00_r;
	end
	pair_reference_robust_csrstorage35_re <= pair_rb_robust_wait_for_00_re;
	if (pair_rb_robust_wait_for_11_re) begin
		pair_reference_robust_csrstorage36_storage_full[13:8] <= pair_rb_robust_wait_for_11_r;
	end
	if (pair_rb_robust_wait_for_10_re) begin
		pair_reference_robust_csrstorage36_storage_full[7:0] <= pair_rb_robust_wait_for_10_r;
	end
	pair_reference_robust_csrstorage36_re <= pair_rb_robust_wait_for_10_re;
	if (pair_rb_robust_wait_for_21_re) begin
		pair_reference_robust_csrstorage37_storage_full[13:8] <= pair_rb_robust_wait_for_21_r;
	end
	if (pair_rb_robust_wait_for_20_re) begin
		pair_reference_robust_csrstorage37_storage_full[7:0] <= pair_rb_robust_wait_for_20_r;
	end
	pair_reference_robust_csrstorage37_re <= pair_rb_robust_wait_for_20_re;
	if (pair_rb_robust_wait_for_31_re) begin
		pair_reference_robust_csrstorage38_storage_full[13:8] <= pair_rb_robust_wait_for_31_r;
	end
	if (pair_rb_robust_wait_for_30_re) begin
		pair_reference_robust_csrstorage38_storage_full[7:0] <= pair_rb_robust_wait_for_30_r;
	end
	pair_reference_robust_csrstorage38_re <= pair_rb_robust_wait_for_30_re;
	if (pair_rb_robust_wait_for_41_re) begin
		pair_reference_robust_csrstorage39_storage_full[13:8] <= pair_rb_robust_wait_for_41_r;
	end
	if (pair_rb_robust_wait_for_40_re) begin
		pair_reference_robust_csrstorage39_storage_full[7:0] <= pair_rb_robust_wait_for_40_r;
	end
	pair_reference_robust_csrstorage39_re <= pair_rb_robust_wait_for_40_re;
	if (pair_rb_robust_wait_for_51_re) begin
		pair_reference_robust_csrstorage40_storage_full[13:8] <= pair_rb_robust_wait_for_51_r;
	end
	if (pair_rb_robust_wait_for_50_re) begin
		pair_reference_robust_csrstorage40_storage_full[7:0] <= pair_rb_robust_wait_for_50_r;
	end
	pair_reference_robust_csrstorage40_re <= pair_rb_robust_wait_for_50_re;
	if (pair_rb_robust_wait_for_61_re) begin
		pair_reference_robust_csrstorage41_storage_full[13:8] <= pair_rb_robust_wait_for_61_r;
	end
	if (pair_rb_robust_wait_for_60_re) begin
		pair_reference_robust_csrstorage41_storage_full[7:0] <= pair_rb_robust_wait_for_60_r;
	end
	pair_reference_robust_csrstorage41_re <= pair_rb_robust_wait_for_60_re;
	if (pair_rb_robust_wait_for_71_re) begin
		pair_reference_robust_csrstorage42_storage_full[13:8] <= pair_rb_robust_wait_for_71_r;
	end
	if (pair_rb_robust_wait_for_70_re) begin
		pair_reference_robust_csrstorage42_storage_full[7:0] <= pair_rb_robust_wait_for_70_r;
	end
	pair_reference_robust_csrstorage42_re <= pair_rb_robust_wait_for_70_re;
	if (pair_rb_robust_wait_for_81_re) begin
		pair_reference_robust_csrstorage43_storage_full[13:8] <= pair_rb_robust_wait_for_81_r;
	end
	if (pair_rb_robust_wait_for_80_re) begin
		pair_reference_robust_csrstorage43_storage_full[7:0] <= pair_rb_robust_wait_for_80_r;
	end
	pair_reference_robust_csrstorage43_re <= pair_rb_robust_wait_for_80_re;
	if (pair_rb_robust_wait_for_91_re) begin
		pair_reference_robust_csrstorage44_storage_full[13:8] <= pair_rb_robust_wait_for_91_r;
	end
	if (pair_rb_robust_wait_for_90_re) begin
		pair_reference_robust_csrstorage44_storage_full[7:0] <= pair_rb_robust_wait_for_90_r;
	end
	pair_reference_robust_csrstorage44_re <= pair_rb_robust_wait_for_90_re;
	if (pair_rb_robust_wait_for_101_re) begin
		pair_reference_robust_csrstorage45_storage_full[13:8] <= pair_rb_robust_wait_for_101_r;
	end
	if (pair_rb_robust_wait_for_100_re) begin
		pair_reference_robust_csrstorage45_storage_full[7:0] <= pair_rb_robust_wait_for_100_r;
	end
	pair_reference_robust_csrstorage45_re <= pair_rb_robust_wait_for_100_re;
	if (pair_rb_robust_wait_for_111_re) begin
		pair_reference_robust_csrstorage46_storage_full[13:8] <= pair_rb_robust_wait_for_111_r;
	end
	if (pair_rb_robust_wait_for_110_re) begin
		pair_reference_robust_csrstorage46_storage_full[7:0] <= pair_rb_robust_wait_for_110_r;
	end
	pair_reference_robust_csrstorage46_re <= pair_rb_robust_wait_for_110_re;
	if (pair_rb_robust_wait_for_121_re) begin
		pair_reference_robust_csrstorage47_storage_full[13:8] <= pair_rb_robust_wait_for_121_r;
	end
	if (pair_rb_robust_wait_for_120_re) begin
		pair_reference_robust_csrstorage47_storage_full[7:0] <= pair_rb_robust_wait_for_120_r;
	end
	pair_reference_robust_csrstorage47_re <= pair_rb_robust_wait_for_120_re;
	if (pair_rb_robust_wait_for_131_re) begin
		pair_reference_robust_csrstorage48_storage_full[13:8] <= pair_rb_robust_wait_for_131_r;
	end
	if (pair_rb_robust_wait_for_130_re) begin
		pair_reference_robust_csrstorage48_storage_full[7:0] <= pair_rb_robust_wait_for_130_r;
	end
	pair_reference_robust_csrstorage48_re <= pair_rb_robust_wait_for_130_re;
	if (pair_rb_robust_wait_for_141_re) begin
		pair_reference_robust_csrstorage49_storage_full[13:8] <= pair_rb_robust_wait_for_141_r;
	end
	if (pair_rb_robust_wait_for_140_re) begin
		pair_reference_robust_csrstorage49_storage_full[7:0] <= pair_rb_robust_wait_for_140_r;
	end
	pair_reference_robust_csrstorage49_re <= pair_rb_robust_wait_for_140_re;
	if (pair_rb_robust_wait_for_151_re) begin
		pair_reference_robust_csrstorage50_storage_full[13:8] <= pair_rb_robust_wait_for_151_r;
	end
	if (pair_rb_robust_wait_for_150_re) begin
		pair_reference_robust_csrstorage50_storage_full[7:0] <= pair_rb_robust_wait_for_150_r;
	end
	pair_reference_robust_csrstorage50_re <= pair_rb_robust_wait_for_150_re;
	if (pair_rb_robust_wait_for_161_re) begin
		pair_reference_robust_csrstorage51_storage_full[13:8] <= pair_rb_robust_wait_for_161_r;
	end
	if (pair_rb_robust_wait_for_160_re) begin
		pair_reference_robust_csrstorage51_storage_full[7:0] <= pair_rb_robust_wait_for_160_r;
	end
	pair_reference_robust_csrstorage51_re <= pair_rb_robust_wait_for_160_re;
	if (pair_rb_robust_wait_for_171_re) begin
		pair_reference_robust_csrstorage52_storage_full[13:8] <= pair_rb_robust_wait_for_171_r;
	end
	if (pair_rb_robust_wait_for_170_re) begin
		pair_reference_robust_csrstorage52_storage_full[7:0] <= pair_rb_robust_wait_for_170_r;
	end
	pair_reference_robust_csrstorage52_re <= pair_rb_robust_wait_for_170_re;
	if (pair_rb_robust_wait_for_181_re) begin
		pair_reference_robust_csrstorage53_storage_full[13:8] <= pair_rb_robust_wait_for_181_r;
	end
	if (pair_rb_robust_wait_for_180_re) begin
		pair_reference_robust_csrstorage53_storage_full[7:0] <= pair_rb_robust_wait_for_180_r;
	end
	pair_reference_robust_csrstorage53_re <= pair_rb_robust_wait_for_180_re;
	if (pair_rb_robust_wait_for_191_re) begin
		pair_reference_robust_csrstorage54_storage_full[13:8] <= pair_rb_robust_wait_for_191_r;
	end
	if (pair_rb_robust_wait_for_190_re) begin
		pair_reference_robust_csrstorage54_storage_full[7:0] <= pair_rb_robust_wait_for_190_r;
	end
	pair_reference_robust_csrstorage54_re <= pair_rb_robust_wait_for_190_re;
	if (pair_rb_robust_wait_for_201_re) begin
		pair_reference_robust_csrstorage55_storage_full[13:8] <= pair_rb_robust_wait_for_201_r;
	end
	if (pair_rb_robust_wait_for_200_re) begin
		pair_reference_robust_csrstorage55_storage_full[7:0] <= pair_rb_robust_wait_for_200_r;
	end
	pair_reference_robust_csrstorage55_re <= pair_rb_robust_wait_for_200_re;
	if (pair_rb_robust_wait_for_211_re) begin
		pair_reference_robust_csrstorage56_storage_full[13:8] <= pair_rb_robust_wait_for_211_r;
	end
	if (pair_rb_robust_wait_for_210_re) begin
		pair_reference_robust_csrstorage56_storage_full[7:0] <= pair_rb_robust_wait_for_210_r;
	end
	pair_reference_robust_csrstorage56_re <= pair_rb_robust_wait_for_210_re;
	if (pair_rb_robust_wait_for_221_re) begin
		pair_reference_robust_csrstorage57_storage_full[13:8] <= pair_rb_robust_wait_for_221_r;
	end
	if (pair_rb_robust_wait_for_220_re) begin
		pair_reference_robust_csrstorage57_storage_full[7:0] <= pair_rb_robust_wait_for_220_r;
	end
	pair_reference_robust_csrstorage57_re <= pair_rb_robust_wait_for_220_re;
	if (pair_rb_robust_wait_for_231_re) begin
		pair_reference_robust_csrstorage58_storage_full[13:8] <= pair_rb_robust_wait_for_231_r;
	end
	if (pair_rb_robust_wait_for_230_re) begin
		pair_reference_robust_csrstorage58_storage_full[7:0] <= pair_rb_robust_wait_for_230_r;
	end
	pair_reference_robust_csrstorage58_re <= pair_rb_robust_wait_for_230_re;
	if (pair_rb_robust_wait_for_241_re) begin
		pair_reference_robust_csrstorage59_storage_full[13:8] <= pair_rb_robust_wait_for_241_r;
	end
	if (pair_rb_robust_wait_for_240_re) begin
		pair_reference_robust_csrstorage59_storage_full[7:0] <= pair_rb_robust_wait_for_240_r;
	end
	pair_reference_robust_csrstorage59_re <= pair_rb_robust_wait_for_240_re;
	if (pair_rb_robust_wait_for_251_re) begin
		pair_reference_robust_csrstorage60_storage_full[13:8] <= pair_rb_robust_wait_for_251_r;
	end
	if (pair_rb_robust_wait_for_250_re) begin
		pair_reference_robust_csrstorage60_storage_full[7:0] <= pair_rb_robust_wait_for_250_r;
	end
	pair_reference_robust_csrstorage60_re <= pair_rb_robust_wait_for_250_re;
	if (pair_rb_robust_wait_for_261_re) begin
		pair_reference_robust_csrstorage61_storage_full[13:8] <= pair_rb_robust_wait_for_261_r;
	end
	if (pair_rb_robust_wait_for_260_re) begin
		pair_reference_robust_csrstorage61_storage_full[7:0] <= pair_rb_robust_wait_for_260_r;
	end
	pair_reference_robust_csrstorage61_re <= pair_rb_robust_wait_for_260_re;
	if (pair_rb_robust_wait_for_271_re) begin
		pair_reference_robust_csrstorage62_storage_full[13:8] <= pair_rb_robust_wait_for_271_r;
	end
	if (pair_rb_robust_wait_for_270_re) begin
		pair_reference_robust_csrstorage62_storage_full[7:0] <= pair_rb_robust_wait_for_270_r;
	end
	pair_reference_robust_csrstorage62_re <= pair_rb_robust_wait_for_270_re;
	if (pair_rb_robust_wait_for_281_re) begin
		pair_reference_robust_csrstorage63_storage_full[13:8] <= pair_rb_robust_wait_for_281_r;
	end
	if (pair_rb_robust_wait_for_280_re) begin
		pair_reference_robust_csrstorage63_storage_full[7:0] <= pair_rb_robust_wait_for_280_r;
	end
	pair_reference_robust_csrstorage63_re <= pair_rb_robust_wait_for_280_re;
	if (pair_rb_robust_wait_for_291_re) begin
		pair_reference_robust_csrstorage64_storage_full[13:8] <= pair_rb_robust_wait_for_291_r;
	end
	if (pair_rb_robust_wait_for_290_re) begin
		pair_reference_robust_csrstorage64_storage_full[7:0] <= pair_rb_robust_wait_for_290_r;
	end
	pair_reference_robust_csrstorage64_re <= pair_rb_robust_wait_for_290_re;
	if (pair_rb_robust_wait_for_301_re) begin
		pair_reference_robust_csrstorage65_storage_full[13:8] <= pair_rb_robust_wait_for_301_r;
	end
	if (pair_rb_robust_wait_for_300_re) begin
		pair_reference_robust_csrstorage65_storage_full[7:0] <= pair_rb_robust_wait_for_300_r;
	end
	pair_reference_robust_csrstorage65_re <= pair_rb_robust_wait_for_300_re;
	if (pair_rb_robust_wait_for_311_re) begin
		pair_reference_robust_csrstorage66_storage_full[13:8] <= pair_rb_robust_wait_for_311_r;
	end
	if (pair_rb_robust_wait_for_310_re) begin
		pair_reference_robust_csrstorage66_storage_full[7:0] <= pair_rb_robust_wait_for_310_r;
	end
	pair_reference_robust_csrstorage66_re <= pair_rb_robust_wait_for_310_re;
	if (pair_rb_fast_target_position1_re) begin
		pair_reference_fast_storage_full[13:8] <= pair_rb_fast_target_position1_r;
	end
	if (pair_rb_fast_target_position0_re) begin
		pair_reference_fast_storage_full[7:0] <= pair_rb_fast_target_position0_r;
	end
	pair_reference_fast_re <= pair_rb_fast_target_position0_re;
	if (pair_rb_request_lock0_re) begin
		pair_reference_request_lock_storage_full <= pair_rb_request_lock0_r;
	end
	pair_reference_request_lock_re <= pair_rb_request_lock0_re;
	if (pair_rb_autolock_mode0_re) begin
		pair_reference_autolock_mode_storage_full[1:0] <= pair_rb_autolock_mode0_r;
	end
	pair_reference_autolock_mode_re <= pair_rb_autolock_mode0_re;
	pair_cb_bus_dat_r <= 1'd0;
	if (pair_cb_sel) begin
		case (pair_cb_bus_adr[7:0])
			1'd0: begin
				pair_cb_bus_dat_r <= pair_cb_robust_time_scale1_w;
			end
			1'd1: begin
				pair_cb_bus_dat_r <= pair_cb_robust_time_scale0_w;
			end
			2'd2: begin
				pair_cb_bus_dat_r <= pair_cb_robust_N_instructions0_w;
			end
			2'd3: begin
				pair_cb_bus_dat_r <= pair_cb_robust_final_wait_time1_w;
			end
			3'd4: begin
				pair_cb_bus_dat_r <= pair_cb_robust_final_wait_time0_w;
			end
			3'd5: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_03_w;
			end
			3'd6: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_02_w;
			end
			3'd7: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_01_w;
			end
			4'd8: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_00_w;
			end
			4'd9: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_13_w;
			end
			4'd10: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_12_w;
			end
			4'd11: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_11_w;
			end
			4'd12: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_10_w;
			end
			4'd13: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_23_w;
			end
			4'd14: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_22_w;
			end
			4'd15: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_21_w;
			end
			5'd16: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_20_w;
			end
			5'd17: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_33_w;
			end
			5'd18: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_32_w;
			end
			5'd19: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_31_w;
			end
			5'd20: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_30_w;
			end
			5'd21: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_43_w;
			end
			5'd22: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_42_w;
			end
			5'd23: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_41_w;
			end
			5'd24: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_40_w;
			end
			5'd25: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_53_w;
			end
			5'd26: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_52_w;
			end
			5'd27: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_51_w;
			end
			5'd28: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_50_w;
			end
			5'd29: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_63_w;
			end
			5'd30: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_62_w;
			end
			5'd31: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_61_w;
			end
			6'd32: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_60_w;
			end
			6'd33: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_73_w;
			end
			6'd34: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_72_w;
			end
			6'd35: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_71_w;
			end
			6'd36: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_70_w;
			end
			6'd37: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_83_w;
			end
			6'd38: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_82_w;
			end
			6'd39: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_81_w;
			end
			6'd40: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_80_w;
			end
			6'd41: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_93_w;
			end
			6'd42: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_92_w;
			end
			6'd43: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_91_w;
			end
			6'd44: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_90_w;
			end
			6'd45: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_103_w;
			end
			6'd46: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_102_w;
			end
			6'd47: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_101_w;
			end
			6'd48: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_100_w;
			end
			6'd49: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_113_w;
			end
			6'd50: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_112_w;
			end
			6'd51: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_111_w;
			end
			6'd52: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_110_w;
			end
			6'd53: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_123_w;
			end
			6'd54: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_122_w;
			end
			6'd55: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_121_w;
			end
			6'd56: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_120_w;
			end
			6'd57: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_133_w;
			end
			6'd58: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_132_w;
			end
			6'd59: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_131_w;
			end
			6'd60: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_130_w;
			end
			6'd61: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_143_w;
			end
			6'd62: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_142_w;
			end
			6'd63: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_141_w;
			end
			7'd64: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_140_w;
			end
			7'd65: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_153_w;
			end
			7'd66: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_152_w;
			end
			7'd67: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_151_w;
			end
			7'd68: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_150_w;
			end
			7'd69: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_163_w;
			end
			7'd70: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_162_w;
			end
			7'd71: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_161_w;
			end
			7'd72: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_160_w;
			end
			7'd73: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_173_w;
			end
			7'd74: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_172_w;
			end
			7'd75: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_171_w;
			end
			7'd76: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_170_w;
			end
			7'd77: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_183_w;
			end
			7'd78: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_182_w;
			end
			7'd79: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_181_w;
			end
			7'd80: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_180_w;
			end
			7'd81: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_193_w;
			end
			7'd82: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_192_w;
			end
			7'd83: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_191_w;
			end
			7'd84: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_190_w;
			end
			7'd85: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_203_w;
			end
			7'd86: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_202_w;
			end
			7'd87: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_201_w;
			end
			7'd88: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_200_w;
			end
			7'd89: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_213_w;
			end
			7'd90: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_212_w;
			end
			7'd91: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_211_w;
			end
			7'd92: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_210_w;
			end
			7'd93: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_223_w;
			end
			7'd94: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_222_w;
			end
			7'd95: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_221_w;
			end
			7'd96: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_220_w;
			end
			7'd97: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_233_w;
			end
			7'd98: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_232_w;
			end
			7'd99: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_231_w;
			end
			7'd100: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_230_w;
			end
			7'd101: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_243_w;
			end
			7'd102: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_242_w;
			end
			7'd103: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_241_w;
			end
			7'd104: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_240_w;
			end
			7'd105: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_253_w;
			end
			7'd106: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_252_w;
			end
			7'd107: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_251_w;
			end
			7'd108: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_250_w;
			end
			7'd109: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_263_w;
			end
			7'd110: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_262_w;
			end
			7'd111: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_261_w;
			end
			7'd112: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_260_w;
			end
			7'd113: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_273_w;
			end
			7'd114: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_272_w;
			end
			7'd115: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_271_w;
			end
			7'd116: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_270_w;
			end
			7'd117: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_283_w;
			end
			7'd118: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_282_w;
			end
			7'd119: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_281_w;
			end
			7'd120: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_280_w;
			end
			7'd121: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_293_w;
			end
			7'd122: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_292_w;
			end
			7'd123: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_291_w;
			end
			7'd124: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_290_w;
			end
			7'd125: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_303_w;
			end
			7'd126: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_302_w;
			end
			7'd127: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_301_w;
			end
			8'd128: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_300_w;
			end
			8'd129: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_313_w;
			end
			8'd130: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_312_w;
			end
			8'd131: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_311_w;
			end
			8'd132: begin
				pair_cb_bus_dat_r <= pair_cb_robust_peak_height_310_w;
			end
			8'd133: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_01_w;
			end
			8'd134: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_00_w;
			end
			8'd135: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_11_w;
			end
			8'd136: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_10_w;
			end
			8'd137: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_21_w;
			end
			8'd138: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_20_w;
			end
			8'd139: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_31_w;
			end
			8'd140: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_30_w;
			end
			8'd141: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_41_w;
			end
			8'd142: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_40_w;
			end
			8'd143: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_51_w;
			end
			8'd144: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_50_w;
			end
			8'd145: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_61_w;
			end
			8'd146: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_60_w;
			end
			8'd147: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_71_w;
			end
			8'd148: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_70_w;
			end
			8'd149: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_81_w;
			end
			8'd150: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_80_w;
			end
			8'd151: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_91_w;
			end
			8'd152: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_90_w;
			end
			8'd153: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_101_w;
			end
			8'd154: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_100_w;
			end
			8'd155: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_111_w;
			end
			8'd156: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_110_w;
			end
			8'd157: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_121_w;
			end
			8'd158: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_120_w;
			end
			8'd159: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_131_w;
			end
			8'd160: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_130_w;
			end
			8'd161: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_141_w;
			end
			8'd162: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_140_w;
			end
			8'd163: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_151_w;
			end
			8'd164: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_150_w;
			end
			8'd165: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_161_w;
			end
			8'd166: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_160_w;
			end
			8'd167: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_171_w;
			end
			8'd168: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_170_w;
			end
			8'd169: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_181_w;
			end
			8'd170: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_180_w;
			end
			8'd171: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_191_w;
			end
			8'd172: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_190_w;
			end
			8'd173: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_201_w;
			end
			8'd174: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_200_w;
			end
			8'd175: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_211_w;
			end
			8'd176: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_210_w;
			end
			8'd177: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_221_w;
			end
			8'd178: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_220_w;
			end
			8'd179: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_231_w;
			end
			8'd180: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_230_w;
			end
			8'd181: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_241_w;
			end
			8'd182: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_240_w;
			end
			8'd183: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_251_w;
			end
			8'd184: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_250_w;
			end
			8'd185: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_261_w;
			end
			8'd186: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_260_w;
			end
			8'd187: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_271_w;
			end
			8'd188: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_270_w;
			end
			8'd189: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_281_w;
			end
			8'd190: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_280_w;
			end
			8'd191: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_291_w;
			end
			8'd192: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_290_w;
			end
			8'd193: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_301_w;
			end
			8'd194: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_300_w;
			end
			8'd195: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_311_w;
			end
			8'd196: begin
				pair_cb_bus_dat_r <= pair_cb_robust_wait_for_310_w;
			end
			8'd197: begin
				pair_cb_bus_dat_r <= pair_cb_fast_target_position1_w;
			end
			8'd198: begin
				pair_cb_bus_dat_r <= pair_cb_fast_target_position0_w;
			end
			8'd199: begin
				pair_cb_bus_dat_r <= pair_cb_request_lock0_w;
			end
			8'd200: begin
				pair_cb_bus_dat_r <= pair_cb_autolock_mode0_w;
			end
			8'd201: begin
				pair_cb_bus_dat_r <= pair_cb_lock_running_w;
			end
		endcase
	end
	if (pair_cb_robust_time_scale1_re) begin
		pair_candidate_pipelinedrobustautolock_time_scale_storage_full[13:8] <= pair_cb_robust_time_scale1_r;
	end
	if (pair_cb_robust_time_scale0_re) begin
		pair_candidate_pipelinedrobustautolock_time_scale_storage_full[7:0] <= pair_cb_robust_time_scale0_r;
	end
	pair_candidate_pipelinedrobustautolock_time_scale_re <= pair_cb_robust_time_scale0_re;
	if (pair_cb_robust_N_instructions0_re) begin
		pair_candidate_pipelinedrobustautolock_N_instructions_storage_full[4:0] <= pair_cb_robust_N_instructions0_r;
	end
	pair_candidate_pipelinedrobustautolock_N_instructions_re <= pair_cb_robust_N_instructions0_re;
	if (pair_cb_robust_final_wait_time1_re) begin
		pair_candidate_pipelinedrobustautolock_final_wait_time_storage_full[13:8] <= pair_cb_robust_final_wait_time1_r;
	end
	if (pair_cb_robust_final_wait_time0_re) begin
		pair_candidate_pipelinedrobustautolock_final_wait_time_storage_full[7:0] <= pair_cb_robust_final_wait_time0_r;
	end
	pair_candidate_pipelinedrobustautolock_final_wait_time_re <= pair_cb_robust_final_wait_time0_re;
	if (pair_cb_robust_peak_height_03_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full[27:24] <= pair_cb_robust_peak_height_03_r;
	end
	if (pair_cb_robust_peak_height_02_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full[23:16] <= pair_cb_robust_peak_height_02_r;
	end
	if (pair_cb_robust_peak_height_01_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full[15:8] <= pair_cb_robust_peak_height_01_r;
	end
	if (pair_cb_robust_peak_height_00_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full[7:0] <= pair_cb_robust_peak_height_00_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage0_re <= pair_cb_robust_peak_height_00_re;
	if (pair_cb_robust_peak_height_13_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full[27:24] <= pair_cb_robust_peak_height_13_r;
	end
	if (pair_cb_robust_peak_height_12_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full[23:16] <= pair_cb_robust_peak_height_12_r;
	end
	if (pair_cb_robust_peak_height_11_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full[15:8] <= pair_cb_robust_peak_height_11_r;
	end
	if (pair_cb_robust_peak_height_10_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full[7:0] <= pair_cb_robust_peak_height_10_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage1_re <= pair_cb_robust_peak_height_10_re;
	if (pair_cb_robust_peak_height_23_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full[27:24] <= pair_cb_robust_peak_height_23_r;
	end
	if (pair_cb_robust_peak_height_22_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full[23:16] <= pair_cb_robust_peak_height_22_r;
	end
	if (pair_cb_robust_peak_height_21_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full[15:8] <= pair_cb_robust_peak_height_21_r;
	end
	if (pair_cb_robust_peak_height_20_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full[7:0] <= pair_cb_robust_peak_height_20_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage2_re <= pair_cb_robust_peak_height_20_re;
	if (pair_cb_robust_peak_height_33_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full[27:24] <= pair_cb_robust_peak_height_33_r;
	end
	if (pair_cb_robust_peak_height_32_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full[23:16] <= pair_cb_robust_peak_height_32_r;
	end
	if (pair_cb_robust_peak_height_31_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full[15:8] <= pair_cb_robust_peak_height_31_r;
	end
	if (pair_cb_robust_peak_height_30_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full[7:0] <= pair_cb_robust_peak_height_30_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage3_re <= pair_cb_robust_peak_height_30_re;
	if (pair_cb_robust_peak_height_43_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full[27:24] <= pair_cb_robust_peak_height_43_r;
	end
	if (pair_cb_robust_peak_height_42_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full[23:16] <= pair_cb_robust_peak_height_42_r;
	end
	if (pair_cb_robust_peak_height_41_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full[15:8] <= pair_cb_robust_peak_height_41_r;
	end
	if (pair_cb_robust_peak_height_40_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full[7:0] <= pair_cb_robust_peak_height_40_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage4_re <= pair_cb_robust_peak_height_40_re;
	if (pair_cb_robust_peak_height_53_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full[27:24] <= pair_cb_robust_peak_height_53_r;
	end
	if (pair_cb_robust_peak_height_52_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full[23:16] <= pair_cb_robust_peak_height_52_r;
	end
	if (pair_cb_robust_peak_height_51_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full[15:8] <= pair_cb_robust_peak_height_51_r;
	end
	if (pair_cb_robust_peak_height_50_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full[7:0] <= pair_cb_robust_peak_height_50_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage5_re <= pair_cb_robust_peak_height_50_re;
	if (pair_cb_robust_peak_height_63_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full[27:24] <= pair_cb_robust_peak_height_63_r;
	end
	if (pair_cb_robust_peak_height_62_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full[23:16] <= pair_cb_robust_peak_height_62_r;
	end
	if (pair_cb_robust_peak_height_61_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full[15:8] <= pair_cb_robust_peak_height_61_r;
	end
	if (pair_cb_robust_peak_height_60_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full[7:0] <= pair_cb_robust_peak_height_60_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage6_re <= pair_cb_robust_peak_height_60_re;
	if (pair_cb_robust_peak_height_73_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full[27:24] <= pair_cb_robust_peak_height_73_r;
	end
	if (pair_cb_robust_peak_height_72_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full[23:16] <= pair_cb_robust_peak_height_72_r;
	end
	if (pair_cb_robust_peak_height_71_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full[15:8] <= pair_cb_robust_peak_height_71_r;
	end
	if (pair_cb_robust_peak_height_70_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full[7:0] <= pair_cb_robust_peak_height_70_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage7_re <= pair_cb_robust_peak_height_70_re;
	if (pair_cb_robust_peak_height_83_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full[27:24] <= pair_cb_robust_peak_height_83_r;
	end
	if (pair_cb_robust_peak_height_82_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full[23:16] <= pair_cb_robust_peak_height_82_r;
	end
	if (pair_cb_robust_peak_height_81_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full[15:8] <= pair_cb_robust_peak_height_81_r;
	end
	if (pair_cb_robust_peak_height_80_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full[7:0] <= pair_cb_robust_peak_height_80_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage8_re <= pair_cb_robust_peak_height_80_re;
	if (pair_cb_robust_peak_height_93_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full[27:24] <= pair_cb_robust_peak_height_93_r;
	end
	if (pair_cb_robust_peak_height_92_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full[23:16] <= pair_cb_robust_peak_height_92_r;
	end
	if (pair_cb_robust_peak_height_91_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full[15:8] <= pair_cb_robust_peak_height_91_r;
	end
	if (pair_cb_robust_peak_height_90_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full[7:0] <= pair_cb_robust_peak_height_90_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage9_re <= pair_cb_robust_peak_height_90_re;
	if (pair_cb_robust_peak_height_103_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full[27:24] <= pair_cb_robust_peak_height_103_r;
	end
	if (pair_cb_robust_peak_height_102_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full[23:16] <= pair_cb_robust_peak_height_102_r;
	end
	if (pair_cb_robust_peak_height_101_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full[15:8] <= pair_cb_robust_peak_height_101_r;
	end
	if (pair_cb_robust_peak_height_100_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full[7:0] <= pair_cb_robust_peak_height_100_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage10_re <= pair_cb_robust_peak_height_100_re;
	if (pair_cb_robust_peak_height_113_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full[27:24] <= pair_cb_robust_peak_height_113_r;
	end
	if (pair_cb_robust_peak_height_112_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full[23:16] <= pair_cb_robust_peak_height_112_r;
	end
	if (pair_cb_robust_peak_height_111_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full[15:8] <= pair_cb_robust_peak_height_111_r;
	end
	if (pair_cb_robust_peak_height_110_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full[7:0] <= pair_cb_robust_peak_height_110_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage11_re <= pair_cb_robust_peak_height_110_re;
	if (pair_cb_robust_peak_height_123_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full[27:24] <= pair_cb_robust_peak_height_123_r;
	end
	if (pair_cb_robust_peak_height_122_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full[23:16] <= pair_cb_robust_peak_height_122_r;
	end
	if (pair_cb_robust_peak_height_121_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full[15:8] <= pair_cb_robust_peak_height_121_r;
	end
	if (pair_cb_robust_peak_height_120_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full[7:0] <= pair_cb_robust_peak_height_120_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage12_re <= pair_cb_robust_peak_height_120_re;
	if (pair_cb_robust_peak_height_133_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full[27:24] <= pair_cb_robust_peak_height_133_r;
	end
	if (pair_cb_robust_peak_height_132_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full[23:16] <= pair_cb_robust_peak_height_132_r;
	end
	if (pair_cb_robust_peak_height_131_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full[15:8] <= pair_cb_robust_peak_height_131_r;
	end
	if (pair_cb_robust_peak_height_130_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full[7:0] <= pair_cb_robust_peak_height_130_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage13_re <= pair_cb_robust_peak_height_130_re;
	if (pair_cb_robust_peak_height_143_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full[27:24] <= pair_cb_robust_peak_height_143_r;
	end
	if (pair_cb_robust_peak_height_142_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full[23:16] <= pair_cb_robust_peak_height_142_r;
	end
	if (pair_cb_robust_peak_height_141_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full[15:8] <= pair_cb_robust_peak_height_141_r;
	end
	if (pair_cb_robust_peak_height_140_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full[7:0] <= pair_cb_robust_peak_height_140_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage14_re <= pair_cb_robust_peak_height_140_re;
	if (pair_cb_robust_peak_height_153_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full[27:24] <= pair_cb_robust_peak_height_153_r;
	end
	if (pair_cb_robust_peak_height_152_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full[23:16] <= pair_cb_robust_peak_height_152_r;
	end
	if (pair_cb_robust_peak_height_151_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full[15:8] <= pair_cb_robust_peak_height_151_r;
	end
	if (pair_cb_robust_peak_height_150_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full[7:0] <= pair_cb_robust_peak_height_150_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage15_re <= pair_cb_robust_peak_height_150_re;
	if (pair_cb_robust_peak_height_163_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full[27:24] <= pair_cb_robust_peak_height_163_r;
	end
	if (pair_cb_robust_peak_height_162_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full[23:16] <= pair_cb_robust_peak_height_162_r;
	end
	if (pair_cb_robust_peak_height_161_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full[15:8] <= pair_cb_robust_peak_height_161_r;
	end
	if (pair_cb_robust_peak_height_160_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full[7:0] <= pair_cb_robust_peak_height_160_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage16_re <= pair_cb_robust_peak_height_160_re;
	if (pair_cb_robust_peak_height_173_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full[27:24] <= pair_cb_robust_peak_height_173_r;
	end
	if (pair_cb_robust_peak_height_172_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full[23:16] <= pair_cb_robust_peak_height_172_r;
	end
	if (pair_cb_robust_peak_height_171_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full[15:8] <= pair_cb_robust_peak_height_171_r;
	end
	if (pair_cb_robust_peak_height_170_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full[7:0] <= pair_cb_robust_peak_height_170_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage17_re <= pair_cb_robust_peak_height_170_re;
	if (pair_cb_robust_peak_height_183_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full[27:24] <= pair_cb_robust_peak_height_183_r;
	end
	if (pair_cb_robust_peak_height_182_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full[23:16] <= pair_cb_robust_peak_height_182_r;
	end
	if (pair_cb_robust_peak_height_181_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full[15:8] <= pair_cb_robust_peak_height_181_r;
	end
	if (pair_cb_robust_peak_height_180_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full[7:0] <= pair_cb_robust_peak_height_180_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage18_re <= pair_cb_robust_peak_height_180_re;
	if (pair_cb_robust_peak_height_193_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full[27:24] <= pair_cb_robust_peak_height_193_r;
	end
	if (pair_cb_robust_peak_height_192_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full[23:16] <= pair_cb_robust_peak_height_192_r;
	end
	if (pair_cb_robust_peak_height_191_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full[15:8] <= pair_cb_robust_peak_height_191_r;
	end
	if (pair_cb_robust_peak_height_190_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full[7:0] <= pair_cb_robust_peak_height_190_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage19_re <= pair_cb_robust_peak_height_190_re;
	if (pair_cb_robust_peak_height_203_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full[27:24] <= pair_cb_robust_peak_height_203_r;
	end
	if (pair_cb_robust_peak_height_202_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full[23:16] <= pair_cb_robust_peak_height_202_r;
	end
	if (pair_cb_robust_peak_height_201_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full[15:8] <= pair_cb_robust_peak_height_201_r;
	end
	if (pair_cb_robust_peak_height_200_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full[7:0] <= pair_cb_robust_peak_height_200_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage20_re <= pair_cb_robust_peak_height_200_re;
	if (pair_cb_robust_peak_height_213_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full[27:24] <= pair_cb_robust_peak_height_213_r;
	end
	if (pair_cb_robust_peak_height_212_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full[23:16] <= pair_cb_robust_peak_height_212_r;
	end
	if (pair_cb_robust_peak_height_211_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full[15:8] <= pair_cb_robust_peak_height_211_r;
	end
	if (pair_cb_robust_peak_height_210_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full[7:0] <= pair_cb_robust_peak_height_210_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage21_re <= pair_cb_robust_peak_height_210_re;
	if (pair_cb_robust_peak_height_223_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full[27:24] <= pair_cb_robust_peak_height_223_r;
	end
	if (pair_cb_robust_peak_height_222_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full[23:16] <= pair_cb_robust_peak_height_222_r;
	end
	if (pair_cb_robust_peak_height_221_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full[15:8] <= pair_cb_robust_peak_height_221_r;
	end
	if (pair_cb_robust_peak_height_220_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full[7:0] <= pair_cb_robust_peak_height_220_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage22_re <= pair_cb_robust_peak_height_220_re;
	if (pair_cb_robust_peak_height_233_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full[27:24] <= pair_cb_robust_peak_height_233_r;
	end
	if (pair_cb_robust_peak_height_232_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full[23:16] <= pair_cb_robust_peak_height_232_r;
	end
	if (pair_cb_robust_peak_height_231_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full[15:8] <= pair_cb_robust_peak_height_231_r;
	end
	if (pair_cb_robust_peak_height_230_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full[7:0] <= pair_cb_robust_peak_height_230_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage23_re <= pair_cb_robust_peak_height_230_re;
	if (pair_cb_robust_peak_height_243_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full[27:24] <= pair_cb_robust_peak_height_243_r;
	end
	if (pair_cb_robust_peak_height_242_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full[23:16] <= pair_cb_robust_peak_height_242_r;
	end
	if (pair_cb_robust_peak_height_241_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full[15:8] <= pair_cb_robust_peak_height_241_r;
	end
	if (pair_cb_robust_peak_height_240_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full[7:0] <= pair_cb_robust_peak_height_240_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage24_re <= pair_cb_robust_peak_height_240_re;
	if (pair_cb_robust_peak_height_253_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full[27:24] <= pair_cb_robust_peak_height_253_r;
	end
	if (pair_cb_robust_peak_height_252_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full[23:16] <= pair_cb_robust_peak_height_252_r;
	end
	if (pair_cb_robust_peak_height_251_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full[15:8] <= pair_cb_robust_peak_height_251_r;
	end
	if (pair_cb_robust_peak_height_250_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full[7:0] <= pair_cb_robust_peak_height_250_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage25_re <= pair_cb_robust_peak_height_250_re;
	if (pair_cb_robust_peak_height_263_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full[27:24] <= pair_cb_robust_peak_height_263_r;
	end
	if (pair_cb_robust_peak_height_262_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full[23:16] <= pair_cb_robust_peak_height_262_r;
	end
	if (pair_cb_robust_peak_height_261_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full[15:8] <= pair_cb_robust_peak_height_261_r;
	end
	if (pair_cb_robust_peak_height_260_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full[7:0] <= pair_cb_robust_peak_height_260_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage26_re <= pair_cb_robust_peak_height_260_re;
	if (pair_cb_robust_peak_height_273_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full[27:24] <= pair_cb_robust_peak_height_273_r;
	end
	if (pair_cb_robust_peak_height_272_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full[23:16] <= pair_cb_robust_peak_height_272_r;
	end
	if (pair_cb_robust_peak_height_271_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full[15:8] <= pair_cb_robust_peak_height_271_r;
	end
	if (pair_cb_robust_peak_height_270_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full[7:0] <= pair_cb_robust_peak_height_270_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage27_re <= pair_cb_robust_peak_height_270_re;
	if (pair_cb_robust_peak_height_283_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full[27:24] <= pair_cb_robust_peak_height_283_r;
	end
	if (pair_cb_robust_peak_height_282_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full[23:16] <= pair_cb_robust_peak_height_282_r;
	end
	if (pair_cb_robust_peak_height_281_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full[15:8] <= pair_cb_robust_peak_height_281_r;
	end
	if (pair_cb_robust_peak_height_280_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full[7:0] <= pair_cb_robust_peak_height_280_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage28_re <= pair_cb_robust_peak_height_280_re;
	if (pair_cb_robust_peak_height_293_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full[27:24] <= pair_cb_robust_peak_height_293_r;
	end
	if (pair_cb_robust_peak_height_292_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full[23:16] <= pair_cb_robust_peak_height_292_r;
	end
	if (pair_cb_robust_peak_height_291_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full[15:8] <= pair_cb_robust_peak_height_291_r;
	end
	if (pair_cb_robust_peak_height_290_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full[7:0] <= pair_cb_robust_peak_height_290_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage29_re <= pair_cb_robust_peak_height_290_re;
	if (pair_cb_robust_peak_height_303_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full[27:24] <= pair_cb_robust_peak_height_303_r;
	end
	if (pair_cb_robust_peak_height_302_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full[23:16] <= pair_cb_robust_peak_height_302_r;
	end
	if (pair_cb_robust_peak_height_301_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full[15:8] <= pair_cb_robust_peak_height_301_r;
	end
	if (pair_cb_robust_peak_height_300_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full[7:0] <= pair_cb_robust_peak_height_300_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage30_re <= pair_cb_robust_peak_height_300_re;
	if (pair_cb_robust_peak_height_313_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full[27:24] <= pair_cb_robust_peak_height_313_r;
	end
	if (pair_cb_robust_peak_height_312_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full[23:16] <= pair_cb_robust_peak_height_312_r;
	end
	if (pair_cb_robust_peak_height_311_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full[15:8] <= pair_cb_robust_peak_height_311_r;
	end
	if (pair_cb_robust_peak_height_310_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full[7:0] <= pair_cb_robust_peak_height_310_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage31_re <= pair_cb_robust_peak_height_310_re;
	if (pair_cb_robust_wait_for_01_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage32_storage_full[13:8] <= pair_cb_robust_wait_for_01_r;
	end
	if (pair_cb_robust_wait_for_00_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage32_storage_full[7:0] <= pair_cb_robust_wait_for_00_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage32_re <= pair_cb_robust_wait_for_00_re;
	if (pair_cb_robust_wait_for_11_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage33_storage_full[13:8] <= pair_cb_robust_wait_for_11_r;
	end
	if (pair_cb_robust_wait_for_10_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage33_storage_full[7:0] <= pair_cb_robust_wait_for_10_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage33_re <= pair_cb_robust_wait_for_10_re;
	if (pair_cb_robust_wait_for_21_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage34_storage_full[13:8] <= pair_cb_robust_wait_for_21_r;
	end
	if (pair_cb_robust_wait_for_20_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage34_storage_full[7:0] <= pair_cb_robust_wait_for_20_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage34_re <= pair_cb_robust_wait_for_20_re;
	if (pair_cb_robust_wait_for_31_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage35_storage_full[13:8] <= pair_cb_robust_wait_for_31_r;
	end
	if (pair_cb_robust_wait_for_30_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage35_storage_full[7:0] <= pair_cb_robust_wait_for_30_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage35_re <= pair_cb_robust_wait_for_30_re;
	if (pair_cb_robust_wait_for_41_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage36_storage_full[13:8] <= pair_cb_robust_wait_for_41_r;
	end
	if (pair_cb_robust_wait_for_40_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage36_storage_full[7:0] <= pair_cb_robust_wait_for_40_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage36_re <= pair_cb_robust_wait_for_40_re;
	if (pair_cb_robust_wait_for_51_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage37_storage_full[13:8] <= pair_cb_robust_wait_for_51_r;
	end
	if (pair_cb_robust_wait_for_50_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage37_storage_full[7:0] <= pair_cb_robust_wait_for_50_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage37_re <= pair_cb_robust_wait_for_50_re;
	if (pair_cb_robust_wait_for_61_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage38_storage_full[13:8] <= pair_cb_robust_wait_for_61_r;
	end
	if (pair_cb_robust_wait_for_60_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage38_storage_full[7:0] <= pair_cb_robust_wait_for_60_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage38_re <= pair_cb_robust_wait_for_60_re;
	if (pair_cb_robust_wait_for_71_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage39_storage_full[13:8] <= pair_cb_robust_wait_for_71_r;
	end
	if (pair_cb_robust_wait_for_70_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage39_storage_full[7:0] <= pair_cb_robust_wait_for_70_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage39_re <= pair_cb_robust_wait_for_70_re;
	if (pair_cb_robust_wait_for_81_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage40_storage_full[13:8] <= pair_cb_robust_wait_for_81_r;
	end
	if (pair_cb_robust_wait_for_80_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage40_storage_full[7:0] <= pair_cb_robust_wait_for_80_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage40_re <= pair_cb_robust_wait_for_80_re;
	if (pair_cb_robust_wait_for_91_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage41_storage_full[13:8] <= pair_cb_robust_wait_for_91_r;
	end
	if (pair_cb_robust_wait_for_90_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage41_storage_full[7:0] <= pair_cb_robust_wait_for_90_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage41_re <= pair_cb_robust_wait_for_90_re;
	if (pair_cb_robust_wait_for_101_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage42_storage_full[13:8] <= pair_cb_robust_wait_for_101_r;
	end
	if (pair_cb_robust_wait_for_100_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage42_storage_full[7:0] <= pair_cb_robust_wait_for_100_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage42_re <= pair_cb_robust_wait_for_100_re;
	if (pair_cb_robust_wait_for_111_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage43_storage_full[13:8] <= pair_cb_robust_wait_for_111_r;
	end
	if (pair_cb_robust_wait_for_110_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage43_storage_full[7:0] <= pair_cb_robust_wait_for_110_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage43_re <= pair_cb_robust_wait_for_110_re;
	if (pair_cb_robust_wait_for_121_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage44_storage_full[13:8] <= pair_cb_robust_wait_for_121_r;
	end
	if (pair_cb_robust_wait_for_120_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage44_storage_full[7:0] <= pair_cb_robust_wait_for_120_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage44_re <= pair_cb_robust_wait_for_120_re;
	if (pair_cb_robust_wait_for_131_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage45_storage_full[13:8] <= pair_cb_robust_wait_for_131_r;
	end
	if (pair_cb_robust_wait_for_130_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage45_storage_full[7:0] <= pair_cb_robust_wait_for_130_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage45_re <= pair_cb_robust_wait_for_130_re;
	if (pair_cb_robust_wait_for_141_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage46_storage_full[13:8] <= pair_cb_robust_wait_for_141_r;
	end
	if (pair_cb_robust_wait_for_140_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage46_storage_full[7:0] <= pair_cb_robust_wait_for_140_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage46_re <= pair_cb_robust_wait_for_140_re;
	if (pair_cb_robust_wait_for_151_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage47_storage_full[13:8] <= pair_cb_robust_wait_for_151_r;
	end
	if (pair_cb_robust_wait_for_150_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage47_storage_full[7:0] <= pair_cb_robust_wait_for_150_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage47_re <= pair_cb_robust_wait_for_150_re;
	if (pair_cb_robust_wait_for_161_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage48_storage_full[13:8] <= pair_cb_robust_wait_for_161_r;
	end
	if (pair_cb_robust_wait_for_160_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage48_storage_full[7:0] <= pair_cb_robust_wait_for_160_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage48_re <= pair_cb_robust_wait_for_160_re;
	if (pair_cb_robust_wait_for_171_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage49_storage_full[13:8] <= pair_cb_robust_wait_for_171_r;
	end
	if (pair_cb_robust_wait_for_170_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage49_storage_full[7:0] <= pair_cb_robust_wait_for_170_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage49_re <= pair_cb_robust_wait_for_170_re;
	if (pair_cb_robust_wait_for_181_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage50_storage_full[13:8] <= pair_cb_robust_wait_for_181_r;
	end
	if (pair_cb_robust_wait_for_180_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage50_storage_full[7:0] <= pair_cb_robust_wait_for_180_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage50_re <= pair_cb_robust_wait_for_180_re;
	if (pair_cb_robust_wait_for_191_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage51_storage_full[13:8] <= pair_cb_robust_wait_for_191_r;
	end
	if (pair_cb_robust_wait_for_190_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage51_storage_full[7:0] <= pair_cb_robust_wait_for_190_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage51_re <= pair_cb_robust_wait_for_190_re;
	if (pair_cb_robust_wait_for_201_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage52_storage_full[13:8] <= pair_cb_robust_wait_for_201_r;
	end
	if (pair_cb_robust_wait_for_200_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage52_storage_full[7:0] <= pair_cb_robust_wait_for_200_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage52_re <= pair_cb_robust_wait_for_200_re;
	if (pair_cb_robust_wait_for_211_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage53_storage_full[13:8] <= pair_cb_robust_wait_for_211_r;
	end
	if (pair_cb_robust_wait_for_210_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage53_storage_full[7:0] <= pair_cb_robust_wait_for_210_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage53_re <= pair_cb_robust_wait_for_210_re;
	if (pair_cb_robust_wait_for_221_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage54_storage_full[13:8] <= pair_cb_robust_wait_for_221_r;
	end
	if (pair_cb_robust_wait_for_220_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage54_storage_full[7:0] <= pair_cb_robust_wait_for_220_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage54_re <= pair_cb_robust_wait_for_220_re;
	if (pair_cb_robust_wait_for_231_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage55_storage_full[13:8] <= pair_cb_robust_wait_for_231_r;
	end
	if (pair_cb_robust_wait_for_230_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage55_storage_full[7:0] <= pair_cb_robust_wait_for_230_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage55_re <= pair_cb_robust_wait_for_230_re;
	if (pair_cb_robust_wait_for_241_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage56_storage_full[13:8] <= pair_cb_robust_wait_for_241_r;
	end
	if (pair_cb_robust_wait_for_240_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage56_storage_full[7:0] <= pair_cb_robust_wait_for_240_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage56_re <= pair_cb_robust_wait_for_240_re;
	if (pair_cb_robust_wait_for_251_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage57_storage_full[13:8] <= pair_cb_robust_wait_for_251_r;
	end
	if (pair_cb_robust_wait_for_250_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage57_storage_full[7:0] <= pair_cb_robust_wait_for_250_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage57_re <= pair_cb_robust_wait_for_250_re;
	if (pair_cb_robust_wait_for_261_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage58_storage_full[13:8] <= pair_cb_robust_wait_for_261_r;
	end
	if (pair_cb_robust_wait_for_260_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage58_storage_full[7:0] <= pair_cb_robust_wait_for_260_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage58_re <= pair_cb_robust_wait_for_260_re;
	if (pair_cb_robust_wait_for_271_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage59_storage_full[13:8] <= pair_cb_robust_wait_for_271_r;
	end
	if (pair_cb_robust_wait_for_270_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage59_storage_full[7:0] <= pair_cb_robust_wait_for_270_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage59_re <= pair_cb_robust_wait_for_270_re;
	if (pair_cb_robust_wait_for_281_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage60_storage_full[13:8] <= pair_cb_robust_wait_for_281_r;
	end
	if (pair_cb_robust_wait_for_280_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage60_storage_full[7:0] <= pair_cb_robust_wait_for_280_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage60_re <= pair_cb_robust_wait_for_280_re;
	if (pair_cb_robust_wait_for_291_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage61_storage_full[13:8] <= pair_cb_robust_wait_for_291_r;
	end
	if (pair_cb_robust_wait_for_290_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage61_storage_full[7:0] <= pair_cb_robust_wait_for_290_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage61_re <= pair_cb_robust_wait_for_290_re;
	if (pair_cb_robust_wait_for_301_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage62_storage_full[13:8] <= pair_cb_robust_wait_for_301_r;
	end
	if (pair_cb_robust_wait_for_300_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage62_storage_full[7:0] <= pair_cb_robust_wait_for_300_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage62_re <= pair_cb_robust_wait_for_300_re;
	if (pair_cb_robust_wait_for_311_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage63_storage_full[13:8] <= pair_cb_robust_wait_for_311_r;
	end
	if (pair_cb_robust_wait_for_310_re) begin
		pair_candidate_pipelinedrobustautolock_csrstorage63_storage_full[7:0] <= pair_cb_robust_wait_for_310_r;
	end
	pair_candidate_pipelinedrobustautolock_csrstorage63_re <= pair_cb_robust_wait_for_310_re;
	if (pair_cb_fast_target_position1_re) begin
		pair_candidate_fast_storage_full[13:8] <= pair_cb_fast_target_position1_r;
	end
	if (pair_cb_fast_target_position0_re) begin
		pair_candidate_fast_storage_full[7:0] <= pair_cb_fast_target_position0_r;
	end
	pair_candidate_fast_re <= pair_cb_fast_target_position0_re;
	if (pair_cb_request_lock0_re) begin
		pair_candidate_request_lock_storage_full <= pair_cb_request_lock0_r;
	end
	pair_candidate_request_lock_re <= pair_cb_request_lock0_re;
	if (pair_cb_autolock_mode0_re) begin
		pair_candidate_autolock_mode_storage_full[1:0] <= pair_cb_autolock_mode0_r;
	end
	pair_candidate_autolock_mode_re <= pair_cb_autolock_mode0_re;
	if (sys_rst) begin
		pair_reference_robust_sum_value <= 28'sd0;
		pair_reference_robust_counter <= 13'd0;
		pair_reference_robust_watching <= 1'd0;
		pair_reference_robust_current_instruction_idx <= 5'd0;
		pair_reference_robust_waited_for <= 14'd0;
		pair_reference_robust_final_waited_for <= 14'd0;
		pair_reference_robust_q0 <= 14'sd0;
		pair_reference_robust_q1 <= 1'd0;
		pair_reference_robust_q2 <= 1'd0;
		pair_reference_robust_q3 <= 1'd0;
		pair_reference_robust_q4 <= 1'd0;
		pair_reference_robust_csrstorage0_storage_full <= 14'd0;
		pair_reference_robust_csrstorage0_re <= 1'd0;
		pair_reference_robust_q5 <= 14'd0;
		pair_reference_robust_csrstorage1_storage_full <= 5'd0;
		pair_reference_robust_csrstorage1_re <= 1'd0;
		pair_reference_robust_q6 <= 5'd0;
		pair_reference_robust_csrstorage2_storage_full <= 14'd0;
		pair_reference_robust_csrstorage2_re <= 1'd0;
		pair_reference_robust_q7 <= 14'd0;
		pair_reference_robust_csrstorage3_storage_full <= 28'd0;
		pair_reference_robust_csrstorage3_re <= 1'd0;
		pair_reference_robust_q8 <= 28'd0;
		pair_reference_robust_csrstorage4_storage_full <= 28'd0;
		pair_reference_robust_csrstorage4_re <= 1'd0;
		pair_reference_robust_q9 <= 28'd0;
		pair_reference_robust_csrstorage5_storage_full <= 28'd0;
		pair_reference_robust_csrstorage5_re <= 1'd0;
		pair_reference_robust_q10 <= 28'd0;
		pair_reference_robust_csrstorage6_storage_full <= 28'd0;
		pair_reference_robust_csrstorage6_re <= 1'd0;
		pair_reference_robust_q11 <= 28'd0;
		pair_reference_robust_csrstorage7_storage_full <= 28'd0;
		pair_reference_robust_csrstorage7_re <= 1'd0;
		pair_reference_robust_q12 <= 28'd0;
		pair_reference_robust_csrstorage8_storage_full <= 28'd0;
		pair_reference_robust_csrstorage8_re <= 1'd0;
		pair_reference_robust_q13 <= 28'd0;
		pair_reference_robust_csrstorage9_storage_full <= 28'd0;
		pair_reference_robust_csrstorage9_re <= 1'd0;
		pair_reference_robust_q14 <= 28'd0;
		pair_reference_robust_csrstorage10_storage_full <= 28'd0;
		pair_reference_robust_csrstorage10_re <= 1'd0;
		pair_reference_robust_q15 <= 28'd0;
		pair_reference_robust_csrstorage11_storage_full <= 28'd0;
		pair_reference_robust_csrstorage11_re <= 1'd0;
		pair_reference_robust_q16 <= 28'd0;
		pair_reference_robust_csrstorage12_storage_full <= 28'd0;
		pair_reference_robust_csrstorage12_re <= 1'd0;
		pair_reference_robust_q17 <= 28'd0;
		pair_reference_robust_csrstorage13_storage_full <= 28'd0;
		pair_reference_robust_csrstorage13_re <= 1'd0;
		pair_reference_robust_q18 <= 28'd0;
		pair_reference_robust_csrstorage14_storage_full <= 28'd0;
		pair_reference_robust_csrstorage14_re <= 1'd0;
		pair_reference_robust_q19 <= 28'd0;
		pair_reference_robust_csrstorage15_storage_full <= 28'd0;
		pair_reference_robust_csrstorage15_re <= 1'd0;
		pair_reference_robust_q20 <= 28'd0;
		pair_reference_robust_csrstorage16_storage_full <= 28'd0;
		pair_reference_robust_csrstorage16_re <= 1'd0;
		pair_reference_robust_q21 <= 28'd0;
		pair_reference_robust_csrstorage17_storage_full <= 28'd0;
		pair_reference_robust_csrstorage17_re <= 1'd0;
		pair_reference_robust_q22 <= 28'd0;
		pair_reference_robust_csrstorage18_storage_full <= 28'd0;
		pair_reference_robust_csrstorage18_re <= 1'd0;
		pair_reference_robust_q23 <= 28'd0;
		pair_reference_robust_csrstorage19_storage_full <= 28'd0;
		pair_reference_robust_csrstorage19_re <= 1'd0;
		pair_reference_robust_q24 <= 28'd0;
		pair_reference_robust_csrstorage20_storage_full <= 28'd0;
		pair_reference_robust_csrstorage20_re <= 1'd0;
		pair_reference_robust_q25 <= 28'd0;
		pair_reference_robust_csrstorage21_storage_full <= 28'd0;
		pair_reference_robust_csrstorage21_re <= 1'd0;
		pair_reference_robust_q26 <= 28'd0;
		pair_reference_robust_csrstorage22_storage_full <= 28'd0;
		pair_reference_robust_csrstorage22_re <= 1'd0;
		pair_reference_robust_q27 <= 28'd0;
		pair_reference_robust_csrstorage23_storage_full <= 28'd0;
		pair_reference_robust_csrstorage23_re <= 1'd0;
		pair_reference_robust_q28 <= 28'd0;
		pair_reference_robust_csrstorage24_storage_full <= 28'd0;
		pair_reference_robust_csrstorage24_re <= 1'd0;
		pair_reference_robust_q29 <= 28'd0;
		pair_reference_robust_csrstorage25_storage_full <= 28'd0;
		pair_reference_robust_csrstorage25_re <= 1'd0;
		pair_reference_robust_q30 <= 28'd0;
		pair_reference_robust_csrstorage26_storage_full <= 28'd0;
		pair_reference_robust_csrstorage26_re <= 1'd0;
		pair_reference_robust_q31 <= 28'd0;
		pair_reference_robust_csrstorage27_storage_full <= 28'd0;
		pair_reference_robust_csrstorage27_re <= 1'd0;
		pair_reference_robust_q32 <= 28'd0;
		pair_reference_robust_csrstorage28_storage_full <= 28'd0;
		pair_reference_robust_csrstorage28_re <= 1'd0;
		pair_reference_robust_q33 <= 28'd0;
		pair_reference_robust_csrstorage29_storage_full <= 28'd0;
		pair_reference_robust_csrstorage29_re <= 1'd0;
		pair_reference_robust_q34 <= 28'd0;
		pair_reference_robust_csrstorage30_storage_full <= 28'd0;
		pair_reference_robust_csrstorage30_re <= 1'd0;
		pair_reference_robust_q35 <= 28'd0;
		pair_reference_robust_csrstorage31_storage_full <= 28'd0;
		pair_reference_robust_csrstorage31_re <= 1'd0;
		pair_reference_robust_q36 <= 28'd0;
		pair_reference_robust_csrstorage32_storage_full <= 28'd0;
		pair_reference_robust_csrstorage32_re <= 1'd0;
		pair_reference_robust_q37 <= 28'd0;
		pair_reference_robust_csrstorage33_storage_full <= 28'd0;
		pair_reference_robust_csrstorage33_re <= 1'd0;
		pair_reference_robust_q38 <= 28'd0;
		pair_reference_robust_csrstorage34_storage_full <= 28'd0;
		pair_reference_robust_csrstorage34_re <= 1'd0;
		pair_reference_robust_q39 <= 28'd0;
		pair_reference_robust_csrstorage35_storage_full <= 14'd0;
		pair_reference_robust_csrstorage35_re <= 1'd0;
		pair_reference_robust_q40 <= 14'd0;
		pair_reference_robust_csrstorage36_storage_full <= 14'd0;
		pair_reference_robust_csrstorage36_re <= 1'd0;
		pair_reference_robust_q41 <= 14'd0;
		pair_reference_robust_csrstorage37_storage_full <= 14'd0;
		pair_reference_robust_csrstorage37_re <= 1'd0;
		pair_reference_robust_q42 <= 14'd0;
		pair_reference_robust_csrstorage38_storage_full <= 14'd0;
		pair_reference_robust_csrstorage38_re <= 1'd0;
		pair_reference_robust_q43 <= 14'd0;
		pair_reference_robust_csrstorage39_storage_full <= 14'd0;
		pair_reference_robust_csrstorage39_re <= 1'd0;
		pair_reference_robust_q44 <= 14'd0;
		pair_reference_robust_csrstorage40_storage_full <= 14'd0;
		pair_reference_robust_csrstorage40_re <= 1'd0;
		pair_reference_robust_q45 <= 14'd0;
		pair_reference_robust_csrstorage41_storage_full <= 14'd0;
		pair_reference_robust_csrstorage41_re <= 1'd0;
		pair_reference_robust_q46 <= 14'd0;
		pair_reference_robust_csrstorage42_storage_full <= 14'd0;
		pair_reference_robust_csrstorage42_re <= 1'd0;
		pair_reference_robust_q47 <= 14'd0;
		pair_reference_robust_csrstorage43_storage_full <= 14'd0;
		pair_reference_robust_csrstorage43_re <= 1'd0;
		pair_reference_robust_q48 <= 14'd0;
		pair_reference_robust_csrstorage44_storage_full <= 14'd0;
		pair_reference_robust_csrstorage44_re <= 1'd0;
		pair_reference_robust_q49 <= 14'd0;
		pair_reference_robust_csrstorage45_storage_full <= 14'd0;
		pair_reference_robust_csrstorage45_re <= 1'd0;
		pair_reference_robust_q50 <= 14'd0;
		pair_reference_robust_csrstorage46_storage_full <= 14'd0;
		pair_reference_robust_csrstorage46_re <= 1'd0;
		pair_reference_robust_q51 <= 14'd0;
		pair_reference_robust_csrstorage47_storage_full <= 14'd0;
		pair_reference_robust_csrstorage47_re <= 1'd0;
		pair_reference_robust_q52 <= 14'd0;
		pair_reference_robust_csrstorage48_storage_full <= 14'd0;
		pair_reference_robust_csrstorage48_re <= 1'd0;
		pair_reference_robust_q53 <= 14'd0;
		pair_reference_robust_csrstorage49_storage_full <= 14'd0;
		pair_reference_robust_csrstorage49_re <= 1'd0;
		pair_reference_robust_q54 <= 14'd0;
		pair_reference_robust_csrstorage50_storage_full <= 14'd0;
		pair_reference_robust_csrstorage50_re <= 1'd0;
		pair_reference_robust_q55 <= 14'd0;
		pair_reference_robust_csrstorage51_storage_full <= 14'd0;
		pair_reference_robust_csrstorage51_re <= 1'd0;
		pair_reference_robust_q56 <= 14'd0;
		pair_reference_robust_csrstorage52_storage_full <= 14'd0;
		pair_reference_robust_csrstorage52_re <= 1'd0;
		pair_reference_robust_q57 <= 14'd0;
		pair_reference_robust_csrstorage53_storage_full <= 14'd0;
		pair_reference_robust_csrstorage53_re <= 1'd0;
		pair_reference_robust_q58 <= 14'd0;
		pair_reference_robust_csrstorage54_storage_full <= 14'd0;
		pair_reference_robust_csrstorage54_re <= 1'd0;
		pair_reference_robust_q59 <= 14'd0;
		pair_reference_robust_csrstorage55_storage_full <= 14'd0;
		pair_reference_robust_csrstorage55_re <= 1'd0;
		pair_reference_robust_q60 <= 14'd0;
		pair_reference_robust_csrstorage56_storage_full <= 14'd0;
		pair_reference_robust_csrstorage56_re <= 1'd0;
		pair_reference_robust_q61 <= 14'd0;
		pair_reference_robust_csrstorage57_storage_full <= 14'd0;
		pair_reference_robust_csrstorage57_re <= 1'd0;
		pair_reference_robust_q62 <= 14'd0;
		pair_reference_robust_csrstorage58_storage_full <= 14'd0;
		pair_reference_robust_csrstorage58_re <= 1'd0;
		pair_reference_robust_q63 <= 14'd0;
		pair_reference_robust_csrstorage59_storage_full <= 14'd0;
		pair_reference_robust_csrstorage59_re <= 1'd0;
		pair_reference_robust_q64 <= 14'd0;
		pair_reference_robust_csrstorage60_storage_full <= 14'd0;
		pair_reference_robust_csrstorage60_re <= 1'd0;
		pair_reference_robust_q65 <= 14'd0;
		pair_reference_robust_csrstorage61_storage_full <= 14'd0;
		pair_reference_robust_csrstorage61_re <= 1'd0;
		pair_reference_robust_q66 <= 14'd0;
		pair_reference_robust_csrstorage62_storage_full <= 14'd0;
		pair_reference_robust_csrstorage62_re <= 1'd0;
		pair_reference_robust_q67 <= 14'd0;
		pair_reference_robust_csrstorage63_storage_full <= 14'd0;
		pair_reference_robust_csrstorage63_re <= 1'd0;
		pair_reference_robust_q68 <= 14'd0;
		pair_reference_robust_csrstorage64_storage_full <= 14'd0;
		pair_reference_robust_csrstorage64_re <= 1'd0;
		pair_reference_robust_q69 <= 14'd0;
		pair_reference_robust_csrstorage65_storage_full <= 14'd0;
		pair_reference_robust_csrstorage65_re <= 1'd0;
		pair_reference_robust_q70 <= 14'd0;
		pair_reference_robust_csrstorage66_storage_full <= 14'd0;
		pair_reference_robust_csrstorage66_re <= 1'd0;
		pair_reference_robust_q71 <= 14'd0;
		pair_reference_fast_turn_on_lock <= 1'd0;
		pair_reference_fast_storage_full <= 14'd0;
		pair_reference_fast_re <= 1'd0;
		pair_reference_request_lock_storage_full <= 1'd0;
		pair_reference_request_lock_re <= 1'd0;
		pair_reference_autolock_mode_storage_full <= 2'd0;
		pair_reference_autolock_mode_re <= 1'd0;
		pair_reference_status <= 1'd0;
		pair_candidate_pipelinedrobustautolock_sum_value <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_counter <= 13'd0;
		pair_candidate_pipelinedrobustautolock_time_scale_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_time_scale_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_N_instructions_storage_full <= 5'd0;
		pair_candidate_pipelinedrobustautolock_N_instructions_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_final_wait_time_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_final_wait_time_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage0_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage0_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage1_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage1_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage2_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage2_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage3_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage3_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage4_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage4_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage5_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage5_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage6_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage6_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage7_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage7_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage8_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage8_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage9_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage9_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage10_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage10_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage11_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage11_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage12_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage12_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage13_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage13_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage14_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage14_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage15_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage15_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage16_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage16_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage17_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage17_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage18_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage18_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage19_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage19_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage20_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage20_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage21_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage21_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage22_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage22_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage23_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage23_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage24_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage24_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage25_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage25_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage26_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage26_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage27_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage27_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage28_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage28_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage29_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage29_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage30_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage30_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage31_storage_full <= 28'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage31_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage32_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage32_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage33_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage33_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage34_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage34_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage35_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage35_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage36_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage36_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage37_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage37_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage38_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage38_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage39_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage39_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage40_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage40_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage41_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage41_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage42_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage42_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage43_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage43_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage44_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage44_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage45_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage45_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage46_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage46_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage47_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage47_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage48_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage48_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage49_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage49_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage50_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage50_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage51_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage51_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage52_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage52_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage53_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage53_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage54_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage54_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage55_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage55_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage56_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage56_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage57_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage57_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage58_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage58_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage59_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage59_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage60_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage60_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage61_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage61_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage62_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage62_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage63_storage_full <= 14'd0;
		pair_candidate_pipelinedrobustautolock_csrstorage63_re <= 1'd0;
		pair_candidate_pipelinedrobustautolock0 <= 1'd0;
		pair_candidate_pipelinedrobustautolock1 <= 1'd0;
		pair_candidate_pipelinedrobustautolock2 <= 1'd0;
		pair_candidate_pipelinedrobustautolock3 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_sum_diff_s1 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_n_instructions_s1 <= 5'd0;
		pair_candidate_pipelinedrobustautolock_final_wait_s1 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_magnitude0 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive0 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative0 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude1 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive1 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative1 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude2 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive2 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative2 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude3 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive3 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative3 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude4 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive4 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative4 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude5 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive5 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative5 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude6 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive6 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative6 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude7 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive7 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative7 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude8 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive8 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative8 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude9 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive9 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative9 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude10 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive10 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative10 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude11 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive11 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative11 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude12 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive12 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative12 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude13 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive13 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative13 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude14 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive14 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative14 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude15 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive15 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative15 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude16 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive16 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative16 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude17 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive17 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative17 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude18 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive18 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative18 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude19 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive19 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative19 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude20 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive20 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative20 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude21 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive21 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative21 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude22 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive22 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative22 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude23 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive23 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative23 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude24 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive24 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative24 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude25 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive25 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative25 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude26 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive26 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative26 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude27 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive27 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative27 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude28 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive28 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative28 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude29 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive29 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative29 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude30 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive30 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative30 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_magnitude31 <= 28'sd0;
		pair_candidate_pipelinedrobustautolock_positive31 <= 1'd0;
		pair_candidate_pipelinedrobustautolock_negative31 <= 29'sd0;
		pair_candidate_pipelinedrobustautolock_value0 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value1 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value2 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value3 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value4 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value5 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value6 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value7 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value8 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value9 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value10 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value11 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value12 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value13 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value14 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value15 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value16 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value17 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value18 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value19 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value20 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value21 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value22 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value23 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value24 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value25 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value26 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value27 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value28 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value29 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value30 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_value31 <= 14'd0;
		pair_candidate_pipelinedrobustautolock_watching <= 1'd0;
		pair_candidate_pipelinedrobustautolock_current_instruction_idx <= 5'd0;
		pair_candidate_pipelinedrobustautolock_waited_for <= 14'd0;
		pair_candidate_pipelinedrobustautolock_final_waited_for <= 14'd0;
		pair_candidate_fast_turn_on_lock <= 1'd0;
		pair_candidate_fast_storage_full <= 14'd0;
		pair_candidate_fast_re <= 1'd0;
		pair_candidate_request_lock_storage_full <= 1'd0;
		pair_candidate_request_lock_re <= 1'd0;
		pair_candidate_autolock_mode_storage_full <= 2'd0;
		pair_candidate_autolock_mode_re <= 1'd0;
		pair_candidate_status <= 1'd0;
		pair_rb_bus_dat_r <= 8'd0;
		pair_cb_bus_dat_r <= 8'd0;
		pair_pair0 <= 28'sd0;
		pair_pair1 <= 13'd0;
		pair_pair_q <= 13'd1;
		pair_pair2 <= 29'sd0;
	end
end

reg [27:0] dynamic_delay_mem[0:8190];
reg [12:0] memadr;
reg [12:0] memadr_1;
always @(posedge sys_clk) begin
	memadr <= pair_reference_robust_rdport_adr;
end

always @(posedge sys_clk) begin
	if (pair_reference_robust_wrport_we)
		dynamic_delay_mem[pair_reference_robust_wrport_adr] <= pair_reference_robust_wrport_dat_w;
	memadr_1 <= pair_reference_robust_wrport_adr;
end

assign pair_reference_robust_rdport_dat_r = dynamic_delay_mem[memadr];
assign pair_reference_robust_wrport_dat_r = dynamic_delay_mem[memadr_1];

reg [27:0] dynamic_delay_mem_1[0:8190];
reg [12:0] memadr_2;
reg [12:0] memadr_3;
always @(posedge sys_clk) begin
	memadr_2 <= pair_candidate_pipelinedrobustautolock_rdport_adr;
end

always @(posedge sys_clk) begin
	if (pair_candidate_pipelinedrobustautolock_wrport_we)
		dynamic_delay_mem_1[pair_candidate_pipelinedrobustautolock_wrport_adr] <= pair_candidate_pipelinedrobustautolock_wrport_dat_w;
	memadr_3 <= pair_candidate_pipelinedrobustautolock_wrport_adr;
end

assign pair_candidate_pipelinedrobustautolock_rdport_dat_r = dynamic_delay_mem_1[memadr_2];
assign pair_candidate_pipelinedrobustautolock_wrport_dat_r = dynamic_delay_mem_1[memadr_3];

endmodule
