from pathlib import Path
import json
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r53-carry-fold-postroute');t=r/'gateware/build/trials/20261111_164427_r53_carry_fold_postroute'
m=json.loads((t/'manifest.json').read_text());assert m['route']=='COMPLETE' and m['postopt']=='COMPLETE' and m['input_r52_dcp_unchanged'] and not m['source_changes_during_run'] and all(m['r52_code_and_test_hash_matches'].values())
def parse(p):
 d={}
 for b in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in b.splitlines() if '=' in s);d[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return d
a=parse(h/'r52_mapped/all_dsp.txt');b=parse(h/'r53_mapped/all_dsp.txt');assert len(a)==len(b)==94 and a==b
old=Path(m['input_r52_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(old/n).read_bytes(),n
rec={'passed':True,'all_94_DSP_register_and_operating_properties_same_input_R52_ignoring_LOC_BEL':True,'raw_hardware_test_count':len(m['r52_code_and_test_hash_matches']),'all_raw_hardware_test_inputs_same_R52':True,'generated_top_CSR_XDC_bytes_same_R52':True,'new_serial_data_feedback_CSR_cycles_this_physical_round':0,'input_DCP_SHA_unchanged':True,'phys_options':['placement_opt','routing_opt','rewire','critical_cell_opt'],'scope':'Source native/synthesis REUSED_R52_NOT_RERUN; new physical optimization and real TNS route cleanup. Actual input is R52, not R48; R52-vs-R48 mapping differences remain explicitly inherited, not erased. Not postroute fullRoot SDF/formal or physical CDC proof.'}
(h/'r53_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R53_ALL94_DSP_AND_FROZEN_INPUTS_AUDIT_PASS')
