set_param general.maxThreads 2
open_checkpoint {D:/RP_Dev/linien_trials/20261111-r41-scope-source-predecode/gateware/build/trials/20261111_105510_r41_scope_source_predecode/routed.dcp}
set out {C:/Users/admin/Documents/Codex/2026-11-05/ba/work/r6_execution/r43_query_diagnosis.tsv}
set f [open $out w];puts $f "cell\tref\tO_net\tlocal_loads\tsegment_loads"
set count 0;set maximum 0;set target {}
foreach c [get_cells -hier -quiet -filter {NAME =~ *average_select* && REF_NAME =~ LUT*}] {
 set q [get_pins -quiet -of_objects $c -filter {DIRECTION == OUT}]
 set n [get_nets -quiet -of_objects $q]
 set loads [llength [get_pins -quiet -of_objects $n -filter {DIRECTION == IN}]]
 set all [get_nets -quiet -segments -of_objects $q]
 set all_loads [llength [get_pins -quiet -leaf -of_objects $all -filter {DIRECTION == IN}]]
 puts $f "$c\t[get_property REF_NAME $c]\t$n\t$loads\t$all_loads"
 incr count
 if {$all_loads>$maximum} {set maximum $all_loads;set target $c}
}
close $f
puts "SCOPE_QUERY_DIAG_COUNT $count MAX $maximum TARGET $target"
puts "QUESTION_FILTER_COUNT [llength [get_cells -hier -quiet -filter {NAME =~ *average_select* && REF_NAME =~ LUT?}]]"
puts "SLASH_FILTER_COUNT [llength [get_cells -hier -quiet -filter {NAME =~ red_pitaya_scope/average_select_*/* && REF_NAME =~ LUT*}]]"
puts R43_QUERY_DIAGNOSTIC_COMPLETE
exit 0
