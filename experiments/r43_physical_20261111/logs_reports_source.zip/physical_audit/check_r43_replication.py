from pathlib import Path
import collections,csv,hashlib,json
h=Path(__file__).parent
r=Path('D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution')
trial=r/'gateware/build/trials/20261111_112707_r43_scope_csr_distribution_v2'
m=json.loads((trial/'manifest.json').read_text())
assert m['functional']=='REUSED_R41_EXACT_INPUTS_NOT_RERUN' and m['route']=='COMPLETE' and m['input_r41_dcp_unchanged'] and not m['source_changes_during_run'] and all(m['r41_code_and_test_hash_matches'].values())
def rows(s):return list(csv.DictReader((trial/s).open(),delimiter='\t'))
a=rows('csr_replication_before.tsv');b=rows('csr_replication_after.tsv');c=rows('csr_replication_routed.tsv')
keys=('ref','D','C','CE','R','INIT','ASYNC_REG','DONT_TOUCH')
def group(v):
 d={}
 for row in v:
  k=tuple(row[n] for n in keys)
  assert row['ASYNC_REG']!='1',row
  loads=row['load_pins'].split('|') if row['load_pins'] else []
  assert len(loads)==int(row['loads']) and len(set(loads))==len(loads)
  for pin in loads:
   assert pin not in d.get(k,set()),pin
  d.setdefault(k,set()).update(loads)
 return d
assert group(a)==group(b),'Copy changes state inputs or load set'
assert len(b)>len(a),'No actual replication'
def dsp(p):
 d={}
 for block in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in block.splitlines() if '=' in s)
  d[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return d
da=dsp(h/'r41_mapped/all_dsp.txt');db=dsp(h/'r43_mapped/all_dsp.txt');assert len(da)==len(db)==94 and da==db
old=Path(m['input_r41_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (trial/n).read_bytes()==(old/n).read_bytes(),n
rec={'passed':True,'FF_before':len(a),'FF_after_replication':len(b),'FF_after_route':len(c),'max_Q_loads_before':max(int(x['loads']) for x in a),'max_Q_loads_after_replication':max(int(x['loads']) for x in b),'max_Q_loads_after_route':max(int(x['loads']) for x in c),'same_D_C_CE_R_INIT_ASYNC_DONT_and_aggregated_loads':True,'all_94_DSP_operating_register_properties_identical_ignoring_LOC_BEL':True,'input_dcp_unchanged':m['input_r41_dcp_unchanged'],'raw_R41_hardware_and_tests_identical':all(m['r41_code_and_test_hash_matches'].values()),'new_serial_cycles':0,'RTL_generated_top_CSR_XDC_same_bytes_R41':True,'full_RTL_regression':'REUSED_R41_NOT_RERUN','synthesis':'REUSED_R41_NOT_RERUN','full_root_postroute_SDF_formal':'NOT_RUN','Scope_LUT_replication_before':len(rows('scope_lut_before.tsv')),'Scope_LUT_replication_after':len(rows('scope_lut_after.tsv')),'Scope_max_logical_leaf_loads_before':max(int(v['loads']) for v in rows('scope_lut_before.tsv')),'Scope_max_logical_leaf_loads_after':max(int(v['loads']) for v in rows('scope_lut_after.tsv')),'physical_CDC_safety':'NOT_PROVEN'}
(h/'r43_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
print(json.dumps(rec,indent=2))
