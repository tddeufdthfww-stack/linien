/* Machine-generated using Migen */
module iir_frame_pair(
	input sys_clk,
	input sys_rst,
	input signed [24:0] x,
	input hold,
	input clear,
	input [13:0] csr_adr,
	input csr_we,
	input [7:0] csr_dat_w,
	output [24:0] ref_y,
	output [24:0] cand_y,
	output ref_error,
	output cand_error,
	output [7:0] read_value,
	output [274:0] ref_coeff,
	output [274:0] cand_coeff,
	output [301:0] cfg
);

wire signed [24:0] pair_candidate_x;
reg signed [24:0] pair_candidate_y0 = 25'sd0;
wire pair_candidate_hold;
wire pair_candidate_clear;
reg pair_candidate_error = 1'd0;
reg [26:0] pair_candidate_storage_full = 27'd0;
wire [26:0] pair_candidate_storage;
reg pair_candidate_re = 1'd0;
reg signed [24:0] pair_candidate_a1 = 25'sd0;
reg [24:0] pair_candidate_csrstorage0_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage0_storage;
reg pair_candidate_csrstorage0_re = 1'd0;
reg [24:0] pair_candidate_cohort0 = 25'd0;
reg signed [24:0] pair_candidate_a2 = 25'sd0;
reg [24:0] pair_candidate_csrstorage1_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage1_storage;
reg pair_candidate_csrstorage1_re = 1'd0;
reg [24:0] pair_candidate_cohort1 = 25'd0;
reg signed [24:0] pair_candidate_a3 = 25'sd0;
reg [24:0] pair_candidate_csrstorage2_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage2_storage;
reg pair_candidate_csrstorage2_re = 1'd0;
reg [24:0] pair_candidate_cohort2 = 25'd0;
reg signed [24:0] pair_candidate_a4 = 25'sd0;
reg [24:0] pair_candidate_csrstorage3_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage3_storage;
reg pair_candidate_csrstorage3_re = 1'd0;
reg [24:0] pair_candidate_cohort3 = 25'd0;
reg signed [24:0] pair_candidate_a5 = 25'sd0;
reg [24:0] pair_candidate_csrstorage4_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage4_storage;
reg pair_candidate_csrstorage4_re = 1'd0;
reg [24:0] pair_candidate_cohort4 = 25'd0;
reg signed [24:0] pair_candidate_b0 = 25'sd0;
reg [24:0] pair_candidate_csrstorage5_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage5_storage;
reg pair_candidate_csrstorage5_re = 1'd0;
reg [24:0] pair_candidate_cohort5 = 25'd0;
reg signed [24:0] pair_candidate_b1 = 25'sd0;
reg [24:0] pair_candidate_csrstorage6_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage6_storage;
reg pair_candidate_csrstorage6_re = 1'd0;
reg [24:0] pair_candidate_cohort6 = 25'd0;
reg signed [24:0] pair_candidate_b2 = 25'sd0;
reg [24:0] pair_candidate_csrstorage7_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage7_storage;
reg pair_candidate_csrstorage7_re = 1'd0;
reg [24:0] pair_candidate_cohort7 = 25'd0;
reg signed [24:0] pair_candidate_b3 = 25'sd0;
reg [24:0] pair_candidate_csrstorage8_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage8_storage;
reg pair_candidate_csrstorage8_re = 1'd0;
reg [24:0] pair_candidate_cohort8 = 25'd0;
reg signed [24:0] pair_candidate_b4 = 25'sd0;
reg [24:0] pair_candidate_csrstorage9_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage9_storage;
reg pair_candidate_csrstorage9_re = 1'd0;
reg [24:0] pair_candidate_cohort9 = 25'd0;
reg signed [24:0] pair_candidate_b5 = 25'sd0;
reg [24:0] pair_candidate_csrstorage10_storage_full = 25'd0;
wire [24:0] pair_candidate_csrstorage10_storage;
reg pair_candidate_csrstorage10_re = 1'd0;
reg [24:0] pair_candidate_cohort10 = 25'd0;
reg signed [49:0] pair_candidate_z0r = 50'sd0;
reg [26:0] pair_candidate_z0_cohort = 27'd0;
reg signed [24:0] pair_candidate_y_lim;
wire signed [49:0] pair_candidate_y_next;
reg [2:0] pair_candidate_y_pat = 3'd7;
reg signed [24:0] pair_candidate_y1 = 25'sd0;
wire pair_candidate_railed;
reg signed [49:0] pair_candidate_zr0 = 50'sd0;
wire signed [49:0] pair_candidate_z0;
reg signed [49:0] pair_candidate_zr1 = 50'sd0;
wire signed [49:0] pair_candidate_z1;
reg signed [49:0] pair_candidate_zr2 = 50'sd0;
wire signed [49:0] pair_candidate_z2;
reg signed [49:0] pair_candidate_zr3 = 50'sd0;
wire signed [49:0] pair_candidate_z3;
reg signed [49:0] pair_candidate_zr4 = 50'sd0;
wire signed [49:0] pair_candidate_z4;
reg signed [49:0] pair_candidate_zr5 = 50'sd0;
wire signed [49:0] pair_candidate_z5;
reg signed [49:0] pair_candidate_zr6 = 50'sd0;
wire signed [49:0] pair_candidate_z6;
reg signed [49:0] pair_candidate_zr7 = 50'sd0;
wire signed [49:0] pair_candidate_z7;
reg signed [49:0] pair_candidate_zr8 = 50'sd0;
wire signed [49:0] pair_candidate_z8;
reg signed [49:0] pair_candidate_zr9 = 50'sd0;
wire signed [49:0] pair_candidate_z9;
reg signed [49:0] pair_candidate_zr10 = 50'sd0;
wire signed [49:0] pair_candidate_z10;
wire signed [24:0] pair_reference_x;
reg signed [24:0] pair_reference_y0 = 25'sd0;
wire pair_reference_hold;
wire pair_reference_clear;
reg pair_reference_error = 1'd0;
wire [26:0] pair_reference_z0_storage;
reg signed [24:0] pair_reference_a1 = 25'sd0;
wire [24:0] pair_reference_rci_storage0;
reg signed [24:0] pair_reference_a2 = 25'sd0;
wire [24:0] pair_reference_rci_storage1;
reg signed [24:0] pair_reference_a3 = 25'sd0;
wire [24:0] pair_reference_rci_storage2;
reg signed [24:0] pair_reference_a4 = 25'sd0;
wire [24:0] pair_reference_rci_storage3;
reg signed [24:0] pair_reference_a5 = 25'sd0;
wire [24:0] pair_reference_rci_storage4;
reg signed [24:0] pair_reference_b0 = 25'sd0;
wire [24:0] pair_reference_rci_storage5;
reg signed [24:0] pair_reference_b1 = 25'sd0;
wire [24:0] pair_reference_rci_storage6;
reg signed [24:0] pair_reference_b2 = 25'sd0;
wire [24:0] pair_reference_rci_storage7;
reg signed [24:0] pair_reference_b3 = 25'sd0;
wire [24:0] pair_reference_rci_storage8;
reg signed [24:0] pair_reference_b4 = 25'sd0;
wire [24:0] pair_reference_rci_storage9;
reg signed [24:0] pair_reference_b5 = 25'sd0;
wire [24:0] pair_reference_rci_storage10;
reg signed [49:0] pair_reference_z0r = 50'sd0;
reg signed [24:0] pair_reference_y_lim;
wire signed [49:0] pair_reference_y_next;
reg [2:0] pair_reference_y_pat = 3'd7;
reg signed [24:0] pair_reference_y1 = 25'sd0;
wire pair_reference_railed;
reg signed [49:0] pair_reference_zr0 = 50'sd0;
wire signed [49:0] pair_reference_z0;
reg signed [49:0] pair_reference_zr1 = 50'sd0;
wire signed [49:0] pair_reference_z1;
reg signed [49:0] pair_reference_zr2 = 50'sd0;
wire signed [49:0] pair_reference_z2;
reg signed [49:0] pair_reference_zr3 = 50'sd0;
wire signed [49:0] pair_reference_z3;
reg signed [49:0] pair_reference_zr4 = 50'sd0;
wire signed [49:0] pair_reference_z4;
reg signed [49:0] pair_reference_zr5 = 50'sd0;
wire signed [49:0] pair_reference_z5;
reg signed [49:0] pair_reference_zr6 = 50'sd0;
wire signed [49:0] pair_reference_z6;
reg signed [49:0] pair_reference_zr7 = 50'sd0;
wire signed [49:0] pair_reference_z7;
reg signed [49:0] pair_reference_zr8 = 50'sd0;
wire signed [49:0] pair_reference_z8;
reg signed [49:0] pair_reference_zr9 = 50'sd0;
wire signed [49:0] pair_reference_z9;
reg signed [49:0] pair_reference_zr10 = 50'sd0;
wire signed [49:0] pair_reference_z10;
wire [13:0] pair_bus_adr;
wire pair_bus_we;
wire [7:0] pair_bus_dat_w;
reg [7:0] pair_bus_dat_r = 8'd0;
wire pair_z03_re;
wire [2:0] pair_z03_r;
wire [2:0] pair_z03_w;
wire pair_z02_re;
wire [7:0] pair_z02_r;
wire [7:0] pair_z02_w;
wire pair_z01_re;
wire [7:0] pair_z01_r;
wire [7:0] pair_z01_w;
wire pair_z00_re;
wire [7:0] pair_z00_r;
wire [7:0] pair_z00_w;
wire pair_a13_re;
wire pair_a13_r;
wire pair_a13_w;
wire pair_a12_re;
wire [7:0] pair_a12_r;
wire [7:0] pair_a12_w;
wire pair_a11_re;
wire [7:0] pair_a11_r;
wire [7:0] pair_a11_w;
wire pair_a10_re;
wire [7:0] pair_a10_r;
wire [7:0] pair_a10_w;
wire pair_a23_re;
wire pair_a23_r;
wire pair_a23_w;
wire pair_a22_re;
wire [7:0] pair_a22_r;
wire [7:0] pair_a22_w;
wire pair_a21_re;
wire [7:0] pair_a21_r;
wire [7:0] pair_a21_w;
wire pair_a20_re;
wire [7:0] pair_a20_r;
wire [7:0] pair_a20_w;
wire pair_a33_re;
wire pair_a33_r;
wire pair_a33_w;
wire pair_a32_re;
wire [7:0] pair_a32_r;
wire [7:0] pair_a32_w;
wire pair_a31_re;
wire [7:0] pair_a31_r;
wire [7:0] pair_a31_w;
wire pair_a30_re;
wire [7:0] pair_a30_r;
wire [7:0] pair_a30_w;
wire pair_a43_re;
wire pair_a43_r;
wire pair_a43_w;
wire pair_a42_re;
wire [7:0] pair_a42_r;
wire [7:0] pair_a42_w;
wire pair_a41_re;
wire [7:0] pair_a41_r;
wire [7:0] pair_a41_w;
wire pair_a40_re;
wire [7:0] pair_a40_r;
wire [7:0] pair_a40_w;
wire pair_a53_re;
wire pair_a53_r;
wire pair_a53_w;
wire pair_a52_re;
wire [7:0] pair_a52_r;
wire [7:0] pair_a52_w;
wire pair_a51_re;
wire [7:0] pair_a51_r;
wire [7:0] pair_a51_w;
wire pair_a50_re;
wire [7:0] pair_a50_r;
wire [7:0] pair_a50_w;
wire pair_b03_re;
wire pair_b03_r;
wire pair_b03_w;
wire pair_b02_re;
wire [7:0] pair_b02_r;
wire [7:0] pair_b02_w;
wire pair_b01_re;
wire [7:0] pair_b01_r;
wire [7:0] pair_b01_w;
wire pair_b00_re;
wire [7:0] pair_b00_r;
wire [7:0] pair_b00_w;
wire pair_b13_re;
wire pair_b13_r;
wire pair_b13_w;
wire pair_b12_re;
wire [7:0] pair_b12_r;
wire [7:0] pair_b12_w;
wire pair_b11_re;
wire [7:0] pair_b11_r;
wire [7:0] pair_b11_w;
wire pair_b10_re;
wire [7:0] pair_b10_r;
wire [7:0] pair_b10_w;
wire pair_b23_re;
wire pair_b23_r;
wire pair_b23_w;
wire pair_b22_re;
wire [7:0] pair_b22_r;
wire [7:0] pair_b22_w;
wire pair_b21_re;
wire [7:0] pair_b21_r;
wire [7:0] pair_b21_w;
wire pair_b20_re;
wire [7:0] pair_b20_r;
wire [7:0] pair_b20_w;
wire pair_b33_re;
wire pair_b33_r;
wire pair_b33_w;
wire pair_b32_re;
wire [7:0] pair_b32_r;
wire [7:0] pair_b32_w;
wire pair_b31_re;
wire [7:0] pair_b31_r;
wire [7:0] pair_b31_w;
wire pair_b30_re;
wire [7:0] pair_b30_r;
wire [7:0] pair_b30_w;
wire pair_b43_re;
wire pair_b43_r;
wire pair_b43_w;
wire pair_b42_re;
wire [7:0] pair_b42_r;
wire [7:0] pair_b42_w;
wire pair_b41_re;
wire [7:0] pair_b41_r;
wire [7:0] pair_b41_w;
wire pair_b40_re;
wire [7:0] pair_b40_r;
wire [7:0] pair_b40_w;
wire pair_b53_re;
wire pair_b53_r;
wire pair_b53_w;
wire pair_b52_re;
wire [7:0] pair_b52_r;
wire [7:0] pair_b52_w;
wire pair_b51_re;
wire [7:0] pair_b51_r;
wire [7:0] pair_b51_w;
wire pair_b50_re;
wire [7:0] pair_b50_r;
wire [7:0] pair_b50_w;
wire pair_sel;
reg signed [24:0] pair_q0 = 25'sd0;
reg signed [24:0] pair_q1 = 25'sd0;
reg pair_q2 = 1'd0;
reg pair_q3 = 1'd0;
reg pair_q4 = 1'd0;
reg pair_q5 = 1'd0;
reg [26:0] pair_q6 = 27'd0;
reg [24:0] pair_q7 = 25'd0;
reg [24:0] pair_q8 = 25'd0;
reg [24:0] pair_q9 = 25'd0;
reg [24:0] pair_q10 = 25'd0;
reg [24:0] pair_q11 = 25'd0;
reg [24:0] pair_q12 = 25'd0;
reg [24:0] pair_q13 = 25'd0;
reg [24:0] pair_q14 = 25'd0;
reg [24:0] pair_q15 = 25'd0;
reg [24:0] pair_q16 = 25'd0;
reg [24:0] pair_q17 = 25'd0;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign pair_candidate_x = pair_q0;
assign pair_reference_x = pair_q1;
assign pair_candidate_hold = pair_q2;
assign pair_reference_hold = pair_q3;
assign pair_candidate_clear = pair_q4;
assign pair_reference_clear = pair_q5;
assign pair_reference_z0_storage = pair_q6;
assign pair_reference_rci_storage0 = pair_q7;
assign pair_reference_rci_storage1 = pair_q8;
assign pair_reference_rci_storage2 = pair_q9;
assign pair_reference_rci_storage3 = pair_q10;
assign pair_reference_rci_storage4 = pair_q11;
assign pair_reference_rci_storage5 = pair_q12;
assign pair_reference_rci_storage6 = pair_q13;
assign pair_reference_rci_storage7 = pair_q14;
assign pair_reference_rci_storage8 = pair_q15;
assign pair_reference_rci_storage9 = pair_q16;
assign pair_reference_rci_storage10 = pair_q17;
assign pair_bus_adr = csr_adr;
assign pair_bus_we = csr_we;
assign pair_bus_dat_w = csr_dat_w;
assign ref_y = pair_reference_y0;
assign cand_y = pair_candidate_y0;
assign ref_error = pair_reference_error;
assign cand_error = pair_candidate_error;
assign read_value = pair_bus_dat_r;
assign ref_coeff = {pair_reference_b5, pair_reference_b4, pair_reference_b3, pair_reference_b2, pair_reference_b1, pair_reference_b0, pair_reference_a5, pair_reference_a4, pair_reference_a3, pair_reference_a2, pair_reference_a1};
assign cand_coeff = {pair_candidate_b5, pair_candidate_b4, pair_candidate_b3, pair_candidate_b2, pair_candidate_b1, pair_candidate_b0, pair_candidate_a5, pair_candidate_a4, pair_candidate_a3, pair_candidate_a2, pair_candidate_a1};
assign cfg = {pair_candidate_csrstorage10_storage, pair_candidate_csrstorage9_storage, pair_candidate_csrstorage8_storage, pair_candidate_csrstorage7_storage, pair_candidate_csrstorage6_storage, pair_candidate_csrstorage5_storage, pair_candidate_csrstorage4_storage, pair_candidate_csrstorage3_storage, pair_candidate_csrstorage2_storage, pair_candidate_csrstorage1_storage, pair_candidate_csrstorage0_storage, pair_candidate_storage};
assign pair_candidate_railed = (~((pair_candidate_y_next[49:47] == $signed({1'd0, pair_candidate_y_pat})) | (pair_candidate_y_next[49:47] == $signed({1'd0, (~pair_candidate_y_pat)}))));

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	pair_candidate_y_lim <= 25'sd0;
	if (pair_candidate_railed) begin
		pair_candidate_y_lim <= pair_candidate_y0;
	end else begin
		pair_candidate_y_lim <= pair_candidate_y_next[49:23];
	end
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end
assign pair_candidate_z0 = (pair_candidate_zr0 + (pair_candidate_x * pair_candidate_b5));
assign pair_candidate_z1 = (pair_candidate_zr1 + (pair_candidate_x * pair_candidate_b4));
assign pair_candidate_z2 = (pair_candidate_zr2 + (pair_candidate_x * pair_candidate_b3));
assign pair_candidate_z3 = (pair_candidate_zr3 + (pair_candidate_x * pair_candidate_b2));
assign pair_candidate_z4 = (pair_candidate_zr4 + (pair_candidate_x * pair_candidate_b1));
assign pair_candidate_z5 = (pair_candidate_zr5 + (pair_candidate_x * pair_candidate_b0));
assign pair_candidate_z6 = (pair_candidate_zr6 + (pair_candidate_y1 * pair_candidate_a5));
assign pair_candidate_z7 = (pair_candidate_zr7 + (pair_candidate_y1 * pair_candidate_a4));
assign pair_candidate_z8 = (pair_candidate_zr8 + (pair_candidate_y1 * pair_candidate_a3));
assign pair_candidate_z9 = (pair_candidate_zr9 + (pair_candidate_y1 * pair_candidate_a2));
assign pair_candidate_z10 = (pair_candidate_zr10 + (pair_candidate_y1 * pair_candidate_a1));
assign pair_candidate_y_next = pair_candidate_z10;
assign pair_reference_railed = (~((pair_reference_y_next[49:47] == $signed({1'd0, pair_reference_y_pat})) | (pair_reference_y_next[49:47] == $signed({1'd0, (~pair_reference_y_pat)}))));

// synthesis translate_off
reg dummy_d_1;
// synthesis translate_on
always @(*) begin
	pair_reference_y_lim <= 25'sd0;
	if (pair_reference_railed) begin
		pair_reference_y_lim <= pair_reference_y0;
	end else begin
		pair_reference_y_lim <= pair_reference_y_next[49:23];
	end
// synthesis translate_off
	dummy_d_1 <= dummy_s;
// synthesis translate_on
end
assign pair_reference_z0 = (pair_reference_zr0 + (pair_reference_x * pair_reference_b5));
assign pair_reference_z1 = (pair_reference_zr1 + (pair_reference_x * pair_reference_b4));
assign pair_reference_z2 = (pair_reference_zr2 + (pair_reference_x * pair_reference_b3));
assign pair_reference_z3 = (pair_reference_zr3 + (pair_reference_x * pair_reference_b2));
assign pair_reference_z4 = (pair_reference_zr4 + (pair_reference_x * pair_reference_b1));
assign pair_reference_z5 = (pair_reference_zr5 + (pair_reference_x * pair_reference_b0));
assign pair_reference_z6 = (pair_reference_zr6 + (pair_reference_y1 * pair_reference_a5));
assign pair_reference_z7 = (pair_reference_zr7 + (pair_reference_y1 * pair_reference_a4));
assign pair_reference_z8 = (pair_reference_zr8 + (pair_reference_y1 * pair_reference_a3));
assign pair_reference_z9 = (pair_reference_zr9 + (pair_reference_y1 * pair_reference_a2));
assign pair_reference_z10 = (pair_reference_zr10 + (pair_reference_y1 * pair_reference_a1));
assign pair_reference_y_next = pair_reference_z10;
assign pair_sel = (pair_bus_adr[13:9] == 1'd0);
assign pair_z03_r = pair_bus_dat_w[2:0];
assign pair_z03_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 1'd0));
assign pair_z02_r = pair_bus_dat_w[7:0];
assign pair_z02_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 1'd1));
assign pair_z01_r = pair_bus_dat_w[7:0];
assign pair_z01_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 2'd2));
assign pair_z00_r = pair_bus_dat_w[7:0];
assign pair_z00_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 2'd3));
assign pair_a13_r = pair_bus_dat_w[0];
assign pair_a13_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 3'd4));
assign pair_a12_r = pair_bus_dat_w[7:0];
assign pair_a12_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 3'd5));
assign pair_a11_r = pair_bus_dat_w[7:0];
assign pair_a11_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 3'd6));
assign pair_a10_r = pair_bus_dat_w[7:0];
assign pair_a10_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 3'd7));
assign pair_a23_r = pair_bus_dat_w[0];
assign pair_a23_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 4'd8));
assign pair_a22_r = pair_bus_dat_w[7:0];
assign pair_a22_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 4'd9));
assign pair_a21_r = pair_bus_dat_w[7:0];
assign pair_a21_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 4'd10));
assign pair_a20_r = pair_bus_dat_w[7:0];
assign pair_a20_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 4'd11));
assign pair_a33_r = pair_bus_dat_w[0];
assign pair_a33_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 4'd12));
assign pair_a32_r = pair_bus_dat_w[7:0];
assign pair_a32_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 4'd13));
assign pair_a31_r = pair_bus_dat_w[7:0];
assign pair_a31_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 4'd14));
assign pair_a30_r = pair_bus_dat_w[7:0];
assign pair_a30_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 4'd15));
assign pair_a43_r = pair_bus_dat_w[0];
assign pair_a43_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd16));
assign pair_a42_r = pair_bus_dat_w[7:0];
assign pair_a42_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd17));
assign pair_a41_r = pair_bus_dat_w[7:0];
assign pair_a41_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd18));
assign pair_a40_r = pair_bus_dat_w[7:0];
assign pair_a40_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd19));
assign pair_a53_r = pair_bus_dat_w[0];
assign pair_a53_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd20));
assign pair_a52_r = pair_bus_dat_w[7:0];
assign pair_a52_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd21));
assign pair_a51_r = pair_bus_dat_w[7:0];
assign pair_a51_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd22));
assign pair_a50_r = pair_bus_dat_w[7:0];
assign pair_a50_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd23));
assign pair_b03_r = pair_bus_dat_w[0];
assign pair_b03_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd24));
assign pair_b02_r = pair_bus_dat_w[7:0];
assign pair_b02_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd25));
assign pair_b01_r = pair_bus_dat_w[7:0];
assign pair_b01_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd26));
assign pair_b00_r = pair_bus_dat_w[7:0];
assign pair_b00_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd27));
assign pair_b13_r = pair_bus_dat_w[0];
assign pair_b13_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd28));
assign pair_b12_r = pair_bus_dat_w[7:0];
assign pair_b12_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd29));
assign pair_b11_r = pair_bus_dat_w[7:0];
assign pair_b11_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd30));
assign pair_b10_r = pair_bus_dat_w[7:0];
assign pair_b10_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 5'd31));
assign pair_b23_r = pair_bus_dat_w[0];
assign pair_b23_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd32));
assign pair_b22_r = pair_bus_dat_w[7:0];
assign pair_b22_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd33));
assign pair_b21_r = pair_bus_dat_w[7:0];
assign pair_b21_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd34));
assign pair_b20_r = pair_bus_dat_w[7:0];
assign pair_b20_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd35));
assign pair_b33_r = pair_bus_dat_w[0];
assign pair_b33_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd36));
assign pair_b32_r = pair_bus_dat_w[7:0];
assign pair_b32_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd37));
assign pair_b31_r = pair_bus_dat_w[7:0];
assign pair_b31_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd38));
assign pair_b30_r = pair_bus_dat_w[7:0];
assign pair_b30_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd39));
assign pair_b43_r = pair_bus_dat_w[0];
assign pair_b43_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd40));
assign pair_b42_r = pair_bus_dat_w[7:0];
assign pair_b42_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd41));
assign pair_b41_r = pair_bus_dat_w[7:0];
assign pair_b41_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd42));
assign pair_b40_r = pair_bus_dat_w[7:0];
assign pair_b40_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd43));
assign pair_b53_r = pair_bus_dat_w[0];
assign pair_b53_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd44));
assign pair_b52_r = pair_bus_dat_w[7:0];
assign pair_b52_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd45));
assign pair_b51_r = pair_bus_dat_w[7:0];
assign pair_b51_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd46));
assign pair_b50_r = pair_bus_dat_w[7:0];
assign pair_b50_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[5:0] == 6'd47));
assign pair_candidate_storage = pair_candidate_storage_full[26:0];
assign pair_z03_w = pair_candidate_storage_full[26:24];
assign pair_z02_w = pair_candidate_storage_full[23:16];
assign pair_z01_w = pair_candidate_storage_full[15:8];
assign pair_z00_w = pair_candidate_storage_full[7:0];
assign pair_candidate_csrstorage0_storage = pair_candidate_csrstorage0_storage_full[24:0];
assign pair_a13_w = pair_candidate_csrstorage0_storage_full[24];
assign pair_a12_w = pair_candidate_csrstorage0_storage_full[23:16];
assign pair_a11_w = pair_candidate_csrstorage0_storage_full[15:8];
assign pair_a10_w = pair_candidate_csrstorage0_storage_full[7:0];
assign pair_candidate_csrstorage1_storage = pair_candidate_csrstorage1_storage_full[24:0];
assign pair_a23_w = pair_candidate_csrstorage1_storage_full[24];
assign pair_a22_w = pair_candidate_csrstorage1_storage_full[23:16];
assign pair_a21_w = pair_candidate_csrstorage1_storage_full[15:8];
assign pair_a20_w = pair_candidate_csrstorage1_storage_full[7:0];
assign pair_candidate_csrstorage2_storage = pair_candidate_csrstorage2_storage_full[24:0];
assign pair_a33_w = pair_candidate_csrstorage2_storage_full[24];
assign pair_a32_w = pair_candidate_csrstorage2_storage_full[23:16];
assign pair_a31_w = pair_candidate_csrstorage2_storage_full[15:8];
assign pair_a30_w = pair_candidate_csrstorage2_storage_full[7:0];
assign pair_candidate_csrstorage3_storage = pair_candidate_csrstorage3_storage_full[24:0];
assign pair_a43_w = pair_candidate_csrstorage3_storage_full[24];
assign pair_a42_w = pair_candidate_csrstorage3_storage_full[23:16];
assign pair_a41_w = pair_candidate_csrstorage3_storage_full[15:8];
assign pair_a40_w = pair_candidate_csrstorage3_storage_full[7:0];
assign pair_candidate_csrstorage4_storage = pair_candidate_csrstorage4_storage_full[24:0];
assign pair_a53_w = pair_candidate_csrstorage4_storage_full[24];
assign pair_a52_w = pair_candidate_csrstorage4_storage_full[23:16];
assign pair_a51_w = pair_candidate_csrstorage4_storage_full[15:8];
assign pair_a50_w = pair_candidate_csrstorage4_storage_full[7:0];
assign pair_candidate_csrstorage5_storage = pair_candidate_csrstorage5_storage_full[24:0];
assign pair_b03_w = pair_candidate_csrstorage5_storage_full[24];
assign pair_b02_w = pair_candidate_csrstorage5_storage_full[23:16];
assign pair_b01_w = pair_candidate_csrstorage5_storage_full[15:8];
assign pair_b00_w = pair_candidate_csrstorage5_storage_full[7:0];
assign pair_candidate_csrstorage6_storage = pair_candidate_csrstorage6_storage_full[24:0];
assign pair_b13_w = pair_candidate_csrstorage6_storage_full[24];
assign pair_b12_w = pair_candidate_csrstorage6_storage_full[23:16];
assign pair_b11_w = pair_candidate_csrstorage6_storage_full[15:8];
assign pair_b10_w = pair_candidate_csrstorage6_storage_full[7:0];
assign pair_candidate_csrstorage7_storage = pair_candidate_csrstorage7_storage_full[24:0];
assign pair_b23_w = pair_candidate_csrstorage7_storage_full[24];
assign pair_b22_w = pair_candidate_csrstorage7_storage_full[23:16];
assign pair_b21_w = pair_candidate_csrstorage7_storage_full[15:8];
assign pair_b20_w = pair_candidate_csrstorage7_storage_full[7:0];
assign pair_candidate_csrstorage8_storage = pair_candidate_csrstorage8_storage_full[24:0];
assign pair_b33_w = pair_candidate_csrstorage8_storage_full[24];
assign pair_b32_w = pair_candidate_csrstorage8_storage_full[23:16];
assign pair_b31_w = pair_candidate_csrstorage8_storage_full[15:8];
assign pair_b30_w = pair_candidate_csrstorage8_storage_full[7:0];
assign pair_candidate_csrstorage9_storage = pair_candidate_csrstorage9_storage_full[24:0];
assign pair_b43_w = pair_candidate_csrstorage9_storage_full[24];
assign pair_b42_w = pair_candidate_csrstorage9_storage_full[23:16];
assign pair_b41_w = pair_candidate_csrstorage9_storage_full[15:8];
assign pair_b40_w = pair_candidate_csrstorage9_storage_full[7:0];
assign pair_candidate_csrstorage10_storage = pair_candidate_csrstorage10_storage_full[24:0];
assign pair_b53_w = pair_candidate_csrstorage10_storage_full[24];
assign pair_b52_w = pair_candidate_csrstorage10_storage_full[23:16];
assign pair_b51_w = pair_candidate_csrstorage10_storage_full[15:8];
assign pair_b50_w = pair_candidate_csrstorage10_storage_full[7:0];

always @(posedge sys_clk) begin
	pair_q0 <= x;
	pair_q1 <= x;
	pair_q2 <= hold;
	pair_q3 <= hold;
	pair_q4 <= clear;
	pair_q5 <= clear;
	pair_q6 <= pair_candidate_storage;
	pair_q7 <= pair_candidate_csrstorage0_storage;
	pair_q8 <= pair_candidate_csrstorage1_storage;
	pair_q9 <= pair_candidate_csrstorage2_storage;
	pair_q10 <= pair_candidate_csrstorage3_storage;
	pair_q11 <= pair_candidate_csrstorage4_storage;
	pair_q12 <= pair_candidate_csrstorage5_storage;
	pair_q13 <= pair_candidate_csrstorage6_storage;
	pair_q14 <= pair_candidate_csrstorage7_storage;
	pair_q15 <= pair_candidate_csrstorage8_storage;
	pair_q16 <= pair_candidate_csrstorage9_storage;
	pair_q17 <= pair_candidate_csrstorage10_storage;
	pair_candidate_cohort0 <= pair_candidate_csrstorage0_storage;
	pair_candidate_a1 <= pair_candidate_cohort0;
	pair_candidate_cohort1 <= pair_candidate_csrstorage1_storage;
	pair_candidate_a2 <= pair_candidate_cohort1;
	pair_candidate_cohort2 <= pair_candidate_csrstorage2_storage;
	pair_candidate_a3 <= pair_candidate_cohort2;
	pair_candidate_cohort3 <= pair_candidate_csrstorage3_storage;
	pair_candidate_a4 <= pair_candidate_cohort3;
	pair_candidate_cohort4 <= pair_candidate_csrstorage4_storage;
	pair_candidate_a5 <= pair_candidate_cohort4;
	pair_candidate_cohort5 <= pair_candidate_csrstorage5_storage;
	pair_candidate_b0 <= pair_candidate_cohort5;
	pair_candidate_cohort6 <= pair_candidate_csrstorage6_storage;
	pair_candidate_b1 <= pair_candidate_cohort6;
	pair_candidate_cohort7 <= pair_candidate_csrstorage7_storage;
	pair_candidate_b2 <= pair_candidate_cohort7;
	pair_candidate_cohort8 <= pair_candidate_csrstorage8_storage;
	pair_candidate_b3 <= pair_candidate_cohort8;
	pair_candidate_cohort9 <= pair_candidate_csrstorage9_storage;
	pair_candidate_b4 <= pair_candidate_cohort9;
	pair_candidate_cohort10 <= pair_candidate_csrstorage10_storage;
	pair_candidate_b5 <= pair_candidate_cohort10;
	pair_candidate_z0_cohort <= pair_candidate_storage;
	pair_candidate_z0r <= (pair_candidate_z0_cohort <<< 5'd23);
	pair_candidate_error <= pair_candidate_railed;
	pair_candidate_y0 <= pair_candidate_y_lim;
	if (pair_candidate_clear) begin
		pair_candidate_y1 <= 1'd0;
	end else begin
		if ((~pair_candidate_hold)) begin
			pair_candidate_y1 <= pair_candidate_y_lim;
		end
	end
	pair_candidate_zr0 <= pair_candidate_z0r;
	pair_candidate_zr1 <= pair_candidate_z0;
	pair_candidate_zr2 <= pair_candidate_z1;
	pair_candidate_zr3 <= pair_candidate_z2;
	pair_candidate_zr4 <= pair_candidate_z3;
	pair_candidate_zr5 <= pair_candidate_z4;
	pair_candidate_zr6 <= pair_candidate_z5;
	pair_candidate_zr7 <= pair_candidate_z6;
	pair_candidate_zr8 <= pair_candidate_z7;
	pair_candidate_zr9 <= pair_candidate_z8;
	pair_candidate_zr10 <= pair_candidate_z9;
	pair_reference_a1 <= pair_reference_rci_storage0;
	pair_reference_a2 <= pair_reference_rci_storage1;
	pair_reference_a3 <= pair_reference_rci_storage2;
	pair_reference_a4 <= pair_reference_rci_storage3;
	pair_reference_a5 <= pair_reference_rci_storage4;
	pair_reference_b0 <= pair_reference_rci_storage5;
	pair_reference_b1 <= pair_reference_rci_storage6;
	pair_reference_b2 <= pair_reference_rci_storage7;
	pair_reference_b3 <= pair_reference_rci_storage8;
	pair_reference_b4 <= pair_reference_rci_storage9;
	pair_reference_b5 <= pair_reference_rci_storage10;
	pair_reference_z0r <= (pair_reference_z0_storage <<< 5'd23);
	pair_reference_error <= pair_reference_railed;
	pair_reference_y0 <= pair_reference_y_lim;
	if (pair_reference_clear) begin
		pair_reference_y1 <= 1'd0;
	end else begin
		if ((~pair_reference_hold)) begin
			pair_reference_y1 <= pair_reference_y_lim;
		end
	end
	pair_reference_zr0 <= pair_reference_z0r;
	pair_reference_zr1 <= pair_reference_z0;
	pair_reference_zr2 <= pair_reference_z1;
	pair_reference_zr3 <= pair_reference_z2;
	pair_reference_zr4 <= pair_reference_z3;
	pair_reference_zr5 <= pair_reference_z4;
	pair_reference_zr6 <= pair_reference_z5;
	pair_reference_zr7 <= pair_reference_z6;
	pair_reference_zr8 <= pair_reference_z7;
	pair_reference_zr9 <= pair_reference_z8;
	pair_reference_zr10 <= pair_reference_z9;
	pair_bus_dat_r <= 1'd0;
	if (pair_sel) begin
		case (pair_bus_adr[5:0])
			1'd0: begin
				pair_bus_dat_r <= pair_z03_w;
			end
			1'd1: begin
				pair_bus_dat_r <= pair_z02_w;
			end
			2'd2: begin
				pair_bus_dat_r <= pair_z01_w;
			end
			2'd3: begin
				pair_bus_dat_r <= pair_z00_w;
			end
			3'd4: begin
				pair_bus_dat_r <= pair_a13_w;
			end
			3'd5: begin
				pair_bus_dat_r <= pair_a12_w;
			end
			3'd6: begin
				pair_bus_dat_r <= pair_a11_w;
			end
			3'd7: begin
				pair_bus_dat_r <= pair_a10_w;
			end
			4'd8: begin
				pair_bus_dat_r <= pair_a23_w;
			end
			4'd9: begin
				pair_bus_dat_r <= pair_a22_w;
			end
			4'd10: begin
				pair_bus_dat_r <= pair_a21_w;
			end
			4'd11: begin
				pair_bus_dat_r <= pair_a20_w;
			end
			4'd12: begin
				pair_bus_dat_r <= pair_a33_w;
			end
			4'd13: begin
				pair_bus_dat_r <= pair_a32_w;
			end
			4'd14: begin
				pair_bus_dat_r <= pair_a31_w;
			end
			4'd15: begin
				pair_bus_dat_r <= pair_a30_w;
			end
			5'd16: begin
				pair_bus_dat_r <= pair_a43_w;
			end
			5'd17: begin
				pair_bus_dat_r <= pair_a42_w;
			end
			5'd18: begin
				pair_bus_dat_r <= pair_a41_w;
			end
			5'd19: begin
				pair_bus_dat_r <= pair_a40_w;
			end
			5'd20: begin
				pair_bus_dat_r <= pair_a53_w;
			end
			5'd21: begin
				pair_bus_dat_r <= pair_a52_w;
			end
			5'd22: begin
				pair_bus_dat_r <= pair_a51_w;
			end
			5'd23: begin
				pair_bus_dat_r <= pair_a50_w;
			end
			5'd24: begin
				pair_bus_dat_r <= pair_b03_w;
			end
			5'd25: begin
				pair_bus_dat_r <= pair_b02_w;
			end
			5'd26: begin
				pair_bus_dat_r <= pair_b01_w;
			end
			5'd27: begin
				pair_bus_dat_r <= pair_b00_w;
			end
			5'd28: begin
				pair_bus_dat_r <= pair_b13_w;
			end
			5'd29: begin
				pair_bus_dat_r <= pair_b12_w;
			end
			5'd30: begin
				pair_bus_dat_r <= pair_b11_w;
			end
			5'd31: begin
				pair_bus_dat_r <= pair_b10_w;
			end
			6'd32: begin
				pair_bus_dat_r <= pair_b23_w;
			end
			6'd33: begin
				pair_bus_dat_r <= pair_b22_w;
			end
			6'd34: begin
				pair_bus_dat_r <= pair_b21_w;
			end
			6'd35: begin
				pair_bus_dat_r <= pair_b20_w;
			end
			6'd36: begin
				pair_bus_dat_r <= pair_b33_w;
			end
			6'd37: begin
				pair_bus_dat_r <= pair_b32_w;
			end
			6'd38: begin
				pair_bus_dat_r <= pair_b31_w;
			end
			6'd39: begin
				pair_bus_dat_r <= pair_b30_w;
			end
			6'd40: begin
				pair_bus_dat_r <= pair_b43_w;
			end
			6'd41: begin
				pair_bus_dat_r <= pair_b42_w;
			end
			6'd42: begin
				pair_bus_dat_r <= pair_b41_w;
			end
			6'd43: begin
				pair_bus_dat_r <= pair_b40_w;
			end
			6'd44: begin
				pair_bus_dat_r <= pair_b53_w;
			end
			6'd45: begin
				pair_bus_dat_r <= pair_b52_w;
			end
			6'd46: begin
				pair_bus_dat_r <= pair_b51_w;
			end
			6'd47: begin
				pair_bus_dat_r <= pair_b50_w;
			end
		endcase
	end
	if (pair_z03_re) begin
		pair_candidate_storage_full[26:24] <= pair_z03_r;
	end
	if (pair_z02_re) begin
		pair_candidate_storage_full[23:16] <= pair_z02_r;
	end
	if (pair_z01_re) begin
		pair_candidate_storage_full[15:8] <= pair_z01_r;
	end
	if (pair_z00_re) begin
		pair_candidate_storage_full[7:0] <= pair_z00_r;
	end
	pair_candidate_re <= pair_z00_re;
	if (pair_a13_re) begin
		pair_candidate_csrstorage0_storage_full[24] <= pair_a13_r;
	end
	if (pair_a12_re) begin
		pair_candidate_csrstorage0_storage_full[23:16] <= pair_a12_r;
	end
	if (pair_a11_re) begin
		pair_candidate_csrstorage0_storage_full[15:8] <= pair_a11_r;
	end
	if (pair_a10_re) begin
		pair_candidate_csrstorage0_storage_full[7:0] <= pair_a10_r;
	end
	pair_candidate_csrstorage0_re <= pair_a10_re;
	if (pair_a23_re) begin
		pair_candidate_csrstorage1_storage_full[24] <= pair_a23_r;
	end
	if (pair_a22_re) begin
		pair_candidate_csrstorage1_storage_full[23:16] <= pair_a22_r;
	end
	if (pair_a21_re) begin
		pair_candidate_csrstorage1_storage_full[15:8] <= pair_a21_r;
	end
	if (pair_a20_re) begin
		pair_candidate_csrstorage1_storage_full[7:0] <= pair_a20_r;
	end
	pair_candidate_csrstorage1_re <= pair_a20_re;
	if (pair_a33_re) begin
		pair_candidate_csrstorage2_storage_full[24] <= pair_a33_r;
	end
	if (pair_a32_re) begin
		pair_candidate_csrstorage2_storage_full[23:16] <= pair_a32_r;
	end
	if (pair_a31_re) begin
		pair_candidate_csrstorage2_storage_full[15:8] <= pair_a31_r;
	end
	if (pair_a30_re) begin
		pair_candidate_csrstorage2_storage_full[7:0] <= pair_a30_r;
	end
	pair_candidate_csrstorage2_re <= pair_a30_re;
	if (pair_a43_re) begin
		pair_candidate_csrstorage3_storage_full[24] <= pair_a43_r;
	end
	if (pair_a42_re) begin
		pair_candidate_csrstorage3_storage_full[23:16] <= pair_a42_r;
	end
	if (pair_a41_re) begin
		pair_candidate_csrstorage3_storage_full[15:8] <= pair_a41_r;
	end
	if (pair_a40_re) begin
		pair_candidate_csrstorage3_storage_full[7:0] <= pair_a40_r;
	end
	pair_candidate_csrstorage3_re <= pair_a40_re;
	if (pair_a53_re) begin
		pair_candidate_csrstorage4_storage_full[24] <= pair_a53_r;
	end
	if (pair_a52_re) begin
		pair_candidate_csrstorage4_storage_full[23:16] <= pair_a52_r;
	end
	if (pair_a51_re) begin
		pair_candidate_csrstorage4_storage_full[15:8] <= pair_a51_r;
	end
	if (pair_a50_re) begin
		pair_candidate_csrstorage4_storage_full[7:0] <= pair_a50_r;
	end
	pair_candidate_csrstorage4_re <= pair_a50_re;
	if (pair_b03_re) begin
		pair_candidate_csrstorage5_storage_full[24] <= pair_b03_r;
	end
	if (pair_b02_re) begin
		pair_candidate_csrstorage5_storage_full[23:16] <= pair_b02_r;
	end
	if (pair_b01_re) begin
		pair_candidate_csrstorage5_storage_full[15:8] <= pair_b01_r;
	end
	if (pair_b00_re) begin
		pair_candidate_csrstorage5_storage_full[7:0] <= pair_b00_r;
	end
	pair_candidate_csrstorage5_re <= pair_b00_re;
	if (pair_b13_re) begin
		pair_candidate_csrstorage6_storage_full[24] <= pair_b13_r;
	end
	if (pair_b12_re) begin
		pair_candidate_csrstorage6_storage_full[23:16] <= pair_b12_r;
	end
	if (pair_b11_re) begin
		pair_candidate_csrstorage6_storage_full[15:8] <= pair_b11_r;
	end
	if (pair_b10_re) begin
		pair_candidate_csrstorage6_storage_full[7:0] <= pair_b10_r;
	end
	pair_candidate_csrstorage6_re <= pair_b10_re;
	if (pair_b23_re) begin
		pair_candidate_csrstorage7_storage_full[24] <= pair_b23_r;
	end
	if (pair_b22_re) begin
		pair_candidate_csrstorage7_storage_full[23:16] <= pair_b22_r;
	end
	if (pair_b21_re) begin
		pair_candidate_csrstorage7_storage_full[15:8] <= pair_b21_r;
	end
	if (pair_b20_re) begin
		pair_candidate_csrstorage7_storage_full[7:0] <= pair_b20_r;
	end
	pair_candidate_csrstorage7_re <= pair_b20_re;
	if (pair_b33_re) begin
		pair_candidate_csrstorage8_storage_full[24] <= pair_b33_r;
	end
	if (pair_b32_re) begin
		pair_candidate_csrstorage8_storage_full[23:16] <= pair_b32_r;
	end
	if (pair_b31_re) begin
		pair_candidate_csrstorage8_storage_full[15:8] <= pair_b31_r;
	end
	if (pair_b30_re) begin
		pair_candidate_csrstorage8_storage_full[7:0] <= pair_b30_r;
	end
	pair_candidate_csrstorage8_re <= pair_b30_re;
	if (pair_b43_re) begin
		pair_candidate_csrstorage9_storage_full[24] <= pair_b43_r;
	end
	if (pair_b42_re) begin
		pair_candidate_csrstorage9_storage_full[23:16] <= pair_b42_r;
	end
	if (pair_b41_re) begin
		pair_candidate_csrstorage9_storage_full[15:8] <= pair_b41_r;
	end
	if (pair_b40_re) begin
		pair_candidate_csrstorage9_storage_full[7:0] <= pair_b40_r;
	end
	pair_candidate_csrstorage9_re <= pair_b40_re;
	if (pair_b53_re) begin
		pair_candidate_csrstorage10_storage_full[24] <= pair_b53_r;
	end
	if (pair_b52_re) begin
		pair_candidate_csrstorage10_storage_full[23:16] <= pair_b52_r;
	end
	if (pair_b51_re) begin
		pair_candidate_csrstorage10_storage_full[15:8] <= pair_b51_r;
	end
	if (pair_b50_re) begin
		pair_candidate_csrstorage10_storage_full[7:0] <= pair_b50_r;
	end
	pair_candidate_csrstorage10_re <= pair_b50_re;
	if (sys_rst) begin
		pair_candidate_y0 <= 25'sd0;
		pair_candidate_error <= 1'd0;
		pair_candidate_storage_full <= 27'd0;
		pair_candidate_re <= 1'd0;
		pair_candidate_a1 <= 25'sd0;
		pair_candidate_csrstorage0_storage_full <= 25'd0;
		pair_candidate_csrstorage0_re <= 1'd0;
		pair_candidate_cohort0 <= 25'd0;
		pair_candidate_a2 <= 25'sd0;
		pair_candidate_csrstorage1_storage_full <= 25'd0;
		pair_candidate_csrstorage1_re <= 1'd0;
		pair_candidate_cohort1 <= 25'd0;
		pair_candidate_a3 <= 25'sd0;
		pair_candidate_csrstorage2_storage_full <= 25'd0;
		pair_candidate_csrstorage2_re <= 1'd0;
		pair_candidate_cohort2 <= 25'd0;
		pair_candidate_a4 <= 25'sd0;
		pair_candidate_csrstorage3_storage_full <= 25'd0;
		pair_candidate_csrstorage3_re <= 1'd0;
		pair_candidate_cohort3 <= 25'd0;
		pair_candidate_a5 <= 25'sd0;
		pair_candidate_csrstorage4_storage_full <= 25'd0;
		pair_candidate_csrstorage4_re <= 1'd0;
		pair_candidate_cohort4 <= 25'd0;
		pair_candidate_b0 <= 25'sd0;
		pair_candidate_csrstorage5_storage_full <= 25'd0;
		pair_candidate_csrstorage5_re <= 1'd0;
		pair_candidate_cohort5 <= 25'd0;
		pair_candidate_b1 <= 25'sd0;
		pair_candidate_csrstorage6_storage_full <= 25'd0;
		pair_candidate_csrstorage6_re <= 1'd0;
		pair_candidate_cohort6 <= 25'd0;
		pair_candidate_b2 <= 25'sd0;
		pair_candidate_csrstorage7_storage_full <= 25'd0;
		pair_candidate_csrstorage7_re <= 1'd0;
		pair_candidate_cohort7 <= 25'd0;
		pair_candidate_b3 <= 25'sd0;
		pair_candidate_csrstorage8_storage_full <= 25'd0;
		pair_candidate_csrstorage8_re <= 1'd0;
		pair_candidate_cohort8 <= 25'd0;
		pair_candidate_b4 <= 25'sd0;
		pair_candidate_csrstorage9_storage_full <= 25'd0;
		pair_candidate_csrstorage9_re <= 1'd0;
		pair_candidate_cohort9 <= 25'd0;
		pair_candidate_b5 <= 25'sd0;
		pair_candidate_csrstorage10_storage_full <= 25'd0;
		pair_candidate_csrstorage10_re <= 1'd0;
		pair_candidate_cohort10 <= 25'd0;
		pair_candidate_z0r <= 50'sd0;
		pair_candidate_z0_cohort <= 27'd0;
		pair_candidate_y1 <= 25'sd0;
		pair_candidate_zr0 <= 50'sd0;
		pair_candidate_zr1 <= 50'sd0;
		pair_candidate_zr2 <= 50'sd0;
		pair_candidate_zr3 <= 50'sd0;
		pair_candidate_zr4 <= 50'sd0;
		pair_candidate_zr5 <= 50'sd0;
		pair_candidate_zr6 <= 50'sd0;
		pair_candidate_zr7 <= 50'sd0;
		pair_candidate_zr8 <= 50'sd0;
		pair_candidate_zr9 <= 50'sd0;
		pair_candidate_zr10 <= 50'sd0;
		pair_reference_y0 <= 25'sd0;
		pair_reference_error <= 1'd0;
		pair_reference_a1 <= 25'sd0;
		pair_reference_a2 <= 25'sd0;
		pair_reference_a3 <= 25'sd0;
		pair_reference_a4 <= 25'sd0;
		pair_reference_a5 <= 25'sd0;
		pair_reference_b0 <= 25'sd0;
		pair_reference_b1 <= 25'sd0;
		pair_reference_b2 <= 25'sd0;
		pair_reference_b3 <= 25'sd0;
		pair_reference_b4 <= 25'sd0;
		pair_reference_b5 <= 25'sd0;
		pair_reference_z0r <= 50'sd0;
		pair_reference_y1 <= 25'sd0;
		pair_reference_zr0 <= 50'sd0;
		pair_reference_zr1 <= 50'sd0;
		pair_reference_zr2 <= 50'sd0;
		pair_reference_zr3 <= 50'sd0;
		pair_reference_zr4 <= 50'sd0;
		pair_reference_zr5 <= 50'sd0;
		pair_reference_zr6 <= 50'sd0;
		pair_reference_zr7 <= 50'sd0;
		pair_reference_zr8 <= 50'sd0;
		pair_reference_zr9 <= 50'sd0;
		pair_reference_zr10 <= 50'sd0;
		pair_bus_dat_r <= 8'd0;
		pair_q0 <= 25'sd0;
		pair_q1 <= 25'sd0;
		pair_q2 <= 1'd0;
		pair_q3 <= 1'd0;
		pair_q4 <= 1'd0;
		pair_q5 <= 1'd0;
		pair_q6 <= 27'd0;
		pair_q7 <= 25'd0;
		pair_q8 <= 25'd0;
		pair_q9 <= 25'd0;
		pair_q10 <= 25'd0;
		pair_q11 <= 25'd0;
		pair_q12 <= 25'd0;
		pair_q13 <= 25'd0;
		pair_q14 <= 25'd0;
		pair_q15 <= 25'd0;
		pair_q16 <= 25'd0;
		pair_q17 <= 25'd0;
	end
end

endmodule
