from pathlib import Path
import collections,hashlib,json
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r52-c48-carry-fold');t=r/'gateware/build/trials/20261111_141424_r52_c48_carry_fold'
base=Path('D:/RP_Dev/linien_trials/20261111-r48-routed-pin-refine');old=base/'gateware/build/trials/20261111_130524_r48_compatible_postroute_v3'
m=json.loads((t/'manifest.json').read_text());assert m['functional']=='PASS' and m['synthesis']=='COMPLETE' and m['route']=='COMPLETE' and not m['source_changes_during_run']
for n in ('top.xdc','csrmap.py'):assert (t/n).read_bytes()==(old/n).read_bytes(),n
for n in ('gateware/logic/iir.py','gateware/logic/iir_registered_c48.py','gateware/logic/chains.py','gateware/linien_module.py'):
 assert (r/n).read_bytes()==(base/n).read_bytes(),n
assert (r/'gateware/tests/timing/reference/r48_iir_c48_mac.py').read_bytes()==(base/'gateware/logic/iir_c48_mac.py').read_bytes()
ref=(r/'gateware/tests/timing/reference/r48_iir_c48_frame.py').read_text(encoding='utf-8').replace('from .r48_iir_c48_mac import split_c48_mac','from .iir_c48_mac import split_c48_mac')
assert ref==(base/'gateware/logic/iir.py').read_text(encoding='utf-8')
fold=json.loads((t/'c48_carry_fold_checks/results.json').read_text());assert fold['passed'] and fold['known_integer_cases']==320 and fold['partial_X_Z_cases']==4606
filters=json.loads((t/'c48_fold_filter_checks/results.json').read_text());assert filters['passed'] and filters['config_delay']==2 and filters['unknown_cycles_each']==3000 and [v['order'] for v in filters['results']]==[1,2,5]
native=json.loads((t/'c48_mac_checks/results.json').read_text());assert native['passed'] and native['cases']==71760
assert json.loads((t/'c48_filter_checks/results.json').read_text())['passed']
def parse(p):
 return {v['NAME']:{k:d for k,d in v.items() if k not in ('LOC','BEL')} for v in [dict(s.split('=',1) for s in b.splitlines() if '=' in s) for b in p.read_text().split('CELL_BEGIN')[1:]]}
a=parse(h/'r48_mapped/all_dsp.txt');b=parse(h/'r52_mapped/all_dsp.txt')
metrics=json.loads((h/'r52_mapped/metrics.json').read_text());assert len(b)==metrics['resources']['dsp']
diff={k:{'before':a.get(k),'after':b.get(k)} for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}
def matrix(d):return dict(collections.Counter('A'+v['AREG']+'_B'+v['BREG']+'_M'+v['MREG']+'_P'+v['PREG'] for v in d.values()))
rec={'passed':True,'CSR_XDC_raw_identical_R48':True,'production_IIR_registered_MAC_Chains_Root_raw_identical_R48':True,'frozen_helper_and_IIR_references_independent_original_R48':True,'native_full50_fold':fold,'original_71760_native':native,'native_cfg2_IIR':filters,'actual_DSP_count_before':len(a),'actual_DSP_count_after':len(b),'actual_DSP_register_matrix_before':matrix(a),'actual_DSP_register_matrix_after':matrix(b),'actual_DSP_property_differences_ignoring_LOC_BEL':diff,'actual_DSP_properties_unchanged':not diff,'new_serial_sample_cycles_RTL':0,'source_sha256':hashlib.sha256((r/'gateware/logic/iir_c48_mac.py').read_bytes()).hexdigest(),'top_sha256':hashlib.sha256((t/'top.v').read_bytes()).hexdigest(),'scope':'All original sequential source unchanged; finite full50 math and specified native strict X/Z. Actual mapped DSP properties reported as observed, not assumed equal; not postroute/fullRoot SDF/formal/physical CDC/board/plant proof.'}
(h/'r52_generated_mapping_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R52_GENERATED_CSR_XDC_FROZEN_NATIVE_AUDIT_COMPLETE','DSP_count',len(b),'actual_property_differences',len(diff))
