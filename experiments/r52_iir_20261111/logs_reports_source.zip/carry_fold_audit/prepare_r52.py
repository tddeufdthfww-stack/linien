from pathlib import Path
import hashlib,json
h=Path(__file__).parent;base=Path('D:/RP_Dev/linien_trials/20261111-r48-routed-pin-refine');root=Path('D:/RP_Dev/linien_trials/20261111-r52-c48-carry-fold')
m=json.loads((base/'gateware/build/trials/20261111_130524_r48_compatible_postroute_v3/manifest.json').read_text());proof=json.loads((h/'r52_mathematical_preanalysis.json').read_text());assert proof['passed_known_integer_proof']
for n,d in m['source_hashes'].items():
 if n.startswith(('gateware/','tools/')) and not n.startswith(('gateware/build/','gateware/ps_project/')):
  b=(base/n).read_bytes();assert hashlib.sha256(b).hexdigest()==d,n;(root/n).write_bytes(b)
(root/'docs/R52_PLAN.md').write_bytes('''# R52：R48 末级 C48 符号进位化简

输入R48 b0824e3/76dd452，最佳实际route-.179/-4.904ns、70端点，最终STA FAIL。R50输出边沿重定位虽然全功能PASS但route-.931/-706.938ns、1663端点，拒绝；R51仅物理列试验在独立树运行，结果不混用。本轮明确回到R48输出FF结构，不携入R50重定位或R51列pblock；新综合和route，不继承R47/R48的布局收益。

1. 只改gateware/logic/iir_c48_mac.py组合修正：Z=zlo.sign，C=coeff.sign，L=low.sign，原U=Z+(!Z & !C & L)-(Z & C & !L)，已知位真值等于(Z&L)|(!C&(Z|L))，即majority(Z,L,!C)。原correction=ztop+U、4位signed、最终50位拼接/模4高2位、乘法/级联/系数/右移/饱和/FF边沿均保持。已知8种符号×4种ztop、100320完整50位整数向量修改前PASS。
2. 不声称独立符号谓词对任意X组合等价（Z=X/C=0/L=1存在差异）。完整MAC中若zlo/coeff/xlo含X/Z，原低乘加全字未知并使高乘加及top未知，两种修正不改变完整输出；仅xhi未知则低17位保持、高31/top未知，修正输入相同；仅ztop未知则低48保持、top两位未知。该传播论证仍需原生完整50位严格四态验证，不能借此弱化断言。
3. 新增冻结原R48 helper与完整MAC320边界整数+4606部分X/Z逐位case-equality；原样71760完整50位乘加整数oracle及原config0完整IIR；新增config2/order1/2/5/真实CSR/冻结R48(明确引用旧split helper)/独立整数oracle/各3000X-Z。先小模块PASS，失败拒绝，不开始整机。原旧测试均不改。
4. 全旧14/25位PID/饱和/复位/CE/真实CSR/FastChain/Scope/阈值/AXI/CDC功能，再新生成/synth/place/route和readonly完整路径/实际DSP/CDC/DRC/覆盖；注册MAC helper不改，新增ADC/反馈/CSR周期0。不预言LUT级数或时序收益，只有实际route可判优劣。
5. 原用户工程/R2b/R4a/R48冻结保护；新输入SHA/代码/结果/失败日志分别归档。PS7/PLL/器件/引脚/ADC/DAC/CSR/总线源码和时序约束不改，不加false/multicycle/clock-group，不降阶/精度/吞吐，不部署。
'''.encode())
old=(base/'gateware/logic/iir_c48_mac.py').read_bytes();(root/'gateware/tests/timing/reference/r48_iir_c48_mac.py').write_bytes(old)
p=root/'gateware/logic/iir_c48_mac.py';s=p.read_text(encoding='utf-8');s=s.replace('positive_overflow,negative_overflow=Signal(),Signal()','carry=Signal()')
before='''        positive_overflow.eq(~zlo[-1] & ~c[-1] & low[-1]),
        negative_overflow.eq(zlo[-1] & c[-1] & ~low[-1]),
        correction.eq(ztop+zlo[-1]+positive_overflow-negative_overflow),'''
after='''        # Z + positive_overflow - negative_overflow is unsigned carry.
        carry.eq((zlo[-1] & low[-1]) | (~c[-1] & (zlo[-1] | low[-1]))),
        correction.eq(ztop+carry),'''
assert s.count(before)==1;s=s.replace(before,after);p.write_bytes(s.encode())
(root/'tools/check_c48_carry_fold.py').write_bytes((h/'check_c48_carry_fold_template.py').read_bytes())
frozen=(base/'gateware/logic/iir.py').read_text(encoding='utf-8');assert frozen.count('from .iir_c48_mac import split_c48_mac')==1
(root/'gateware/tests/timing/reference/r48_iir_c48_frame.py').write_bytes(frozen.replace('from .iir_c48_mac import split_c48_mac','from .r48_iir_c48_mac import split_c48_mac').encode())
oldcheck=Path('D:/RP_Dev/linien_trials/20261111-r45-iir-output-edge/tools/check_iir_output_edge.py').read_text(encoding='utf-8')
check=oldcheck.replace('r44_iir_registered_c48.py','r48_iir_c48_frame.py').replace('IIR_OUTPUT_EDGE_CONFIG2_SUITE_PASS','C48_FOLD_FILTER_CONFIG2_SUITE_PASS').replace('IIR_OUTPUT_EDGE_XZ_FAIL','C48_FOLD_FILTER_XZ_FAIL').replace('R45 output-edge retiming','R52 split-C48 carry fold')
(root/'tools/check_c48_fold_filter.py').write_bytes(check.encode())
p=root/'tools/run_gateware_trial.py';s=p.read_text(encoding='utf-8');needle="        if 'functional' in stages:\n";assert s.count(needle)==1
s=s.replace(needle,needle+"            execute([sys.executable, ROOT / 'tools/check_c48_carry_fold.py', '--out', out / 'c48_carry_fold_checks'],\n                    ROOT, out, 'c48_carry_fold', env, 'C48_CARRY_FOLD_SUITE_PASS')\n            execute([sys.executable, ROOT / 'tools/check_c48_fold_filter.py', '--out', out / 'c48_fold_filter_checks'],\n                    ROOT, out, 'c48_fold_filter', env, 'C48_FOLD_FILTER_CONFIG2_SUITE_PASS')\n")
p.write_bytes(s.encode())
unchanged={n:hashlib.sha256((root/n).read_bytes()).hexdigest()==d for n,d in m['source_hashes'].items() if n.startswith(('gateware/','tools/')) and not n.startswith(('gateware/build/','gateware/ps_project/')) and n not in ('gateware/logic/iir_c48_mac.py','tools/run_gateware_trial.py')};assert all(unchanged.values())
rec={'passed':True,'known_math':proof,'only_production_helper_changed':'gateware/logic/iir_c48_mac.py','all_other_existing_hardware_tests_raw_identical':unchanged,'frozen_old_helper_sha256':hashlib.sha256(old).hexdigest(),'candidate_helper_sha256':hashlib.sha256((root/'gateware/logic/iir_c48_mac.py').read_bytes()).hexdigest(),'registered_MAC_IIR_output_FF_and_cohorts_unchanged':True,'new_serial_cycles_target':0,'native_functional_synth_route':'NOT_RUN'}
(h/'r52_source_math_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R52_MINIMAL_HELPER_SOURCE_AND_KNOWN_MATH_AUDIT_PASS')
