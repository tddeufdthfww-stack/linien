from pathlib import Path
import itertools,json,random
h=Path(__file__).parent
def signed(v,n):return (v&((1<<n)-1))-(1<<n) if v&(1<<(n-1)) else v&((1<<n)-1)
signs=[]
for z,c,l in itertools.product((0,1),repeat=3):
 old=z+int(not z and not c and l)-int(z and c and not l)
 new=(z&l)|((1-c)&(z|l));assert old==new
 for top in (-2,-1,0,1):assert top+old==top+new
 signs.append({'zlo_sign':z,'coeff_sign':c,'low_sign':l,'old_unsigned_carry':old,'new_majority_carry':new})
rng=random.Random(2026111152);count=0
cases=itertools.product([-(1<<24),-(1<<24)+1,-131072,-1,0,1,131071,(1<<24)-1],[-(1<<24),-1,0,1,(1<<24)-1],[-(1<<49),-(1<<49)+1,-(1<<47),-1,0,1,(1<<47)-1,(1<<49)-1])
def check(x,c,z):
 zlo=signed(z,48);ztop=signed((z&((1<<50)-1))>>48,2)
 low=signed(c*(x&131071)+zlo,48);high=c*signed(x>>17,8)+(low>>17)
 zs,cs,ls=int(zlo<0),int(c<0),int(low<0)
 old=ztop+zs+int(not zs and not cs and ls)-int(zs and cs and not ls)
 new=ztop+((zs&ls)|((1-cs)&(zs|ls)))
 def join(k):return (low&131071)|((high&((1<<31)-1))<<17)|((((high>>31)+k)&3)<<48)
 assert join(old)==join(new)==((z+x*c)&((1<<50)-1)),(x,c,z)
for x,c,z in cases:check(x,c,z);count+=1
for _ in range(100000):check(signed(rng.getrandbits(25),25),signed(rng.getrandbits(25),25),signed(rng.getrandbits(50),50));count+=1
rec={'passed_known_integer_proof':True,'known_three_sign_truth_cases':signs,'full50_integer_cases':count,'candidate':'correction=ztop+majority(zlo_sign,low_sign,!coeff_sign), only split_c48 final MAC in R48; registered MAC unchanged.','four_state_status':'NOT_NATIVE_VERIFIED. Standalone sign predicate is not equivalent for every unreachable X combination (Z=X,C=0,L=1: old X,new1). Full MAC must separately preserve X/Z propagation: arithmetic lowP is unknown whenever zlo/coeff/xlo unknown, highP/top then unknown; if only ztop unknown both top2 additions unknown. Do not claim predicate four-state equivalence or weaken old tests. Require dedicated generated full50 frozen-helper X/Z and existing native IIR tests before integration.','new_serial_cycles_target':0,'source_changes':'NONE; mathematical preanalysis only','whole_functional_synth_route':'NOT_RUN'}
(h/'r52_mathematical_preanalysis.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R52_KNOWN_MATH_PREANALYSIS_PASS',count,'FULL_MAC_XZ_NOT_RUN')
