/* Machine-generated using Migen */
module latency_pair(
	input sys_clk,
	input sys_rst,
	input sys_double_clk,
	input dac_2p_clk,
	input [15:0] adc_word,
	input [13:0] csr_adr,
	input csr_we,
	input [7:0] csr_dat_w,
	output [13:0] ref_data,
	output ref_wrt,
	output ref_sel,
	output [13:0] ref_kp,
	output [13:0] cand_data,
	output cand_wrt,
	output cand_sel,
	output [13:0] cand_kp
);

wire [15:0] pair_record0_adc_data_a;
wire [15:0] pair_record0_adc_data_b;
wire pair_record0_adc_cdcs;
wire [1:0] pair_record0_adc_clk;
wire [13:0] pair_record0_dac_data;
wire pair_record0_dac_clk;
wire pair_record0_dac_wrt;
wire pair_record0_dac_sel;
wire pair_record0_dac_rst;
wire signed [13:0] pair_pitayaanalog0_adc_a;
wire signed [13:0] pair_pitayaanalog0_adc_b;
wire signed [13:0] pair_pitayaanalog0_dac_a;
wire signed [13:0] pair_pitayaanalog0_dac_b;
reg [15:0] pair_pitayaanalog0_adca = 16'd0;
reg [15:0] pair_pitayaanalog0_adcb = 16'd0;
reg [13:0] pair_pitayaanalog0_daca = 14'd0;
reg [13:0] pair_pitayaanalog0_dacb = 14'd0;
reg signed [25:0] pair_pipelinedpid_error_s1 = 26'sd0;
reg signed [13:0] pair_pipelinedpid_kp_s1 = 14'sd0;
reg signed [13:0] pair_pipelinedpid_ki_s1 = 14'sd0;
reg signed [13:0] pair_pipelinedpid_kd_s1 = 14'sd0;
reg pair_pipelinedpid_reset_s1 = 1'd0;
reg pair_pipelinedpid_reset_s2 = 1'd0;
reg pair_pipelinedpid_valid_s1 = 1'd0;
reg pair_pipelinedpid_valid_s2 = 1'd0;
wire signed [24:0] pair_pipelinedpid_input;
wire pair_pipelinedpid_running;
wire pair_pipelinedpid_update_en0;
reg [24:0] pair_pipelinedpid_pipelinedpid_setpoint_storage_full = 25'd0;
wire [24:0] pair_pipelinedpid_pipelinedpid_setpoint_storage;
reg pair_pipelinedpid_pipelinedpid_setpoint_re = 1'd0;
wire signed [24:0] pair_pipelinedpid_pipelinedpid_setpoint_signed;
reg signed [25:0] pair_pipelinedpid_pipelinedpid_error;
reg [13:0] pair_pipelinedpid_pipelinedpid_kp_storage_full = 14'd0;
wire [13:0] pair_pipelinedpid_pipelinedpid_kp_storage;
reg pair_pipelinedpid_pipelinedpid_kp_re = 1'd0;
reg signed [38:0] pair_pipelinedpid_pipelinedpid_kp_mult = 39'sd0;
wire signed [24:0] pair_pipelinedpid_pipelinedpid_output_p;
reg [13:0] pair_pipelinedpid_pipelinedpid_ki_storage_full = 14'd0;
wire [13:0] pair_pipelinedpid_pipelinedpid_ki_storage;
reg pair_pipelinedpid_pipelinedpid_ki_re = 1'd0;
reg pair_pipelinedpid_pipelinedpid_reset_storage_full = 1'd0;
wire pair_pipelinedpid_pipelinedpid_reset_storage;
reg pair_pipelinedpid_pipelinedpid_reset_re = 1'd0;
reg signed [39:0] pair_pipelinedpid_pipelinedpid_ki_mult = 40'sd0;
reg signed [42:0] pair_pipelinedpid_pipelinedpid_int_reg = 43'sd0;
wire signed [43:0] pair_pipelinedpid_pipelinedpid_int_sum;
wire signed [24:0] pair_pipelinedpid_pipelinedpid_int_out;
wire pair_pipelinedpid_pipelinedpid0;
wire pair_pipelinedpid_pipelinedpid1;
reg [13:0] pair_pipelinedpid_pipelinedpid_kd_storage_full = 14'd0;
wire [13:0] pair_pipelinedpid_pipelinedpid_kd_storage;
reg pair_pipelinedpid_pipelinedpid_kd_re = 1'd0;
reg signed [40:0] pair_pipelinedpid_pipelinedpid_kd_mult = 41'sd0;
reg signed [33:0] pair_pipelinedpid_pipelinedpid_kd_reg = 34'sd0;
reg signed [33:0] pair_pipelinedpid_pipelinedpid_kd_reg_r = 34'sd0;
reg signed [33:0] pair_pipelinedpid_pipelinedpid_output_d = 34'sd0;
reg signed [83:0] pair_pipelinedpid_pipelinedpid_pid_sum = 84'sd0;
reg signed [24:0] pair_pipelinedpid_pipelinedpid_pid_out;
wire pair_pipelinedpid_update_en1;
reg signed [13:0] pair_limitcsr0_limitcsr0_y = 14'sd0;
reg pair_limitcsr0_limitcsr0_error = 1'd0;
reg pair_limitcsr0_update_en = 1'd1;
reg signed [18:0] pair_limitcsr0_x = 19'sd0;
reg [13:0] pair_limitcsr0_min_storage = 14'd8192;
reg [13:0] pair_limitcsr0_max_storage = 14'd8191;
wire signed [18:0] pair_limitcsr0_limit_x;
reg signed [18:0] pair_limitcsr0_limit_y;
reg signed [18:0] pair_limitcsr0_limit_max = 19'sd0;
reg signed [18:0] pair_limitcsr0_limit_min = 19'sd0;
reg pair_limitcsr0_limit_railed;
wire [13:0] pair_csrbank0_bus_adr;
wire pair_csrbank0_bus_we;
wire [7:0] pair_csrbank0_bus_dat_w;
reg [7:0] pair_csrbank0_bus_dat_r = 8'd0;
wire pair_csrbank0_setpoint3_re;
wire pair_csrbank0_setpoint3_r;
wire pair_csrbank0_setpoint3_w;
wire pair_csrbank0_setpoint2_re;
wire [7:0] pair_csrbank0_setpoint2_r;
wire [7:0] pair_csrbank0_setpoint2_w;
wire pair_csrbank0_setpoint1_re;
wire [7:0] pair_csrbank0_setpoint1_r;
wire [7:0] pair_csrbank0_setpoint1_w;
wire pair_csrbank0_setpoint0_re;
wire [7:0] pair_csrbank0_setpoint0_r;
wire [7:0] pair_csrbank0_setpoint0_w;
wire pair_csrbank0_kp1_re;
wire [5:0] pair_csrbank0_kp1_r;
wire [5:0] pair_csrbank0_kp1_w;
wire pair_csrbank0_kp0_re;
wire [7:0] pair_csrbank0_kp0_r;
wire [7:0] pair_csrbank0_kp0_w;
wire pair_csrbank0_ki1_re;
wire [5:0] pair_csrbank0_ki1_r;
wire [5:0] pair_csrbank0_ki1_w;
wire pair_csrbank0_ki0_re;
wire [7:0] pair_csrbank0_ki0_r;
wire [7:0] pair_csrbank0_ki0_w;
wire pair_csrbank0_reset0_re;
wire pair_csrbank0_reset0_r;
wire pair_csrbank0_reset0_w;
wire pair_csrbank0_kd1_re;
wire [5:0] pair_csrbank0_kd1_r;
wire [5:0] pair_csrbank0_kd1_w;
wire pair_csrbank0_kd0_re;
wire [7:0] pair_csrbank0_kd0_r;
wire [7:0] pair_csrbank0_kd0_w;
wire pair_csrbank0_sel;
wire [15:0] pair_record1_adc_data_a;
wire [15:0] pair_record1_adc_data_b;
wire pair_record1_adc_cdcs;
wire [1:0] pair_record1_adc_clk;
wire [13:0] pair_record1_dac_data;
wire pair_record1_dac_clk;
wire pair_record1_dac_wrt;
wire pair_record1_dac_sel;
wire pair_record1_dac_rst;
wire signed [13:0] pair_pitayaanalog1_adc_a;
wire signed [13:0] pair_pitayaanalog1_adc_b;
wire signed [13:0] pair_pitayaanalog1_dac_a;
wire signed [13:0] pair_pitayaanalog1_dac_b;
reg [15:0] pair_pitayaanalog1_adca = 16'd0;
reg [15:0] pair_pitayaanalog1_adcb = 16'd0;
reg [13:0] pair_pitayaanalog1_daca = 14'd0;
reg [13:0] pair_pitayaanalog1_dacb = 14'd0;
reg signed [25:0] pair_mixeralignedpid_error_s1 = 26'sd0;
reg signed [13:0] pair_mixeralignedpid0 = 14'sd0;
reg signed [13:0] pair_mixeralignedpid1 = 14'sd0;
reg signed [13:0] pair_mixeralignedpid2 = 14'sd0;
reg pair_mixeralignedpid3 = 1'd0;
reg pair_mixeralignedpid4 = 1'd0;
reg pair_mixeralignedpid5 = 1'd0;
reg pair_mixeralignedpid6 = 1'd0;
reg [24:0] pair_mixeralignedpid_setpoint_cohort = 25'd0;
reg pair_mixeralignedpid_running_cohort = 1'd0;
reg [13:0] pair_mixeralignedpid7 = 14'd0;
reg [13:0] pair_mixeralignedpid8 = 14'd0;
reg [13:0] pair_mixeralignedpid9 = 14'd0;
reg pair_mixeralignedpid10 = 1'd0;
reg pair_mixeralignedpid11 = 1'd0;
wire signed [24:0] pair_mixeralignedpid_input;
wire pair_mixeralignedpid_running;
wire pair_mixeralignedpid_update_en0;
reg [24:0] pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full = 25'd0;
wire [24:0] pair_mixeralignedpid_mixeralignedpid_setpoint_storage;
reg pair_mixeralignedpid_mixeralignedpid_setpoint_re = 1'd0;
reg signed [25:0] pair_mixeralignedpid_mixeralignedpid_error;
reg [13:0] pair_mixeralignedpid_mixeralignedpid_kp_storage_full = 14'd0;
wire [13:0] pair_mixeralignedpid_mixeralignedpid_kp_storage;
reg pair_mixeralignedpid_mixeralignedpid_kp_re = 1'd0;
reg signed [38:0] pair_mixeralignedpid_mixeralignedpid_kp_mult = 39'sd0;
wire signed [24:0] pair_mixeralignedpid_mixeralignedpid_output_p;
reg [13:0] pair_mixeralignedpid_mixeralignedpid_ki_storage_full = 14'd0;
wire [13:0] pair_mixeralignedpid_mixeralignedpid_ki_storage;
reg pair_mixeralignedpid_mixeralignedpid_ki_re = 1'd0;
reg pair_mixeralignedpid_mixeralignedpid_reset_storage_full = 1'd0;
wire pair_mixeralignedpid_mixeralignedpid_reset_storage;
reg pair_mixeralignedpid_mixeralignedpid_reset_re = 1'd0;
reg signed [39:0] pair_mixeralignedpid_mixeralignedpid_ki_mult = 40'sd0;
reg signed [42:0] pair_mixeralignedpid_mixeralignedpid_int_reg = 43'sd0;
wire signed [43:0] pair_mixeralignedpid_mixeralignedpid_int_sum;
wire signed [24:0] pair_mixeralignedpid_mixeralignedpid_int_out;
wire pair_mixeralignedpid_mixeralignedpid0;
wire pair_mixeralignedpid_mixeralignedpid1;
reg [13:0] pair_mixeralignedpid_mixeralignedpid_kd_storage_full = 14'd0;
wire [13:0] pair_mixeralignedpid_mixeralignedpid_kd_storage;
reg pair_mixeralignedpid_mixeralignedpid_kd_re = 1'd0;
reg signed [40:0] pair_mixeralignedpid_mixeralignedpid_kd_mult = 41'sd0;
reg signed [33:0] pair_mixeralignedpid_mixeralignedpid_kd_reg = 34'sd0;
reg signed [33:0] pair_mixeralignedpid_mixeralignedpid_kd_reg_r = 34'sd0;
reg signed [33:0] pair_mixeralignedpid_mixeralignedpid_output_d = 34'sd0;
reg signed [83:0] pair_mixeralignedpid_mixeralignedpid_pid_sum = 84'sd0;
reg signed [24:0] pair_mixeralignedpid_mixeralignedpid_pid_out;
wire pair_mixeralignedpid_update_en1;
reg signed [13:0] pair_limitcsr1_limitcsr1_y = 14'sd0;
reg pair_limitcsr1_limitcsr1_error = 1'd0;
reg pair_limitcsr1_update_en = 1'd1;
reg signed [18:0] pair_limitcsr1_x = 19'sd0;
reg [13:0] pair_limitcsr1_min_storage = 14'd8192;
reg [13:0] pair_limitcsr1_max_storage = 14'd8191;
wire signed [18:0] pair_limitcsr1_limit_x;
reg signed [18:0] pair_limitcsr1_limit_y;
reg signed [18:0] pair_limitcsr1_limit_max = 19'sd0;
reg signed [18:0] pair_limitcsr1_limit_min = 19'sd0;
reg pair_limitcsr1_limit_railed;
wire [13:0] pair_csrbank1_bus_adr;
wire pair_csrbank1_bus_we;
wire [7:0] pair_csrbank1_bus_dat_w;
reg [7:0] pair_csrbank1_bus_dat_r = 8'd0;
wire pair_csrbank1_setpoint3_re;
wire pair_csrbank1_setpoint3_r;
wire pair_csrbank1_setpoint3_w;
wire pair_csrbank1_setpoint2_re;
wire [7:0] pair_csrbank1_setpoint2_r;
wire [7:0] pair_csrbank1_setpoint2_w;
wire pair_csrbank1_setpoint1_re;
wire [7:0] pair_csrbank1_setpoint1_r;
wire [7:0] pair_csrbank1_setpoint1_w;
wire pair_csrbank1_setpoint0_re;
wire [7:0] pair_csrbank1_setpoint0_r;
wire [7:0] pair_csrbank1_setpoint0_w;
wire pair_csrbank1_kp1_re;
wire [5:0] pair_csrbank1_kp1_r;
wire [5:0] pair_csrbank1_kp1_w;
wire pair_csrbank1_kp0_re;
wire [7:0] pair_csrbank1_kp0_r;
wire [7:0] pair_csrbank1_kp0_w;
wire pair_csrbank1_ki1_re;
wire [5:0] pair_csrbank1_ki1_r;
wire [5:0] pair_csrbank1_ki1_w;
wire pair_csrbank1_ki0_re;
wire [7:0] pair_csrbank1_ki0_r;
wire [7:0] pair_csrbank1_ki0_w;
wire pair_csrbank1_reset0_re;
wire pair_csrbank1_reset0_r;
wire pair_csrbank1_reset0_w;
wire pair_csrbank1_kd1_re;
wire [5:0] pair_csrbank1_kd1_r;
wire [5:0] pair_csrbank1_kd1_w;
wire pair_csrbank1_kd0_re;
wire [7:0] pair_csrbank1_kd0_r;
wire [7:0] pair_csrbank1_kd0_w;
wire pair_csrbank1_sel;
wire signed [13:0] pair_direct_adc;
wire signed [24:0] pair_mixed_error;
wire pair_pid_only;
reg pair_limit_accept_en = 1'd1;
reg pair_limit_execute_en = 1'd0;
wire signed [24:0] pair_output;
reg signed [13:0] pair_adc_cohort = 14'sd0;
reg pair_mode_cohort = 1'd0;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign pair_record0_adc_data_a = adc_word;
assign pair_record0_adc_data_b = 15'd32764;
assign pair_pipelinedpid_running = 1'd1;
assign pair_pipelinedpid_update_en1 = 1'd1;
assign pair_pitayaanalog0_dac_a = pair_limitcsr0_limitcsr0_y;
assign pair_pitayaanalog0_dac_b = 1'd0;
assign pair_csrbank0_bus_adr = csr_adr;
assign pair_csrbank0_bus_we = csr_we;
assign pair_csrbank0_bus_dat_w = csr_dat_w;
assign pair_pipelinedpid_input = (pair_pitayaanalog0_adc_a <<< 4'd11);
assign ref_data = pair_record0_dac_data;
assign ref_wrt = pair_record0_dac_wrt;
assign ref_sel = pair_record0_dac_sel;
assign ref_kp = pair_pipelinedpid_pipelinedpid_kp_storage;
assign pair_record1_adc_data_a = adc_word;
assign pair_record1_adc_data_b = 15'd32764;
assign pair_mixeralignedpid_running = 1'd1;
assign pair_mixeralignedpid_update_en1 = 1'd1;
assign pair_pitayaanalog1_dac_a = pair_limitcsr1_limitcsr1_y;
assign pair_pitayaanalog1_dac_b = 1'd0;
assign pair_csrbank1_bus_adr = csr_adr;
assign pair_csrbank1_bus_we = csr_we;
assign pair_csrbank1_bus_dat_w = csr_dat_w;
assign pair_direct_adc = pair_pitayaanalog1_adc_a;
assign pair_pid_only = 1'd1;
assign pair_mixed_error = 1'd0;
assign pair_mixeralignedpid_input = pair_output;
assign cand_data = pair_record1_dac_data;
assign cand_wrt = pair_record1_dac_wrt;
assign cand_sel = pair_record1_dac_sel;
assign cand_kp = pair_mixeralignedpid_mixeralignedpid_kp_storage;
assign pair_record0_adc_cdcs = 1'd1;
assign pair_record0_adc_clk = 2'd2;
assign pair_pitayaanalog0_adc_a = {pair_pitayaanalog0_adca[15], (~pair_pitayaanalog0_adca[14:2])};
assign pair_pitayaanalog0_adc_b = {pair_pitayaanalog0_adcb[15], (~pair_pitayaanalog0_adcb[14:2])};
assign pair_record0_dac_rst = sys_rst;
assign pair_pipelinedpid_pipelinedpid_setpoint_signed = pair_pipelinedpid_pipelinedpid_setpoint_storage;

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	pair_pipelinedpid_pipelinedpid_error <= 26'sd0;
	if (pair_pipelinedpid_running) begin
		pair_pipelinedpid_pipelinedpid_error <= (pair_pipelinedpid_input - $signed({1'd0, pair_pipelinedpid_pipelinedpid_setpoint_storage}));
	end else begin
		pair_pipelinedpid_pipelinedpid_error <= 1'd0;
	end
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end
assign pair_pipelinedpid_pipelinedpid_output_p = (pair_pipelinedpid_pipelinedpid_kp_mult >>> 4'd12);
assign pair_pipelinedpid_pipelinedpid_int_sum = (pair_pipelinedpid_pipelinedpid_ki_mult + pair_pipelinedpid_pipelinedpid_int_reg);
assign pair_pipelinedpid_pipelinedpid_int_out = (pair_pipelinedpid_pipelinedpid_int_reg >>> 5'd18);
assign pair_pipelinedpid_pipelinedpid0 = ((~pair_pipelinedpid_pipelinedpid_int_sum[43]) & (pair_pipelinedpid_pipelinedpid_int_sum[42] | ((pair_pipelinedpid_pipelinedpid_int_sum[41:18] == $signed({1'd0, 24'd16777215})) & (pair_pipelinedpid_pipelinedpid_int_sum[17:0] != $signed({1'd0, 1'd0})))));
assign pair_pipelinedpid_pipelinedpid1 = (pair_pipelinedpid_pipelinedpid_int_sum[43] & ((~pair_pipelinedpid_pipelinedpid_int_sum[42]) | ((pair_pipelinedpid_pipelinedpid_int_sum[41:18] == $signed({1'd0, 1'd0})) & (pair_pipelinedpid_pipelinedpid_int_sum[17:0] != $signed({1'd0, 18'd262143})))));

// synthesis translate_off
reg dummy_d_1;
// synthesis translate_on
always @(*) begin
	pair_pipelinedpid_pipelinedpid_pid_out <= 25'sd0;
	if ((pair_pipelinedpid_pipelinedpid_pid_sum > $signed({1'd0, 24'd16777215}))) begin
		pair_pipelinedpid_pipelinedpid_pid_out <= 24'd16777215;
	end else begin
		if ((pair_pipelinedpid_pipelinedpid_pid_sum < 25'sd16777216)) begin
			pair_pipelinedpid_pipelinedpid_pid_out <= 25'sd16777216;
		end else begin
			pair_pipelinedpid_pipelinedpid_pid_out <= pair_pipelinedpid_pipelinedpid_pid_sum[24:0];
		end
	end
// synthesis translate_off
	dummy_d_1 <= dummy_s;
// synthesis translate_on
end
assign pair_pipelinedpid_update_en0 = pair_pipelinedpid_valid_s2;
assign pair_limitcsr0_limit_x = pair_limitcsr0_x;

// synthesis translate_off
reg dummy_d_2;
// synthesis translate_on
always @(*) begin
	pair_limitcsr0_limit_y <= 19'sd0;
	pair_limitcsr0_limit_railed <= 1'd0;
	if ((pair_limitcsr0_limit_x >= pair_limitcsr0_limit_max)) begin
		pair_limitcsr0_limit_y <= pair_limitcsr0_limit_max;
		pair_limitcsr0_limit_railed <= 1'd1;
	end else begin
		if ((pair_limitcsr0_limit_x <= pair_limitcsr0_limit_min)) begin
			pair_limitcsr0_limit_y <= pair_limitcsr0_limit_min;
			pair_limitcsr0_limit_railed <= 1'd1;
		end else begin
			pair_limitcsr0_limit_y <= pair_limitcsr0_limit_x;
			pair_limitcsr0_limit_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_2 <= dummy_s;
// synthesis translate_on
end
assign pair_csrbank0_sel = (pair_csrbank0_bus_adr[13:9] == 1'd0);
assign pair_csrbank0_setpoint3_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_setpoint3_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 1'd0));
assign pair_csrbank0_setpoint2_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_setpoint2_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 1'd1));
assign pair_csrbank0_setpoint1_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_setpoint1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 2'd2));
assign pair_csrbank0_setpoint0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_setpoint0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 2'd3));
assign pair_csrbank0_kp1_r = pair_csrbank0_bus_dat_w[5:0];
assign pair_csrbank0_kp1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 3'd4));
assign pair_csrbank0_kp0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_kp0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 3'd5));
assign pair_csrbank0_ki1_r = pair_csrbank0_bus_dat_w[5:0];
assign pair_csrbank0_ki1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 3'd6));
assign pair_csrbank0_ki0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_ki0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 3'd7));
assign pair_csrbank0_reset0_r = pair_csrbank0_bus_dat_w[0];
assign pair_csrbank0_reset0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 4'd8));
assign pair_csrbank0_kd1_r = pair_csrbank0_bus_dat_w[5:0];
assign pair_csrbank0_kd1_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 4'd9));
assign pair_csrbank0_kd0_r = pair_csrbank0_bus_dat_w[7:0];
assign pair_csrbank0_kd0_re = ((pair_csrbank0_sel & pair_csrbank0_bus_we) & (pair_csrbank0_bus_adr[3:0] == 4'd10));
assign pair_pipelinedpid_pipelinedpid_setpoint_storage = pair_pipelinedpid_pipelinedpid_setpoint_storage_full[24:0];
assign pair_csrbank0_setpoint3_w = pair_pipelinedpid_pipelinedpid_setpoint_storage_full[24];
assign pair_csrbank0_setpoint2_w = pair_pipelinedpid_pipelinedpid_setpoint_storage_full[23:16];
assign pair_csrbank0_setpoint1_w = pair_pipelinedpid_pipelinedpid_setpoint_storage_full[15:8];
assign pair_csrbank0_setpoint0_w = pair_pipelinedpid_pipelinedpid_setpoint_storage_full[7:0];
assign pair_pipelinedpid_pipelinedpid_kp_storage = pair_pipelinedpid_pipelinedpid_kp_storage_full[13:0];
assign pair_csrbank0_kp1_w = pair_pipelinedpid_pipelinedpid_kp_storage_full[13:8];
assign pair_csrbank0_kp0_w = pair_pipelinedpid_pipelinedpid_kp_storage_full[7:0];
assign pair_pipelinedpid_pipelinedpid_ki_storage = pair_pipelinedpid_pipelinedpid_ki_storage_full[13:0];
assign pair_csrbank0_ki1_w = pair_pipelinedpid_pipelinedpid_ki_storage_full[13:8];
assign pair_csrbank0_ki0_w = pair_pipelinedpid_pipelinedpid_ki_storage_full[7:0];
assign pair_pipelinedpid_pipelinedpid_reset_storage = pair_pipelinedpid_pipelinedpid_reset_storage_full;
assign pair_csrbank0_reset0_w = pair_pipelinedpid_pipelinedpid_reset_storage_full;
assign pair_pipelinedpid_pipelinedpid_kd_storage = pair_pipelinedpid_pipelinedpid_kd_storage_full[13:0];
assign pair_csrbank0_kd1_w = pair_pipelinedpid_pipelinedpid_kd_storage_full[13:8];
assign pair_csrbank0_kd0_w = pair_pipelinedpid_pipelinedpid_kd_storage_full[7:0];
assign pair_record1_adc_cdcs = 1'd1;
assign pair_record1_adc_clk = 2'd2;
assign pair_pitayaanalog1_adc_a = {pair_pitayaanalog1_adca[15], (~pair_pitayaanalog1_adca[14:2])};
assign pair_pitayaanalog1_adc_b = {pair_pitayaanalog1_adcb[15], (~pair_pitayaanalog1_adcb[14:2])};
assign pair_record1_dac_rst = sys_rst;

// synthesis translate_off
reg dummy_d_3;
// synthesis translate_on
always @(*) begin
	pair_mixeralignedpid_mixeralignedpid_error <= 26'sd0;
	if (pair_mixeralignedpid_running_cohort) begin
		pair_mixeralignedpid_mixeralignedpid_error <= (pair_mixeralignedpid_input - $signed({1'd0, pair_mixeralignedpid_setpoint_cohort}));
	end else begin
		pair_mixeralignedpid_mixeralignedpid_error <= 1'd0;
	end
// synthesis translate_off
	dummy_d_3 <= dummy_s;
// synthesis translate_on
end
assign pair_mixeralignedpid_mixeralignedpid_output_p = (pair_mixeralignedpid_mixeralignedpid_kp_mult >>> 4'd12);
assign pair_mixeralignedpid_mixeralignedpid_int_sum = (pair_mixeralignedpid_mixeralignedpid_ki_mult + pair_mixeralignedpid_mixeralignedpid_int_reg);
assign pair_mixeralignedpid_mixeralignedpid_int_out = (pair_mixeralignedpid_mixeralignedpid_int_reg >>> 5'd18);
assign pair_mixeralignedpid_mixeralignedpid0 = ((~pair_mixeralignedpid_mixeralignedpid_int_sum[43]) & (pair_mixeralignedpid_mixeralignedpid_int_sum[42] | ((pair_mixeralignedpid_mixeralignedpid_int_sum[41:18] == $signed({1'd0, 24'd16777215})) & (pair_mixeralignedpid_mixeralignedpid_int_sum[17:0] != $signed({1'd0, 1'd0})))));
assign pair_mixeralignedpid_mixeralignedpid1 = (pair_mixeralignedpid_mixeralignedpid_int_sum[43] & ((~pair_mixeralignedpid_mixeralignedpid_int_sum[42]) | ((pair_mixeralignedpid_mixeralignedpid_int_sum[41:18] == $signed({1'd0, 1'd0})) & (pair_mixeralignedpid_mixeralignedpid_int_sum[17:0] != $signed({1'd0, 18'd262143})))));

// synthesis translate_off
reg dummy_d_4;
// synthesis translate_on
always @(*) begin
	pair_mixeralignedpid_mixeralignedpid_pid_out <= 25'sd0;
	if ((pair_mixeralignedpid_mixeralignedpid_pid_sum > $signed({1'd0, 24'd16777215}))) begin
		pair_mixeralignedpid_mixeralignedpid_pid_out <= 24'd16777215;
	end else begin
		if ((pair_mixeralignedpid_mixeralignedpid_pid_sum < 25'sd16777216)) begin
			pair_mixeralignedpid_mixeralignedpid_pid_out <= 25'sd16777216;
		end else begin
			pair_mixeralignedpid_mixeralignedpid_pid_out <= pair_mixeralignedpid_mixeralignedpid_pid_sum[24:0];
		end
	end
// synthesis translate_off
	dummy_d_4 <= dummy_s;
// synthesis translate_on
end
assign pair_mixeralignedpid_update_en0 = pair_mixeralignedpid6;
assign pair_limitcsr1_limit_x = pair_limitcsr1_x;

// synthesis translate_off
reg dummy_d_5;
// synthesis translate_on
always @(*) begin
	pair_limitcsr1_limit_y <= 19'sd0;
	pair_limitcsr1_limit_railed <= 1'd0;
	if ((pair_limitcsr1_limit_x >= pair_limitcsr1_limit_max)) begin
		pair_limitcsr1_limit_y <= pair_limitcsr1_limit_max;
		pair_limitcsr1_limit_railed <= 1'd1;
	end else begin
		if ((pair_limitcsr1_limit_x <= pair_limitcsr1_limit_min)) begin
			pair_limitcsr1_limit_y <= pair_limitcsr1_limit_min;
			pair_limitcsr1_limit_railed <= 1'd1;
		end else begin
			pair_limitcsr1_limit_y <= pair_limitcsr1_limit_x;
			pair_limitcsr1_limit_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_5 <= dummy_s;
// synthesis translate_on
end
assign pair_csrbank1_sel = (pair_csrbank1_bus_adr[13:9] == 1'd0);
assign pair_csrbank1_setpoint3_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_setpoint3_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 1'd0));
assign pair_csrbank1_setpoint2_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_setpoint2_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 1'd1));
assign pair_csrbank1_setpoint1_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_setpoint1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 2'd2));
assign pair_csrbank1_setpoint0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_setpoint0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 2'd3));
assign pair_csrbank1_kp1_r = pair_csrbank1_bus_dat_w[5:0];
assign pair_csrbank1_kp1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 3'd4));
assign pair_csrbank1_kp0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_kp0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 3'd5));
assign pair_csrbank1_ki1_r = pair_csrbank1_bus_dat_w[5:0];
assign pair_csrbank1_ki1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 3'd6));
assign pair_csrbank1_ki0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_ki0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 3'd7));
assign pair_csrbank1_reset0_r = pair_csrbank1_bus_dat_w[0];
assign pair_csrbank1_reset0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 4'd8));
assign pair_csrbank1_kd1_r = pair_csrbank1_bus_dat_w[5:0];
assign pair_csrbank1_kd1_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 4'd9));
assign pair_csrbank1_kd0_r = pair_csrbank1_bus_dat_w[7:0];
assign pair_csrbank1_kd0_re = ((pair_csrbank1_sel & pair_csrbank1_bus_we) & (pair_csrbank1_bus_adr[3:0] == 4'd10));
assign pair_mixeralignedpid_mixeralignedpid_setpoint_storage = pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full[24:0];
assign pair_csrbank1_setpoint3_w = pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full[24];
assign pair_csrbank1_setpoint2_w = pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full[23:16];
assign pair_csrbank1_setpoint1_w = pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full[15:8];
assign pair_csrbank1_setpoint0_w = pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full[7:0];
assign pair_mixeralignedpid_mixeralignedpid_kp_storage = pair_mixeralignedpid_mixeralignedpid_kp_storage_full[13:0];
assign pair_csrbank1_kp1_w = pair_mixeralignedpid_mixeralignedpid_kp_storage_full[13:8];
assign pair_csrbank1_kp0_w = pair_mixeralignedpid_mixeralignedpid_kp_storage_full[7:0];
assign pair_mixeralignedpid_mixeralignedpid_ki_storage = pair_mixeralignedpid_mixeralignedpid_ki_storage_full[13:0];
assign pair_csrbank1_ki1_w = pair_mixeralignedpid_mixeralignedpid_ki_storage_full[13:8];
assign pair_csrbank1_ki0_w = pair_mixeralignedpid_mixeralignedpid_ki_storage_full[7:0];
assign pair_mixeralignedpid_mixeralignedpid_reset_storage = pair_mixeralignedpid_mixeralignedpid_reset_storage_full;
assign pair_csrbank1_reset0_w = pair_mixeralignedpid_mixeralignedpid_reset_storage_full;
assign pair_mixeralignedpid_mixeralignedpid_kd_storage = pair_mixeralignedpid_mixeralignedpid_kd_storage_full[13:0];
assign pair_csrbank1_kd1_w = pair_mixeralignedpid_mixeralignedpid_kd_storage_full[13:8];
assign pair_csrbank1_kd0_w = pair_mixeralignedpid_mixeralignedpid_kd_storage_full[7:0];
assign pair_output = (pair_mode_cohort ? (pair_adc_cohort <<< 4'd11) : pair_mixed_error);

always @(posedge sys_clk) begin
	pair_limitcsr0_x <= (pair_pipelinedpid_pipelinedpid_pid_out >>> 4'd11);
	pair_limitcsr1_x <= (pair_mixeralignedpid_mixeralignedpid_pid_out >>> 4'd11);
	pair_pitayaanalog0_adca <= pair_record0_adc_data_a;
	pair_pitayaanalog0_adcb <= pair_record0_adc_data_b;
	pair_pitayaanalog0_daca <= {pair_pitayaanalog0_dac_a[13], (~pair_pitayaanalog0_dac_a[12:0])};
	pair_pitayaanalog0_dacb <= {pair_pitayaanalog0_dac_b[13], (~pair_pitayaanalog0_dac_b[12:0])};
	pair_pipelinedpid_pipelinedpid_kp_mult <= (pair_pipelinedpid_error_s1 * pair_pipelinedpid_kp_s1);
	pair_pipelinedpid_pipelinedpid_ki_mult <= ((pair_pipelinedpid_error_s1 * pair_pipelinedpid_ki_s1) >>> 3'd4);
	if (pair_pipelinedpid_update_en0) begin
		if (pair_pipelinedpid_reset_s2) begin
			pair_pipelinedpid_pipelinedpid_int_reg <= 1'd0;
		end else begin
			if (pair_pipelinedpid_pipelinedpid0) begin
				pair_pipelinedpid_pipelinedpid_int_reg <= 42'd4398046248960;
			end else begin
				if (pair_pipelinedpid_pipelinedpid1) begin
					pair_pipelinedpid_pipelinedpid_int_reg <= 43'sd4398046773247;
				end else begin
					pair_pipelinedpid_pipelinedpid_int_reg <= pair_pipelinedpid_pipelinedpid_int_sum;
				end
			end
		end
	end
	pair_pipelinedpid_pipelinedpid_kd_mult <= (pair_pipelinedpid_error_s1 * pair_pipelinedpid_kd_s1);
	if (pair_pipelinedpid_update_en0) begin
		pair_pipelinedpid_pipelinedpid_kd_reg <= (pair_pipelinedpid_pipelinedpid_kd_mult >>> 4'd8);
		pair_pipelinedpid_pipelinedpid_kd_reg_r <= pair_pipelinedpid_pipelinedpid_kd_reg;
		pair_pipelinedpid_pipelinedpid_output_d <= (pair_pipelinedpid_pipelinedpid_kd_reg - pair_pipelinedpid_pipelinedpid_kd_reg_r);
	end
	if (pair_pipelinedpid_update_en0) begin
		pair_pipelinedpid_pipelinedpid_pid_sum <= ((pair_pipelinedpid_pipelinedpid_output_p + pair_pipelinedpid_pipelinedpid_int_out) + pair_pipelinedpid_pipelinedpid_output_d);
	end
	pair_pipelinedpid_valid_s1 <= pair_pipelinedpid_update_en1;
	pair_pipelinedpid_valid_s2 <= pair_pipelinedpid_valid_s1;
	pair_pipelinedpid_error_s1 <= pair_pipelinedpid_pipelinedpid_error;
	pair_pipelinedpid_kp_s1 <= pair_pipelinedpid_pipelinedpid_kp_storage;
	pair_pipelinedpid_ki_s1 <= pair_pipelinedpid_pipelinedpid_ki_storage;
	pair_pipelinedpid_kd_s1 <= pair_pipelinedpid_pipelinedpid_kd_storage;
	pair_pipelinedpid_reset_s1 <= pair_pipelinedpid_pipelinedpid_reset_storage;
	pair_pipelinedpid_reset_s2 <= pair_pipelinedpid_reset_s1;
	if (pair_limitcsr0_update_en) begin
		pair_limitcsr0_limit_min <= {{5{pair_limitcsr0_min_storage[13]}}, pair_limitcsr0_min_storage};
		pair_limitcsr0_limit_max <= {{5{pair_limitcsr0_max_storage[13]}}, pair_limitcsr0_max_storage};
		pair_limitcsr0_limitcsr0_y <= pair_limitcsr0_limit_y;
		pair_limitcsr0_limitcsr0_error <= pair_limitcsr0_limit_railed;
	end
	pair_csrbank0_bus_dat_r <= 1'd0;
	if (pair_csrbank0_sel) begin
		case (pair_csrbank0_bus_adr[3:0])
			1'd0: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_setpoint3_w;
			end
			1'd1: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_setpoint2_w;
			end
			2'd2: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_setpoint1_w;
			end
			2'd3: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_setpoint0_w;
			end
			3'd4: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_kp1_w;
			end
			3'd5: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_kp0_w;
			end
			3'd6: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_ki1_w;
			end
			3'd7: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_ki0_w;
			end
			4'd8: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_reset0_w;
			end
			4'd9: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_kd1_w;
			end
			4'd10: begin
				pair_csrbank0_bus_dat_r <= pair_csrbank0_kd0_w;
			end
		endcase
	end
	if (pair_csrbank0_setpoint3_re) begin
		pair_pipelinedpid_pipelinedpid_setpoint_storage_full[24] <= pair_csrbank0_setpoint3_r;
	end
	if (pair_csrbank0_setpoint2_re) begin
		pair_pipelinedpid_pipelinedpid_setpoint_storage_full[23:16] <= pair_csrbank0_setpoint2_r;
	end
	if (pair_csrbank0_setpoint1_re) begin
		pair_pipelinedpid_pipelinedpid_setpoint_storage_full[15:8] <= pair_csrbank0_setpoint1_r;
	end
	if (pair_csrbank0_setpoint0_re) begin
		pair_pipelinedpid_pipelinedpid_setpoint_storage_full[7:0] <= pair_csrbank0_setpoint0_r;
	end
	pair_pipelinedpid_pipelinedpid_setpoint_re <= pair_csrbank0_setpoint0_re;
	if (pair_csrbank0_kp1_re) begin
		pair_pipelinedpid_pipelinedpid_kp_storage_full[13:8] <= pair_csrbank0_kp1_r;
	end
	if (pair_csrbank0_kp0_re) begin
		pair_pipelinedpid_pipelinedpid_kp_storage_full[7:0] <= pair_csrbank0_kp0_r;
	end
	pair_pipelinedpid_pipelinedpid_kp_re <= pair_csrbank0_kp0_re;
	if (pair_csrbank0_ki1_re) begin
		pair_pipelinedpid_pipelinedpid_ki_storage_full[13:8] <= pair_csrbank0_ki1_r;
	end
	if (pair_csrbank0_ki0_re) begin
		pair_pipelinedpid_pipelinedpid_ki_storage_full[7:0] <= pair_csrbank0_ki0_r;
	end
	pair_pipelinedpid_pipelinedpid_ki_re <= pair_csrbank0_ki0_re;
	if (pair_csrbank0_reset0_re) begin
		pair_pipelinedpid_pipelinedpid_reset_storage_full <= pair_csrbank0_reset0_r;
	end
	pair_pipelinedpid_pipelinedpid_reset_re <= pair_csrbank0_reset0_re;
	if (pair_csrbank0_kd1_re) begin
		pair_pipelinedpid_pipelinedpid_kd_storage_full[13:8] <= pair_csrbank0_kd1_r;
	end
	if (pair_csrbank0_kd0_re) begin
		pair_pipelinedpid_pipelinedpid_kd_storage_full[7:0] <= pair_csrbank0_kd0_r;
	end
	pair_pipelinedpid_pipelinedpid_kd_re <= pair_csrbank0_kd0_re;
	pair_pitayaanalog1_adca <= pair_record1_adc_data_a;
	pair_pitayaanalog1_adcb <= pair_record1_adc_data_b;
	pair_pitayaanalog1_daca <= {pair_pitayaanalog1_dac_a[13], (~pair_pitayaanalog1_dac_a[12:0])};
	pair_pitayaanalog1_dacb <= {pair_pitayaanalog1_dac_b[13], (~pair_pitayaanalog1_dac_b[12:0])};
	pair_mixeralignedpid_mixeralignedpid_kp_mult <= (pair_mixeralignedpid_error_s1 * pair_mixeralignedpid0);
	pair_mixeralignedpid_mixeralignedpid_ki_mult <= ((pair_mixeralignedpid_error_s1 * pair_mixeralignedpid1) >>> 3'd4);
	if (pair_mixeralignedpid_update_en0) begin
		if (pair_mixeralignedpid4) begin
			pair_mixeralignedpid_mixeralignedpid_int_reg <= 1'd0;
		end else begin
			if (pair_mixeralignedpid_mixeralignedpid0) begin
				pair_mixeralignedpid_mixeralignedpid_int_reg <= 42'd4398046248960;
			end else begin
				if (pair_mixeralignedpid_mixeralignedpid1) begin
					pair_mixeralignedpid_mixeralignedpid_int_reg <= 43'sd4398046773247;
				end else begin
					pair_mixeralignedpid_mixeralignedpid_int_reg <= pair_mixeralignedpid_mixeralignedpid_int_sum;
				end
			end
		end
	end
	pair_mixeralignedpid_mixeralignedpid_kd_mult <= (pair_mixeralignedpid_error_s1 * pair_mixeralignedpid2);
	if (pair_mixeralignedpid_update_en0) begin
		pair_mixeralignedpid_mixeralignedpid_kd_reg <= (pair_mixeralignedpid_mixeralignedpid_kd_mult >>> 4'd8);
		pair_mixeralignedpid_mixeralignedpid_kd_reg_r <= pair_mixeralignedpid_mixeralignedpid_kd_reg;
		pair_mixeralignedpid_mixeralignedpid_output_d <= (pair_mixeralignedpid_mixeralignedpid_kd_reg - pair_mixeralignedpid_mixeralignedpid_kd_reg_r);
	end
	if (pair_mixeralignedpid_update_en0) begin
		pair_mixeralignedpid_mixeralignedpid_pid_sum <= ((pair_mixeralignedpid_mixeralignedpid_output_p + pair_mixeralignedpid_mixeralignedpid_int_out) + pair_mixeralignedpid_mixeralignedpid_output_d);
	end
	pair_mixeralignedpid_setpoint_cohort <= pair_mixeralignedpid_mixeralignedpid_setpoint_storage;
	pair_mixeralignedpid_running_cohort <= pair_mixeralignedpid_running;
	pair_mixeralignedpid7 <= pair_mixeralignedpid_mixeralignedpid_kp_storage;
	pair_mixeralignedpid8 <= pair_mixeralignedpid_mixeralignedpid_ki_storage;
	pair_mixeralignedpid9 <= pair_mixeralignedpid_mixeralignedpid_kd_storage;
	pair_mixeralignedpid10 <= pair_mixeralignedpid_mixeralignedpid_reset_storage;
	pair_mixeralignedpid11 <= pair_mixeralignedpid_update_en1;
	pair_mixeralignedpid5 <= pair_mixeralignedpid11;
	pair_mixeralignedpid6 <= pair_mixeralignedpid5;
	pair_mixeralignedpid_error_s1 <= pair_mixeralignedpid_mixeralignedpid_error;
	pair_mixeralignedpid0 <= pair_mixeralignedpid7;
	pair_mixeralignedpid1 <= pair_mixeralignedpid8;
	pair_mixeralignedpid2 <= pair_mixeralignedpid9;
	pair_mixeralignedpid3 <= pair_mixeralignedpid10;
	pair_mixeralignedpid4 <= pair_mixeralignedpid3;
	if (pair_limitcsr1_update_en) begin
		pair_limitcsr1_limit_min <= {{5{pair_limitcsr1_min_storage[13]}}, pair_limitcsr1_min_storage};
		pair_limitcsr1_limit_max <= {{5{pair_limitcsr1_max_storage[13]}}, pair_limitcsr1_max_storage};
		pair_limitcsr1_limitcsr1_y <= pair_limitcsr1_limit_y;
		pair_limitcsr1_limitcsr1_error <= pair_limitcsr1_limit_railed;
	end
	pair_csrbank1_bus_dat_r <= 1'd0;
	if (pair_csrbank1_sel) begin
		case (pair_csrbank1_bus_adr[3:0])
			1'd0: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_setpoint3_w;
			end
			1'd1: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_setpoint2_w;
			end
			2'd2: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_setpoint1_w;
			end
			2'd3: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_setpoint0_w;
			end
			3'd4: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_kp1_w;
			end
			3'd5: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_kp0_w;
			end
			3'd6: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_ki1_w;
			end
			3'd7: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_ki0_w;
			end
			4'd8: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_reset0_w;
			end
			4'd9: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_kd1_w;
			end
			4'd10: begin
				pair_csrbank1_bus_dat_r <= pair_csrbank1_kd0_w;
			end
		endcase
	end
	if (pair_csrbank1_setpoint3_re) begin
		pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full[24] <= pair_csrbank1_setpoint3_r;
	end
	if (pair_csrbank1_setpoint2_re) begin
		pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full[23:16] <= pair_csrbank1_setpoint2_r;
	end
	if (pair_csrbank1_setpoint1_re) begin
		pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full[15:8] <= pair_csrbank1_setpoint1_r;
	end
	if (pair_csrbank1_setpoint0_re) begin
		pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full[7:0] <= pair_csrbank1_setpoint0_r;
	end
	pair_mixeralignedpid_mixeralignedpid_setpoint_re <= pair_csrbank1_setpoint0_re;
	if (pair_csrbank1_kp1_re) begin
		pair_mixeralignedpid_mixeralignedpid_kp_storage_full[13:8] <= pair_csrbank1_kp1_r;
	end
	if (pair_csrbank1_kp0_re) begin
		pair_mixeralignedpid_mixeralignedpid_kp_storage_full[7:0] <= pair_csrbank1_kp0_r;
	end
	pair_mixeralignedpid_mixeralignedpid_kp_re <= pair_csrbank1_kp0_re;
	if (pair_csrbank1_ki1_re) begin
		pair_mixeralignedpid_mixeralignedpid_ki_storage_full[13:8] <= pair_csrbank1_ki1_r;
	end
	if (pair_csrbank1_ki0_re) begin
		pair_mixeralignedpid_mixeralignedpid_ki_storage_full[7:0] <= pair_csrbank1_ki0_r;
	end
	pair_mixeralignedpid_mixeralignedpid_ki_re <= pair_csrbank1_ki0_re;
	if (pair_csrbank1_reset0_re) begin
		pair_mixeralignedpid_mixeralignedpid_reset_storage_full <= pair_csrbank1_reset0_r;
	end
	pair_mixeralignedpid_mixeralignedpid_reset_re <= pair_csrbank1_reset0_re;
	if (pair_csrbank1_kd1_re) begin
		pair_mixeralignedpid_mixeralignedpid_kd_storage_full[13:8] <= pair_csrbank1_kd1_r;
	end
	if (pair_csrbank1_kd0_re) begin
		pair_mixeralignedpid_mixeralignedpid_kd_storage_full[7:0] <= pair_csrbank1_kd0_r;
	end
	pair_mixeralignedpid_mixeralignedpid_kd_re <= pair_csrbank1_kd0_re;
	pair_adc_cohort <= pair_direct_adc;
	pair_mode_cohort <= pair_pid_only;
	pair_limit_execute_en <= pair_limit_accept_en;
	if (sys_rst) begin
		pair_pitayaanalog0_adca <= 16'd0;
		pair_pitayaanalog0_adcb <= 16'd0;
		pair_pitayaanalog0_daca <= 14'd0;
		pair_pitayaanalog0_dacb <= 14'd0;
		pair_pipelinedpid_error_s1 <= 26'sd0;
		pair_pipelinedpid_kp_s1 <= 14'sd0;
		pair_pipelinedpid_ki_s1 <= 14'sd0;
		pair_pipelinedpid_kd_s1 <= 14'sd0;
		pair_pipelinedpid_reset_s1 <= 1'd0;
		pair_pipelinedpid_reset_s2 <= 1'd0;
		pair_pipelinedpid_valid_s1 <= 1'd0;
		pair_pipelinedpid_valid_s2 <= 1'd0;
		pair_pipelinedpid_pipelinedpid_setpoint_storage_full <= 25'd0;
		pair_pipelinedpid_pipelinedpid_setpoint_re <= 1'd0;
		pair_pipelinedpid_pipelinedpid_kp_storage_full <= 14'd0;
		pair_pipelinedpid_pipelinedpid_kp_re <= 1'd0;
		pair_pipelinedpid_pipelinedpid_kp_mult <= 39'sd0;
		pair_pipelinedpid_pipelinedpid_ki_storage_full <= 14'd0;
		pair_pipelinedpid_pipelinedpid_ki_re <= 1'd0;
		pair_pipelinedpid_pipelinedpid_reset_storage_full <= 1'd0;
		pair_pipelinedpid_pipelinedpid_reset_re <= 1'd0;
		pair_pipelinedpid_pipelinedpid_ki_mult <= 40'sd0;
		pair_pipelinedpid_pipelinedpid_int_reg <= 43'sd0;
		pair_pipelinedpid_pipelinedpid_kd_storage_full <= 14'd0;
		pair_pipelinedpid_pipelinedpid_kd_re <= 1'd0;
		pair_pipelinedpid_pipelinedpid_kd_mult <= 41'sd0;
		pair_pipelinedpid_pipelinedpid_kd_reg <= 34'sd0;
		pair_pipelinedpid_pipelinedpid_kd_reg_r <= 34'sd0;
		pair_pipelinedpid_pipelinedpid_output_d <= 34'sd0;
		pair_pipelinedpid_pipelinedpid_pid_sum <= 84'sd0;
		pair_limitcsr0_limitcsr0_y <= 14'sd0;
		pair_limitcsr0_limitcsr0_error <= 1'd0;
		pair_limitcsr0_x <= 19'sd0;
		pair_limitcsr0_limit_max <= 19'sd0;
		pair_limitcsr0_limit_min <= 19'sd0;
		pair_csrbank0_bus_dat_r <= 8'd0;
		pair_pitayaanalog1_adca <= 16'd0;
		pair_pitayaanalog1_adcb <= 16'd0;
		pair_pitayaanalog1_daca <= 14'd0;
		pair_pitayaanalog1_dacb <= 14'd0;
		pair_mixeralignedpid_error_s1 <= 26'sd0;
		pair_mixeralignedpid0 <= 14'sd0;
		pair_mixeralignedpid1 <= 14'sd0;
		pair_mixeralignedpid2 <= 14'sd0;
		pair_mixeralignedpid3 <= 1'd0;
		pair_mixeralignedpid4 <= 1'd0;
		pair_mixeralignedpid5 <= 1'd0;
		pair_mixeralignedpid6 <= 1'd0;
		pair_mixeralignedpid_setpoint_cohort <= 25'd0;
		pair_mixeralignedpid_running_cohort <= 1'd0;
		pair_mixeralignedpid7 <= 14'd0;
		pair_mixeralignedpid8 <= 14'd0;
		pair_mixeralignedpid9 <= 14'd0;
		pair_mixeralignedpid10 <= 1'd0;
		pair_mixeralignedpid11 <= 1'd0;
		pair_mixeralignedpid_mixeralignedpid_setpoint_storage_full <= 25'd0;
		pair_mixeralignedpid_mixeralignedpid_setpoint_re <= 1'd0;
		pair_mixeralignedpid_mixeralignedpid_kp_storage_full <= 14'd0;
		pair_mixeralignedpid_mixeralignedpid_kp_re <= 1'd0;
		pair_mixeralignedpid_mixeralignedpid_kp_mult <= 39'sd0;
		pair_mixeralignedpid_mixeralignedpid_ki_storage_full <= 14'd0;
		pair_mixeralignedpid_mixeralignedpid_ki_re <= 1'd0;
		pair_mixeralignedpid_mixeralignedpid_reset_storage_full <= 1'd0;
		pair_mixeralignedpid_mixeralignedpid_reset_re <= 1'd0;
		pair_mixeralignedpid_mixeralignedpid_ki_mult <= 40'sd0;
		pair_mixeralignedpid_mixeralignedpid_int_reg <= 43'sd0;
		pair_mixeralignedpid_mixeralignedpid_kd_storage_full <= 14'd0;
		pair_mixeralignedpid_mixeralignedpid_kd_re <= 1'd0;
		pair_mixeralignedpid_mixeralignedpid_kd_mult <= 41'sd0;
		pair_mixeralignedpid_mixeralignedpid_kd_reg <= 34'sd0;
		pair_mixeralignedpid_mixeralignedpid_kd_reg_r <= 34'sd0;
		pair_mixeralignedpid_mixeralignedpid_output_d <= 34'sd0;
		pair_mixeralignedpid_mixeralignedpid_pid_sum <= 84'sd0;
		pair_limitcsr1_limitcsr1_y <= 14'sd0;
		pair_limitcsr1_limitcsr1_error <= 1'd0;
		pair_limitcsr1_x <= 19'sd0;
		pair_limitcsr1_limit_max <= 19'sd0;
		pair_limitcsr1_limit_min <= 19'sd0;
		pair_csrbank1_bus_dat_r <= 8'd0;
		pair_limit_execute_en <= 1'd0;
		pair_adc_cohort <= 14'sd0;
		pair_mode_cohort <= 1'd0;
	end
end

ODDR ODDR(
	.C(dac_2p_clk),
	.CE(1'd1),
	.D1(1'd0),
	.D2(1'd1),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_clk)
);

ODDR ODDR_1(
	.C(sys_double_clk),
	.CE(1'd1),
	.D1(1'd0),
	.D2(1'd1),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_wrt)
);

ODDR ODDR_2(
	.C(sys_clk),
	.CE(1'd1),
	.D1(1'd0),
	.D2(1'd1),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_sel)
);

ODDR ODDR_3(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[0]),
	.D2(pair_pitayaanalog0_dacb[0]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[0])
);

ODDR ODDR_4(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[1]),
	.D2(pair_pitayaanalog0_dacb[1]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[1])
);

ODDR ODDR_5(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[2]),
	.D2(pair_pitayaanalog0_dacb[2]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[2])
);

ODDR ODDR_6(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[3]),
	.D2(pair_pitayaanalog0_dacb[3]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[3])
);

ODDR ODDR_7(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[4]),
	.D2(pair_pitayaanalog0_dacb[4]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[4])
);

ODDR ODDR_8(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[5]),
	.D2(pair_pitayaanalog0_dacb[5]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[5])
);

ODDR ODDR_9(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[6]),
	.D2(pair_pitayaanalog0_dacb[6]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[6])
);

ODDR ODDR_10(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[7]),
	.D2(pair_pitayaanalog0_dacb[7]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[7])
);

ODDR ODDR_11(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[8]),
	.D2(pair_pitayaanalog0_dacb[8]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[8])
);

ODDR ODDR_12(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[9]),
	.D2(pair_pitayaanalog0_dacb[9]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[9])
);

ODDR ODDR_13(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[10]),
	.D2(pair_pitayaanalog0_dacb[10]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[10])
);

ODDR ODDR_14(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[11]),
	.D2(pair_pitayaanalog0_dacb[11]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[11])
);

ODDR ODDR_15(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[12]),
	.D2(pair_pitayaanalog0_dacb[12]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[12])
);

ODDR ODDR_16(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog0_daca[13]),
	.D2(pair_pitayaanalog0_dacb[13]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record0_dac_data[13])
);

ODDR ODDR_17(
	.C(dac_2p_clk),
	.CE(1'd1),
	.D1(1'd0),
	.D2(1'd1),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_clk)
);

ODDR ODDR_18(
	.C(sys_double_clk),
	.CE(1'd1),
	.D1(1'd0),
	.D2(1'd1),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_wrt)
);

ODDR ODDR_19(
	.C(sys_clk),
	.CE(1'd1),
	.D1(1'd0),
	.D2(1'd1),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_sel)
);

ODDR ODDR_20(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[0]),
	.D2(pair_pitayaanalog1_dacb[0]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[0])
);

ODDR ODDR_21(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[1]),
	.D2(pair_pitayaanalog1_dacb[1]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[1])
);

ODDR ODDR_22(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[2]),
	.D2(pair_pitayaanalog1_dacb[2]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[2])
);

ODDR ODDR_23(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[3]),
	.D2(pair_pitayaanalog1_dacb[3]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[3])
);

ODDR ODDR_24(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[4]),
	.D2(pair_pitayaanalog1_dacb[4]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[4])
);

ODDR ODDR_25(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[5]),
	.D2(pair_pitayaanalog1_dacb[5]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[5])
);

ODDR ODDR_26(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[6]),
	.D2(pair_pitayaanalog1_dacb[6]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[6])
);

ODDR ODDR_27(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[7]),
	.D2(pair_pitayaanalog1_dacb[7]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[7])
);

ODDR ODDR_28(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[8]),
	.D2(pair_pitayaanalog1_dacb[8]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[8])
);

ODDR ODDR_29(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[9]),
	.D2(pair_pitayaanalog1_dacb[9]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[9])
);

ODDR ODDR_30(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[10]),
	.D2(pair_pitayaanalog1_dacb[10]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[10])
);

ODDR ODDR_31(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[11]),
	.D2(pair_pitayaanalog1_dacb[11]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[11])
);

ODDR ODDR_32(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[12]),
	.D2(pair_pitayaanalog1_dacb[12]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[12])
);

ODDR ODDR_33(
	.C(sys_clk),
	.CE(1'd1),
	.D1(pair_pitayaanalog1_daca[13]),
	.D2(pair_pitayaanalog1_dacb[13]),
	.R(1'd0),
	.S(1'd0),
	.Q(pair_record1_dac_data[13])
);

endmodule
