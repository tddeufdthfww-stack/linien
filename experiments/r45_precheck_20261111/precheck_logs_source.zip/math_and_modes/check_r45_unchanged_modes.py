from pathlib import Path
import hashlib,importlib.util,json
from migen import ClockDomain,Module
from migen.fhdl import verilog
from gateware.logic.iir import Iir
r=Path('D:/RP_Dev/linien_trials/20261111-r45-iir-output-edge');h=Path(__file__).parent
frozen=r/'gateware/tests/timing/reference/r44_iir_registered_c48.py'
spec=importlib.util.spec_from_file_location('gateware.logic.r45_native_frozen',frozen);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
class Top(Module):
 def __init__(self,cls,kw):
  self.clock_domains.cd_sys=ClockDomain('sys')
  self.submodules.unit=d=cls(**kw)
  self.ports={self.cd_sys.clk,self.cd_sys.rst,d.x,d.y,d.error,d.hold,d.clear,d.z0.storage}
  self.ports.update(getattr(d,'r_'+k).storage for k in d.c)
def generate(cls,kw):
 d=Top(cls,kw);return str(verilog.convert(d,ios=d.ports,name='unchanged_modes'))
records=[]
for width in (14,25):
 for order in (1,2,5):
  for delay in (0,2):
   for mode in ('pipelined','iterative'):
    kw=dict(order=order,width=width,coeff_width=width,shift=width-2,config_delay=delay,mode=mode,mac_impl='native')
    a,b=generate(old.Iir,kw),generate(Iir,kw)
    assert a==b,kw
    records.append({'parameters':kw,'same_complete_generated_verilog':True,'sha256':hashlib.sha256(a.encode()).hexdigest()})
for order in (1,2,5):
 for delay in (0,2):
  kw=dict(order=order,width=25,coeff_width=25,shift=23,config_delay=delay,mode='pipelined',mac_impl='split_c48')
  a,b=generate(old.Iir,kw),generate(Iir,kw);assert a==b,kw
  records.append({'parameters':kw,'same_complete_generated_verilog':True,'sha256':hashlib.sha256(a.encode()).hexdigest()})
record={'passed':True,'case_count':len(records),'native_14_25_order_1_2_5_config0_2_pipelined_iterative_and_split_c48_25_unchanged':True,'cases':records,'scope':'Actual Migen complete Verilog exact byte equality for non-retimed modes. Registered_c48 output-edge mode uses separate native finite50/frozen-reference tests; this is not that mode or physical signoff.'}
(h/'r45_unmodified_modes_generated_audit.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print('R45_NONRETIMED_ALL30_GENERATED_NETLISTS_IDENTICAL_PASS')
