from pathlib import Path
import re,json,hashlib,csv
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r58-cordic-preserved-route')
m=json.loads((h/'r58_mapped/metrics.json').read_text());t=Path(m['trial']);ma=json.loads((t/'manifest.json').read_text());assert ma['route']=='COMPLETE' and ma['target_routing']=='COMPLETE' and ma['input_r57_dcp_unchanged'] and not ma['source_changes_during_run'] and all(ma['r57_code_and_test_hash_matches'].values())
def canonical(lab):
 s=(h/(lab+'_mapped/routed_netlist.v')).read_text()
 s=re.sub(r'//[^\n]*','',s);s=re.sub(r'\(\*.*?\*\)','',s,flags=re.S)
 return re.sub(r'\s+','',s)
a,b=canonical('r57'),canonical('r58');assert a==b,'Functional simulation HDL differs beyond comments/attributes/whitespace'
def dsps(lab):
 out={}
 for block in (h/(lab+'_mapped/all_dsp.txt')).read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in block.splitlines() if '=' in s);out[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return out
assert len(dsps('r57'))==94 and dsps('r57')==dsps('r58')
tables={n:list(csv.DictReader((t/n).open(),delimiter='\t')) for n in ('target_nets_before.tsv','target_nets_after.tsv','target_nets_routed.tsv')};v=list(tables.values());assert v[0]==v[1]==v[2] and len(v[0])==1 and v[0][0]['loads']=='2'
prior=Path(ma['input_r57_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(prior/n).read_bytes()
rec={'passed':True,'whole_funcsim_HDL_identical_excluding_comments_attributes_whitespace':True,'canonical_funcsim_SHA256':hashlib.sha256(a.encode()).hexdigest(),'all94_DSP_properties_same_R57_ignoring_LOC_BEL':True,'exact_target_net_driver_and_loads_same':True,'target_table':v[0],'raw_hardware_test_inputs_same_R57':len(ma['r57_code_and_test_hash_matches']),'top_CSR_XDC_bytes_same_R57':True,'input_DCP_SHA_unchanged':True,'new_serial_ADC_feedback_CSR_cycles':0,'functional_and_synthesis':'REUSED_R52_VIA_R57_NOT_RERUN','scope':'Route-only canonical whole functional-simulation netlist text equality (HDL parameters/ports/constants/INIT retained; synthesis/physical attributes omitted), explicit all94 DSP property audit and connectivity audit. Not timing-annotated/SDF simulation, fullRoot formal equivalence, physical CDC or board proof. -preserve applies to target repair route command only, final TNS cleanup may reroute other nets.'}
(h/'r58_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R58_WHOLE_FUNCSIM_HDL_TARGET_AND_ALL94_DSP_AUDIT_PASS')
