if {[catch {
set out {D:/RP_Dev/linien_trials/20261111-r58-cordic-preserved-route/gateware/build/trials/20261111_191130_r58_preserved_two_load}
set input_dcp {D:/RP_Dev/linien_trials/20261111-r57-critical-ff-postroute/gateware/build/trials/20261111_175257_r57_distributed_ff_postroute/routed.dcp}

set_param general.maxThreads 2
open_checkpoint $input_dcp
report_timing_summary -file "$out/input_routed_timing.rpt"
set targets {}
foreach wanted {{linienmodule_fast_b_cordic33[10]_i_8_n_0}} {
    set matches {}
    foreach n [get_nets -hier -quiet -filter {NAME =~ linienmodule_fast_b_*}] {
        if {[get_property NAME $n] eq $wanted} {lappend matches $n}
    }
    if {[llength $matches]!=1} {error "Expected exactly one selected data net $wanted: $matches"}
    set n [lindex $matches 0]
    if {[get_property IS_ROUTE_FIXED $n]} {error "Refuse fixed route: $n"}
    set dp [get_pins -quiet -leaf -of_objects $n -filter {DIRECTION == OUT}]
    set lp [get_pins -quiet -leaf -of_objects $n -filter {DIRECTION == IN}]
    if {[llength $dp]!=1 || [llength $lp]!=2} {error "Unexpected original driver/load count: $n $dp [llength $lp]"}
    set paths [get_timing_paths -quiet -through $n -max_paths 1]
    if {![llength $paths] || [get_property SLACK $paths]>=0} {error "Selected original R57 net no longer lies on a negative path: $n"}
    lappend targets $n
}
proc target_table {file targets} {
    set f [open $file w];puts $f "net\tdrivers\tloads\tload_pins"
    foreach n $targets {
        set dp [lsort [get_pins -quiet -leaf -of_objects $n -filter {DIRECTION == OUT}]]
        set lp [lsort [get_pins -quiet -leaf -of_objects $n -filter {DIRECTION == IN}]]
        puts $f "$n\t[join $dp |]\t[llength $lp]\t[join $lp |]"
    };close $f
}
target_table "$out/target_nets_before.tsv" $targets
set index 0
foreach n $targets {
    route_design -unroute -nets [get_nets $n]
    route_design -preserve
    report_timing_summary -file "$out/target${index}_timing.rpt"
    puts "CORDIC_PRESERVED_TARGET_COMPLETE $index $n"
    incr index
}
target_table "$out/target_nets_after.tsv" $targets
write_checkpoint "$out/local_routed.dcp"
puts CORDIC_PRESERVED_TARGETS_COMPLETE
route_design -tns_cleanup
target_table "$out/target_nets_routed.tsv" $targets
report_route_status -file "$out/routed_status.rpt"
report_timing_summary -max_paths 30 -file "$out/routed_timing.rpt"
report_timing -max_paths 100 -file "$out/routed_setup.rpt"
report_timing -delay_type min -max_paths 30 -file "$out/routed_hold.rpt"
report_utilization -file "$out/routed_utilization.rpt"
check_timing -verbose -file "$out/routed_checks.rpt"
report_cdc -details -file "$out/routed_cdc.rpt"
report_drc -file "$out/routed_drc.rpt"
report_clock_interaction -file "$out/routed_clocks.rpt"
report_exceptions -file "$out/routed_exceptions.rpt"
write_checkpoint "$out/routed.dcp"
puts CORDIC_PRESERVED_ROUTE_TRIAL_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
