from pathlib import Path
import ast,hashlib,json,re,subprocess
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261110-r33-autolock-onehot');t=r/'gateware/build/trials/20261110_215739_r33_autolock_onehot';src=(r/'gateware/logic/autolock_pipeline.py').read_text(encoding='utf-8');old=subprocess.check_output(['git','show','9c5c32a:gateware/logic/autolock_pipeline.py'],cwd=r).decode()
def is_mirror(node):
    return isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='eq' and isinstance(node.func.value,ast.Attribute) and node.func.value.attr=='_instruction_onehot'
class StripMirror(ast.NodeTransformer):
    def visit_Call(self,node):
        return None if is_mirror(node) else self.generic_visit(node)
def syncs(tree):
    return [ast.dump(n) for n in ast.walk(tree) if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Attribute) and n.target.attr=='sync']
tree=ast.parse(src);assigns=[n for n in ast.walk(tree) if is_mirror(n)];assert len(assigns)==2
assert isinstance(assigns[0].args[0],ast.Constant) and assigns[0].args[0].value==1
assert isinstance(assigns[1].args[0],ast.Call) and isinstance(assigns[1].args[0].func,ast.Name) and assigns[1].args[0].func.id=='Cat'
assert syncs(ast.parse(old))==syncs(StripMirror().visit(ast.parse(src)))
helper=ast.parse((r/'gateware/logic/onehot_select.py').read_text(encoding='utf-8'));assert not any(isinstance(n,ast.Attribute) and n.attr=='sync' for n in ast.walk(helper))
for rel in ('gateware/logic/pid.py','gateware/logic/pid_pipeline.py','gateware/logic/pid_output_limit.py','gateware/logic/iir.py','gateware/linien_module.py','gateware/logic/slow_pipeline.py','gateware/logic/abs_threshold.py'):
    a=subprocess.check_output(['git','show','9c5c32a:'+rel],cwd=r).replace(b'\r\n',b'\n');b=(r/rel).read_bytes().replace(b'\r\n',b'\n');assert a==b,rel
s=(t/'top.v').read_text();match=re.search(r'reg \[31:0\] (\w*instruction_onehot\w*) = 32\'d1;',s);assert match
name=match[1];assert re.search(re.escape(name)+r' <= \{'+re.escape(name)+r'\[30:0\], '+re.escape(name)+r'\[31\]\};',s)
assert not re.search(re.escape(name)+r' <= .*<<.*current_instruction_idx',s)
assert len(re.findall(re.escape(name)+r" <= (?:1|32)'d1;",s))==2
base=Path('D:/RP_Dev/linien_trials/20261110-r28-pid-output-bitdecode/gateware/build/trials/20261110_193543_r28_pid_output_bitdecode');assert(t/'top.xdc').read_bytes()==(base/'top.xdc').read_bytes()
ns={};exec((t/'csrmap.py').read_text(),ns);assert ns['states'][12]=='robustover_threshold' and len(ns['states'])==14
parent=json.loads((t/'autolock_pipeline_checks/results.json').read_text());assert parent['onehot_mirror_every_cycle'] and parent['indices_visited']==32 and parent['original_R28_vectors_preserved']==50076
record={'passed':True,'top_sha256':hashlib.sha256((t/'top.v').read_bytes()).hexdigest(),'RTL_parallel_state_bits':32,'generated_register':name,'init_and_reset':1,'transition':'same-edge rotate on original increment branch, reset1 on original reset0 branch; no registered binary decode','original_sync_AST_same_after_removing_two_mirror_assignments':True,'lookup_helper_combinational':True,'serial_cycles_added':0,'PID_IIR_Root_scalar_sources_unchanged':True,'XDC_same_bytes_R28':True,'CSR_states_unchanged':True,'parent_native':parent,'scope':'Actual production generated structure and original-statement checks plus separately logged native invariant; not final STA or postroute/SDF/board proof.'}
(h/'r33_generated_structure.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print('R33_GENERATED_SAME_EDGE_ONEHOT_AND_ORIGINAL_SYNC_AST_PASS')
