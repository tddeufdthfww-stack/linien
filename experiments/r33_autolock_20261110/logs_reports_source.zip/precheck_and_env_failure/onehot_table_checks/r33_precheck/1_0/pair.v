/* Machine-generated using Migen */
module onehot_word_pair(
	input [31:0] packed_words,
	input [4:0] index,
	input [31:0] onehot,
	output old_word,
	output new_word
);

wire x0;
wire x1;
wire x2;
wire x3;
wire x4;
wire x5;
wire x6;
wire x7;
wire x8;
wire x9;
wire x10;
wire x11;
wire x12;
wire x13;
wire x14;
wire x15;
wire x16;
wire x17;
wire x18;
wire x19;
wire x20;
wire x21;
wire x22;
wire x23;
wire x24;
wire x25;
wire x26;
wire x27;
wire x28;
wire x29;
wire x30;
wire x31;
wire selected;
reg array_muxed;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign x0 = packed_words[0];
assign x1 = packed_words[1];
assign x2 = packed_words[2];
assign x3 = packed_words[3];
assign x4 = packed_words[4];
assign x5 = packed_words[5];
assign x6 = packed_words[6];
assign x7 = packed_words[7];
assign x8 = packed_words[8];
assign x9 = packed_words[9];
assign x10 = packed_words[10];
assign x11 = packed_words[11];
assign x12 = packed_words[12];
assign x13 = packed_words[13];
assign x14 = packed_words[14];
assign x15 = packed_words[15];
assign x16 = packed_words[16];
assign x17 = packed_words[17];
assign x18 = packed_words[18];
assign x19 = packed_words[19];
assign x20 = packed_words[20];
assign x21 = packed_words[21];
assign x22 = packed_words[22];
assign x23 = packed_words[23];
assign x24 = packed_words[24];
assign x25 = packed_words[25];
assign x26 = packed_words[26];
assign x27 = packed_words[27];
assign x28 = packed_words[28];
assign x29 = packed_words[29];
assign x30 = packed_words[30];
assign x31 = packed_words[31];
assign selected = ((((((((((((((((((((((((((((((((1'd0 | (x0 & {1{onehot[0]}})) | (x1 & {1{onehot[1]}})) | (x2 & {1{onehot[2]}})) | (x3 & {1{onehot[3]}})) | (x4 & {1{onehot[4]}})) | (x5 & {1{onehot[5]}})) | (x6 & {1{onehot[6]}})) | (x7 & {1{onehot[7]}})) | (x8 & {1{onehot[8]}})) | (x9 & {1{onehot[9]}})) | (x10 & {1{onehot[10]}})) | (x11 & {1{onehot[11]}})) | (x12 & {1{onehot[12]}})) | (x13 & {1{onehot[13]}})) | (x14 & {1{onehot[14]}})) | (x15 & {1{onehot[15]}})) | (x16 & {1{onehot[16]}})) | (x17 & {1{onehot[17]}})) | (x18 & {1{onehot[18]}})) | (x19 & {1{onehot[19]}})) | (x20 & {1{onehot[20]}})) | (x21 & {1{onehot[21]}})) | (x22 & {1{onehot[22]}})) | (x23 & {1{onehot[23]}})) | (x24 & {1{onehot[24]}})) | (x25 & {1{onehot[25]}})) | (x26 & {1{onehot[26]}})) | (x27 & {1{onehot[27]}})) | (x28 & {1{onehot[28]}})) | (x29 & {1{onehot[29]}})) | (x30 & {1{onehot[30]}})) | (x31 & {1{onehot[31]}}));
assign old_word = array_muxed;
assign new_word = selected;

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	array_muxed <= 1'd0;
	case (index)
		1'd0: begin
			array_muxed <= x0;
		end
		1'd1: begin
			array_muxed <= x1;
		end
		2'd2: begin
			array_muxed <= x2;
		end
		2'd3: begin
			array_muxed <= x3;
		end
		3'd4: begin
			array_muxed <= x4;
		end
		3'd5: begin
			array_muxed <= x5;
		end
		3'd6: begin
			array_muxed <= x6;
		end
		3'd7: begin
			array_muxed <= x7;
		end
		4'd8: begin
			array_muxed <= x8;
		end
		4'd9: begin
			array_muxed <= x9;
		end
		4'd10: begin
			array_muxed <= x10;
		end
		4'd11: begin
			array_muxed <= x11;
		end
		4'd12: begin
			array_muxed <= x12;
		end
		4'd13: begin
			array_muxed <= x13;
		end
		4'd14: begin
			array_muxed <= x14;
		end
		4'd15: begin
			array_muxed <= x15;
		end
		5'd16: begin
			array_muxed <= x16;
		end
		5'd17: begin
			array_muxed <= x17;
		end
		5'd18: begin
			array_muxed <= x18;
		end
		5'd19: begin
			array_muxed <= x19;
		end
		5'd20: begin
			array_muxed <= x20;
		end
		5'd21: begin
			array_muxed <= x21;
		end
		5'd22: begin
			array_muxed <= x22;
		end
		5'd23: begin
			array_muxed <= x23;
		end
		5'd24: begin
			array_muxed <= x24;
		end
		5'd25: begin
			array_muxed <= x25;
		end
		5'd26: begin
			array_muxed <= x26;
		end
		5'd27: begin
			array_muxed <= x27;
		end
		5'd28: begin
			array_muxed <= x28;
		end
		5'd29: begin
			array_muxed <= x29;
		end
		5'd30: begin
			array_muxed <= x30;
		end
		default: begin
			array_muxed <= x31;
		end
	endcase
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end

endmodule
