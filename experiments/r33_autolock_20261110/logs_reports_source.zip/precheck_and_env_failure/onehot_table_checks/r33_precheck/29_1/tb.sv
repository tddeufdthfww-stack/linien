`timescale 1ns/1ps
module tb_onehot_word;
reg [927:0] packed_words;reg [4:0] index;reg [31:0] onehot;wire [28:0] old_word,new_word;reg [28:0] expected;
integer fd,k,count=0,unknown_count=0;onehot_word_pair dut(.*);
initial begin
fd=$fopen("vectors.txt","r");if(!fd)$fatal(1,"vectors missing");
while(!$feof(fd))begin
k=$fscanf(fd,"%h %h %h %h\n",packed_words,index,onehot,expected);if(k!=4)$fatal(1,"bad vector");#1;
if(old_word!==expected || new_word!==expected)$fatal(1,"ONEHOT_WORD_FAIL W=29 signed=1 cycle=%0d index=%0d old=%h new=%h expected=%h",count,index,old_word,new_word,expected);count=count+1;
end
$fclose(fd);fd=$fopen("unknown.txt","r");
while(!$feof(fd))begin
k=$fscanf(fd,"%b %b %h\n",packed_words,index,onehot);if(k!=3)$fatal(1,"bad unknown vector");#1;
if(old_word!==new_word)$fatal(1,"ONEHOT_WORD_UNKNOWN_FAIL W=29 case=%0d idx=%b OH=%h old=%b new=%b",unknown_count,index,onehot,old_word,new_word);unknown_count=unknown_count+1;
end
$display("ONEHOT_WORD_PASS width=29 signed=1 cases=%0d unknown=%0d indices=32",count,unknown_count);$finish;
end
endmodule
