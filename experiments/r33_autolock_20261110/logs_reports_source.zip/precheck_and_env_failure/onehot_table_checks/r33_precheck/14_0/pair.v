/* Machine-generated using Migen */
module onehot_word_pair(
	input [447:0] packed_words,
	input [4:0] index,
	input [31:0] onehot,
	output [13:0] old_word,
	output [13:0] new_word
);

wire [13:0] x0;
wire [13:0] x1;
wire [13:0] x2;
wire [13:0] x3;
wire [13:0] x4;
wire [13:0] x5;
wire [13:0] x6;
wire [13:0] x7;
wire [13:0] x8;
wire [13:0] x9;
wire [13:0] x10;
wire [13:0] x11;
wire [13:0] x12;
wire [13:0] x13;
wire [13:0] x14;
wire [13:0] x15;
wire [13:0] x16;
wire [13:0] x17;
wire [13:0] x18;
wire [13:0] x19;
wire [13:0] x20;
wire [13:0] x21;
wire [13:0] x22;
wire [13:0] x23;
wire [13:0] x24;
wire [13:0] x25;
wire [13:0] x26;
wire [13:0] x27;
wire [13:0] x28;
wire [13:0] x29;
wire [13:0] x30;
wire [13:0] x31;
wire [13:0] selected;
reg [13:0] array_muxed;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign x0 = packed_words[13:0];
assign x1 = packed_words[27:14];
assign x2 = packed_words[41:28];
assign x3 = packed_words[55:42];
assign x4 = packed_words[69:56];
assign x5 = packed_words[83:70];
assign x6 = packed_words[97:84];
assign x7 = packed_words[111:98];
assign x8 = packed_words[125:112];
assign x9 = packed_words[139:126];
assign x10 = packed_words[153:140];
assign x11 = packed_words[167:154];
assign x12 = packed_words[181:168];
assign x13 = packed_words[195:182];
assign x14 = packed_words[209:196];
assign x15 = packed_words[223:210];
assign x16 = packed_words[237:224];
assign x17 = packed_words[251:238];
assign x18 = packed_words[265:252];
assign x19 = packed_words[279:266];
assign x20 = packed_words[293:280];
assign x21 = packed_words[307:294];
assign x22 = packed_words[321:308];
assign x23 = packed_words[335:322];
assign x24 = packed_words[349:336];
assign x25 = packed_words[363:350];
assign x26 = packed_words[377:364];
assign x27 = packed_words[391:378];
assign x28 = packed_words[405:392];
assign x29 = packed_words[419:406];
assign x30 = packed_words[433:420];
assign x31 = packed_words[447:434];
assign selected = ((((((((((((((((((((((((((((((((1'd0 | (x0 & {14{onehot[0]}})) | (x1 & {14{onehot[1]}})) | (x2 & {14{onehot[2]}})) | (x3 & {14{onehot[3]}})) | (x4 & {14{onehot[4]}})) | (x5 & {14{onehot[5]}})) | (x6 & {14{onehot[6]}})) | (x7 & {14{onehot[7]}})) | (x8 & {14{onehot[8]}})) | (x9 & {14{onehot[9]}})) | (x10 & {14{onehot[10]}})) | (x11 & {14{onehot[11]}})) | (x12 & {14{onehot[12]}})) | (x13 & {14{onehot[13]}})) | (x14 & {14{onehot[14]}})) | (x15 & {14{onehot[15]}})) | (x16 & {14{onehot[16]}})) | (x17 & {14{onehot[17]}})) | (x18 & {14{onehot[18]}})) | (x19 & {14{onehot[19]}})) | (x20 & {14{onehot[20]}})) | (x21 & {14{onehot[21]}})) | (x22 & {14{onehot[22]}})) | (x23 & {14{onehot[23]}})) | (x24 & {14{onehot[24]}})) | (x25 & {14{onehot[25]}})) | (x26 & {14{onehot[26]}})) | (x27 & {14{onehot[27]}})) | (x28 & {14{onehot[28]}})) | (x29 & {14{onehot[29]}})) | (x30 & {14{onehot[30]}})) | (x31 & {14{onehot[31]}}));
assign old_word = array_muxed;
assign new_word = selected;

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	array_muxed <= 14'd0;
	case (index)
		1'd0: begin
			array_muxed <= x0;
		end
		1'd1: begin
			array_muxed <= x1;
		end
		2'd2: begin
			array_muxed <= x2;
		end
		2'd3: begin
			array_muxed <= x3;
		end
		3'd4: begin
			array_muxed <= x4;
		end
		3'd5: begin
			array_muxed <= x5;
		end
		3'd6: begin
			array_muxed <= x6;
		end
		3'd7: begin
			array_muxed <= x7;
		end
		4'd8: begin
			array_muxed <= x8;
		end
		4'd9: begin
			array_muxed <= x9;
		end
		4'd10: begin
			array_muxed <= x10;
		end
		4'd11: begin
			array_muxed <= x11;
		end
		4'd12: begin
			array_muxed <= x12;
		end
		4'd13: begin
			array_muxed <= x13;
		end
		4'd14: begin
			array_muxed <= x14;
		end
		4'd15: begin
			array_muxed <= x15;
		end
		5'd16: begin
			array_muxed <= x16;
		end
		5'd17: begin
			array_muxed <= x17;
		end
		5'd18: begin
			array_muxed <= x18;
		end
		5'd19: begin
			array_muxed <= x19;
		end
		5'd20: begin
			array_muxed <= x20;
		end
		5'd21: begin
			array_muxed <= x21;
		end
		5'd22: begin
			array_muxed <= x22;
		end
		5'd23: begin
			array_muxed <= x23;
		end
		5'd24: begin
			array_muxed <= x24;
		end
		5'd25: begin
			array_muxed <= x25;
		end
		5'd26: begin
			array_muxed <= x26;
		end
		5'd27: begin
			array_muxed <= x27;
		end
		5'd28: begin
			array_muxed <= x28;
		end
		5'd29: begin
			array_muxed <= x29;
		end
		5'd30: begin
			array_muxed <= x30;
		end
		default: begin
			array_muxed <= x31;
		end
	endcase
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end

endmodule
