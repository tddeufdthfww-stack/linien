/* Machine-generated using Migen */
module onehot_word_pair(
	input [895:0] packed_words,
	input [4:0] index,
	input [31:0] onehot,
	output signed [27:0] old_word,
	output signed [27:0] new_word
);

wire signed [27:0] x0;
wire signed [27:0] x1;
wire signed [27:0] x2;
wire signed [27:0] x3;
wire signed [27:0] x4;
wire signed [27:0] x5;
wire signed [27:0] x6;
wire signed [27:0] x7;
wire signed [27:0] x8;
wire signed [27:0] x9;
wire signed [27:0] x10;
wire signed [27:0] x11;
wire signed [27:0] x12;
wire signed [27:0] x13;
wire signed [27:0] x14;
wire signed [27:0] x15;
wire signed [27:0] x16;
wire signed [27:0] x17;
wire signed [27:0] x18;
wire signed [27:0] x19;
wire signed [27:0] x20;
wire signed [27:0] x21;
wire signed [27:0] x22;
wire signed [27:0] x23;
wire signed [27:0] x24;
wire signed [27:0] x25;
wire signed [27:0] x26;
wire signed [27:0] x27;
wire signed [27:0] x28;
wire signed [27:0] x29;
wire signed [27:0] x30;
wire signed [27:0] x31;
wire signed [27:0] selected;
reg signed [27:0] array_muxed;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign x0 = packed_words[27:0];
assign x1 = packed_words[55:28];
assign x2 = packed_words[83:56];
assign x3 = packed_words[111:84];
assign x4 = packed_words[139:112];
assign x5 = packed_words[167:140];
assign x6 = packed_words[195:168];
assign x7 = packed_words[223:196];
assign x8 = packed_words[251:224];
assign x9 = packed_words[279:252];
assign x10 = packed_words[307:280];
assign x11 = packed_words[335:308];
assign x12 = packed_words[363:336];
assign x13 = packed_words[391:364];
assign x14 = packed_words[419:392];
assign x15 = packed_words[447:420];
assign x16 = packed_words[475:448];
assign x17 = packed_words[503:476];
assign x18 = packed_words[531:504];
assign x19 = packed_words[559:532];
assign x20 = packed_words[587:560];
assign x21 = packed_words[615:588];
assign x22 = packed_words[643:616];
assign x23 = packed_words[671:644];
assign x24 = packed_words[699:672];
assign x25 = packed_words[727:700];
assign x26 = packed_words[755:728];
assign x27 = packed_words[783:756];
assign x28 = packed_words[811:784];
assign x29 = packed_words[839:812];
assign x30 = packed_words[867:840];
assign x31 = packed_words[895:868];
assign selected = (((((((((((((((((((((((((((((((($signed({1'd0, 1'd0}) | (x0 & $signed({1'd0, {28{onehot[0]}}}))) | (x1 & $signed({1'd0, {28{onehot[1]}}}))) | (x2 & $signed({1'd0, {28{onehot[2]}}}))) | (x3 & $signed({1'd0, {28{onehot[3]}}}))) | (x4 & $signed({1'd0, {28{onehot[4]}}}))) | (x5 & $signed({1'd0, {28{onehot[5]}}}))) | (x6 & $signed({1'd0, {28{onehot[6]}}}))) | (x7 & $signed({1'd0, {28{onehot[7]}}}))) | (x8 & $signed({1'd0, {28{onehot[8]}}}))) | (x9 & $signed({1'd0, {28{onehot[9]}}}))) | (x10 & $signed({1'd0, {28{onehot[10]}}}))) | (x11 & $signed({1'd0, {28{onehot[11]}}}))) | (x12 & $signed({1'd0, {28{onehot[12]}}}))) | (x13 & $signed({1'd0, {28{onehot[13]}}}))) | (x14 & $signed({1'd0, {28{onehot[14]}}}))) | (x15 & $signed({1'd0, {28{onehot[15]}}}))) | (x16 & $signed({1'd0, {28{onehot[16]}}}))) | (x17 & $signed({1'd0, {28{onehot[17]}}}))) | (x18 & $signed({1'd0, {28{onehot[18]}}}))) | (x19 & $signed({1'd0, {28{onehot[19]}}}))) | (x20 & $signed({1'd0, {28{onehot[20]}}}))) | (x21 & $signed({1'd0, {28{onehot[21]}}}))) | (x22 & $signed({1'd0, {28{onehot[22]}}}))) | (x23 & $signed({1'd0, {28{onehot[23]}}}))) | (x24 & $signed({1'd0, {28{onehot[24]}}}))) | (x25 & $signed({1'd0, {28{onehot[25]}}}))) | (x26 & $signed({1'd0, {28{onehot[26]}}}))) | (x27 & $signed({1'd0, {28{onehot[27]}}}))) | (x28 & $signed({1'd0, {28{onehot[28]}}}))) | (x29 & $signed({1'd0, {28{onehot[29]}}}))) | (x30 & $signed({1'd0, {28{onehot[30]}}}))) | (x31 & $signed({1'd0, {28{onehot[31]}}})));
assign old_word = array_muxed;
assign new_word = selected;

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	array_muxed <= 28'sd0;
	case (index)
		1'd0: begin
			array_muxed <= x0;
		end
		1'd1: begin
			array_muxed <= x1;
		end
		2'd2: begin
			array_muxed <= x2;
		end
		2'd3: begin
			array_muxed <= x3;
		end
		3'd4: begin
			array_muxed <= x4;
		end
		3'd5: begin
			array_muxed <= x5;
		end
		3'd6: begin
			array_muxed <= x6;
		end
		3'd7: begin
			array_muxed <= x7;
		end
		4'd8: begin
			array_muxed <= x8;
		end
		4'd9: begin
			array_muxed <= x9;
		end
		4'd10: begin
			array_muxed <= x10;
		end
		4'd11: begin
			array_muxed <= x11;
		end
		4'd12: begin
			array_muxed <= x12;
		end
		4'd13: begin
			array_muxed <= x13;
		end
		4'd14: begin
			array_muxed <= x14;
		end
		4'd15: begin
			array_muxed <= x15;
		end
		5'd16: begin
			array_muxed <= x16;
		end
		5'd17: begin
			array_muxed <= x17;
		end
		5'd18: begin
			array_muxed <= x18;
		end
		5'd19: begin
			array_muxed <= x19;
		end
		5'd20: begin
			array_muxed <= x20;
		end
		5'd21: begin
			array_muxed <= x21;
		end
		5'd22: begin
			array_muxed <= x22;
		end
		5'd23: begin
			array_muxed <= x23;
		end
		5'd24: begin
			array_muxed <= x24;
		end
		5'd25: begin
			array_muxed <= x25;
		end
		5'd26: begin
			array_muxed <= x26;
		end
		5'd27: begin
			array_muxed <= x27;
		end
		5'd28: begin
			array_muxed <= x28;
		end
		5'd29: begin
			array_muxed <= x29;
		end
		5'd30: begin
			array_muxed <= x30;
		end
		default: begin
			array_muxed <= x31;
		end
	endcase
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end

endmodule
