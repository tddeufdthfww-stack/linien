from pathlib import Path
import hashlib,json,re,subprocess
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r44-scope-factor-cache');old=Path('D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution')
a=(old/'gateware/verilog/red_pitaya_scope.v').read_text(encoding='utf-8');b=(r/'gateware/verilog/red_pitaya_scope.v').read_text(encoding='utf-8')
prior_helper=a[a.index('// Purely combinational:'):];assert prior_helper in b
reconstructed=b[:b.index('// Parallel configuration metadata;')]
start=reconstructed.index('wire [4:0] scope_dec_shift_next;');end=reconstructed.index('always @(posedge sys_clk_i) begin',start)
reconstructed=reconstructed[:start]+reconstructed[end:]
for line in ('      scope_dec_shift_source <= scope_dec_shift_next;\n','      scope_dec_zero_source <= scope_dec_zero_next;\n','reg [4:0] set_dec_shift;\n','reg set_dec_zero;\n',"      set_dec_shift <= 5'd0;\n","      set_dec_zero <= 1'b0;\n"):
 assert reconstructed.count(line)==1,line
 reconstructed=reconstructed.replace(line,'')
before='''         if (scope_addr_match[5]) begin
            set_dec <= wdata[32-1:0];
            set_dec_shift <= scope_dec_shift_source;
            set_dec_zero <= scope_dec_zero_source;
         end'''
assert reconstructed.count(before)==1
reconstructed=reconstructed.replace(before,'         if (scope_addr_match[5]) set_dec <= wdata[32-1:0];')
assert reconstructed.count('scope_average_cached average_select_')==4
reconstructed=reconstructed.replace('scope_average_cached average_select_','scope_average_select average_select_').replace('.shift_i(set_dec_shift),.zero_i(set_dec_zero)','.dec_i(set_dec)')
assert re.sub(r'\s+','',reconstructed)==re.sub(r'\s+','',a),'Unexpected Scope control/data/CSR/reset change'
unchanged=['tools/check_scope_average.py','tools/check_scope_predecode.py','gateware/verilog/bus_clk_bridge.v','gateware/verilog/axi_slave.v','gateware/logic/iir.py','gateware/logic/pid.py','gateware/logic/chains.py','gateware/logic/autolock_pipeline.py','gateware/linien_module.py','gateware/lowlevel/crg.py','gateware/lowlevel/pitaya_ps.py','gateware/hw_platform.py']
for n in unchanged:assert (r/n).read_bytes()==(old/n).read_bytes(),n
precheck=r/'gateware/build/scope_factor_cache_precheck/results.json'
native=json.loads(precheck.read_text());assert native['passed'] and native['parallel_metadata_bits']==12
assert native['scalar']['passed'] and native['scalar']['known_cases']==161872 and native['scalar']['unknown_cases']==3000
rec={'passed':True,'source_inverse_transform_matches_original_Scope_ignoring_whitespace':True,'original_average_helper_sha256_unchanged':hashlib.sha256(prior_helper.encode()).hexdigest(),'old_tests_and_unrelated_sources_exact_raw_bytes_unchanged':unchanged,'new_parallel_metadata_bits':12,'new_ADC_CSR_trigger_serial_cycles':0,'native_precheck':native,'mathematical_preanalysis':json.loads((h/'r44_mathematical_preanalysis.json').read_text()),'scope':'Source inverse audit + actual native scalar/frozen full Scope and source/target cohort checks. Native exhaustive20bit-address, metastability/independent-reset/fullRoot SDF and physical CDC are NOT_PROVEN.'}
(h/'r44_source_and_native_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R44_SOURCE_COHORT_AND_NATIVE_PRECHECK_AUDIT_PASS')
