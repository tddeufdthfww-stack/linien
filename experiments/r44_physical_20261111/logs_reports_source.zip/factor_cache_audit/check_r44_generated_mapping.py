from pathlib import Path
import collections,hashlib,json,re
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r44-scope-factor-cache');trial=r/'gateware/build/trials/20261111_114517_r44_scope_factor_cache'
m=json.loads((h/'r44_mapped/metrics.json').read_text());rows=m['scope_factor_cache_registers'];assert rows
src=[v for v in rows if '/scope_dec_' in v['cell']];dst=[v for v in rows if '/set_dec_' in v['cell']]
assert all(v['clock']=='clk_fpga_0' for v in src) and all(v['clock']=='clk_2' for v in dst)
for label,group in [('source',src),('target',dst)]:
 shift=[v for v in group if 'shift' in v['cell']];zero=[v for v in group if 'zero' in v['cell']]
 indices={int(re.search(r'\[(\d+)\]',v['cell'])[1]) for v in shift}
 assert indices==set(range(5)) and zero,(label,indices,zero)
 assert all(v['ref'] in ('FDRE','FDSE') for v in group)
prior=Path('D:/RP_Dev/linien_trials/20261111-r41-scope-source-predecode/gateware/build/trials/20261111_105510_r41_scope_source_predecode')
for n in ('top.v','top.xdc','csrmap.py'):assert (trial/n).read_bytes()==(prior/n).read_bytes(),n
record={'passed':True,'top_verilog_CSR_XDC_bytes_identical_R41':True,'new_parallel_metadata_bits_RTL':12,'physical_metadata_FF_count':len(rows),'source_FCLK_FF_count':len(src),'target_ADC_FF_count':len(dst),'physical_ref_counts':dict(collections.Counter(v['ref'] for v in rows)),'logical_all_shift_bits_and_zero_flag_present_both_domains':True,'native_full_suite':'PASS','new_serial_ADC_CSR_Scope_trigger_cycles':0,'source_and_target_cache_paths_reported_separately':{k:m[k] for k in ('scope_factor_source_to','scope_factor_source_from','scope_factor_target_to','scope_factor_target_from','scope_factor_to_data')},'physical_CDC':'NOT_PROVEN','fullRoot_SDF_formal':'NOT_RUN'}
(h/'r44_generated_mapping_audit.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print('R44_ACTUAL_SOURCE_TARGET_CACHE_MAPPING_AND_CSR_XDC_PASS',len(src),len(dst))
