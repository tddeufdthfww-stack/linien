if {[catch {
set_param general.maxThreads 2
open_checkpoint {D:/RP_Dev/linien_trials/20261110-r28-pid-output-bitdecode/gateware/build/trials/20261110_193543_r28_pid_output_bitdecode/routed.dcp}
report_timing_summary -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/input_routed_timing.rpt}
phys_opt_design -fanout_opt -placement_opt -routing_opt -rewire -critical_cell_opt
route_design -directive Explore -tns_cleanup
report_route_status -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_status.rpt}
report_timing_summary -max_paths 30 -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_timing.rpt}
report_timing -max_paths 100 -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_setup.rpt}
report_timing -delay_type min -max_paths 30 -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_hold.rpt}
report_utilization -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_utilization.rpt}
check_timing -verbose -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_checks.rpt}
report_cdc -details -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_cdc.rpt}
report_drc -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_drc.rpt}
report_clock_interaction -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_clocks.rpt}
report_exceptions -file {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed_exceptions.rpt}
write_checkpoint {D:/RP_Dev/linien_trials/20261110-r29-postroute-fanout/gateware/build/trials/20261110_200152_r29_postroute_fanout/routed.dcp}
puts POSTROUTE_TRIAL_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
