if {[catch {
open_checkpoint {D:/RP_Dev/linien_trials/20261106-ce-saturation/gateware/build/trials/20261109_100550_ce_sat_bits/routed.dcp}
set f [open {D:/RP_Dev/linien_trials/20261109-r3-fast-front/gateware/build/r3_dsp_audit/connections.txt} w]
foreach c [get_cells -hier -filter {REF_NAME == DSP48E1 && (LOC == DSP48_X2Y25 || LOC == DSP48_X2Y24)}] {
 puts $f "DSP $c"
 foreach prop {AREG BREG MREG PREG CREG DREG ADREG USE_DPORT USE_MULT USE_SIMD A_INPUT B_INPUT} {puts $f "$prop=[get_property $prop $c]"}
 foreach p [get_pins -of_objects $c -filter {DIRECTION == IN}] {
  set net [get_nets -of_objects $p]
  set drivers [get_pins -quiet -of_objects $net -filter {DIRECTION == OUT}]
  puts $f "[get_property REF_PIN_NAME $p] NET=$net DRIVER=$drivers"
 }
}
close $f
puts R3_DSP_AUDIT_COMPLETE

} msg opts]} {
puts stderr "ERROR: $msg"
puts stderr [dict get $opts -errorinfo]
exit 3
}
exit 0
