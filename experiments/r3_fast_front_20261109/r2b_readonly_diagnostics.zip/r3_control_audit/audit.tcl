if {[catch {
open_checkpoint {D:/RP_Dev/linien_trials/20261106-ce-saturation/gateware/build/trials/20261109_100550_ce_sat_bits/routed.dcp}
set f [open {D:/RP_Dev/linien_trials/20261109-r3-fast-front/gateware/build/r3_control_audit/lut_connections.txt} w]
foreach c [get_cells -hier -filter {NAME =~ *slow_chain_pid_int_reg* && REF_NAME =~ LUT*}] {
 puts $f "$c [get_property REF_NAME $c] INIT=[get_property INIT $c]"
 foreach p [get_pins -of_objects $c -filter {DIRECTION == IN}] {
  set net [get_nets -of_objects $p]
  set drivers [get_pins -quiet -of_objects $net -filter {DIRECTION == OUT}]
  puts $f "  [get_property REF_PIN_NAME $p] NET=$net DRIVER=$drivers"
 }
}
foreach c [get_cells -hier -filter {NAME =~ *slow_chain_pid_int_reg_reg* && REF_NAME =~ FD*}] {
 foreach p [get_pins -of_objects $c -filter {REF_PIN_NAME == S || REF_PIN_NAME == R || REF_PIN_NAME == CE}] {
  set net [get_nets -of_objects $p];puts $f "$p NET=$net"
 }
}
close $f
puts R3_CONTROL_AUDIT_COMPLETE

} msg opts]} {
puts stderr "ERROR: $msg"
puts stderr [dict get $opts -errorinfo]
exit 3
}
exit 0
