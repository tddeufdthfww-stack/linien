open_checkpoint {D:/RP_Dev/linien_trials/20261106-ce-saturation/gateware/build/trials/20261109_100550_ce_sat_bits/routed.dcp}
set out {D:/RP_Dev/linien_trials/20261109-r3-fast-front/gateware/build/r3_baseline_readonly_v3}
set f [open "$out/pin_inventory.txt" w]
foreach scope {integrator all_pid} {
 foreach group {fast slow} {
  if {$group eq "fast"} {set pattern *logic_pid_*} else {set pattern *slow_chain_pid_*}
  set cells [get_cells -hier -filter "REF_NAME =~ FD* && NAME =~ $pattern"]
  if {$scope eq "integrator"} {set cells [filter $cells {NAME =~ *int_reg_reg*}]}
  puts $f "$scope $group CELLS [llength $cells]"
  foreach pin {D S R CE} {
   set ends [get_pins -quiet -of_objects $cells -filter "REF_PIN_NAME == $pin"]
   puts $f "$scope $group $pin PINS [llength $ends]"
   if {[llength $ends]} {
    report_timing -delay_type max -max_paths 20 -to $ends -file "$out/${scope}_${group}_${pin}.rpt"
   }
  }
 }
}
close $f
set f [open "$out/dsp_registers.txt" w]
foreach c [get_cells -hier -filter {REF_NAME == DSP48E1}] {
 puts $f "[get_property NAME $c] LOC=[get_property LOC $c] AREG=[get_property AREG $c] BREG=[get_property BREG $c] MREG=[get_property MREG $c] PREG=[get_property PREG $c]"
}
close $f
# Record logic functions in the actual first path, rather than infer from names.
set f [open "$out/critical_cells.txt" w]
foreach group {fast slow} {
 if {$group eq "fast"} {set pattern *logic_pid_int_reg_reg*} else {set pattern *slow_chain_pid_int_reg_reg*}
 set cells [get_cells -hier -filter "REF_NAME =~ FD* && NAME =~ $pattern"]
 foreach pin {D S R CE} {
  set ends [get_pins -quiet -of_objects $cells -filter "REF_PIN_NAME == $pin"]
  if {![llength $ends]} {continue}
  set paths [get_timing_paths -quiet -max_paths 1 -to $ends]
  foreach path $paths {
   puts $f "GROUP $group $pin"
   set end [get_property ENDPOINT_PIN $path]
   foreach c [all_fanin -flat -levels 2 -only_cells -to $end] {
    set ref [get_property REF_NAME $c]
    if {[string match LUT* $ref]} {puts $f "$c $ref INIT=[get_property INIT $c]"} else {puts $f "$c $ref"}
   }
  }
 }
}
close $f
puts R3_BASELINE_READONLY_COMPLETE
exit 0
