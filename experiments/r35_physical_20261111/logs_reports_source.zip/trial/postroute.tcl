if {[catch {
set_param general.maxThreads 2
open_checkpoint {D:/RP_Dev/linien_trials/20261110-r34-gpio-status-pipeline/gateware/build/trials/20261110_225335_r34_gpio_status_pipeline/routed.dcp}
report_timing_summary -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/input_routed_timing.rpt}
# Explicitly return the in-memory design to post-place state before forcing
# replication; no unsupported post-route fanout_opt call is made.
route_design -unroute
report_route_status -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/unrouted_status.rpt}
set chosen {}
set log [open {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/index_replication_before.tsv} w]
puts $log "cell	ref	net	loads"
foreach c [get_cells -hier -quiet -filter {NAME =~ *current_instruction_idx_reg* && REF_NAME =~ FD*}] {
    set q [get_pins -quiet -of_objects $c -filter {REF_PIN_NAME == Q}]
    set nets [get_nets -quiet -of_objects $q]
    foreach n $nets {
        set loads [llength [get_pins -quiet -of_objects $n -filter {DIRECTION == IN}]]
        puts $log "$c	[get_property REF_NAME $c]	$n	$loads"
        if {$loads >= 64} {lappend chosen $n}
    }
}
close $log
if {![llength $chosen]} {error "No high-fanout index driver found"}
puts "FORCE_REPLICATION_SELECTED $chosen"
write_checkpoint {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/placed_before_replication.dcp}
phys_opt_design -force_replication_on_nets $chosen
write_checkpoint {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/placed_after_replication.dcp}
set log [open {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/index_replication_after.tsv} w]
puts $log "cell	ref	net	loads"
foreach c [get_cells -hier -quiet -filter {NAME =~ *current_instruction_idx_reg* && REF_NAME =~ FD*}] {
    foreach n [get_nets -quiet -of_objects [get_pins -quiet -of_objects $c -filter {REF_PIN_NAME == Q}]] {
        puts $log "$c	[get_property REF_NAME $c]	$n	[llength [get_pins -quiet -of_objects $n -filter {DIRECTION == IN}]]"
    }
}
close $log
phys_opt_design -placement_opt -rewire -critical_cell_opt
route_design -directive Explore -tns_cleanup
report_route_status -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_status.rpt}
report_timing_summary -max_paths 30 -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_timing.rpt}
report_timing -max_paths 100 -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_setup.rpt}
report_timing -delay_type min -max_paths 30 -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_hold.rpt}
report_utilization -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_utilization.rpt}
check_timing -verbose -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_checks.rpt}
report_cdc -details -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_cdc.rpt}
report_drc -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_drc.rpt}
report_clock_interaction -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_clocks.rpt}
report_exceptions -file {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed_exceptions.rpt}
write_checkpoint {D:/RP_Dev/linien_trials/20261110-r35-index-driver-replication/gateware/build/trials/20261110_231828_r35_index_driver_replication/routed.dcp}
puts POSTROUTE_TRIAL_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
