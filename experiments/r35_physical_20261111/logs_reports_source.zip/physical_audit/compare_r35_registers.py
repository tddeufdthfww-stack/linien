from pathlib import Path
import collections,csv,json
h=Path(__file__).parent
def parse(p):
    result={}
    for block in p.read_text().split('CELL_BEGIN')[1:]:
        d=dict(s.split('=',1) for s in block.splitlines() if '=' in s)
        result[d['NAME']]={k:v for k,v in d.items() if k not in ('LOC','BEL')}
    return result
a=parse(h/'r34_mapped/all_dsp.txt');b=parse(h/'r35_mapped/all_dsp.txt')
assert len(a)==len(b)==94
changes={k:{'old':a.get(k),'new':b.get(k)} for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}
assert not changes,changes
t=Path(json.loads((h/'r35_mapped/metrics.json').read_text())['trial'])
before=list(csv.DictReader((t/'index_replication_before.tsv').open(),delimiter='\t'))
after=list(csv.DictReader((t/'index_replication_after.tsv').open(),delimiter='\t'))
rec={'passed':True,'DSP_count':94,'all_DSP_register_and_operating_properties_identical_ignoring_LOC_BEL':True,'DSP_changes':changes,'index_driver_rows_before':before,'index_driver_rows_after':after,'index_driver_count_before':len(before),'index_driver_count_after':len(after),'new_serial_edges':0,'scope':'Same RTL/test raw hashes and legal FF replication/physical flags; mapped DSP register props unchanged. Not postroute/SDF/full-root formal equivalence or board test.'}
(h/'r35_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
print('R35_ALL94_DSP_REGISTERS_IDENTICAL_AND_INDEX_REPLICATION_LOGGED_PASS',len(before),len(after))
