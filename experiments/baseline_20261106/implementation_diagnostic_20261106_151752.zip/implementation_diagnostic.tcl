# Diagnostic-only implementation: never calls write_bitstream.
set out {D:/RP_Dev/linien-v2.1.0/gateware/build/reports/implementation_diagnostic_20261106_151752}
set stage OPEN_CHECKPOINT
if {[catch {
    puts "[clock format [clock seconds]] : Opening current synthesis checkpoint"
    open_checkpoint {D:/RP_Dev/linien-v2.1.0/gateware/build/top_synth_first.dcp}

    set stage OPT_DESIGN
    puts "STEP_OPT_DESIGN_START"
    opt_design

    set stage PLACE_DESIGN
    puts "STEP_PLACE_DESIGN_START"
    place_design
    report_timing_summary -max_paths 20 -file "$out/placed_timing_summary.rpt"
    report_utilization -file "$out/placed_utilization.rpt"
    report_drc -file "$out/placed_drc.rpt"
    write_checkpoint -force "$out/placed.dcp"
    puts "STEP_PLACE_DESIGN_PASS"

    set stage PHYS_OPT_DESIGN
    puts "STEP_PHYS_OPT_DESIGN_START"
    phys_opt_design
    report_timing_summary -max_paths 20 -file "$out/physopt_timing_summary.rpt"
    puts "STEP_PHYS_OPT_DESIGN_PASS"

    set stage ROUTE_DESIGN
    puts "STEP_ROUTE_DESIGN_START"
    route_design
    report_timing_summary -max_paths 30 -file "$out/routed_timing_summary.rpt"
    report_timing -delay_type max -max_paths 30 -file "$out/routed_setup_paths.rpt"
    report_timing -delay_type min -max_paths 30 -file "$out/routed_hold_paths.rpt"
    report_clock_interaction -file "$out/routed_clock_interaction.rpt"
    check_timing -verbose -file "$out/routed_timing_checks.rpt"
    report_cdc -details -file "$out/routed_cdc.rpt"
    report_drc -file "$out/routed_drc.rpt"
    report_utilization -file "$out/routed_utilization.rpt"
    write_checkpoint -force "$out/routed.dcp"
    puts "STEP_ROUTE_DESIGN_PASS"
    puts "IMPLEMENTATION_DIAGNOSTIC_FLOW_PASS"
} msg opts]} {
    puts stderr "IMPLEMENTATION_STAGE_FAILED: $stage"
    puts stderr "DETAIL: $msg"
    exit 3
}
exit 0