from pathlib import Path
import hashlib,json,re
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r46-prefetch-negative-fold');t=r/'gateware/build/trials/20261111_121804_r46_prefetch_negative_fold'
old=Path('D:/RP_Dev/linien_trials/20261111-r44-scope-factor-cache/gateware/build/trials/20261111_114517_r44_scope_factor_cache')
text=(t/'top.v').read_text();found={}
for label in ('current','next','zero'):
 pattern=r'reg signed \[28:0\] (\w*prefetch_'+label+r'_negative\w*) = 29\x27sd0;'
 matches=re.findall(pattern,text);assert len(matches)==1,(label,matches)
 name=matches[0]
 assign=re.findall(r'\b'+re.escape(name)+r' <= (\{[^;]+\});',text)
 assert len(assign)==1 and 'negative_sign' in assign[0] and 'negative_low' in assign[0],(name,assign)
 found[label]={'register':name,'input_expression':assign[0],'width':29,'reset':0}
for n in ('top.xdc','csrmap.py'):assert (t/n).read_bytes()==(old/n).read_bytes(),n
native=json.loads((t/'instruction_prefetch_checks/results.json').read_text());assert native['passed'] and [v['cycles'] for v in native['results']]==[63520,63648,63648]
parent=json.loads((t/'autolock_pipeline_checks/results.json').read_text());assert parent['original_R28_vectors_preserved']==50076 and parent['indices_visited']==32 and parent['prefetch_choice_valid_every_cycle']
audit={'passed':True,'actual_three_negative_banks_and_concat_sources':found,'negative_width_reset_and_cohort_registers_preserved':True,'CSR_XDC_exact_R44':True,'top_sha256':hashlib.sha256((t/'top.v').read_bytes()).hexdigest(),'full_native_prefetch':native,'parent_native':parent,'source_inverse_math_audit':json.loads((h/'r46_source_native_audit.json').read_text()),'new_serial_ADC_robust_GPIO_CSR_cycles':0,'scope':'Generated root wiring and native full parent fixture; actual MSB/low-bit carry mapping and route/CDC are separate, no physical success inferred here.'}
(h/'r46_generated_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8');print('R46_GENERATED_NEGATIVE_CONCAT_FSM_CSR_XDC_NATIVE_PASS')
