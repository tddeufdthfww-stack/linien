from pathlib import Path
import json,re
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r46-prefetch-negative-fold');old=Path('D:/RP_Dev/linien_trials/20261111-r44-scope-factor-cache')
s=(r/'gateware/logic/instruction_prefetch.py').read_text(encoding='utf-8')
s=s.replace('from migen import Array, Case, Cat, Constant, If, Signal','from migen import Array, Case, Constant, If, Signal')
s=s.replace('        negative_low = Signal((width, True))\n        negative_sign = Signal()','        extended = Signal((width + 1, True))')
start=s.index('                        If(raw < 0, negative_low.eq(raw))');end=s.index('        module.sync +=',start)
s=s[:start]+'                        extended.eq(absolute)]\n'+s[end:]
s=s.replace('negative.eq(Cat(negative_low, negative_sign))','negative.eq(-extended)')
assert s==(old/'gateware/logic/instruction_prefetch.py').read_text(encoding='utf-8')
for n in ('gateware/logic/autolock_pipeline.py','gateware/logic/abs_threshold.py','gateware/logic/iir.py','gateware/logic/pid.py','gateware/logic/chains.py','gateware/linien_module.py','gateware/verilog/red_pitaya_scope.v','gateware/verilog/bus_clk_bridge.v','gateware/verilog/axi_slave.v','tools/check_instruction_prefetch.py','tools/check_autolock_pipeline.py','tools/check_scope_factor_cache.py','tools/run_gateware_trial.py'):
 assert (r/n).read_bytes()==(old/n).read_bytes(),n
native=json.loads((r/'gateware/build/prefetch_negative_precheck/results.json').read_text());assert native['passed'] and [v['cycles'] for v in native['results']]==[63520,63648,63648]
rec={'passed':True,'inverse_exact_original_source':True,'only_negative_input_combinational_arithmetic_changes':True,'original_FSM_CSR_choice_magnitude_positive_wait_IIR_PID_Root_Scope_AXI_CDC_fixtures_unchanged':True,'native_precheck':native,'math':json.loads((h/'r46_mathematical_preanalysis.json').read_text()),'new_serial_ADC_robust_GPIO_CSR_cycles':0,'scope':'Source inverse audit and unchanged original whole-bank/fixed integer native fixture. Not full Root/postroute/SDF/physical CDC proof.'}
(h/'r46_source_native_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R46_ONLY_NEGATIVE_COMB_CHANGE_AND_UNCHANGED_NATIVE_FIXTURES_PASS')
