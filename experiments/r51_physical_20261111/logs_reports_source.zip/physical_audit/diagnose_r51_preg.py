from pathlib import Path
h=Path(__file__).parent;p=h/'check_r51_registers.py';s=p.read_text(encoding='utf-8');(h/'check_r51_registers_initial_strict.py').write_bytes(p.read_bytes())
s=s.replace("assert len(a)==len(b)==94 and a==b","assert len(a)==len(b)==94 and set(a)==set(b)\ndiff={k:{'before':a[k],'after':b[k]} for k in a if a[k]!=b[k]}\nassert set(diff)=={'p_1_out'} and a['p_1_out']['PREG']=='0' and b['p_1_out']['PREG']=='1'\nassert {k:v for k,v in a['p_1_out'].items() if k!='PREG'}=={k:v for k,v in b['p_1_out'].items() if k!='PREG'}")
s=s.replace("'passed':True,'all_94_DSP_register_and_operating_properties_same_R50_ignoring_LOC_BEL':True", "'passed':False,'audit_execution_complete':True,'mapping_invariance':'FAIL_ONE_UNEXPECTED_PID_DSP_PREG_CHANGE','all_94_DSP_register_and_operating_properties_same_R50_ignoring_LOC_BEL':False,'other_93_DSP_properties_identical':True,'actual_DSP_property_difference':diff,'postmap_cycle_equivalence':'NOT_PROVEN; rejected candidate, do not infer a serial-cycle result solely from source identity'")
s=s.replace("'new_serial_data_feedback_CSR_cycles':0", "'RTL_new_serial_cycles_target':0,'postmap_new_serial_cycles_verified':False")
s=s.replace("print('R51_ALL94_DSP_AND_ACTUAL86_COLUMN_MEMBERS_AUDIT_PASS')", "print('R51_AUDIT_COMPLETE_WITH_PREG_INVARIANCE_FAIL; 86_COLUMN_MEMBERS_PASS; 93_DSP_IDENTICAL')")
p.write_bytes(s.encode());print('R51_DIAGNOSTIC_COLLECTOR_PRESERVES_STRICT_FAIL')
p=h/'record_round.py';s=p.read_text(encoding='utf-8');start=s.index("if label=='r51':\n    assert manifest");end=s.index("(exp/'metrics.json').write_bytes",start);block=s[start:end]
block=block.replace("m['serial_ADC_robust_GPIO_CSR_cycles_added_this_round']=0", "m['serial_ADC_robust_GPIO_CSR_cycles_added_this_round']={'RTL_target':0,'postmap':'NOT_PROVEN_PREG_CHANGE'}\n    m['mapping_contract']='FAIL_ONE_UNEXPECTED_PID_DSP_PREG_CHANGE; rejected, not merged'")
s=s[:start]+block+s[end:]
s=s.replace("('r51_physical_register_audit.json','check_r51_registers.py')", "('r51_physical_register_audit.json','check_r51_registers.py','check_r51_registers_initial_strict.py','diagnose_r51_preg.py')")
needle="verdict='REJECTED"
extra="if label=='r51':\n    functional+='；实际映射不变性审计FAIL：93个DSP属性相同，PID p_1_out 的PREG0→1，IIR86成员参数/列位置PASS；Explore布局器默认映射变化不等于本轮新插一拍，但本轮未完成postmap周期等价证明，不能声称全部DSP不变或映射周期已验证。原生PASS仅覆盖输入RTL；该候选拒绝，不用于后续基线。'\n    latency='RTL新增串行周期目标0；实际PID PREG变化，postmap周期等价NOT_PROVEN；原数字组件模型只继承，不能当作本轮实际映射测量'\n"
assert needle in s;s=s.replace(needle,extra+needle,1);p.write_bytes(s.encode())
