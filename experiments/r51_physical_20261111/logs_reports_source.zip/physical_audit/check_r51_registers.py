from pathlib import Path
import csv,json,re
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r51-iir-column-placement');t=r/'gateware/build/trials/20261111_135844_r51_iir_column_compatible_v2'
m=json.loads((t/'manifest.json').read_text());assert m['route']=='COMPLETE' and m['placement']=='COMPLETE' and m['input_r50_dcps_unchanged'] and not m['source_changes_during_run'] and all(m['r50_code_and_test_hash_matches'].values())
def parse(p):
 d={}
 for b in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in b.splitlines() if '=' in s);d[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return d
a=parse(h/'r50_mapped/all_dsp.txt');b=parse(h/'r51_mapped/all_dsp.txt');assert len(a)==len(b)==94 and set(a)==set(b)
diff={k:{'before':a[k],'after':b[k]} for k in a if a[k]!=b[k]}
assert set(diff)=={'p_1_out'} and a['p_1_out']['PREG']=='0' and b['p_1_out']['PREG']=='1'
assert {k:v for k,v in a['p_1_out'].items() if k!='PREG'}=={k:v for k,v in b['p_1_out'].items() if k!='PREG'}
prior=Path(m['input_r50_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(prior/n).read_bytes(),n
assign=list(csv.DictReader((t/'column_assignment.tsv').open(),delimiter='\t'));sites=list(csv.DictReader((t/'dsp_columns.tsv').open(),delimiter='\t'));members=list(csv.DictReader((t/'routed_pblock_members.tsv').open(),delimiter='\t'))
assert sum(int(d['capacity']) for d in sites)==220
expected={'fast_a':32,'fast_b':32,'raw':22};groups={}
for d in assign:
 kind=d['group'];col=d['column'];group=[v for v in members if v['group']==kind];assert len(group)==expected[kind]==int(d['DSPcount'])
 assert all(re.match(r'^DSP48_X'+col+r'Y\d+$',v['LOC']) for v in group)
 assert len({v['cell'] for v in group})==len(group)
 groups[kind]={'column':int(col),'count':len(group),'cells':group}
assert len({d['column'] for d in assign})==3 and len(members)==86
rec={'passed':False,'audit_execution_complete':True,'mapping_invariance':'FAIL_ONE_UNEXPECTED_PID_DSP_PREG_CHANGE','all_94_DSP_register_and_operating_properties_same_R50_ignoring_LOC_BEL':False,'other_93_DSP_properties_identical':True,'actual_DSP_property_difference':diff,'postmap_cycle_equivalence':'NOT_PROVEN; rejected candidate, do not infer a serial-cycle result solely from source identity','raw_87_hardware_test_inputs_same_R50':True,'generated_top_CSR_XDC_bytes_same_R50':True,'actual_DSP_column_inventory':sites,'routed_hard_column_groups':groups,'new_physical_placement_constraints':'Three hard pblocks, DSP cells/sites only. This is a physical placement change; timing requirements/exceptions unchanged.','RTL_new_serial_cycles_target':0,'postmap_new_serial_cycles_verified':False,'both_input_DCP_SHA_unchanged':True,'scope':'Full native/synthesis inherited R50, NOT RERUN. New opt/place/physical/route and mapped parameter/column audit. Not fullRoot SDF/formal/physical CDC proof; R50 rejected route not a baseline promotion.'}
(h/'r51_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R51_AUDIT_COMPLETE_WITH_PREG_INVARIANCE_FAIL; 86_COLUMN_MEMBERS_PASS; 93_DSP_IDENTICAL')
