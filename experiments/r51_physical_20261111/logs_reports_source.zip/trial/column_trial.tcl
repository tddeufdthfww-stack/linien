if {[catch {
set out {D:/RP_Dev/linien_trials/20261111-r51-iir-column-placement/gateware/build/trials/20261111_135844_r51_iir_column_compatible_v2}
set prior {D:/RP_Dev/linien_trials/20261111-r50-iir-output-edge/gateware/build/trials/20261111_132300_r50_iir_output_edge}

set_param general.maxThreads 2
proc groups {} {
    set result [dict create fast_a {} fast_b {} raw {}]
    foreach c [get_cells -hier -quiet -filter {REF_NAME == DSP48E1}] {
        set pp [get_pins -quiet -of_objects $c -filter {DIRECTION == OUT}]
        set nets [get_nets -quiet -of_objects $pp]
        foreach kind {fast_a fast_b raw} {
            if {$kind eq "raw"} {set hits [filter $nets {NAME =~ *raw_acquisition_iir* || NAME =~ linienmodule_iir_* || NAME =~ linienmodule_logic_iir_*}]
            } else {set hits [filter $nets "NAME =~ linienmodule_${kind}_iir*"]}
            if {[llength $hits]} {dict lappend result $kind [get_property NAME $c]}
        }
    }
    foreach {kind count} {fast_a 32 fast_b 32 raw 22} {
        if {[llength [dict get $result $kind]] != $count} {error "DSP group $kind count differs from frozen R50: [llength [dict get $result $kind]]"}
    }
    return $result
}
open_checkpoint "$prior/routed.dcp"
set originalGroups [groups]
set inventory [dict create]
foreach site [get_sites -filter {SITE_TYPE == DSP48E1}] {
    if {![regexp {DSP48_X([0-9]+)Y([0-9]+)$} [get_property NAME $site] -> x y]} {error "Unexpected DSP site $site"}
    dict lappend inventory $x $y
}
set cols [lsort -integer [dict keys $inventory]]
set f [open "$out/dsp_columns.tsv" w];puts $f "column\tcapacity\tminY\tmaxY"
foreach x $cols {set ys [lsort -integer [dict get $inventory $x]];puts $f "$x\t[llength $ys]\t[lindex $ys 0]\t[lindex $ys end]"};close $f
set originalXs [dict create]
foreach kind {fast_a fast_b raw} {
    foreach c [dict get $originalGroups $kind] {
        if {![regexp {DSP48_X([0-9]+)Y([0-9]+)$} [get_property LOC [get_cells $c]] -> x y]} {error "Unplaced input DSP $c"}
        dict lappend originalXs $kind $x
    }
}
set bestCost 1000000;set assignment {}
foreach a $cols {foreach b $cols {foreach c $cols {
    if {$a==$b || $a==$c || $b==$c} {continue}
    if {[llength [dict get $inventory $a]]<32 || [llength [dict get $inventory $b]]<32 || [llength [dict get $inventory $c]]<22} {continue}
    set cost 0
    foreach kind {fast_a fast_b raw} target [list $a $b $c] {foreach x [dict get $originalXs $kind] {incr cost [expr {abs($x-$target)}]}}
    if {$cost<$bestCost} {set bestCost $cost;set assignment [dict create fast_a $a fast_b $b raw $c]}
}}}
if {[dict size $assignment]!=3} {error "No legal distinct column assignment from actual sites"}
puts "IIR_COLUMN_SELECTION $assignment relocation_cost=$bestCost"
set f [open "$out/column_assignment.tsv" w];puts $f "group\tcolumn\tDSPcount\tminY\tmaxY"
foreach kind {fast_a fast_b raw} {set x [dict get $assignment $kind];set ys [lsort -integer [dict get $inventory $x]];puts $f "$kind\t$x\t[llength [dict get $originalGroups $kind]]\t[lindex $ys 0]\t[lindex $ys end]"};close $f
close_project
open_checkpoint "$prior/synth.dcp"
opt_design
set newGroups [groups]
set f [open "$out/pblock_members.tsv" w];puts $f "group\tcell"
foreach kind {fast_a fast_b raw} {
    if {[lsort [dict get $originalGroups $kind]] ne [lsort [dict get $newGroups $kind]]} {error "Synthesis/routed group member mismatch $kind"}
    set x [dict get $assignment $kind];set ys [lsort -integer [dict get $inventory $x]]
    set pb [create_pblock "IIR_COLUMN_$kind"]
    add_cells_to_pblock $pb [get_cells [dict get $newGroups $kind]]
    resize_pblock $pb -add "DSP48_X${x}Y[lindex $ys 0]:DSP48_X${x}Y[lindex $ys end]"
    set_property IS_SOFT false $pb
    foreach c [dict get $newGroups $kind] {puts $f "$kind\t$c"}
};close $f
place_design -directive Explore
puts IIR_COLUMN_PLACE_ONLY_COMPLETE
phys_opt_design -placement_opt -rewire -critical_cell_opt
report_timing_summary -file "$out/postopt_timing.rpt"
write_checkpoint "$out/placed.dcp"
puts IIR_COLUMN_PLACEMENT_COMPLETE
route_design -directive Explore -tns_cleanup
set f [open "$out/routed_pblock_members.tsv" w];puts $f "group\tcell\tLOC"
foreach kind {fast_a fast_b raw} {
    set x [dict get $assignment $kind]
    foreach c [dict get $newGroups $kind] {
        set loc [get_property LOC [get_cells $c]]
        if {![regexp "^DSP48_X${x}Y" $loc]} {error "DSP escaped hard column pblock: $kind $c $loc"}
        puts $f "$kind\t$c\t$loc"
    }
};close $f
report_route_status -file "$out/routed_status.rpt"
report_timing_summary -max_paths 30 -file "$out/routed_timing.rpt"
report_timing -max_paths 100 -file "$out/routed_setup.rpt"
report_timing -delay_type min -max_paths 30 -file "$out/routed_hold.rpt"
report_utilization -file "$out/routed_utilization.rpt"
check_timing -verbose -file "$out/routed_checks.rpt"
report_cdc -details -file "$out/routed_cdc.rpt"
report_drc -file "$out/routed_drc.rpt"
report_clock_interaction -file "$out/routed_clocks.rpt"
report_exceptions -file "$out/routed_exceptions.rpt"
write_checkpoint "$out/routed.dcp"
puts IIR_COLUMN_TRIAL_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
