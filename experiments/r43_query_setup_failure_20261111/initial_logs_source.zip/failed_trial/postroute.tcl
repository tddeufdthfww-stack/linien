if {[catch {
set_param general.maxThreads 2
open_checkpoint {D:/RP_Dev/linien_trials/20261111-r41-scope-source-predecode/gateware/build/trials/20261111_105510_r41_scope_source_predecode/routed.dcp}
report_timing_summary -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/input_routed_timing.rpt}
# Explicitly return the in-memory design to post-place state before forcing
# replication; no unsupported post-route fanout_opt call is made.
route_design -unroute
report_route_status -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/unrouted_status.rpt}
proc csr_cells {} {
 return [get_cells -hier -quiet -filter {NAME =~ linienmodule_csr_dat_w_reg* && REF_NAME =~ FD*}]
}
proc csr_table {file} {
 set f [open $file w]
 puts $f "cell	ref	D	C	CE	R	INIT	ASYNC_REG	DONT_TOUCH	Q_net	loads	load_pins"
 foreach c [lsort [csr_cells]] {
  set values [list $c [get_property REF_NAME $c]]
  foreach pin {D C CE R} {lappend values [get_nets -quiet -of_objects [get_pins -quiet -of_objects $c -filter "REF_PIN_NAME == $pin"]]}
  foreach prop {INIT ASYNC_REG DONT_TOUCH} {lappend values [get_property $prop $c]}
  set qn [get_nets -quiet -of_objects [get_pins -quiet -of_objects $c -filter {REF_PIN_NAME == Q}]]
  set pins [lsort [get_pins -quiet -of_objects $qn -filter {DIRECTION == IN}]]
  lappend values $qn [llength $pins] [join $pins "|"]
  puts $f [join $values "	"]
 };close $f
}
csr_table {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/csr_replication_before.tsv}
set chosen {}
foreach c [csr_cells] {
 set cp [get_pins -of_objects $c -filter {REF_PIN_NAME == C}]
 if {[get_clocks -of_objects $cp] ne "clk_2"} {error "CSR data is not ADC-clocked: $c"}
 if {[get_property ASYNC_REG $c] eq "1"} {error "Refuse synchronizer replication: $c"}
 set ce [get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == CE}]]
 set cedrv [get_cells -quiet -of_objects [get_pins -quiet -of_objects $ce -filter {DIRECTION == OUT}]]
 if {[get_property REF_NAME $cedrv] ne "VCC"} {error "CSR data CE is not constant1: $c"}
 foreach n [get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == Q}]] {
  if {[llength [get_pins -of_objects $n -filter {DIRECTION == IN}]] >= 192} {lappend chosen $n}
 }
}
proc scope_lut_table {file} {
 set f [open $file w];puts $f "cell	ref	INIT	inputs	Q_net	loads	load_pins"
 foreach c [lsort [get_cells -hier -quiet -filter {NAME =~ red_pitaya_scope/average_select_*/* && REF_NAME =~ LUT?}]] {
  set ins {}
  foreach pin [lsort [get_pins -of_objects $c -filter {DIRECTION == IN}]] {lappend ins "[get_property REF_PIN_NAME $pin]=[get_nets -quiet -of_objects $pin]"}
  set q [get_nets -quiet -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == O}]]
  set loads [lsort [get_pins -quiet -of_objects $q -filter {DIRECTION == IN}]]
  puts $f "$c	[get_property REF_NAME $c]	[get_property INIT $c]	[join $ins |]	$q	[llength $loads]	[join $loads |]"
 };close $f
}
scope_lut_table {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/scope_lut_before.tsv}
set scope_chosen {}
foreach c [get_cells -hier -quiet -filter {NAME =~ red_pitaya_scope/average_select_*/* && REF_NAME =~ LUT?}] {
 foreach n [get_nets -quiet -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == O}]] {
  if {[llength [get_pins -quiet -of_objects $n -filter {DIRECTION == IN}]] >= 96} {lappend scope_chosen $n}
 }
}
if {![llength $scope_chosen]} {error "No identified Scope high-fanout LUT net found"}
puts "SCOPE_FORCE_REPLICATION_SELECTED $scope_chosen"
set chosen [concat $chosen $scope_chosen]
if {![llength $chosen]} {error "No high-fanout CSR data driver found"}
puts "FORCE_REPLICATION_SELECTED $chosen"
write_checkpoint {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/placed_before_replication.dcp}
phys_opt_design -force_replication_on_nets $chosen
write_checkpoint {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/placed_after_replication.dcp}
csr_table {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/csr_replication_after.tsv}
scope_lut_table {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/scope_lut_after.tsv}
phys_opt_design -placement_opt -rewire -critical_cell_opt
route_design -directive Explore -tns_cleanup
report_route_status -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_status.rpt}
report_timing_summary -max_paths 30 -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_timing.rpt}
report_timing -max_paths 100 -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_setup.rpt}
report_timing -delay_type min -max_paths 30 -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_hold.rpt}
report_utilization -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_utilization.rpt}
check_timing -verbose -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_checks.rpt}
report_cdc -details -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_cdc.rpt}
report_drc -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_drc.rpt}
report_clock_interaction -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_clocks.rpt}
report_exceptions -file {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed_exceptions.rpt}
csr_table {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/csr_replication_routed.tsv}
scope_lut_table {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/scope_lut_routed.tsv}
write_checkpoint {D:/RP_Dev/linien_trials/20261111-r43-scope-csr-distribution/gateware/build/trials/20261111_112330_r43_scope_csr_distribution/routed.dcp}
puts POSTROUTE_TRIAL_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
