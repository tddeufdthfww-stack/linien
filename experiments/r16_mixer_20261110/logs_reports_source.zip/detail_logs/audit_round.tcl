if {[llength $argv] != 2} {puts stderr "DCP and fresh output directory required"; exit 2}
set checkpoint [file normalize [lindex $argv 0]]
set out [file normalize [lindex $argv 1]]
if {[file exists $out]} {puts stderr "output must not exist"; exit 2}
file mkdir $out
proc props {c fileHandle} {
    set available [list_property $c]
    foreach p {NAME REF_NAME ORIG_REF_NAME ORIG_CELL_NAME LOC BEL INIT AREG BREG CREG DREG MREG PREG ADREG ACASCREG BCASCREG OPMODEREG ALUMODEREG USE_DPORT USE_MULT USE_SIMD DONT_TOUCH KEEP} {
        if {[lsearch -exact $available $p] >= 0} {puts $fileHandle "$p=[get_property $p $c]"}
    }
}
proc pin_info {cell fh} {
    props $cell $fh
    foreach p [get_pins -quiet -of_objects $cell] {
        set nets [get_nets -quiet -of_objects $p]
        set drivers [get_pins -quiet -of_objects $nets -filter {DIRECTION == OUT}]
        if {[get_property DIRECTION $p] eq "IN"} {
            puts $fh "PIN=$p NET=$nets DRIVER=$drivers"
        } else {puts $fh "PIN=$p NET=$nets LOAD_COUNT=[llength [get_pins -quiet -of_objects $nets -filter {DIRECTION == IN}]]"}
    }
}
if {[catch {
open_checkpoint $checkpoint
set f [open "$out/design.txt" w]
puts $f "CHECKPOINT=$checkpoint PART=[get_property PART [current_design]]"
puts $f "VIVADO=[version -short]"
close $f
report_timing -delay_type max -max_paths 20 -file "$out/worst20.rpt"
report_clock_interaction -file "$out/clock_interaction.rpt"
report_exceptions -summary -file "$out/exceptions.rpt"
report_cdc -details -file "$out/cdc.rpt"
report_utilization -hierarchical -file "$out/utilization_hier.rpt"
set iirCells [get_cells -hier -filter {NAME =~ *raw_acquisition_iir* || NAME =~ linienmodule_logic_iir_*}]
set seq [filter $iirCells {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
if {![llength $seq]} {error "raw acquisition IIR sequential cells missing"}
report_timing -delay_type max -max_paths 30 -to $seq -file "$out/iir_to.rpt"
report_timing -delay_type max -max_paths 30 -from $seq -to $seq -file "$out/iir_internal.rpt"
report_timing -delay_type max -max_paths 20 -from $seq -file "$out/iir_from.rpt"
set f [open "$out/iir_cell_counts.txt" w]
set counts [dict create]
foreach c $iirCells {dict incr counts [get_property REF_NAME $c]}
dict for {key value} $counts {puts $f "$key $value"}
close $f
set f [open "$out/all_dsp.txt" w]
foreach c [get_cells -hier -filter {REF_NAME == DSP48E1}] {
    puts $f "CELL_BEGIN"
    props $c $f
    puts $f "CELL_END"
}
close $f
set f [open "$out/iir_dsp_ports.txt" w]
foreach c [filter $iirCells {REF_NAME == DSP48E1}] {pin_info $c $f}
close $f
set f [open "$out/iir_registers.txt" w]
foreach c [filter $iirCells {REF_NAME =~ FD*}] {puts $f "$c [get_property REF_NAME $c]"}
close $f
set f [open "$out/negative_paths.tsv" w]
puts $f "slack\tstart\tend"
set negative [get_timing_paths -delay_type max -max_paths 20000 -nworst 1 -slack_lesser_than 0.0]
foreach p $negative {puts $f "[get_property SLACK $p]\t[get_property STARTPOINT_PIN $p]\t[get_property ENDPOINT_PIN $p]"}
close $f
puts "NEGATIVE_PATH_COUNT [llength $negative]"
if {[llength $negative]} {
    set f [open "$out/timing_path_properties.txt" w]
    set p [lindex $negative 0]
    foreach key [list_property $p] {puts $f "$key=[get_property $key $p]"}
    close $f
}

set scale_cells [get_cells -hier -quiet -filter {NAME =~ *autolock*time_scale* && REF_NAME =~ FD*}]
set gpio_cells [get_cells -hier -quiet -filter {NAME =~ *gpio_n_o* && REF_NAME =~ FD*}]
if {[llength $scale_cells] && [llength $gpio_cells]} {
    report_timing -from $scale_cells -to $gpio_cells -max_paths 10 -file "$out/time_scale_to_gpio.rpt"
}
set sum_regs [get_cells -hier -quiet -filter {NAME =~ *autolock*sum_diff_s1* && REF_NAME =~ FD*}]
if {[llength $sum_regs]} {
    report_timing -to $sum_regs -max_paths 10 -file "$out/autolock_to_sum_stage.rpt"
    report_timing -from $sum_regs -max_paths 10 -file "$out/autolock_from_sum_stage.rpt"
}
set mixer_cells [get_cells -hier -quiet -filter {NAME =~ *error_mixer* && REF_NAME == DSP48E1}]
if {[llength $mixer_cells]} {
    report_timing -from $mixer_cells -max_paths 10 -file "$out/mixer_from_dsp.rpt"
    report_timing -to $mixer_cells -max_paths 10 -file "$out/mixer_to_dsp.rpt"
}
foreach pair {{fast {*logic_pid*}} {slow {*slow_chain_pid*}}} {
    lassign $pair label pattern
    set cells [get_cells -hier -quiet -filter "NAME =~ $pattern"]
    foreach pinName {D R S CE} {
        set pins [get_pins -quiet -of_objects $cells -filter "REF_PIN_NAME == $pinName"]
        if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/${label}_${pinName}.rpt"}
    }
    set seq [filter $cells {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
    if {[llength $seq]} {report_timing -to $seq -max_paths 10 -file "$out/${label}_all_sequential.rpt"}
}

write_verilog -force -mode funcsim "$out/routed_netlist.v"
puts IIR_READONLY_AUDIT_COMPLETE
} msg opts]} {
    puts stderr "ERROR: $msg"
    puts stderr [dict get $opts -errorinfo]
    exit 3
}
exit 0
