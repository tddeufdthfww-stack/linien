"""Canonical P-only Bare PID FPGA digital-segment latency, not board latency.

Compose the actual Analog -> PID -> fast LimitCSR -> Analog/ODDR components.
Unused sweep/modulation/offset/slow contributions are zero in this configuration.
Includes the explicit top-level fast_outs -> LimitCSR.x register.
No PS, converter internal latency, analog plant or post-route SDF is modeled.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    root=a.root.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    sys.path[:0]=[str(root),str(root/'linien-common')]
    from migen import ClockDomain,Module,Signal
    from migen.genlib.record import Record
    from migen.fhdl import verilog
    from misoc.interconnect.csr_bus import CSRBank
    from gateware.logic.pid import PID
    from gateware.logic.pid_pipeline import PipelinedPID
    from gateware.logic.limit import LimitCSR
    from gateware.logic.chains import SlowChain
    from gateware.logic.slow_pipeline import PipelinedSlowChain
    from gateware.lowlevel.analog import PitayaAnalog
    class Pair(Module):
        def __init__(self):
            self.clock_domains.cd_sys=ClockDomain('sys')
            self.clock_domains.cd_sys_double=ClockDomain('sys_double',reset_less=True)
            self.clock_domains.cd_dac_2p=ClockDomain('dac_2p',reset_less=True)
            self.ports={}
            for name,width in [('adc_word',16),('csr_adr',14),('csr_we',1),('csr_dat_w',8)]:self.ports[name]=Signal(width,name_override=name)
            addresses=[]
            for prefix,factory in [('ref',PipelinedPID),('cand',PipelinedPID)]:
                adc=Record([('data_a',16),('data_b',16),('cdcs',1),('clk',2)])
                dac=Record([('data',14),('clk',1),('wrt',1),('sel',1),('rst',1)])
                analog=PitayaAnalog(adc,dac);core=factory(width=25);limit=LimitCSR(width=14,guard=5);limit_b=LimitCSR(width=14,guard=5);slow=(SlowChain if prefix=='ref' else PipelinedSlowChain)()
                setattr(self.submodules,prefix+'_analog',analog);setattr(self.submodules,prefix+'_pid',core);setattr(self.submodules,prefix+'_limit',limit);setattr(self.submodules,prefix+'_limit_b',limit_b);setattr(self.submodules,prefix+'_slow',slow)
                bank=CSRBank(core.get_csrs()+slow.get_csrs());setattr(self.submodules,prefix+'_bank',bank)
                self.comb += [adc.data_a.eq(self.ports['adc_word']),adc.data_b.eq(0x7ffc),
                    core.input.eq(analog.adc_a<<11),core.running.eq(1),core.update_en.eq(1),
                    analog.dac_a.eq(limit.y),analog.dac_b.eq(limit_b.y),slow.input.eq(limit.y),slow.pid.running.eq(1),slow.update_en.eq(1),slow.limit.x.eq(0),
                    bank.bus.adr.eq(self.ports['csr_adr']),bank.bus.we.eq(self.ports['csr_we']),bank.bus.dat_w.eq(self.ports['csr_dat_w'])]
                # LinienModule registers fast_outs into limit_fast.x explicitly.
                self.sync += [limit.x.eq(core.pid_out>>11),limit_b.x.eq(slow.output)]
                for suffix,width,value in [('data',14,dac.data),('wrt',1,dac.wrt),('sel',1,dac.sel),('kp',14,core.kp.storage)]:
                    q=Signal(width,name_override=prefix+'_'+suffix);self.ports[prefix+'_'+suffix]=q;self.comb += q.eq(value)
                addresses.append([[(bank.simple_csrs.index(csr),csr.size) for csr in source.simple_csrs] for source in (core.kp,slow.pid.kp)])
            assert addresses[0]==addresses[1];self.kp_bytes=addresses[0]
    dut=Pair();ios=set(dut.ports.values())|{dut.cd_sys.clk,dut.cd_sys.rst,dut.cd_sys_double.clk,dut.cd_dac_2p.clk}
    verilog.convert(dut,ios=ios,name='latency_pair').write(str(out/'latency_pair.v'))
    remaining=14;writes=[]
    for adr,width in sum(dut.kp_bytes,[]):
        if width==6:remaining=14
        remaining-=width;value=(4096>>remaining)&((1<<width)-1);writes.append(f'write_byte(14\'d{adr},8\'d{value});')
    tb='''`timescale 1ns/1ps
module tb_latency;
reg sys_clk=0;always #4 sys_clk=~sys_clk;
reg sys_double_clk=1;always #2 sys_double_clk=~sys_double_clk;
reg dac_2p_clk=0;initial begin #1.5;forever #2 dac_2p_clk=~dac_2p_clk;end
reg sys_rst=1;reg [15:0] adc_word=16'h7ffc;reg [13:0] csr_adr=0;reg csr_we=0;reg [7:0] csr_dat_w=0;
wire [13:0] ref_data,cand_data,ref_kp,cand_kp;wire ref_wrt,cand_wrt,ref_sel,cand_sel;
latency_pair dut(.*);
integer cycle=0,sample_cycle=0,ref_cycle=-1,cand_cycle=-1;
always @(posedge sys_clk)cycle=cycle+1;
reg armed=0;reg [13:0] target;real sample_time,ref_time=-1,cand_time=-1,ref_write=-1,cand_write=-1;
always @(ref_data)if(armed && ref_data===target && ref_sel==1 && ref_time<0)begin ref_time=$realtime;ref_cycle=cycle;end
always @(cand_data)if(armed && cand_data===target && cand_sel==1 && cand_time<0)begin cand_time=$realtime;cand_cycle=cycle;end
always @(posedge ref_wrt)if(armed && ref_data===target && ref_sel==1 && ref_write<0)ref_write=$realtime;
always @(posedge cand_wrt)if(armed && cand_data===target && cand_sel==1 && cand_write<0)cand_write=$realtime;
task write_byte(input [13:0] adr,input [7:0] value);
 begin @(negedge sys_clk);csr_adr=adr;csr_dat_w=value;csr_we=1;
 @(negedge sys_clk);csr_we=0;end
endtask
task pulse(input [15:0] word_value,input [13:0] expected,input integer amplitude);
 begin
  armed=0;ref_time=-1;cand_time=-1;ref_write=-1;cand_write=-1;ref_cycle=-1;cand_cycle=-1;
  repeat(8)@(posedge sys_clk);
  @(negedge sys_clk);target=expected;sample_time=$realtime+4;sample_cycle=cycle+1;adc_word=word_value;armed=1;
  @(negedge sys_clk);adc_word=16'h7ffc;
  repeat(20)@(posedge sys_clk);#1;
  if(ref_time<0 || cand_time<0 || ref_write<0 || cand_write<0)$fatal(1,"missing pulse");
  if(cand_cycle-ref_cycle!=2 || cand_time-ref_time<15.999 || cand_time-ref_time>16.001)$fatal(1,"latency delta failed");
  $display("FAST_TO_SLOW_DIGITAL_LATENCY amplitude=%0d ref_cycles=%0d cand_cycles=%0d ref_dq_ns=%0.3f cand_dq_ns=%0.3f ref_wrt_ns=%0.3f cand_wrt_ns=%0.3f delta_ns=%0.3f",amplitude,ref_cycle-sample_cycle,cand_cycle-sample_cycle,ref_time-sample_time,cand_time-sample_time,ref_write-sample_time,cand_write-sample_time,cand_time-ref_time);
  armed=0;
 end
endtask
initial begin
 repeat(20)@(posedge sys_clk);@(negedge sys_clk);sys_rst=0;
 WRITES
 repeat(20)@(posedge sys_clk);#1;
 if(ref_kp!==14'd4096 || cand_kp!==14'd4096)$fatal(1,"KP configuration failed");
 pulse(16'h7e10,14'h1f84,123);
 pulse(16'h81e8,14'h207a,-123);
 $display("FAST_TO_SLOW_DIGITAL_LATENCY_PASS");$finish;
end
initial begin #10000;$fatal(1,"timeout");end
endmodule
'''.replace('WRITES','\n '.join(writes))
    (out/'tb_latency.sv').write_bytes(tb.encode())
    tool=Path('D:/Xilinx/Vivado/2020.1/bin');glbl=tool.parent/'data/verilog/src/glbl.v';commands=[];observations=[]
    for name,cmd,marker in [('compile',[tool/'xvlog.bat','--sv',out/'latency_pair.v',out/'tb_latency.sv',glbl],None),
        ('elaborate',[tool/'xelab.bat','tb_latency','glbl','-L','unisims_ver','-L','unimacro_ver','-s','tb_latency','--timescale','1ns/1ps'],None),
        ('simulate',[tool/'xsim.bat','tb_latency','-runall'],'FAST_TO_SLOW_DIGITAL_LATENCY_PASS')]:
        cmd=[str(v) for v in cmd];r=subprocess.run(cmd,cwd=out,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (out/(name+'.stdout.log')).write_bytes(r.stdout);(out/(name+'.stderr.log')).write_bytes(r.stderr)
        text=(r.stdout+b'\n'+r.stderr).decode(errors='replace');ok=r.returncode==0 and (not marker or marker in text) and not re.search(r'(?m)^(ERROR:|Fatal:|FATAL_ERROR:)',text)
        commands.append({'command':cmd,'exit_code':r.returncode,'passed':bool(ok)});(out/'commands.json').write_bytes(json.dumps(commands,indent=2).encode())
        print(name,'PASS' if ok else 'FAIL',flush=True);assert ok,text[-6000:]
        if marker:observations=re.findall(r'^FAST_TO_SLOW_DIGITAL_LATENCY [^\r\n]+',text,re.M);print('\n'.join(observations),flush=True)
    inputs={rel:hashlib.sha256((root/rel).read_bytes()).hexdigest() for rel in ['gateware/lowlevel/analog.py','gateware/lowlevel/crg.py','gateware/logic/pid.py','gateware/logic/pid_pipeline.py','gateware/logic/limit.py','gateware/linien_module.py','gateware/logic/chains.py','gateware/logic/slow_pipeline.py']}
    results={'passed':True,'configuration':'ADC A -> Pipelined fast PID25 -> registered LimitA -> native or pipelined slow PID14 -> registered LimitB -> Analog DAC B ODDR; both P-only gain1 running1 continuous CE, full-range limits; stable routing A fast/B slow, no sweep/modulation/offset; ref=R4a slow native, cand=R13/R14 slow pipelined',
        'clock_period_ns':8,'dac_clock_phase_deg_at_250MHz':-45,'observations':observations,'inputs':inputs,
        'scope':'Actual components composed for this configuration; untimed XSim with UNISIM ODDR. FPGA digital segment only, not full-root/SDF/board or converter/analog latency.'}
    (out/'results.json').write_bytes(json.dumps(results,indent=2).encode());print('DIGITAL_LATENCY_MEASUREMENT_COMPLETE',flush=True)
if __name__=='__main__':main()
