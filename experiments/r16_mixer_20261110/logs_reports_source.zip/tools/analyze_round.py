from pathlib import Path
import argparse,collections,csv,hashlib,json,re,subprocess
HERE=Path(__file__).parent
BASE=Path('D:/RP_Dev/linien_trials/20261109-r4-pid-pipeline/gateware/build/trials/20261109_111733_r4_fast_pipeline16')

def summary(path):
    txt=path.read_text(errors='replace')
    m=re.search(r'^\s*(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)',txt,re.M)
    assert m,path
    vals=m.groups();return dict(zip(['wns','tns','setup_failing','setup_total','whs','ths','hold_failing','hold_total','wpws','tpws','pulse_failing'],[int(v) if i in (2,3,6,7,10) else float(v) for i,v in enumerate(vals)]))
def worst(path):
    txt=path.read_text(errors='replace')
    return {'slack':float(re.search(r'Slack \([^)]*\)\s*:\s*(-?[\d.]+)ns',txt)[1]),
       'source':re.search(r'Source:\s*(\S+)',txt)[1],'destination':re.search(r'Destination:\s*(\S+)',txt)[1],
       'data_logic_route_ns':re.search(r'Data Path Delay:\s*([\d.]+)ns\s*\(logic ([\d.]+)ns.*?route ([\d.]+)ns',txt).groups(),
       'levels':re.search(r'Logic Levels:\s*(.*)',txt)[1].strip()}
def cdc(path):
    txt=path.read_text(errors='replace');rows=set()
    counts={m[1]:int(m[2]) for m in re.finditer(r'^(CDC-\d+)\s+(?:Critical|Warning|Info)\s+(\d+)\s+',txt,re.M)}
    for line in txt.splitlines():
        m=re.match(r'^\s*\d+\s+(CDC-\d+)\s+',line)
        if m:
            tokens=line.split();rows.add((m[1],tokens[-2],tokens[-1]))
    return counts,rows
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--trial',type=Path,required=True);parser.add_argument('--label',required=True)
    args=parser.parse_args();trial=args.trial.resolve();out=HERE/args.label;logs=HERE/(args.label+'_logs')
    logs.mkdir(exist_ok=False)
    script=(HERE.parent/'iir_readonly_audit/audit.tcl').read_text()
    begin=script.index('# Trace the legacy path');end=script.index('set f [open "$out/iir_registers.txt"',begin)
    script=script[:begin]+script[end:]
    # Free-function construction changes Migen's signal backtrace prefix. The
    # generated top.v still connects this IIR to the same filtered-error signal.
    script=script.replace('NAME =~ *raw_acquisition_iir*','NAME =~ *raw_acquisition_iir* || NAME =~ linienmodule_logic_iir_*')
    insertion='''
set scale_cells [get_cells -hier -quiet -filter {NAME =~ *autolock*time_scale* && REF_NAME =~ FD*}]
set gpio_cells [get_cells -hier -quiet -filter {NAME =~ *gpio_n_o* && REF_NAME =~ FD*}]
if {[llength $scale_cells] && [llength $gpio_cells]} {
    report_timing -from $scale_cells -to $gpio_cells -max_paths 10 -file "$out/time_scale_to_gpio.rpt"
}
set sum_regs [get_cells -hier -quiet -filter {NAME =~ *autolock*sum_diff_s1* && REF_NAME =~ FD*}]
if {[llength $sum_regs]} {
    report_timing -to $sum_regs -max_paths 10 -file "$out/autolock_to_sum_stage.rpt"
    report_timing -from $sum_regs -max_paths 10 -file "$out/autolock_from_sum_stage.rpt"
}
set mixer_cells [get_cells -hier -quiet -filter {NAME =~ *error_mixer* && REF_NAME == DSP48E1}]
if {[llength $mixer_cells]} {
    report_timing -from $mixer_cells -max_paths 10 -file "$out/mixer_from_dsp.rpt"
    report_timing -to $mixer_cells -max_paths 10 -file "$out/mixer_to_dsp.rpt"
}
foreach pair {{fast {*logic_pid*}} {slow {*slow_chain_pid*}}} {
    lassign $pair label pattern
    set cells [get_cells -hier -quiet -filter "NAME =~ $pattern"]
    foreach pinName {D R S CE} {
        set pins [get_pins -quiet -of_objects $cells -filter "REF_PIN_NAME == $pinName"]
        if {[llength $pins]} {report_timing -to $pins -max_paths 10 -file "$out/${label}_${pinName}.rpt"}
    }
    set seq [filter $cells {REF_NAME =~ FD* || REF_NAME == DSP48E1}]
    if {[llength $seq]} {report_timing -to $seq -max_paths 10 -file "$out/${label}_all_sequential.rpt"}
}
'''
    script=script.replace('write_verilog -force -mode funcsim',insertion+'\nwrite_verilog -force -mode funcsim')
    tcl=logs/'audit_round.tcl';tcl.write_bytes(script.encode())
    checkpoint=trial/'routed.dcp';before=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    cmd=['D:/Xilinx/Vivado/2020.1/bin/vivado.bat','-mode','batch','-source',str(tcl),'-log',str(logs/'vivado.log'),'-journal',str(logs/'vivado.jou'),'-tclargs',str(checkpoint),str(out)]
    r=subprocess.run(cmd,cwd=logs,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (logs/'stdout.log').write_bytes(r.stdout);(logs/'stderr.log').write_bytes(r.stderr)
    text=(r.stdout+b'\n'+r.stderr).decode(errors='replace')
    ok=r.returncode==0 and 'IIR_READONLY_AUDIT_COMPLETE' in text and not re.search(r'(?m)^ERROR:',text)
    status={'command':cmd,'exit_code':r.returncode,'passed':ok,'dcp_sha256':before,'dcp_unchanged':before==hashlib.sha256(checkpoint.read_bytes()).hexdigest()}
    (logs/'status.json').write_bytes(json.dumps(status,indent=2).encode());assert ok,text[-6000:]
    results={'trial':str(trial),'synth':summary(trial/'synth_timing.rpt'),'route':summary(trial/'routed_timing.rpt'),
      'global_worst':worst(out/'worst20.rpt'),'raw_internal':worst(out/'iir_internal.rpt'),'raw_entry':worst(out/'iir_to.rpt'),
      'xdc_matches_r4a':(trial/'top.xdc').read_bytes()==(BASE/'top.xdc').read_bytes()}
    for name in ('time_scale_to_gpio','mixer_from_dsp','mixer_to_dsp','autolock_to_sum_stage','autolock_from_sum_stage'):
        p=out/(name+'.rpt')
        if p.exists():
            txt=p.read_text(errors='replace')
            if 'Data Path Delay:' in txt:results[name]=worst(p)
            elif 'No timing paths found' in txt:results[name]={'direct_combinational_path_exists':False}
    util=(trial/'routed_utilization.rpt').read_text(errors='replace')
    resources={}
    for key,pattern in [('lut',r'Slice LUTs\*?'),('ff','Slice Registers'),('dsp','DSPs'),('bram','Block RAM Tile'),('bufg','BUFGCTRL')]:
        mm=re.search(r'^\|\s*'+pattern+r'\s*\|\s*(\d+)',util,re.M)
        resources[key]=int(mm[1]) if mm else None
    results['resources']=resources
    checks=(trial/'routed_checks.rpt').read_text(errors='replace')
    results['coverage']={key:int(re.search(key+r'\s*\((\d+)\)',checks)[1]) for key in ['no_clock','unconstrained_internal_endpoints','no_input_delay','no_output_delay']}
    drc=(trial/'routed_drc.rpt').read_text(errors='replace')
    results['drc_total']=int(re.search(r'Violations found:\s*(\d+)',drc)[1])
    results['drc_rules']=[{'rule':q[1],'severity':q[2],'count':int(q[3])} for q in re.finditer(r'^\|\s*(\S+)\s*\|\s*(Warning|Advisory|Error|Critical Warning)\s*\|[^|]+\|\s*(\d+)\s*\|',drc,re.M)]
    dsps=[]
    for b in (out/'all_dsp.txt').read_text().split('CELL_BEGIN')[1:]:
        d=dict(s.split('=',1) for s in b.splitlines() if '=' in s)
        if 'raw_acquisition_iir' in d.get('NAME','') or d.get('NAME','').startswith('linienmodule_logic_iir_'):dsps.append(d)
    results['raw_dsps']=dsps
    counts,rows=cdc(out/'cdc.rpt');oldcounts,oldrows=cdc(BASE/'routed_cdc.rpt')
    results['cdc']={'baseline_counts':oldcounts,'counts':counts,'added':len(rows-oldrows),'removed':len(oldrows-rows),'physical_safety':'NOT_PROVEN'}
    (out/'cdc_diff.json').write_bytes(json.dumps({'added':sorted(rows-oldrows),'removed':sorted(oldrows-rows)},indent=2).encode())
    paths=list(csv.DictReader((out/'negative_paths.tsv').open(),delimiter='\t'));groups=collections.defaultdict(list)
    for row in paths:
        name=row['end'].replace('linienmodule_logic_iir_','linienmodule_logic_raw_acquisition_iir_')
        group=next((s for s in ['raw_acquisition_iir','slow_chain','autolock','pid','gpio','fast_a_iir','fast_b_iir'] if s in name),'other')
        groups[group].append(float(row['slack']))
    slow=[q for q in paths if 'slow_chain_pid' in q['end']]
    results['slow_pid_negative_endpoints']={'csr':sum('storage' in q['end'] for q in slow),'non_csr':sum('storage' not in q['end'] for q in slow)}
    results['endpoint_groups']={k:{'count':len(v),'worst':min(v),'approx_tns':round(sum(v),3)} for k,v in groups.items()}
    (out/'metrics.json').write_bytes(json.dumps(results,indent=2).encode())
    print(json.dumps({k:v for k,v in results.items() if k not in ('raw_dsps',)},indent=2))
    print('RAW_DSP_COUNT',len(dsps));print('ROUND_ANALYSIS_COMPLETE',args.label)
if __name__=='__main__':main()
