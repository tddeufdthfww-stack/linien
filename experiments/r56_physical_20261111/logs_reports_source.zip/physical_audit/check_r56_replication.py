from pathlib import Path
import csv,json
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r56-critical-ff-distribution');t=r/'gateware/build/trials/20261111_173521_r56_compatible_resume_v3'
m=json.loads((t/'manifest.json').read_text());assert m['replication']=='REUSED_R56_V2_EXACT_DCP_NOT_RERUN' and m['route']=='COMPLETE' and m['input_r53_dcp_unchanged'] and m['input_replication_dcp_unchanged'] and not m['source_changes_during_run'] and all(m['r53_code_and_test_hash_matches'].values())
def rows(n):return list(csv.DictReader((t/n).open(),delimiter='\t'))
a,b,c,d=map(rows,('ff_before.tsv','ff_after.tsv','ff_before_resume.tsv','ff_routed.tsv'))
keys=('ref','D','C','CE','R','INIT','ASYNC_REG','DONT_TOUCH')
def group(v):
 out={}
 for row in v:
  assert row['ref']=='FDRE' and row['ASYNC_REG']!='1' and row['DONT_TOUCH']!='1'
  k=(row['source'],)+tuple(row[n] for n in keys);loads=row['load_pins'].split('|') if row['load_pins'] else []
  assert len(loads)==int(row['loads']) and len(loads)==len(set(loads)) and not out.get(k,set()).intersection(loads)
  out.setdefault(k,set()).update(loads)
 return out
assert group(a)==group(b)==group(c)==group(d) and len(a)==4 and len(b)==len(c)==len(d)==21
def parse(p):
 out={}
 for block in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in block.splitlines() if '=' in s);out[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return out
x=parse(h/'r53_mapped/all_dsp.txt');y=parse(h/'r56_mapped/all_dsp.txt');assert len(x)==len(y)==94 and x==y
prior=Path(m['input_r53_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(prior/n).read_bytes()
old=json.loads((h/'r53_mapped/metrics.json').read_text());new=json.loads((h/'r56_mapped/metrics.json').read_text())
assert new['resources']['ff']-old['resources']['ff']==len(d)-len(a)==17
rec={'passed':True,'ff_before':len(a),'ff_after_force':len(b),'ff_before_resume':len(c),'ff_after_route':len(d),'parallel_FDRE_added':17,'all_same_ref_D_C_CE_R_INIT_ASYNC_DONT_and_exact_aggregate_load_sets':True,'no_duplicate_or_lost_load_pins':True,'max_Q_loads_before':max(int(v['loads']) for v in a),'max_Q_loads_after_force':max(int(v['loads']) for v in b),'max_Q_loads_routed':max(int(v['loads']) for v in d),'all94_DSP_properties_same_R53_ignoring_LOC_BEL':True,'resource_FF_increment_equals_exact_copy_increment':True,'actual_resource_before':old['resources'],'actual_resource_after':new['resources'],'raw90_hardware_test_inputs_same_R53':True,'top_CSR_XDC_bytes_same_R53':True,'both_original_and_replication_DCP_SHA_unchanged':True,'new_serial_ADC_feedback_CSR_cycles':0,'scope':'FDRE q_next=R?0:(CE?D:q), same INIT/inputs imply copy equality by induction for known digital control sequences. Exact load repartition preserves mapped synchronous transfer; not analog metastability, fullRoot SDF/formal or physical CDC/board/plant proof. Native tests/synthesis REUSED_R52 via R53; replication executed V2, route freshly executed V3.'}
(h/'r56_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R56_4_TO_21_STATE_LOAD_AND_ALL94_DSP_EQUIVALENCE_AUDIT_PASS')
