from pathlib import Path
import re,json,csv,itertools,hashlib
h=Path(__file__).parent
r=Path('D:/RP_Dev/linien_trials/20261111-r57-critical-ff-postroute')
t=r/'gateware/build/trials/20261111_175257_r57_distributed_ff_postroute'
def norm(s):return re.sub(r'\s+','',s.replace('\\',''))
def parse(label):
 s=(h/(label+'_mapped/routed_netlist.v')).read_text()
 out={}
 for mod in re.finditer(r'^module (\S+).*?^endmodule',s,re.M|re.S):
  mn=mod[1]
  for v in re.finditer(r'^  (LUT[1-6]|FDRE) #\(\s*(.*?)\)\s+([^\s]+)\s+\((.*?)\);',mod[0],re.M|re.S):
   pars=dict((k,norm(x)) for k,x in re.findall(r'\.(\w+)\((.*?)\)',v[2],re.S))
   ports=dict((k,norm(x)) for k,x in re.findall(r'\.(\w+)\((.*?)\)',v[4],re.S))
   key=mn+'/'+norm(v[3]);assert key not in out,key
   out[key]={'ref':v[1],'params':pars,'ports':ports}
 return out
a,b=parse('r56'),parse('r57')
new=set(b)-set(a);removed=set(a)-set(b)
added_ff={k:b[k] for k in new if b[k]['ref']=='FDRE'}
def sig(c):return (c['ref'],tuple(sorted(c['params'].items())),tuple(sorted((k,v) for k,v in c['ports'].items() if k!='Q')))
aliases={};copy_details=[]
for k,v in added_ff.items():
 matches=[n for n,c in a.items() if sig(c)==sig(v)]
 assert matches,(k,v)
 q={a[n]['ports']['Q'] for n in matches};assert len(q)==1,(k,matches)
 aliases[v['ports']['Q']]=next(iter(q));copy_details.append({'copy':k,'source_matches':matches,'signature':v})
assert len(added_ff)==3 and len(aliases)==3
def canonical(c):
 return {**c,'ports':{p:aliases.get(n,n) for p,n in c['ports'].items()}}
changed_ff=[k for k in a.keys()&b.keys() if a[k]['ref']=='FDRE' and a[k]!=canonical(b[k])]
assert not changed_ff,changed_ff
assert not [k for k in removed if a[k]['ref']=='FDRE']
prefix='top/linienmodule_fast_a_cordic33[10]'
old9=prefix+'_i_9';new9=prefix+'_i_9_rewire';old20=prefix+'_i_20';new20=prefix+'_i_20_replica_rewire'
assert removed=={old9},removed
assert new==set(added_ff)|{new9,new20},new
changed_lut=[k for k in a.keys()&b.keys() if a[k]['ref'].startswith('LUT') and a[k]!=canonical(b[k])]
# Added FF replicas only rename input nets; every other existing LUT must be exactly preserved.
assert not changed_lut,changed_lut
def decode(c):
 init=c['params']['INIT'];mm=re.fullmatch(r"(\d+)'h([0-9A-Fa-f]+)",init);assert mm,init
 return int(mm[2],16),[c['ports']['I'+str(i)] for i in range(int(c['ref'][3:]))]
target=a[old9]['ports']['O'];assert target==b[new9]['ports']['O']
before={a[k]['ports']['O']:a[k] for k in (old9,old20)}
after={b[k]['ports']['O']:b[k] for k in (new9,new20)}
def leaves(nodes):return {n for c in nodes.values() for n in decode(c)[1] if n not in nodes}
inputs=sorted(leaves(before)|leaves(after));assert len(inputs)==8,len(inputs)
def evaluate(nodes,values,net):
 if net in values:return values[net]
 init,ports=decode(nodes[net]);idx=sum(evaluate(nodes,values,n)<<i for i,n in enumerate(ports));return (init>>idx)&1
for bits in itertools.product((0,1),repeat=len(inputs)):
 values=dict(zip(inputs,bits));assert evaluate(before,values,target)==evaluate(after,values,target),(values,target)
def dsps(lab):
 out={}
 for block in (h/(lab+'_mapped/all_dsp.txt')).read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in block.splitlines() if '=' in s);out[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return out
assert len(dsps('r56'))==94 and dsps('r56')==dsps('r57')
tables={n:list(csv.DictReader((t/n).open(),delimiter='\t')) for n in ('input_ff_routed.tsv','ff_before_phys.tsv','ff_after_phys.tsv','ff_routed.tsv')}
keys=('ref','D','C','CE','R','INIT','ASYNC_REG','DONT_TOUCH')
def states(rows):return {(v['source'],v['cell'] if 'cell' in v else v.get('name'),*(v[k] for k in keys)) for v in rows}
assert len({json.dumps(sorted(states(rows))) for rows in tables.values()})==1
def loads(rows):
 out={}
 for v in rows:out.setdefault(v['source'],set()).update(v['load_pins'].split('|') if v['load_pins'] else [])
 return out
x,y=loads(tables['input_ff_routed.tsv']),loads(tables['ff_routed.tsv'])
delta={k:{'added':sorted(y[k]-x[k]),'removed':sorted(x[k]-y[k])} for k in x if x[k]!=y[k]}
assert len(delta)==1 and next(iter(delta.values()))=={'added':['linienmodule_fast_a_cordic33[10]_i_9_rewire/I0'],'removed':[]},delta
ma=json.loads((t/'manifest.json').read_text());assert ma['postopt']=='COMPLETE' and ma['route']=='COMPLETE' and ma['input_r56_dcp_unchanged'] and ma['input_FF_table_unchanged'] and not ma['source_changes_during_run'] and all(ma['r56_code_and_test_hash_matches'].values())
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(Path(ma['input_r56_trial'])/n).read_bytes()
old=json.loads((h/'r56_mapped/metrics.json').read_text())['resources'];cur=json.loads((h/'r57_mapped/metrics.json').read_text())['resources']
assert cur['ff']-old['ff']==3 and cur['lut']-old['lut']==1 and cur['dsp']==94
rec={'passed':True,'all_existing_FDRE_same_INIT_and_state_inputs_after_exact_copy_alias':True,'new_parallel_FDRE':copy_details,'new_parallel_FDRE_count':3,'prior_four_families_state_signatures_same_21':True,'raw_family_load_sets_identical':False,'raw_family_load_differences':delta,'difference_explanation':'One new direct Q input into LUT5 i_9_rewire replaces its old indirect Q dependency through LUT6 i_20. Raw load sets are NOT invariant. Entire changed two-LUT output cone exhaustively equivalent below. Other existing LUT functions/pins invariant after verified FDRE-copy aliases.','changed_LUT_cone_output':target,'cone_input_count':len(inputs),'cone_inputs':inputs,'known_binary_exhaustive_vectors':2**len(inputs),'cone_equivalence':'PASS_EXHAUSTIVE_BOOLEAN_LOCAL_CUT','old_LUTs':{k:a[k] for k in (old9,old20)},'new_LUTs':{k:b[k] for k in (new9,new20)},'all94_DSP_properties_same_R56_ignoring_LOC_BEL':True,'resources_before':old,'resources_after':cur,'source_inputs_same_R56':len(ma['r56_code_and_test_hash_matches']),'functional_and_synthesis':'REUSED_R52_VIA_R56_NOT_RERUN','new_serial_ADC_feedback_CSR_cycles':0,'scope':'Known binary LUT exhaustive local cut and FDRE state-copy induction; not global postmap/SDF/formal equivalence, arbitrary X/Z equivalence, metastability/physical CDC or board/plant proof. Existing RTL four-state/full regressions inherited R52, not rerun.'}
(h/'r57_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
print('R57_LOCAL_REWIRE_FF_COPY_AND_ALL94_DSP_AUDIT_PASS',len(a),len(b),len(inputs),2**len(inputs))
print(json.dumps(copy_details,indent=2))
