from pathlib import Path
import re,json,csv
h=Path(__file__).parent
m=json.loads((h/'r59_mapped/metrics.json').read_text());t=Path(m['trial']);ma=json.loads((t/'manifest.json').read_text())
assert ma['replication']=='COMPLETE' and ma['route']=='COMPLETE' and ma['input_r57_dcp_unchanged'] and not ma['source_changes_during_run'] and all(ma['r57_code_and_test_hash_matches'].values())
def norm(s):return re.sub(r'\s+','',s.replace('\\',''))
def parse(label):
 s=(h/(label+'_mapped/routed_netlist.v')).read_text();out={}
 for mod in re.finditer(r'^module (\S+).*?^endmodule',s,re.M|re.S):
  for v in re.finditer(r'^  (\w+)(?: #\(\s*(.*?)\))?\s+([^\s]+)\s+\((.*?)\);',mod[0],re.M|re.S):
   pars=dict((k,norm(x)) for k,x in re.findall(r'\.(\w+)\((.*?)\)',v[2] or '',re.S));ports=dict((k,norm(x)) for k,x in re.findall(r'\.(\w+)\((.*?)\)',v[4],re.S))
   assert ports,(mod[1],v[1],v[3]);key=mod[1]+'/'+norm(v[3]);assert key not in out,key
   out[key]={'ref':v[1],'params':pars,'ports':ports}
 return out
a,b=parse('r57'),parse('r59');new=set(b)-set(a);removed=set(a)-set(b);assert not removed,removed
assert len(new)==4 and all(b[k]['ref']=='FDRE' for k in new),new
def sig(c):return (c['ref'],tuple(sorted(c['params'].items())),tuple(sorted((k,v) for k,v in c['ports'].items() if k!='Q')))
aliases={};details=[]
for k in sorted(new):
 matches=[n for n,c in a.items() if sig(c)==sig(b[k])];assert matches,k
 qs={a[n]['ports']['Q'] for n in matches};assert len(qs)==1
 aliases[b[k]['ports']['Q']]=next(iter(qs));details.append({'copy':k,'source_matches':matches,'signature':b[k]})
def alias(s):
 for k,v in sorted(aliases.items(),key=lambda kv:-len(kv[0])):s=re.sub(r'(?<![\w$])'+re.escape(k)+r'(?![\w$])',lambda _:v,s)
 return s
def port_bits(s):
 s=alias(s)
 if re.search(r'\d+\{',s):return s
 def expand(v):
  x,y=int(v[2]),int(v[3]);return ','.join(v[1]+'['+str(i)+']' for i in range(x,y+(-1 if x>y else 1),-1 if x>y else 1))
 s=re.sub(r'([\w$]+)\[(\d+):(\d+)\]',expand,s)
 return s.replace('{','').replace('}','')
def canonical(c):return {**c,'ports':{k:port_bits(v) for k,v in c['ports'].items()}}
diff=[k for k in a if canonical(a[k])!=canonical(b[k])];assert not diff,diff[:30]
tables={n:list(csv.DictReader((t/n).open(),delimiter='\t')) for n in ('ff_before.tsv','ff_after.tsv','ff_routed.tsv')}
keys=('ref','D','C','CE','R','INIT','ASYNC_REG','DONT_TOUCH')
def grouped(rows):
 out={}
 for row in rows:
  assert row['ref']=='FDRE' and row['ASYNC_REG']!='1' and row['DONT_TOUCH']!='1'
  k=(row['source'],)+tuple(row[v] for v in keys);pins=row['load_pins'].split('|') if row['load_pins'] else []
  assert len(pins)==int(row['loads']) and len(pins)==len(set(pins)) and not out.get(k,set()).intersection(pins)
  out.setdefault(k,set()).update(pins)
 return out
v=list(tables.values());assert len(v[0])==2 and len(v[1])==len(v[2])==6 and grouped(v[0])==grouped(v[1])==grouped(v[2])
def dsps(lab):
 out={}
 for block in (h/(lab+'_mapped/all_dsp.txt')).read_text().split('CELL_BEGIN')[1:]:
  q=dict(s.split('=',1) for s in block.splitlines() if '=' in s);out[q['NAME']]={k:x for k,x in q.items() if k not in ('LOC','BEL')}
 return out
assert len(dsps('r57'))==94 and dsps('r57')==dsps('r59')
old=json.loads((h/'r57_mapped/metrics.json').read_text())['resources'];cur=m['resources'];assert cur['ff']-old['ff']==4 and cur['lut']==old['lut']
for n in ('top.v','top.xdc','csrmap.py'):assert (t/n).read_bytes()==(Path(ma['input_r57_trial'])/n).read_bytes()
rec={'passed':True,'parsed_all_module_instance_count_before':len(a),'parsed_all_module_instance_count_after':len(b),'all_existing_parsed_instances_same_parameters_ports_after_state_copy_alias':True,'port_normalization':'Explicit ordered part-select bit expansion; e.g original DI concat {...,xlo[16:14]} versus {...,xlo[16],xlo[15]_repN,xlo[14]}. Initial raw string audit stopped on this one CARRY4 DI, never PASS; normalize vector presentation without omitting any bit or port, then compare all instances. Repetition expressions retained unchanged.','new_only_parallel_FDRE':details,'FF_before':2,'FF_after_force':6,'FF_final':6,'parallel_FDRE_added':4,'all_ref_D_C_CE_R_INIT_ASYNC_DONT_and_exact_aggregate_load_sets_same':True,'no_duplicate_or_lost_load_pins':True,'max_Q_load_before':max(int(q['loads']) for q in v[0]),'max_Q_load_after':max(int(q['loads']) for q in v[2]),'all94_DSP_properties_same_R57_ignoring_LOC_BEL':True,'resources_before':old,'resources_after':cur,'hardware_test_source_input_count_same_R57':len(ma['r57_code_and_test_hash_matches']),'top_CSR_XDC_bytes_same_R57':True,'input_DCP_SHA_unchanged':True,'functional_and_synthesis':'REUSED_R52_VIA_R57_NOT_RERUN','new_serial_ADC_feedback_CSR_cycles':0,'scope':'FDRE same INIT and D/C/CE/R imply equal copies by induction for known digital controls. Parsed instance parameters/ports equal after aliases; full exact load repartition verified. Not fullRoot SDF/formal, arbitrary analog reset/metastability/physical CDC/board proof. All original routes were released; routed timing is newly measured.'}
(h/'r59_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R59_STATE_COPIES_ALL_PARSED_INSTANCES_LOAD_SETS_AND94DSP_AUDIT_PASS',len(a),len(b))
