/* Machine-generated using Migen */
module c48_pair(
	input signed [24:0] x,
	input signed [24:0] c,
	input signed [49:0] z,
	output signed [49:0] old_y,
	output signed [49:0] new_y
);

wire signed [17:0] pair_xlo;
wire signed [7:0] pair_xhi;
wire signed [47:0] pair_zlo;
wire signed [1:0] pair_ztop;
(* use_dsp = "yes" *) wire signed [47:0] pair_low;
(* use_dsp = "yes" *) wire signed [47:0] pair_high;
wire pair0;
wire pair1;
wire signed [3:0] pair_correction;
wire [1:0] pair_top;
wire signed [49:0] pair_result;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign pair_xlo = {1'd0, x[16:0]};
assign pair_xhi = x[24:17];
assign pair_zlo = z[47:0];
assign pair_ztop = z[49:48];
assign pair_low = ((c * pair_xlo) + pair_zlo);
assign pair_high = ((c * pair_xhi) + (pair_low >>> 5'd17));
assign pair0 = (((~pair_zlo[47]) & (~c[24])) & pair_low[47]);
assign pair1 = ((pair_zlo[47] & c[24]) & (~pair_low[47]));
assign pair_correction = (((pair_ztop + pair_zlo[47]) + $signed({1'd0, pair0})) - $signed({1'd0, pair1}));
assign pair_top = (pair_high[32:31] + pair_correction);
assign pair_result = {pair_top, pair_high[30:0], pair_low[16:0]};
assign old_y = (z + (x * c));
assign new_y = pair_result;

endmodule
