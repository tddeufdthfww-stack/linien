/* Machine-generated using Migen */
module fast_output_pair(
	input sys_clk,
	input sys_rst,
	input signed [24:0] pid,
	input signed [24:0] mod_data,
	input signed [24:0] sweep_data,
	input signed [24:0] slow_data,
	input ce,
	input [13:0] csr_adr,
	input csr_we,
	input [7:0] csr_dat_w,
	output [28:0] old_word0,
	output [28:0] new_word0,
	output [29:0] old_x0,
	output [29:0] new_x0,
	output [24:0] old_y0,
	output [24:0] new_y0,
	output old_error0,
	output new_error0,
	output [28:0] old_word1,
	output [28:0] new_word1,
	output [29:0] old_x1,
	output [29:0] new_x1,
	output [24:0] old_y1,
	output [24:0] new_y1,
	output old_error1,
	output new_error1,
	output [24:0] cfg,
	output [7:0] csr_read
);

reg pair_csrstorage0_storage_full = 1'd0;
wire pair_csrstorage0_storage;
reg pair_csrstorage0_re = 1'd0;
reg pair_csrstorage1_storage_full = 1'd0;
wire pair_csrstorage1_storage;
reg pair_csrstorage1_re = 1'd0;
reg [1:0] pair_csrstorage2_storage_full = 2'd0;
wire [1:0] pair_csrstorage2_storage;
reg pair_csrstorage2_re = 1'd0;
reg [1:0] pair_csrstorage3_storage_full = 2'd0;
wire [1:0] pair_csrstorage3_storage;
reg pair_csrstorage3_re = 1'd0;
reg [24:0] pair_csrstorage4_storage_full = 25'd0;
wire [24:0] pair_csrstorage4_storage;
reg pair_csrstorage4_re = 1'd0;
wire [13:0] pair_bus_adr;
wire pair_bus_we;
wire [7:0] pair_bus_dat_w;
reg [7:0] pair_bus_dat_r = 8'd0;
wire pair_control0_re;
wire pair_control0_r;
wire pair_control0_w;
wire pair_mod0_re;
wire pair_mod0_r;
wire pair_mod0_w;
wire pair_sweep0_re;
wire [1:0] pair_sweep0_r;
wire [1:0] pair_sweep0_w;
wire pair_slow0_re;
wire [1:0] pair_slow0_r;
wire [1:0] pair_slow0_w;
wire pair_offset3_re;
wire pair_offset3_r;
wire pair_offset3_w;
wire pair_offset2_re;
wire [7:0] pair_offset2_r;
wire [7:0] pair_offset2_w;
wire pair_offset1_re;
wire [7:0] pair_offset1_r;
wire [7:0] pair_offset1_w;
wire pair_offset0_re;
wire [7:0] pair_offset0_r;
wire [7:0] pair_offset0_w;
wire pair_sel;
reg signed [24:0] pair_offset = 25'sd0;
wire signed [28:0] pair_old0;
wire signed [28:0] pair_new0;
wire signed [28:0] pair_extended0;
wire signed [28:0] pair_extended1;
wire signed [28:0] pair_extended2;
wire signed [28:0] pair_extended3;
wire signed [28:0] pair_extended4;
wire [28:0] pair8;
wire [28:0] pair9;
wire [28:0] pair10;
wire [28:0] pair11;
wire [28:0] pair12;
wire [28:0] pair13;
reg signed [24:0] pair_limitcsr0_limitcsr0_y = 25'sd0;
reg pair_limitcsr0_limitcsr0_error = 1'd0;
wire pair_limitcsr0_update_en;
reg signed [29:0] pair_limitcsr0_x = 30'sd0;
reg [24:0] pair_limitcsr0_min_storage = 25'd16777216;
reg [24:0] pair_limitcsr0_max_storage = 25'd16777215;
wire signed [29:0] pair_limitcsr0_limit_x;
reg signed [29:0] pair_limitcsr0_limit_y;
reg signed [29:0] pair_limitcsr0_limit_max = 30'sd0;
reg signed [29:0] pair_limitcsr0_limit_min = 30'sd0;
reg pair_limitcsr0_limit_railed;
reg signed [24:0] pair_limitcsr1_limitcsr1_y = 25'sd0;
reg pair_limitcsr1_limitcsr1_error = 1'd0;
wire pair_limitcsr1_update_en;
reg signed [29:0] pair_limitcsr1_x = 30'sd0;
reg [24:0] pair_limitcsr1_min_storage = 25'd16777216;
reg [24:0] pair_limitcsr1_max_storage = 25'd16777215;
wire signed [29:0] pair_limitcsr1_limit_x;
reg signed [29:0] pair_limitcsr1_limit_y;
reg signed [29:0] pair_limitcsr1_limit_max = 30'sd0;
reg signed [29:0] pair_limitcsr1_limit_min = 30'sd0;
reg pair_limitcsr1_limit_railed;
wire signed [28:0] pair_old1;
wire signed [28:0] pair_new1;
wire signed [28:0] pair_extended5;
wire signed [28:0] pair_extended6;
wire signed [28:0] pair_extended7;
wire signed [28:0] pair_extended8;
wire signed [28:0] pair_extended9;
wire [28:0] pair14;
wire [28:0] pair15;
wire [28:0] pair16;
wire [28:0] pair17;
wire [28:0] pair18;
wire [28:0] pair19;
reg signed [24:0] pair_limitcsr2_limitcsr2_y = 25'sd0;
reg pair_limitcsr2_limitcsr2_error = 1'd0;
wire pair_limitcsr2_update_en;
reg signed [29:0] pair_limitcsr2_x = 30'sd0;
reg [24:0] pair_limitcsr2_min_storage = 25'd16777216;
reg [24:0] pair_limitcsr2_max_storage = 25'd16777215;
wire signed [29:0] pair_limitcsr2_limit_x;
reg signed [29:0] pair_limitcsr2_limit_y;
reg signed [29:0] pair_limitcsr2_limit_max = 30'sd0;
reg signed [29:0] pair_limitcsr2_limit_min = 30'sd0;
reg pair_limitcsr2_limit_railed;
reg signed [24:0] pair_limitcsr3_limitcsr3_y = 25'sd0;
reg pair_limitcsr3_limitcsr3_error = 1'd0;
wire pair_limitcsr3_update_en;
reg signed [29:0] pair_limitcsr3_x = 30'sd0;
reg [24:0] pair_limitcsr3_min_storage = 25'd16777216;
reg [24:0] pair_limitcsr3_max_storage = 25'd16777215;
wire signed [29:0] pair_limitcsr3_limit_x;
reg signed [29:0] pair_limitcsr3_limit_y;
reg signed [29:0] pair_limitcsr3_limit_max = 30'sd0;
reg signed [29:0] pair_limitcsr3_limit_min = 30'sd0;
reg pair_limitcsr3_limit_railed;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign pair_bus_adr = csr_adr;
assign pair_bus_we = csr_we;
assign pair_bus_dat_w = csr_dat_w;
assign pair_old0 = ((((((pair_csrstorage0_storage == 1'd0) ? pid : $signed({1'd0, 1'd0})) + ((pair_csrstorage1_storage == 1'd0) ? mod_data : $signed({1'd0, 1'd0}))) + ((pair_csrstorage2_storage == 1'd0) ? sweep_data : $signed({1'd0, 1'd0}))) + ((pair_csrstorage2_storage == 1'd0) ? pair_offset : $signed({1'd0, 1'd0}))) + ((pair_csrstorage3_storage == 1'd0) ? slow_data : $signed({1'd0, 1'd0})));
assign pair_extended0 = ((pair_csrstorage0_storage == 1'd0) ? pid : $signed({1'd0, 1'd0}));
assign pair_extended1 = ((pair_csrstorage1_storage == 1'd0) ? mod_data : $signed({1'd0, 1'd0}));
assign pair_extended2 = ((pair_csrstorage2_storage == 1'd0) ? sweep_data : $signed({1'd0, 1'd0}));
assign pair_extended3 = ((pair_csrstorage2_storage == 1'd0) ? pair_offset : $signed({1'd0, 1'd0}));
assign pair_extended4 = ((pair_csrstorage3_storage == 1'd0) ? slow_data : $signed({1'd0, 1'd0}));
assign pair8 = ((pair_extended0 ^ pair_extended1) ^ pair_extended2);
assign pair9 = ((((pair_extended0 & pair_extended1) | (pair_extended0 & pair_extended2)) | (pair_extended1 & pair_extended2)) <<< 1'd1);
assign pair10 = ((pair_extended3 ^ pair_extended4) ^ $signed({1'd0, pair8}));
assign pair11 = ((((pair_extended3 & pair_extended4) | (pair_extended3 & $signed({1'd0, pair8}))) | (pair_extended4 & $signed({1'd0, pair8}))) <<< 1'd1);
assign pair12 = ((pair9 ^ pair10) ^ pair11);
assign pair13 = ((((pair9 & pair10) | (pair9 & pair11)) | (pair10 & pair11)) <<< 1'd1);
assign pair_new0 = (pair12 + pair13);
assign pair_limitcsr0_update_en = ce;
assign pair_limitcsr1_update_en = ce;
assign old_word0 = pair_old0;
assign new_word0 = pair_new0;
assign old_x0 = pair_limitcsr0_x;
assign new_x0 = pair_limitcsr1_x;
assign old_y0 = pair_limitcsr0_limitcsr0_y;
assign new_y0 = pair_limitcsr1_limitcsr1_y;
assign old_error0 = pair_limitcsr0_limitcsr0_error;
assign new_error0 = pair_limitcsr1_limitcsr1_error;
assign pair_old1 = ((((((pair_csrstorage0_storage == 1'd1) ? pid : $signed({1'd0, 1'd0})) + ((pair_csrstorage1_storage == 1'd1) ? mod_data : $signed({1'd0, 1'd0}))) + ((pair_csrstorage2_storage == 1'd1) ? sweep_data : $signed({1'd0, 1'd0}))) + ((pair_csrstorage2_storage == 1'd1) ? pair_offset : $signed({1'd0, 1'd0}))) + ((pair_csrstorage3_storage == 1'd1) ? slow_data : $signed({1'd0, 1'd0})));
assign pair_extended5 = ((pair_csrstorage0_storage == 1'd1) ? pid : $signed({1'd0, 1'd0}));
assign pair_extended6 = ((pair_csrstorage1_storage == 1'd1) ? mod_data : $signed({1'd0, 1'd0}));
assign pair_extended7 = ((pair_csrstorage2_storage == 1'd1) ? sweep_data : $signed({1'd0, 1'd0}));
assign pair_extended8 = ((pair_csrstorage2_storage == 1'd1) ? pair_offset : $signed({1'd0, 1'd0}));
assign pair_extended9 = ((pair_csrstorage3_storage == 1'd1) ? slow_data : $signed({1'd0, 1'd0}));
assign pair14 = ((pair_extended5 ^ pair_extended6) ^ pair_extended7);
assign pair15 = ((((pair_extended5 & pair_extended6) | (pair_extended5 & pair_extended7)) | (pair_extended6 & pair_extended7)) <<< 1'd1);
assign pair16 = ((pair_extended8 ^ pair_extended9) ^ $signed({1'd0, pair14}));
assign pair17 = ((((pair_extended8 & pair_extended9) | (pair_extended8 & $signed({1'd0, pair14}))) | (pair_extended9 & $signed({1'd0, pair14}))) <<< 1'd1);
assign pair18 = ((pair15 ^ pair16) ^ pair17);
assign pair19 = ((((pair15 & pair16) | (pair15 & pair17)) | (pair16 & pair17)) <<< 1'd1);
assign pair_new1 = (pair18 + pair19);
assign pair_limitcsr2_update_en = ce;
assign pair_limitcsr3_update_en = ce;
assign old_word1 = pair_old1;
assign new_word1 = pair_new1;
assign old_x1 = pair_limitcsr2_x;
assign new_x1 = pair_limitcsr3_x;
assign old_y1 = pair_limitcsr2_limitcsr2_y;
assign new_y1 = pair_limitcsr3_limitcsr3_y;
assign old_error1 = pair_limitcsr2_limitcsr2_error;
assign new_error1 = pair_limitcsr3_limitcsr3_error;
assign cfg = pair_csrstorage4_storage;
assign csr_read = pair_bus_dat_r;
assign pair_sel = (pair_bus_adr[13:9] == 1'd0);
assign pair_control0_r = pair_bus_dat_w[0];
assign pair_control0_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[2:0] == 1'd0));
assign pair_mod0_r = pair_bus_dat_w[0];
assign pair_mod0_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[2:0] == 1'd1));
assign pair_sweep0_r = pair_bus_dat_w[1:0];
assign pair_sweep0_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[2:0] == 2'd2));
assign pair_slow0_r = pair_bus_dat_w[1:0];
assign pair_slow0_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[2:0] == 2'd3));
assign pair_offset3_r = pair_bus_dat_w[0];
assign pair_offset3_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[2:0] == 3'd4));
assign pair_offset2_r = pair_bus_dat_w[7:0];
assign pair_offset2_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[2:0] == 3'd5));
assign pair_offset1_r = pair_bus_dat_w[7:0];
assign pair_offset1_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[2:0] == 3'd6));
assign pair_offset0_r = pair_bus_dat_w[7:0];
assign pair_offset0_re = ((pair_sel & pair_bus_we) & (pair_bus_adr[2:0] == 3'd7));
assign pair_csrstorage0_storage = pair_csrstorage0_storage_full;
assign pair_control0_w = pair_csrstorage0_storage_full;
assign pair_csrstorage1_storage = pair_csrstorage1_storage_full;
assign pair_mod0_w = pair_csrstorage1_storage_full;
assign pair_csrstorage2_storage = pair_csrstorage2_storage_full[1:0];
assign pair_sweep0_w = pair_csrstorage2_storage_full[1:0];
assign pair_csrstorage3_storage = pair_csrstorage3_storage_full[1:0];
assign pair_slow0_w = pair_csrstorage3_storage_full[1:0];
assign pair_csrstorage4_storage = pair_csrstorage4_storage_full[24:0];
assign pair_offset3_w = pair_csrstorage4_storage_full[24];
assign pair_offset2_w = pair_csrstorage4_storage_full[23:16];
assign pair_offset1_w = pair_csrstorage4_storage_full[15:8];
assign pair_offset0_w = pair_csrstorage4_storage_full[7:0];
assign pair_limitcsr0_limit_x = pair_limitcsr0_x;

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	pair_limitcsr0_limit_y <= 30'sd0;
	pair_limitcsr0_limit_railed <= 1'd0;
	if ((pair_limitcsr0_limit_x >= pair_limitcsr0_limit_max)) begin
		pair_limitcsr0_limit_y <= pair_limitcsr0_limit_max;
		pair_limitcsr0_limit_railed <= 1'd1;
	end else begin
		if ((pair_limitcsr0_limit_x <= pair_limitcsr0_limit_min)) begin
			pair_limitcsr0_limit_y <= pair_limitcsr0_limit_min;
			pair_limitcsr0_limit_railed <= 1'd1;
		end else begin
			pair_limitcsr0_limit_y <= pair_limitcsr0_limit_x;
			pair_limitcsr0_limit_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end
assign pair_limitcsr1_limit_x = pair_limitcsr1_x;

// synthesis translate_off
reg dummy_d_1;
// synthesis translate_on
always @(*) begin
	pair_limitcsr1_limit_y <= 30'sd0;
	pair_limitcsr1_limit_railed <= 1'd0;
	if ((pair_limitcsr1_limit_x >= pair_limitcsr1_limit_max)) begin
		pair_limitcsr1_limit_y <= pair_limitcsr1_limit_max;
		pair_limitcsr1_limit_railed <= 1'd1;
	end else begin
		if ((pair_limitcsr1_limit_x <= pair_limitcsr1_limit_min)) begin
			pair_limitcsr1_limit_y <= pair_limitcsr1_limit_min;
			pair_limitcsr1_limit_railed <= 1'd1;
		end else begin
			pair_limitcsr1_limit_y <= pair_limitcsr1_limit_x;
			pair_limitcsr1_limit_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_1 <= dummy_s;
// synthesis translate_on
end
assign pair_limitcsr2_limit_x = pair_limitcsr2_x;

// synthesis translate_off
reg dummy_d_2;
// synthesis translate_on
always @(*) begin
	pair_limitcsr2_limit_y <= 30'sd0;
	pair_limitcsr2_limit_railed <= 1'd0;
	if ((pair_limitcsr2_limit_x >= pair_limitcsr2_limit_max)) begin
		pair_limitcsr2_limit_y <= pair_limitcsr2_limit_max;
		pair_limitcsr2_limit_railed <= 1'd1;
	end else begin
		if ((pair_limitcsr2_limit_x <= pair_limitcsr2_limit_min)) begin
			pair_limitcsr2_limit_y <= pair_limitcsr2_limit_min;
			pair_limitcsr2_limit_railed <= 1'd1;
		end else begin
			pair_limitcsr2_limit_y <= pair_limitcsr2_limit_x;
			pair_limitcsr2_limit_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_2 <= dummy_s;
// synthesis translate_on
end
assign pair_limitcsr3_limit_x = pair_limitcsr3_x;

// synthesis translate_off
reg dummy_d_3;
// synthesis translate_on
always @(*) begin
	pair_limitcsr3_limit_y <= 30'sd0;
	pair_limitcsr3_limit_railed <= 1'd0;
	if ((pair_limitcsr3_limit_x >= pair_limitcsr3_limit_max)) begin
		pair_limitcsr3_limit_y <= pair_limitcsr3_limit_max;
		pair_limitcsr3_limit_railed <= 1'd1;
	end else begin
		if ((pair_limitcsr3_limit_x <= pair_limitcsr3_limit_min)) begin
			pair_limitcsr3_limit_y <= pair_limitcsr3_limit_min;
			pair_limitcsr3_limit_railed <= 1'd1;
		end else begin
			pair_limitcsr3_limit_y <= pair_limitcsr3_limit_x;
			pair_limitcsr3_limit_railed <= 1'd0;
		end
	end
// synthesis translate_off
	dummy_d_3 <= dummy_s;
// synthesis translate_on
end

always @(posedge sys_clk) begin
	pair_offset <= pair_csrstorage4_storage;
	pair_limitcsr0_x <= pair_old0;
	pair_limitcsr1_x <= pair_new0;
	pair_limitcsr2_x <= pair_old1;
	pair_limitcsr3_x <= pair_new1;
	pair_bus_dat_r <= 1'd0;
	if (pair_sel) begin
		case (pair_bus_adr[2:0])
			1'd0: begin
				pair_bus_dat_r <= pair_control0_w;
			end
			1'd1: begin
				pair_bus_dat_r <= pair_mod0_w;
			end
			2'd2: begin
				pair_bus_dat_r <= pair_sweep0_w;
			end
			2'd3: begin
				pair_bus_dat_r <= pair_slow0_w;
			end
			3'd4: begin
				pair_bus_dat_r <= pair_offset3_w;
			end
			3'd5: begin
				pair_bus_dat_r <= pair_offset2_w;
			end
			3'd6: begin
				pair_bus_dat_r <= pair_offset1_w;
			end
			3'd7: begin
				pair_bus_dat_r <= pair_offset0_w;
			end
		endcase
	end
	if (pair_control0_re) begin
		pair_csrstorage0_storage_full <= pair_control0_r;
	end
	pair_csrstorage0_re <= pair_control0_re;
	if (pair_mod0_re) begin
		pair_csrstorage1_storage_full <= pair_mod0_r;
	end
	pair_csrstorage1_re <= pair_mod0_re;
	if (pair_sweep0_re) begin
		pair_csrstorage2_storage_full[1:0] <= pair_sweep0_r;
	end
	pair_csrstorage2_re <= pair_sweep0_re;
	if (pair_slow0_re) begin
		pair_csrstorage3_storage_full[1:0] <= pair_slow0_r;
	end
	pair_csrstorage3_re <= pair_slow0_re;
	if (pair_offset3_re) begin
		pair_csrstorage4_storage_full[24] <= pair_offset3_r;
	end
	if (pair_offset2_re) begin
		pair_csrstorage4_storage_full[23:16] <= pair_offset2_r;
	end
	if (pair_offset1_re) begin
		pair_csrstorage4_storage_full[15:8] <= pair_offset1_r;
	end
	if (pair_offset0_re) begin
		pair_csrstorage4_storage_full[7:0] <= pair_offset0_r;
	end
	pair_csrstorage4_re <= pair_offset0_re;
	if (pair_limitcsr0_update_en) begin
		pair_limitcsr0_limit_min <= {{5{pair_limitcsr0_min_storage[24]}}, pair_limitcsr0_min_storage};
		pair_limitcsr0_limit_max <= {{5{pair_limitcsr0_max_storage[24]}}, pair_limitcsr0_max_storage};
		pair_limitcsr0_limitcsr0_y <= pair_limitcsr0_limit_y;
		pair_limitcsr0_limitcsr0_error <= pair_limitcsr0_limit_railed;
	end
	if (pair_limitcsr1_update_en) begin
		pair_limitcsr1_limit_min <= {{5{pair_limitcsr1_min_storage[24]}}, pair_limitcsr1_min_storage};
		pair_limitcsr1_limit_max <= {{5{pair_limitcsr1_max_storage[24]}}, pair_limitcsr1_max_storage};
		pair_limitcsr1_limitcsr1_y <= pair_limitcsr1_limit_y;
		pair_limitcsr1_limitcsr1_error <= pair_limitcsr1_limit_railed;
	end
	if (pair_limitcsr2_update_en) begin
		pair_limitcsr2_limit_min <= {{5{pair_limitcsr2_min_storage[24]}}, pair_limitcsr2_min_storage};
		pair_limitcsr2_limit_max <= {{5{pair_limitcsr2_max_storage[24]}}, pair_limitcsr2_max_storage};
		pair_limitcsr2_limitcsr2_y <= pair_limitcsr2_limit_y;
		pair_limitcsr2_limitcsr2_error <= pair_limitcsr2_limit_railed;
	end
	if (pair_limitcsr3_update_en) begin
		pair_limitcsr3_limit_min <= {{5{pair_limitcsr3_min_storage[24]}}, pair_limitcsr3_min_storage};
		pair_limitcsr3_limit_max <= {{5{pair_limitcsr3_max_storage[24]}}, pair_limitcsr3_max_storage};
		pair_limitcsr3_limitcsr3_y <= pair_limitcsr3_limit_y;
		pair_limitcsr3_limitcsr3_error <= pair_limitcsr3_limit_railed;
	end
	if (sys_rst) begin
		pair_csrstorage0_storage_full <= 1'd0;
		pair_csrstorage0_re <= 1'd0;
		pair_csrstorage1_storage_full <= 1'd0;
		pair_csrstorage1_re <= 1'd0;
		pair_csrstorage2_storage_full <= 2'd0;
		pair_csrstorage2_re <= 1'd0;
		pair_csrstorage3_storage_full <= 2'd0;
		pair_csrstorage3_re <= 1'd0;
		pair_csrstorage4_storage_full <= 25'd0;
		pair_csrstorage4_re <= 1'd0;
		pair_bus_dat_r <= 8'd0;
		pair_offset <= 25'sd0;
		pair_limitcsr0_limitcsr0_y <= 25'sd0;
		pair_limitcsr0_limitcsr0_error <= 1'd0;
		pair_limitcsr0_x <= 30'sd0;
		pair_limitcsr0_limit_max <= 30'sd0;
		pair_limitcsr0_limit_min <= 30'sd0;
		pair_limitcsr1_limitcsr1_y <= 25'sd0;
		pair_limitcsr1_limitcsr1_error <= 1'd0;
		pair_limitcsr1_x <= 30'sd0;
		pair_limitcsr1_limit_max <= 30'sd0;
		pair_limitcsr1_limit_min <= 30'sd0;
		pair_limitcsr2_limitcsr2_y <= 25'sd0;
		pair_limitcsr2_limitcsr2_error <= 1'd0;
		pair_limitcsr2_x <= 30'sd0;
		pair_limitcsr2_limit_max <= 30'sd0;
		pair_limitcsr2_limit_min <= 30'sd0;
		pair_limitcsr3_limitcsr3_y <= 25'sd0;
		pair_limitcsr3_limitcsr3_error <= 1'd0;
		pair_limitcsr3_x <= 30'sd0;
		pair_limitcsr3_limit_max <= 30'sd0;
		pair_limitcsr3_limit_min <= 30'sd0;
	end
end

endmodule
