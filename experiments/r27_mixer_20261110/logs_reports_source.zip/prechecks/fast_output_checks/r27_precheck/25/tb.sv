`timescale 1ns/1ps
module tb_fast_output;
reg sys_clk=0;always #4 sys_clk=~sys_clk;reg sys_rst=1;
reg ce=1;reg [13:0] csr_adr=0;reg csr_we=0;reg [7:0] csr_dat_w=0;
reg signed [24:0] pid=0;
reg signed [24:0] mod_data=0;
reg signed [24:0] sweep_data=0;
reg signed [24:0] slow_data=0;
wire [28:0] old_word0;
wire [28:0] new_word0;
wire [29:0] old_x0;
wire [29:0] new_x0;
wire [24:0] old_y0;
wire [24:0] new_y0;
wire [0:0] old_error0;
wire [0:0] new_error0;
wire [28:0] old_word1;
wire [28:0] new_word1;
wire [29:0] old_x1;
wire [29:0] new_x1;
wire [24:0] old_y1;
wire [24:0] new_y1;
wire [0:0] old_error1;
wire [0:0] new_error1;
reg [28:0] expected_word0;
reg [28:0] expected_word1;
reg [29:0] expected_x0;
reg [29:0] expected_x1;
reg [24:0] expected_y0;
reg [24:0] expected_y1;
reg [0:0] expected_error0;
reg [0:0] expected_error1;
reg [24:0] expected_cfg;
reg [7:0] expected_read;
wire [24:0] cfg;wire [7:0] csr_read;
integer fd,k,count=0;fast_output_pair dut(.*);
initial begin
fd=$fopen("vectors.txt","r");if(!fd)$fatal(1,"vectors missing");
while(!$feof(fd))begin
@(negedge sys_clk);k=$fscanf(fd,"%h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h\n",sys_rst,pid,mod_data,sweep_data,slow_data,ce,csr_adr,csr_we,csr_dat_w,expected_word0,expected_word1,expected_x0,expected_x1,expected_y0,expected_y1,expected_error0,expected_error1,expected_cfg,expected_read);if(k!=19)$fatal(1,"bad vector");
@(posedge sys_clk);#1;
if(old_word0 !== expected_word0 || new_word0 !== expected_word0) $fatal(1,"FAST_OUTPUT_FAIL W=25 cycle=%0d field=word0 old=%h new=%h expected=%h",count,old_word0,new_word0,expected_word0);
if(old_x0 !== expected_x0 || new_x0 !== expected_x0) $fatal(1,"FAST_OUTPUT_FAIL W=25 cycle=%0d field=x0 old=%h new=%h expected=%h",count,old_x0,new_x0,expected_x0);
if(old_y0 !== expected_y0 || new_y0 !== expected_y0) $fatal(1,"FAST_OUTPUT_FAIL W=25 cycle=%0d field=y0 old=%h new=%h expected=%h",count,old_y0,new_y0,expected_y0);
if(old_error0 !== expected_error0 || new_error0 !== expected_error0) $fatal(1,"FAST_OUTPUT_FAIL W=25 cycle=%0d field=error0 old=%h new=%h expected=%h",count,old_error0,new_error0,expected_error0);
if(old_word1 !== expected_word1 || new_word1 !== expected_word1) $fatal(1,"FAST_OUTPUT_FAIL W=25 cycle=%0d field=word1 old=%h new=%h expected=%h",count,old_word1,new_word1,expected_word1);
if(old_x1 !== expected_x1 || new_x1 !== expected_x1) $fatal(1,"FAST_OUTPUT_FAIL W=25 cycle=%0d field=x1 old=%h new=%h expected=%h",count,old_x1,new_x1,expected_x1);
if(old_y1 !== expected_y1 || new_y1 !== expected_y1) $fatal(1,"FAST_OUTPUT_FAIL W=25 cycle=%0d field=y1 old=%h new=%h expected=%h",count,old_y1,new_y1,expected_y1);
if(old_error1 !== expected_error1 || new_error1 !== expected_error1) $fatal(1,"FAST_OUTPUT_FAIL W=25 cycle=%0d field=error1 old=%h new=%h expected=%h",count,old_error1,new_error1,expected_error1);
if(cfg!==expected_cfg || csr_read!==expected_read)$fatal(1,"CSR_READ_FAIL cycle=%0d",count);
count=count+1;
end
$display("FAST_OUTPUT_FULL_WORD_PASS width=25 cycles=%0d",count);$finish;
end
endmodule
