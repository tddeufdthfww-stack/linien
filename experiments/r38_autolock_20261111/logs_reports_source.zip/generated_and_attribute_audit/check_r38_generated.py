from pathlib import Path
import ast,hashlib,json,re,subprocess
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r38-common-alias-buffer');t=r/'gateware/build/trials/20261111_092433_r38_common_alias_buffer'
old=subprocess.check_output(['git','show','9c5c32a:gateware/logic/autolock_pipeline.py'],cwd=r).decode()
src=(r/'gateware/logic/autolock_pipeline.py').read_text(encoding='utf-8')
def syncs(s):
    nodes=[n for n in ast.walk(ast.parse(s)) if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Attribute) and n.target.attr=='sync']
    return [ast.dump(n) for n in sorted(nodes,key=lambda n:n.lineno)]
a,b=syncs(old),syncs(src);assert a[0]==b[0] and a[-1]==b[-1] and len(b)==2
for rel in ('gateware/logic/pid.py','gateware/logic/pid_pipeline.py','gateware/logic/pid_output_limit.py','gateware/logic/slow_pipeline.py','gateware/logic/feedback_pipeline.py','gateware/logic/iir.py','gateware/logic/iir_registered_c48.py','gateware/logic/chains.py','gateware/linien_module.py','gateware/verilog/bus_clk_bridge.v','gateware/verilog/axi_slave.v','gateware/verilog/red_pitaya_scope.v'):
    orig=subprocess.check_output(['git','show','9c5c32a:'+rel],cwd=r).replace(b'\r\n',b'\n');assert orig==(r/rel).read_bytes().replace(b'\r\n',b'\n'),rel
s=(t/'top.v').read_text();found={}
for slot in ('current','next','zero'):
    for field,width in [('magnitude',28),('negative',29),('positive',1),('wait',14)]:
        pattern=r'reg(?: signed)? '+(r'\['+str(width-1)+r':0\] ' if width>1 else '')+r'(\w*prefetch_'+slot+'_'+field+r'\w*) = '+str(width)+r"'s?d0;"
        matches=re.findall(pattern,s);assert len(matches)==1,(slot,field,matches);found[slot+'_'+field]=matches[0]
choice=re.findall(r"reg \[1:0\] (\w*prefetch_choice\w*) = 2'd0;",s);assert len(choice)==1
assert 'prefetch_next_idx' not in s
base=Path('D:/RP_Dev/linien_trials/20261110-r28-pid-output-bitdecode/gateware/build/trials/20261110_193543_r28_pid_output_bitdecode');assert(t/'top.xdc').read_bytes()==(base/'top.xdc').read_bytes()
ns={};bn={};exec((t/'csrmap.py').read_text(),ns);exec((base/'csrmap.py').read_text(),bn);assert all(ns[k]==bn[k] for k in ('csr','csr_constants','states','signals'))
parent=json.loads((t/'autolock_pipeline_checks/results.json').read_text());assert parent['original_R28_vectors_preserved']==50076 and parent['indices_visited']==32 and parent['prefetch_choice_valid_every_cycle']
leaf=json.loads((t/'instruction_prefetch_checks/results.json').read_text());assert leaf['passed'] and [v['cycles'] for v in leaf['results']]==[63520,63648,63648]
record={'passed':True,'top_SHA256':hashlib.sha256((t/'top.v').read_bytes()).hexdigest(),'generated_prefetch_registers':found,'choice_register':choice[0],'RTL_cohort_bits_old':2304,'RTL_cohort_bits_new_including_choice':218,'original_metadata_and_FSM_sync_AST_unchanged':True,'PID_IIR_Root_GPIO_AXI_CDC_Scope_sources_unchanged':True,'CSR_and_XDC_same_R28':True,'serial_ADC_robust_GPIO_cycles_added':0,'parent_native':parent,'new_native':leaf,'scope':'Actual generated structure + original sync AST + native differential; not mapped/SDF/board signoff.'}
record['attribute_only_proof']=json.loads((h/'r38_attribute_only_preanalysis.json').read_text());assert record['attribute_only_proof']['passed']
original_top=(Path('D:/RP_Dev/linien_trials/20261111-r36-instruction-prefetch/gateware/build/trials/20261111_072735_r36_instruction_prefetch')/'top.v').read_text()
pattern=r'^\(\* dont_touch = "true" \*\) (?=wire signed \[27:0\] \w*paralleltaplimitcsr[01]_common_sum;$)'
normalized,count=re.subn(pattern,'',original_top,flags=re.M)
assert count==4 and normalized==s,(count,'Unexpected HDL change beyond four common aliases')
record['generated_top_identical_except_four_common_alias_DONT_TOUCH_removals']=True
record['limiter_value_and_error_DONT_TOUCH_all_preserved']=True
(h/'r38_generated_structure.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print('R38_GENERATED_COHORT_AND_UNCHANGED_FSM_AST_PASS')
