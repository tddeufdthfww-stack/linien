from pathlib import Path
import ast,hashlib,json,re,subprocess
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r38-common-alias-buffer');rel='gateware/logic/parallel_tap_limit.py'
old=subprocess.check_output(['git','show','52fba6b:'+rel],cwd=r).decode();new=(r/rel).read_text(encoding='utf-8');removed=[]
class StripAliasKeep(ast.NodeTransformer):
    def visit_Expr(self,node):
        c=node.value
        if isinstance(c,ast.Call) and isinstance(c.func,ast.Attribute) and c.func.attr=='add' and len(c.args)==1 and isinstance(c.args[0],ast.Constant) and c.args[0].value=='keep':
            obj=c.func.value
            if isinstance(obj,ast.Attribute) and obj.attr=='attr' and isinstance(obj.value,ast.Name) and obj.value.id=='common_sum':removed.append('common_sum');return None
        return self.generic_visit(node)
a=ast.dump(StripAliasKeep().visit(ast.parse(old)));assert a==ast.dump(ast.parse(new)) and removed==['common_sum']
netlist=h/'r36_mapped/routed_netlist.v';text=netlist.read_text();target='linienmodule_fast_a_paralleltaplimitcsr0_common_sum_inst__10'
match=re.search(r"LUT1 #\(\s*\.INIT\(2'h2\)\)\s*"+target+r'\s*\(\.I0\((.*?)\),\s*\.O\((.*?)\)\);',text,re.S);assert match
for name in ('limiter.y','limiter.railed','neg_value','neg_rail_value'):assert name+".attr.add('keep')" in new
record={'passed':True,'removed_only_attribute':'common_sum.keep','entire_behavior_AST_same_R36':True,'behavior_AST_SHA256':hashlib.sha256(a.encode()).hexdigest(),'value_and_error_keep_all_preserved':True,'actual_R36_LUT1_BUFFER':{'cell':target,'INIT':"2'h2",'input':match[1],'output':match[2],'function':'Y=I0','routed_netlist_SHA256':hashlib.sha256(netlist.read_bytes()).hexdigest()},'cycles_added':0,'R37_value_attribute_removals_carried':False}
(h/'r38_attribute_only_preanalysis.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print('R38_EXACT_ONE_ALIAS_ATTRIBUTE_AND_REAL_IDENTITY_BUFFER_PROOF_PASS')
