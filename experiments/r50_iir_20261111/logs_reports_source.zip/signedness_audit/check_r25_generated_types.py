from pathlib import Path
import hashlib,json,re
h=Path(__file__).parent;t=Path('D:/RP_Dev/linien_trials/20261110-r25-unsigned-preoffset-fix/gateware/build/trials/20261110_163623_r25_real_csr_signed_fix/top.v')
s=t.read_text();rows={}
for c in ('a','b'):
 signed=f'linienmodule_fast_{c}_signed_offset';common=f'linienmodule_fast_{c}_common';csr=f'linienmodule_chain_{c}_offset_storage'
 assert re.search(r'wire signed \[13:0\] '+signed+r';',s)
 assert f'assign {signed} = {csr};' in s
 rhs=re.search(common+r' <= (.*);',s)[1]
 assert signed in rhs and csr not in rhs and "1'd0" not in rhs,rhs
 rows[c]={'signed_wire':signed,'CSR_alias':csr,'registered_common_rhs':rhs,'passed':True}
(h/'r25_generated_types.json').write_bytes(json.dumps({'passed':True,'top_sha256':hashlib.sha256(t.read_bytes()).hexdigest(),'channels':rows},indent=2).encode());print('R25_ACTUAL_ROOT_SIGNED_PREOFFSET_PASS')
