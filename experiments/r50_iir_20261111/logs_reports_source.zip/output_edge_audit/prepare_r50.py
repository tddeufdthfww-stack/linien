from pathlib import Path
import hashlib,json,subprocess
h=Path(__file__).parent
base=Path('D:/RP_Dev/linien_trials/20261111-r48-routed-pin-refine')
small=Path('D:/RP_Dev/linien_trials/20261111-r45-iir-output-edge')
root=Path('D:/RP_Dev/linien_trials/20261111-r50-iir-output-edge')
m=json.loads((base/'gateware/build/trials/20261111_130524_r48_compatible_postroute_v3/manifest.json').read_text())
for n,d in m['source_hashes'].items():
 if n.startswith(('gateware/','tools/')) and not n.startswith(('gateware/build/','gateware/ps_project/')):
  b=(base/n).read_bytes();assert hashlib.sha256(b).hexdigest()==d,n;(root/n).write_bytes(b)
assert (small/'gateware/tests/timing/reference/r44_iir_registered_c48.py').read_text(encoding='utf-8')==(base/'gateware/logic/iir.py').read_text(encoding='utf-8')
proof='''# R50：零新增采样周期 IIR 输出边沿重定位整机验证

输入 RTL 为 R46 827dfec（经 R48 b0824e3/76dd452 保存），保留 Scope 缓存、源地址预译码与负阈值折叠；不继承 R47/R48 DCP 布局，重新综合、布局和 route。对照 R46 默认 route=-0.539/-18.344ns；最佳物理 R48=-0.179/-4.904ns，最终 STA 均 FAIL。R45 d0b8e2f 只有小模块原生验证，不当成整机通过。

1. 仅 IIR pipelined+registered_c48 模式改变：把原末级组合 split_c48_mac 后的 y 输出 FF 边沿移入现有 registered_c48_mac；原 50 位精确乘加、25 位系数、移位截断、阶数、逐拍吞吐保持，非目标模式不变。
2. 修改前数学依据：F 为旧末级有限50位 MAC，V/T 为原溢出判据与截断。旧 O'=V(F)?T(F):O；B'=clear?0:(!hold?O':B)；E'=!V(F)。新 M'=F，Op'=O，Bp'=B，Cp/Hp'=clear/hold；组合 O=V(M)?T(M):Op，B=Cp?0:(!Hp?O:Bp)，E=!V(M)。代入逐式相同；保存状态并行而非串联新增周期。全局 reset 的 M/Op/Bp/Cp/Hp 均0，对应 O/B/E=0。未知控制仍用原 If/Elif 优先。
3. 原样 R17 冻结 IIR/50位整数oracle order1/2/5，与 R45 新增的 cfg2/冻结 R44/真实CSR/独立双影子整数oracle/X-Z 各3000，必须重新 PASS；再执行所有14/25 PID、Scope、阈值预取、AXI/CDC/复位/背压旧回归。禁止修改旧断言来通过。
4. 目标新增 ADC→DAC/反馈/CSR 采样周期0，latency CSR 不变；输出/error 从 FF Q 改成 MAC 结果寄存器后组合选择，因此模拟传播/毛刺以及输出到后续消费者的 setup 必须新做 STA，不能用离散周期等价替代物理签核。
5. 新综合、place/phys/route、只读路径/全部 DSP 参数/资源/hold/CDC/DRC/覆盖审计与输入 SHA，分别记录 PASS/FAIL/NOT RUN。PS7/PLL/ADC/DAC/AXI/CDC/CSR/约束不改，不降低精度/阶数/吞吐，不加时序例外；失败保留源码/日志不合并保护基线，不上板。
'''
(root/'docs/R50_PLAN.md').write_bytes(proof.encode())
for n in ('gateware/logic/iir.py','tools/check_iir_output_edge.py','gateware/tests/timing/reference/r44_iir_registered_c48.py'):
 (root/n).parent.mkdir(parents=True,exist_ok=True);(root/n).write_bytes((small/n).read_bytes())
p=root/'tools/run_gateware_trial.py';s=p.read_text(encoding='utf-8');needle="        if 'functional' in stages:\n";assert s.count(needle)==1
s=s.replace(needle,needle+"            execute([sys.executable, ROOT / 'tools/check_iir_output_edge.py', '--out', out / 'iir_output_edge_checks'],\n                    ROOT, out, 'iir_output_edge', env, 'IIR_OUTPUT_EDGE_CONFIG2_SUITE_PASS')\n")
p.write_bytes(s.encode())
marker=(root/'tools/check_iir_output_edge.py').read_text(encoding='utf-8');assert 'IIR_OUTPUT_EDGE_CONFIG2_SUITE_PASS' in marker
allowed={'gateware/logic/iir.py','tools/run_gateware_trial.py'}
audit={n:hashlib.sha256((root/n).read_bytes()).hexdigest()==d for n,d in m['source_hashes'].items() if n.startswith(('gateware/','tools/')) and not n.startswith(('gateware/build/','gateware/ps_project/')) and n not in allowed}
assert all(audit.values())
rec={'passed':True,'iir_candidate_exact_R45_SHA':hashlib.sha256((root/'gateware/logic/iir.py').read_bytes()).hexdigest(),'frozen_reference_equals_original_R48_IIR_text':True,'all_other_existing_hardware_tests_raw_identical':audit,'test_unchanged_from_R45':True,'new_serial_sample_cycles_target':0,'new_whole_root_functional_synth_route':'NOT_RUN','source_parent':'R46_via_R48','physical_R47_R48_not_inherited':True}
(h/'r50_source_mathematical_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
print('R50_SOURCE_AND_MATHEMATICAL_PREANALYSIS_PASS')
