from pathlib import Path
import collections,hashlib,json,re
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r50-iir-output-edge');t=r/'gateware/build/trials/20261111_132300_r50_iir_output_edge'
old=Path('D:/RP_Dev/linien_trials/20261111-r46-prefetch-negative-fold/gateware/build/trials/20261111_121804_r46_prefetch_negative_fold')
m=json.loads((t/'manifest.json').read_text());assert m['functional']=='PASS' and m['synthesis']=='COMPLETE' and m['route']=='COMPLETE' and not m['source_changes_during_run']
for n in ('top.xdc','csrmap.py'):assert (t/n).read_bytes()==(old/n).read_bytes(),n
edge=json.loads((t/'iir_output_edge_checks/results.json').read_text());assert edge['passed'] and edge['config_delay']==2 and edge['unknown_cycles_each']==3000 and [v['order'] for v in edge['results']]==[1,2,5]
native=json.loads((t/'c48_filter_checks/results.json').read_text());assert native['passed']
same=json.loads((h/'r50_unmodified_modes_generated_audit.json').read_text());assert same['passed'] and same['case_count']==30
def parse(p):
 return [dict(s.split('=',1) for s in b.splitlines() if '=' in s) for b in p.read_text().split('CELL_BEGIN')[1:]]
def matrix(rows):return dict(collections.Counter('A'+d['AREG']+'_B'+d['BREG']+'_M'+d['MREG']+'_P'+d['PREG'] for d in rows))
a=parse(h/'r48_mapped/all_dsp.txt');b=parse(h/'r50_mapped/all_dsp.txt')
metrics=json.loads((h/'r50_mapped/metrics.json').read_text());assert len(b)==metrics['resources']['dsp']
for key in ('all_iir_outgoing','all_iir_incoming','all_iir_PREG_outgoing','all_iir_to_external_consumers'):
 assert key in metrics and 'slack' in metrics[key],key
text=(t/'top.v').read_text();histories={}
# Record actual generated names, without assuming Migen backtrace suffixes.
for pat in ('previous_output','previous_feedback','clear_q','hold_q'):
 histories[pat]=re.findall(r'^reg(?: signed)?(?: \[[^\]]+\])? (\w*'+pat+r'\w*)[^;]*;',text,re.M)
rec={'passed':True,'CSR_XDC_exact_R46':True,'all_30_nonretimed_generated_modes_identical':True,'new_cfg2_edge_native':edge,'original_cfg0_filter_native':native,'all_actual_DSP_count_before':len(a),'all_actual_DSP_count_after':len(b),'actual_DSP_register_matrix_before':matrix(a),'actual_DSP_register_matrix_after':matrix(b),'generated_history_name_matches':histories,'generated_top_sha256':hashlib.sha256((t/'top.v').read_bytes()).hexdigest(),'new_serial_sample_cycles':0,'IIR_outgoing_and_external_consumers':{k:metrics[k] for k in metrics if k.startswith('all_iir_')},'scope':'Generated root CSR/XDC and finite native IIR equality, full fresh functional/synth/route. DSP matrix changes intentionally audited, not assumed equal. Settled sample-cycle equivalence does not prove unchanged analog propagation/glitches, fullRoot SDF/formal, physical CDC or board/plant behavior.'}
(h/'r50_generated_mapping_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');print('R50_GENERATED_CSR_XDC_NATIVE_AND_ACTUAL_DSP_MAPPING_AUDIT_PASS',len(b))
