if {[catch {
set_param general.maxThreads 2
open_checkpoint {D:/RP_Dev/linien_trials/20261111-r46-prefetch-negative-fold/gateware/build/trials/20261111_121804_r46_prefetch_negative_fold/routed.dcp}
report_timing_summary -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/input_routed_timing.rpt}
# Explicitly return the in-memory design to post-place state before forcing
# replication; no unsupported post-route fanout_opt call is made.
route_design -unroute
report_route_status -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/unrouted_status.rpt}
proc csr_cells {} {
 return [get_cells -hier -quiet -filter {NAME =~ linienmodule_csr_dat_w_reg* && REF_NAME =~ FD*}]
}
proc csr_table {file} {
 set f [open $file w]
 puts $f "cell	ref	D	C	CE	R	INIT	ASYNC_REG	DONT_TOUCH	Q_net	loads	load_pins"
 foreach c [lsort [csr_cells]] {
  set values [list $c [get_property REF_NAME $c]]
  foreach pin {D C CE R} {lappend values [get_nets -quiet -of_objects [get_pins -quiet -of_objects $c -filter "REF_PIN_NAME == $pin"]]}
  foreach prop {INIT ASYNC_REG DONT_TOUCH} {lappend values [get_property $prop $c]}
  set qn [get_nets -quiet -of_objects [get_pins -quiet -of_objects $c -filter {REF_PIN_NAME == Q}]]
  set pins [lsort [get_pins -quiet -of_objects $qn -filter {DIRECTION == IN}]]
  lappend values $qn [llength $pins] [join $pins "|"]
  puts $f [join $values "	"]
 };close $f
}
csr_table {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/csr_replication_before.tsv}
set chosen {}
foreach c [csr_cells] {
 set cp [get_pins -of_objects $c -filter {REF_PIN_NAME == C}]
 if {[get_clocks -of_objects $cp] ne "clk_2"} {error "CSR data is not ADC-clocked: $c"}
 if {[get_property ASYNC_REG $c] eq "1"} {error "Refuse synchronizer replication: $c"}
 set ce [get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == CE}]]
 set cedrv [get_cells -quiet -of_objects [get_pins -quiet -of_objects $ce -filter {DIRECTION == OUT}]]
 if {[get_property REF_NAME $cedrv] ne "VCC"} {error "CSR data CE is not constant1: $c"}
 foreach n [get_nets -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == Q}]] {
  if {[llength [get_pins -of_objects $n -filter {DIRECTION == IN}]] >= 192} {
   set paths [get_timing_paths -quiet -from $c -max_paths 1]
   if {[llength $paths] && [get_property SLACK $paths]<0} {lappend chosen $n}
  }
 }
}
proc ce_table {file} {
 set f [open $file w];puts $f "DSP	clock	BREG	BCASCREG	CE_net	driver	ref	INIT	inputs	loads	slack"
 set selected {}
 foreach c [lsort [get_cells -hier -quiet -filter {REF_NAME == DSP48E1}]] {
  if {![string match *iir* $c] || [get_property BREG $c]!=1} {continue}
  set clk [get_clocks -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == CLK}]]
  if {$clk ne "clk_2" || [get_property BCASCREG $c]!=1} {error "Unexpected IIR input state boundary: $c"}
  set ce [get_pins -of_objects $c -filter {REF_PIN_NAME == CEB2}]
  set seg [get_nets -quiet -segments -of_objects $ce]
  set drv [get_cells -quiet -of_objects [get_pins -quiet -leaf -of_objects $seg -filter {DIRECTION == OUT}]]
  if {[llength $drv]!=1} {error "Nonunique CE driver: $c $drv"}
  set ref [get_property REF_NAME $drv];set init {};set inputs {}
  if {[string match LUT? $ref]} {
   set init [get_property INIT $drv]
   foreach pin [lsort [get_pins -of_objects $drv -filter {DIRECTION == IN}]] {lappend inputs "[get_property REF_PIN_NAME $pin]=[get_nets -quiet -of_objects $pin]"}
  }
  set paths [get_timing_paths -quiet -to $ce -max_paths 1];set slack NO_PATH
  if {[llength $paths]} {set slack [get_property SLACK $paths]}
  puts $f "$c	$clk	[get_property BREG $c]	[get_property BCASCREG $c]	[get_nets -of_objects $ce]	$drv	$ref	$init	[join $inputs |]	[llength [get_pins -quiet -leaf -of_objects $seg -filter {DIRECTION == IN}]]	$slack"
  if {$slack ne "NO_PATH" && $slack<0} {
   if {![string match LUT? $ref]} {error "Refuse non-LUT violating CE driver: $c $drv $ref"}
   if {[get_property DONT_TOUCH $drv] eq "1"} {error "Refuse protected CE driver: $drv"}
   lappend selected [get_nets -of_objects $ce]
  }
 };close $f
 return [lsort -unique $selected]
}
set ce_chosen [ce_table {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/iir_ce_before.tsv}]
if {![llength $ce_chosen]} {error "No actual violating IIR CEB2 LUT driver found"}
puts "IIR_ENABLE_SELECTED $ce_chosen"
puts "NEGATIVE_CSR_DATA_SELECTED $chosen"
set chosen [lsort -unique [concat $chosen $ce_chosen]]
puts "FORCE_REPLICATION_SELECTED $chosen"
write_checkpoint {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/placed_before_replication.dcp}
phys_opt_design -force_replication_on_nets $chosen
write_checkpoint {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/placed_after_replication.dcp}
csr_table {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/csr_replication_after.tsv}
ce_table {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/iir_ce_after_replication.tsv}
phys_opt_design -placement_opt -rewire -critical_cell_opt
route_design -directive Explore -tns_cleanup
report_route_status -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_status.rpt}
report_timing_summary -max_paths 30 -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_timing.rpt}
report_timing -max_paths 100 -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_setup.rpt}
report_timing -delay_type min -max_paths 30 -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_hold.rpt}
report_utilization -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_utilization.rpt}
check_timing -verbose -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_checks.rpt}
report_cdc -details -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_cdc.rpt}
report_drc -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_drc.rpt}
report_clock_interaction -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_clocks.rpt}
report_exceptions -file {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed_exceptions.rpt}
csr_table {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/csr_replication_routed.tsv}
ce_table {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/iir_ce_routed.tsv}
write_checkpoint {D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement/gateware/build/trials/20261111_124333_r47_iir_enable_placement/routed.dcp}
puts POSTROUTE_TRIAL_COMPLETE

} msg opts]} {puts stderr "ERROR: $msg";puts stderr [dict get $opts -errorinfo];exit 3}
exit 0
