set_param general.maxThreads 2
set dcp [lindex $argv 0]
set output [lindex $argv 1]
open_checkpoint $dcp
set f [open $output w]
puts $f "DSP\tclock\tBREG\tBCASCREG\tCEB2_net\tCE_driver\tdriver_ref\tdriver_INIT\tDONT_TOUCH\tfull_leaf_loads\tslack\tsource\tdestination"
foreach c [lsort [get_cells -hier -quiet -filter {REF_NAME == DSP48E1}]] {
 if {![string match *iir* $c] || [get_property BREG $c]!=1} {continue}
 set cep [get_pins -of_objects $c -filter {REF_PIN_NAME == CEB2}]
 set nets [get_nets -quiet -segments -of_objects $cep]
 set drivers [get_cells -quiet -of_objects [get_pins -quiet -leaf -of_objects $nets -filter {DIRECTION == OUT}]]
 set refs {};set inits {};set dont {}
 foreach drv $drivers {
  lappend refs [get_property REF_NAME $drv]
  lappend inits [get_property -quiet INIT $drv]
  lappend dont [get_property DONT_TOUCH $drv]
 }
 set paths [get_timing_paths -quiet -to $cep -max_paths 1]
 set slack NO_PATH;set start {};set end {}
 if {[llength $paths]} {
  set slack [get_property SLACK $paths];set start [get_property STARTPOINT_PIN $paths];set end [get_property ENDPOINT_PIN $paths]
 }
 puts $f "$c\t[get_clocks -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == CLK}]]\t[get_property BREG $c]\t[get_property BCASCREG $c]\t[get_nets -of_objects $cep]\t$drivers\t$refs\t$inits\t$dont\t[llength [get_pins -quiet -leaf -of_objects $nets -filter {DIRECTION == IN}]]\t$slack\t$start\t$end"
}
close $f
puts IIR_ENABLE_DRIVER_AUDIT_COMPLETE
exit 0
