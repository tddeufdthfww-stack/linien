from pathlib import Path
import csv,json,re
h=Path(__file__).parent;r=Path('D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement');t=r/'gateware/build/trials/20261111_124333_r47_iir_enable_placement'
def rows(name):return {v['DSP']:v for v in csv.DictReader((t/name).open(),delimiter='\t')}
def truth(v):
 pins={int(k[1:]):n for k,n in (q.split('=',1) for q in v['inputs'].split('|'))}
 names=sorted(set(pins.values()));init=int(re.search(r"'h([0-9a-fA-F_]+)",v['INIT'])[1].replace('_',''),16)
 table=[]
 for case in range(1<<len(names)):
  value={n:(case>>i)&1 for i,n in enumerate(names)}
  address=sum(value[n]<<pin for pin,n in pins.items());table.append((init>>address)&1)
 return names,table
a=rows('iir_ce_before.tsv');b=rows('iir_ce_after_replication.tsv');assert a.keys()==b.keys() and len(a)==18
diff={k:{'before':a[k],'after':b[k]} for k in a if truth(a[k])!=truth(b[k])}
result={'direct_LUT_function_match_all':not diff,'DSP_CEB2_count':len(a),'direct_function_differences_needing_cone_audit':diff,'selection_phase':'POST_UNROUTE_ESTIMATED_TIMING_NOT_ROUTED_SLACK','functional':'REUSED_R46_NOT_RERUN','new_serial_cycles':0,'scope':'Direct driver LUT truth tables modulo input permutation; differing upstream clone net names need separate recursive cone proof, not automatically FAIL or PASS.'}
(h/'r47_direct_ce_function_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print('R47_DIRECT_CE_FUNCTION_AUDIT',not diff,'differences',len(diff))
for k,v in diff.items():print(k,'before=',v['before']['inputs'],'after=',v['after']['inputs'])
