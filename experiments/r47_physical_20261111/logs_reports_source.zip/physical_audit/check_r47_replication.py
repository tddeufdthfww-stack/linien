from pathlib import Path
import collections,csv,hashlib,json
h=Path(__file__).parent
r=Path('D:/RP_Dev/linien_trials/20261111-r47-iir-enable-placement')
trial=r/'gateware/build/trials/20261111_124333_r47_iir_enable_placement'
m=json.loads((trial/'manifest.json').read_text())
assert m['functional']=='REUSED_R46_EXACT_INPUTS_NOT_RERUN' and m['route']=='COMPLETE' and m['input_r46_dcp_unchanged'] and not m['source_changes_during_run'] and all(m['r46_code_and_test_hash_matches'].values())
def rows(s):return list(csv.DictReader((trial/s).open(),delimiter='\t'))
a=rows('csr_replication_before.tsv');b=rows('csr_replication_after.tsv');c=rows('csr_replication_routed.tsv')
keys=('ref','D','C','CE','R','INIT','ASYNC_REG','DONT_TOUCH')
def group(v):
 d={}
 for row in v:
  k=tuple(row[n] for n in keys)
  assert row['ASYNC_REG']!='1',row
  loads=row['load_pins'].split('|') if row['load_pins'] else []
  assert len(loads)==int(row['loads']) and len(set(loads))==len(loads)
  for pin in loads:
   assert pin not in d.get(k,set()),pin
  d.setdefault(k,set()).update(loads)
 return d
assert group(a)==group(b),'Copy changes state inputs or load set'
assert len(b)>=len(a),'CSR driver removed unexpectedly'
ce=json.loads((h/'r47_direct_ce_function_audit.json').read_text());assert ce['direct_LUT_function_match_all'] and ce['DSP_CEB2_count']==18
def dsp(p):
 d={}
 for block in p.read_text().split('CELL_BEGIN')[1:]:
  v=dict(s.split('=',1) for s in block.splitlines() if '=' in s)
  d[v['NAME']]={k:x for k,x in v.items() if k not in ('LOC','BEL')}
 return d
da=dsp(h/'r46_mapped/all_dsp.txt');db=dsp(h/'r47_mapped/all_dsp.txt');assert len(da)==len(db)==94 and da==db
old=Path(m['input_r46_trial'])
for n in ('top.v','top.xdc','csrmap.py'):assert (trial/n).read_bytes()==(old/n).read_bytes(),n
rec={'passed':True,'FF_before':len(a),'FF_after_replication':len(b),'FF_after_route':len(c),'max_Q_loads_before':max(int(x['loads']) for x in a),'max_Q_loads_after_replication':max(int(x['loads']) for x in b),'max_Q_loads_after_route':max(int(x['loads']) for x in c),'same_D_C_CE_R_INIT_ASYNC_DONT_and_aggregated_loads':True,'all_94_DSP_operating_register_properties_identical_ignoring_LOC_BEL':True,'input_dcp_unchanged':m['input_r46_dcp_unchanged'],'raw_R46_hardware_and_tests_identical':all(m['r46_code_and_test_hash_matches'].values()),'new_serial_cycles':0,'RTL_generated_top_CSR_XDC_same_bytes_R46':True,'full_RTL_regression':'REUSED_R46_NOT_RERUN','synthesis':'REUSED_R46_NOT_RERUN','full_root_postroute_SDF_formal':'NOT_RUN','physical_CDC_safety':'NOT_PROVEN','direct_18_DSP_CEB2_LUT_truth_tables_identical_after_force':ce['direct_LUT_function_match_all'],'selection_phase':ce['selection_phase'],'CSR_data_were_not_selected':len(a)==len(b)}
(h/'r47_physical_register_audit.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
print(json.dumps(rec,indent=2))
